{
			"id":"coinxt-1",
			"name":"coinxt",
			"display name":"CoinXT script layer",
			"library":"coinxt",
			"type":"library",
			"display syntax":[
				"CoinXT script layer"
			],
			"associations":["coinxt"],
			"description":"The script half of CoinXT: hex, Base58Check, bech32 and SegWit addresses,\nBitcoin and Ethereum addresses, WIF keys, RLP, BIP-39 mnemonics, BIP-32 HD\nderivation, the BIP-341 Taproot address path, and Bitcoin and Ethereum\ntransaction building. It is pure script over the CoinXT extension, which\nsupplies every hash and curve operation (start with <cxCheckABI>); this\nlayer only moves bytes and checks checksums.\n\nIt is a separate file from the extension, so it must be in the message\npath before its handlers resolve, for example with\nstart using stack \"coinxt\". If the hashes work but every handler here is\n\"handler not found\", the extension loaded and this script did not.\n\nEvery decoder verifies its checksum and throws an error beginning\n\"CoinXT:\" and naming the handler rather than returning a plausible wrong\nanswer. The transaction builders produce the digest; your app signs it\nwith cxSign, cxSignRecoverable or cxSchnorrSign after showing the user\nwhat it means. Handlers that read comma lists save and restore\nthe itemDelimiter, so your setting does not affect them."
		},{
			"id":"coinxt-2",
			"name":"cxeth1559sighash",
			"display name":"cxEth1559Sighash",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEth1559Sighash(<pChainId>,<pNonce>,<pMaxPriorityHex>,<pMaxFeeHex>,<pGas>,<pToHex>,<pValueHex>,<pDataHex>)"
			],
			"display syntax":[
				"cxEth1559Sighash(<i>pChainId</i>,<i>pNonce</i>,<i>pMaxPriorityHex</i>,<i>pMaxFeeHex</i>,<i>pGas</i>,<i>pToHex</i>,<i>pValueHex</i>,<i>pDataHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The signing digest for an EIP-1559 (type 2) Ethereum transaction.",
			"parameters":[{
				"name":"pChainId",
				"type":"",
				"refparam":"false",
				"description":"The chain id, in digits (1 for Ethereum mainnet)."
			},{
				"name":"pNonce",
				"type":"",
				"refparam":"false",
				"description":"The account nonce, in digits."
			},{
				"name":"pMaxPriorityHex",
				"type":"",
				"refparam":"false",
				"description":"The max priority fee per gas in wei, as big-endian hex."
			},{
				"name":"pMaxFeeHex",
				"type":"",
				"refparam":"false",
				"description":"The max fee per gas in wei, as big-endian hex."
			},{
				"name":"pGas",
				"type":"",
				"refparam":"false",
				"description":"The gas limit, in digits."
			},{
				"name":"pToHex",
				"type":"",
				"refparam":"false",
				"description":"The 20-byte recipient as hex; empty for a contract creation."
			},{
				"name":"pValueHex",
				"type":"",
				"refparam":"false",
				"description":"The value in wei, as big-endian hex."
			},{
				"name":"pDataHex",
				"type":"",
				"refparam":"false",
				"description":"The call data as hex; empty for none."
			}],
			"examples":[{
				"script":"put cxEth1559Sighash(1, 0, \"3b9aca00\", \"04a817c800\", 21000, tToHex, \"0de0b6b3a7640000\", \"\") into tDigest\nput cxSignRecoverable(tSeckey, tDigest) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte Keccak-256 digest to sign with cxSignRecoverable."
			}],
			"description":"The access list is always empty in this build. Wei-scale amounts cross as big-endian hex because they exceed exact\nintegers; the counters are written in digits, at most 2^53. Pass the\nsignature to <cxEth1559Encode> with the same fields. This builds the\ndigest; your app signs it after showing the user what the transaction\ndoes.",
			"references":{
				"handler":["cxEth1559Encode","cxSignRecoverable","cxEthLegacySighash"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-3",
			"name":"cxbtctxencode",
			"display name":"cxBtcTxEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcTxEncode(<pVersion>,<pOutpoints>,<pScriptSigs>,<pSequences>,<pWitnesses>,<pOutputs>,<pLocktime>)"
			],
			"display syntax":[
				"cxBtcTxEncode(<i>pVersion</i>,<i>pOutpoints</i>,<i>pScriptSigs</i>,<i>pSequences</i>,<i>pWitnesses</i>,<i>pOutputs</i>,<i>pLocktime</i>)"
			],
			"associations":["coinxt"],
			"summary":"Serialize a full Bitcoin transaction.",
			"parameters":[{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The transaction version, in digits."
			},{
				"name":"pOutpoints",
				"type":"",
				"refparam":"false",
				"description":"A comma list of outpoint hex (from cxBtcOutpoint), one per input."
			},{
				"name":"pScriptSigs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of scriptSig hex, one per input; an empty item for none."
			},{
				"name":"pSequences",
				"type":"",
				"refparam":"false",
				"description":"A comma list of sequence numbers, exactly one per input."
			},{
				"name":"pWitnesses",
				"type":"",
				"refparam":"false",
				"description":"A comma list of witness hex (from cxBtcWitness), one per input; an empty item, or an empty list, for none."
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of serialized-output hex (from cxBtcOutput)."
			},{
				"name":"pLocktime",
				"type":"",
				"refparam":"false",
				"description":"The transaction locktime, in digits."
			}],
			"examples":[{
				"script":"put cxBtcTxEncode(2, tOutpoints, \"\", tSequences, tWitnessHex, tOutputs, 0) into tRawTx\nput cxHexEncode(tRawTx) into field \"Broadcast\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The raw transaction bytes."
			}],
			"description":"When any witness is non-empty, the BIP-141 marker, flag and witness\nsection are written. The scriptSig and witness lists are read by index,\nso a short list means trailing empty entries; only a list longer than\nthe inputs throws. The sequence list must have exactly one entry per\ninput.",
			"references":{
				"handler":["cxBtcTxid","cxBtcWitness","cxBtcOutput","cxBtcSighashSegwit"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-4",
			"name":"cxeth1559encode",
			"display name":"cxEth1559Encode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEth1559Encode(<pChainId>,<pNonce>,<pMaxPriorityHex>,<pMaxFeeHex>,<pGas>,<pToHex>,<pValueHex>,<pDataHex>,<pRecid>,<pRHex>,<pSHex>)"
			],
			"display syntax":[
				"cxEth1559Encode(<i>pChainId</i>,<i>pNonce</i>,<i>pMaxPriorityHex</i>,<i>pMaxFeeHex</i>,<i>pGas</i>,<i>pToHex</i>,<i>pValueHex</i>,<i>pDataHex</i>,<i>pRecid</i>,<i>pRHex</i>,<i>pSHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The signed EIP-1559 (type 2) Ethereum transaction.",
			"parameters":[{
				"name":"pChainId",
				"type":"",
				"refparam":"false",
				"description":"The chain id, in digits."
			},{
				"name":"pNonce",
				"type":"",
				"refparam":"false",
				"description":"The account nonce, in digits."
			},{
				"name":"pMaxPriorityHex",
				"type":"",
				"refparam":"false",
				"description":"The max priority fee per gas in wei, as big-endian hex."
			},{
				"name":"pMaxFeeHex",
				"type":"",
				"refparam":"false",
				"description":"The max fee per gas in wei, as big-endian hex."
			},{
				"name":"pGas",
				"type":"",
				"refparam":"false",
				"description":"The gas limit, in digits."
			},{
				"name":"pToHex",
				"type":"",
				"refparam":"false",
				"description":"The 20-byte recipient as hex; empty for a contract creation."
			},{
				"name":"pValueHex",
				"type":"",
				"refparam":"false",
				"description":"The value in wei, as big-endian hex."
			},{
				"name":"pDataHex",
				"type":"",
				"refparam":"false",
				"description":"The call data as hex; empty for none."
			},{
				"name":"pRecid",
				"type":"",
				"refparam":"false",
				"description":"The y-parity, 0 or 1: byte 65 of the cxSignRecoverable signature."
			},{
				"name":"pRHex",
				"type":"",
				"refparam":"false",
				"description":"r, the first 32 bytes of the signature, as hex."
			},{
				"name":"pSHex",
				"type":"",
				"refparam":"false",
				"description":"s, bytes 33 to 64 of the signature, as hex."
			}],
			"examples":[{
				"script":"put cxEth1559Encode(1, 0, \"3b9aca00\", \"04a817c800\", 21000, tToHex, \"0de0b6b3a7640000\", \"\", byteToNum(byte 65 of tSig), cxHexEncode(byte 1 to 32 of tSig), cxHexEncode(byte 33 to 64 of tSig)) into tTx\nput tTx[\"txhash\"] into field \"TxHash\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"raw\" (the 0x02-prefixed signed transaction as hex) and \"txhash\" (its Keccak-256 hash as hex)."
			}],
			"description":"The y-parity must be 0 or 1; a 2, or a legacy v such as 27, throws.\nWei-scale amounts cross as big-endian hex because they exceed exact\nintegers; the counters are written in digits, at most 2^53. The fields must match those passed to <cxEth1559Sighash>.",
			"references":{
				"handler":["cxEth1559Sighash","cxSignRecoverable","cxEthLegacyEncode"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-5",
			"name":"cxwifdecode",
			"display name":"cxWifDecode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxWifDecode(<pWif>)"
			],
			"display syntax":[
				"cxWifDecode(<i>pWif</i>)"
			],
			"associations":["coinxt"],
			"summary":"Decode a Wallet Import Format (WIF) private key.",
			"parameters":[{
				"name":"pWif",
				"type":"",
				"refparam":"false",
				"description":"The WIF string."
			}],
			"examples":[{
				"script":"put cxWifDecode(field \"ImportKey\") into tKey\nput cxPublicKey(cxHexDecode(tKey[\"seckey\"]), tKey[\"compressed\"]) into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"seckey\" (64 lowercase hex characters), \"network\" (\"mainnet\" or \"testnet\") and \"compressed\" (true or false)."
			}],
			"description":"The key comes back as hex text; run <cxHexDecode> on it before signing.\nKeep the \"compressed\" flag: deriving the other public key form pays a\ndifferent address. Throws on a bad character or checksum, a payload that\nis not 33 or 34 bytes, an unknown version byte, a trailing byte that is\nnot the 0x01 marker, and a key out of range.",
			"references":{
				"handler":["cxWifEncode","cxBase58CheckDecode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-6",
			"name":"cxmnemonictoseed",
			"display name":"cxMnemonicToSeed",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxMnemonicToSeed(<pMnemonic>,<pPassphrase>)"
			],
			"display syntax":[
				"cxMnemonicToSeed(<i>pMnemonic</i>,<i>pPassphrase</i>)"
			],
			"associations":["coinxt"],
			"summary":"The 64-byte BIP-39 seed for a mnemonic and passphrase.",
			"parameters":[{
				"name":"pMnemonic",
				"type":"",
				"refparam":"false",
				"description":"The mnemonic words."
			},{
				"name":"pPassphrase",
				"type":"",
				"refparam":"false",
				"description":"The optional passphrase; empty for none."
			}],
			"examples":[{
				"script":"put cxHdFromSeed(cxMnemonicToSeed(tMnemonic, \"\")) into tMaster"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 64-byte seed."
			}],
			"description":"PBKDF2-HMAC-SHA512 over the normalized mnemonic, salted with \"mnemonic\"\nand the passphrase, 2048 rounds. It does NOT verify the checksum (BIP-39\ndefines a seed for any text), so a typo gives a good seed for the\nwrong wallet: call <cxMnemonicValidate> first. Unicode NFKD is not\napplied, so a non-ASCII passphrase must be normalized by you.\n\nThe seed is secret; clear your variable when you are done with it.",
			"references":{
				"handler":["cxMnemonicValidate","cxHdFromSeed","cxPbkdf2HmacSha512"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-7",
			"name":"cxxpub",
			"display name":"cxXpub",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxXpub(<pNode>)"
			],
			"display syntax":[
				"cxXpub(<i>pNode</i>)"
			],
			"associations":["coinxt"],
			"summary":"An HD node as a mainnet \"xpub...\" string.",
			"parameters":[{
				"name":"pNode",
				"type":"",
				"refparam":"false",
				"description":"The node, as an array; private or watch-only."
			}],
			"examples":[{
				"script":"put cxXpub(cxHdDerivePath(tMaster, \"m/44'/0'/0'\")) into tAccountXpub"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The Base58Check xpub string."
			}],
			"description":"An xpub holds no private key, but it reveals every address the wallet\nwill use on that branch. Mainnet only. A depth above 255 throws.",
			"references":{
				"handler":["cxXprv","cxHdNeuter"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-8",
			"name":"cxrlpdecode",
			"display name":"cxRlpDecode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxRlpDecode(<pData>)"
			],
			"display syntax":[
				"cxRlpDecode(<i>pData</i>)"
			],
			"associations":["coinxt"],
			"summary":"Decode one RLP item from the front of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The RLP bytes."
			}],
			"examples":[{
				"script":"put cxRlpDecode(tEncoded) into tItem\nput cxRlpDecode(tItem[\"payload\"]) into tFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"kind\" (\"bytes\" or \"list\"), \"payload\" (the item's contents; for a list, the concatenated encodings of its elements) and \"rest\" (whatever followed the item)."
			}],
			"description":"Walk a list by decoding its payload in a loop, reading \"rest\" each time.\nEmpty input and truncated items throw, and so do non-canonical forms (a\nsingle byte below 0x80 wrapped in a prefix, a leading zero in a long\nlength, a long form for a short value), because RLP promises one\nencoding per value.",
			"references":{
				"handler":["cxRlpEncodeBytes","cxRlpEncodeList"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-9",
			"name":"cxbtctxid",
			"display name":"cxBtcTxid",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcTxid(<pVersion>,<pOutpoints>,<pScriptSigs>,<pSequences>,<pOutputs>,<pLocktime>)"
			],
			"display syntax":[
				"cxBtcTxid(<i>pVersion</i>,<i>pOutpoints</i>,<i>pScriptSigs</i>,<i>pSequences</i>,<i>pOutputs</i>,<i>pLocktime</i>)"
			],
			"associations":["coinxt"],
			"summary":"A Bitcoin transaction's txid, as display-order hex.",
			"parameters":[{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The transaction version, in digits."
			},{
				"name":"pOutpoints",
				"type":"",
				"refparam":"false",
				"description":"A comma list of outpoint hex, one per input."
			},{
				"name":"pScriptSigs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of scriptSig hex, one per input."
			},{
				"name":"pSequences",
				"type":"",
				"refparam":"false",
				"description":"A comma list of sequence numbers, one per input."
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of serialized-output hex."
			},{
				"name":"pLocktime",
				"type":"",
				"refparam":"false",
				"description":"The transaction locktime, in digits."
			}],
			"examples":[{
				"script":"put cxBtcTxid(2, tOutpoints, \"\", tSequences, tOutputs, 0) into tTxid"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The txid as 64 hex characters."
			}],
			"description":"HASH256 of the serialization without witnesses (BIP-141), byte-reversed\nfor display. It takes the same lists as <cxBtcTxEncode> minus the\nwitnesses, so a SegWit transaction's txid does not depend on its\nsignatures.",
			"references":{
				"handler":["cxBtcTxEncode","cxHash256","cxBtcOutpoint"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-10",
			"name":"cxvarint",
			"display name":"cxVarInt",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxVarInt(<pN>)"
			],
			"display syntax":[
				"cxVarInt(<i>pN</i>)"
			],
			"associations":["coinxt"],
			"summary":"Bitcoin CompactSize (varint) encoding of a count.",
			"parameters":[{
				"name":"pN",
				"type":"",
				"refparam":"false",
				"description":"The count, written in digits, at most 2^53."
			}],
			"examples":[{
				"script":"put cxVarInt(the number of bytes of tScript) & tScript into tPrefixed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"1, 3, 5 or 9 bytes."
			}],
			"description":"The count must be a run of ASCII digits: a minus, an exponent such as\n\"1e3\", a decimal point or an empty value throws, and so does a count\nabove 2^53.",
			"references":{
				"handler":["cxBtcOutput","cxBtcWitness"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-11",
			"name":"cxhdneuter",
			"display name":"cxHdNeuter",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHdNeuter(<pNode>)"
			],
			"display syntax":[
				"cxHdNeuter(<i>pNode</i>)"
			],
			"associations":["coinxt"],
			"summary":"The watch-only form of an HD node: same public key and chain code, no private key.",
			"parameters":[{
				"name":"pNode",
				"type":"",
				"refparam":"false",
				"description":"The node, as an array."
			}],
			"examples":[{
				"script":"put cxXpub(cxHdNeuter(tAccount)) into tXpub"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A copy of the node with an empty \"seckey\"."
			}],
			"description":"A neutered node still derives non-hardened children, and therefore every\nreceive address on that branch: that is what makes an xpub useful, and a\nprivacy risk if it leaks. It cannot derive a hardened child.",
			"references":{
				"handler":["cxXpub","cxHdDeriveChild"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-12",
			"name":"cxxprv",
			"display name":"cxXprv",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxXprv(<pNode>)"
			],
			"display syntax":[
				"cxXprv(<i>pNode</i>)"
			],
			"associations":["coinxt"],
			"summary":"An HD node as a mainnet \"xprv...\" string.",
			"parameters":[{
				"name":"pNode",
				"type":"",
				"refparam":"false",
				"description":"The node, as an array, with its private key."
			}],
			"examples":[{
				"script":"put cxXprv(cxHdDerivePath(tMaster, \"m/44'/0'/0'\")) into tAccountXprv"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The Base58Check xprv string."
			}],
			"description":"Mainnet only: CoinXT does not ship a version prefix it has not pinned to\na vector. A node with no private key, or a depth above 255, throws. The\nresult is a secret; store it as carefully as the seed.",
			"references":{
				"handler":["cxXpub","cxHdFromSeed"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-13",
			"name":"cxsegwitaddressdecode",
			"display name":"cxSegwitAddressDecode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxSegwitAddressDecode(<pHrp>,<pAddress>)"
			],
			"display syntax":[
				"cxSegwitAddressDecode(<i>pHrp</i>,<i>pAddress</i>)"
			],
			"associations":["coinxt"],
			"summary":"Decode a SegWit address, checking it is for the network you expect.",
			"parameters":[{
				"name":"pHrp",
				"type":"",
				"refparam":"false",
				"description":"The expected human-readable part: \"bc\" for mainnet, \"tb\" for testnet."
			},{
				"name":"pAddress",
				"type":"",
				"refparam":"false",
				"description":"The address to decode."
			}],
			"examples":[{
				"script":"put cxSegwitAddressDecode(\"bc\", field \"PayTo\") into tDecoded\nput tDecoded[\"version\"] into tVersion"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"version\" (the witness version) and \"program\" (the witness program bytes)."
			}],
			"description":"Throws on every invalidity BIP-173 and BIP-350 define: a checksum that\ndoes not verify, the wrong encoding for the version (version 0 must be\nbech32, 1 and up bech32m), a program outside 2 to 40 bytes (exactly 20 or\n32 for version 0), non-canonical padding, and an address for a different\nnetwork than pHrp.",
			"references":{
				"handler":["cxSegwitAddressEncode","cxBech32DecodeValues"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-14",
			"name":"cxethaddress",
			"display name":"cxEthAddress",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEthAddress(<pPubkey>)"
			],
			"display syntax":[
				"cxEthAddress(<i>pPubkey</i>)"
			],
			"associations":["coinxt"],
			"summary":"The lowercase Ethereum address (\"0x...\") for a public key.",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"A 33-byte compressed or 65-byte uncompressed public key."
			}],
			"examples":[{
				"script":"put cxEthAddressChecksum(cxEthAddress(cxPublicKey(tSeckey, false))) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address as \"0x\" and 40 lowercase hex characters."
			}],
			"description":"The last 20 bytes of Keccak-256 over the 64 bytes of the uncompressed key\nafter its 0x04 prefix. A compressed key is expanded first. For the\nEIP-55 mixed-case form, pass the result to <cxEthAddressChecksum>.",
			"references":{
				"handler":["cxEthAddressChecksum","cxKeccak256","cxRecover"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-15",
			"name":"cxbase58checkencode",
			"display name":"cxBase58CheckEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBase58CheckEncode(<pPayload>)"
			],
			"display syntax":[
				"cxBase58CheckEncode(<i>pPayload</i>)"
			],
			"associations":["coinxt"],
			"summary":"Base58Check text for a payload.",
			"parameters":[{
				"name":"pPayload",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode, usually a version byte followed by the data."
			}],
			"examples":[{
				"script":"put cxBase58CheckEncode(numToByte(0) & cxHash160(tPubkey)) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The Base58Check string."
			}],
			"description":"Appends the first 4 bytes of <cxHash256> of the payload and encodes the\nwhole in Base58. This is how a legacy address, a WIF key and an xprv are\nframed. Leading zero bytes become leading \"1\" characters, one for one.",
			"references":{
				"handler":["cxBase58CheckDecode","cxBtcAddressP2PKH"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-16",
			"name":"cxtapcontrolblock",
			"display name":"cxTapControlBlock",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxTapControlBlock(<pLeafVersion>,<pParity>,<pInternalKeyHex>,<pPathHex>)"
			],
			"display syntax":[
				"cxTapControlBlock(<i>pLeafVersion</i>,<i>pParity</i>,<i>pInternalKeyHex</i>,<i>pPathHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The control block for a Taproot script-path spend, as hex.",
			"parameters":[{
				"name":"pLeafVersion",
				"type":"",
				"refparam":"false",
				"description":"The leaf version, an even byte value: 192 (0xc0) for tapscript."
			},{
				"name":"pParity",
				"type":"",
				"refparam":"false",
				"description":"0 or 1: the parity cxTaprootTweak reported for the output key."
			},{
				"name":"pInternalKeyHex",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only internal key, as hex."
			},{
				"name":"pPathHex",
				"type":"",
				"refparam":"false",
				"description":"The sibling hashes from the leaf up to the root as a comma list of 64-hex; empty for a one-leaf tree."
			}],
			"examples":[{
				"script":"put cxTaprootTweak(tInternal, cxHexDecode(tRoot)) into tTweak\nput cxTapControlBlock(192, tTweak[\"parity\"], cxHexEncode(tInternal), tSiblingHex) into tControl"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control block as hex: the version and parity byte, the internal key, then the path."
			}],
			"description":"The last element of a script-path witness. Leaf version 0x50 (80) is\nrefused (a witness element starting with 0x50 is read as the annex), as\nare an odd version, a parity other than 0 or 1, a key that is not 32\nbytes, and a path longer than 128 nodes or with an element that is not\n32 bytes.",
			"references":{
				"handler":["cxTapLeafHash","cxTapBranchHash","cxTaprootTweak"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-17",
			"name":"cxmnemonicfromentropy",
			"display name":"cxMnemonicFromEntropy",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxMnemonicFromEntropy(<pEntropy>)"
			],
			"display syntax":[
				"cxMnemonicFromEntropy(<i>pEntropy</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-39 mnemonic for some entropy.",
			"parameters":[{
				"name":"pEntropy",
				"type":"",
				"refparam":"false",
				"description":"16, 20, 24, 28 or 32 random bytes."
			}],
			"examples":[{
				"script":"put cxMnemonicFromEntropy(sxRandomBytes(16)) into tMnemonic"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"12, 15, 18, 21 or 24 English words, separated by single spaces."
			}],
			"description":"CoinXT does not generate the entropy; supply it from a source you trust,\nsuch as SodiumXT's sxRandomBytes. Any other length throws.",
			"references":{
				"handler":["cxMnemonicToEntropy","cxMnemonicToSeed","cxBip39Wordlist"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-18",
			"name":"cxethaddresschecksum",
			"display name":"cxEthAddressChecksum",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEthAddressChecksum(<pAddress>)"
			],
			"display syntax":[
				"cxEthAddressChecksum(<i>pAddress</i>)"
			],
			"associations":["coinxt"],
			"summary":"The EIP-55 mixed-case (checksummed) form of an Ethereum address.",
			"parameters":[{
				"name":"pAddress",
				"type":"",
				"refparam":"false",
				"description":"An address of 40 hex characters, with or without \"0x\", in any casing."
			}],
			"examples":[{
				"script":"put cxEthAddressChecksum(\"0x5aaeb6053f3e94c9b9a09f33669435e7ef1beaed\") into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address as \"0x\" and 40 hex characters in EIP-55 casing."
			}],
			"description":"A letter is upper-cased when the matching nibble of Keccak-256 over the\nlowercase address text is 8 or more. Throws if the address is not 40 hex\ncharacters.",
			"references":{
				"handler":["cxEthAddressIsChecksummed","cxEthAddress"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-19",
			"name":"cxbase58checkdecode",
			"display name":"cxBase58CheckDecode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBase58CheckDecode(<pText>)"
			],
			"display syntax":[
				"cxBase58CheckDecode(<i>pText</i>)"
			],
			"associations":["coinxt"],
			"summary":"The payload of a Base58Check string, with its checksum verified.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The Base58Check string."
			}],
			"examples":[{
				"script":"put cxBase58CheckDecode(\"1LqBGSKuX5yYUonjxT5qGfpUsXKYYWeabA\") into tPayload\nput byteToNum(byte 1 of tPayload) into tVersion"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The payload bytes, without the 4 checksum bytes."
			}],
			"description":"A character outside the Base58 alphabet or a bad checksum throws; it\nnever returns the payload it happened to decode. The alphabet is\ncase-significant and is compared by byte value, whatever\nthe caseSensitive is set to.",
			"references":{
				"handler":["cxBase58CheckEncode","cxWifDecode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-20",
			"name":"cxderencode",
			"display name":"cxDerEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxDerEncode(<pCompactSig>)"
			],
			"display syntax":[
				"cxDerEncode(<i>pCompactSig</i>)"
			],
			"associations":["coinxt"],
			"summary":"A 64-byte compact signature as a DER signature.",
			"parameters":[{
				"name":"pCompactSig",
				"type":"",
				"refparam":"false",
				"description":"The 64-byte signature (r then s), as cxSign returns it."
			}],
			"examples":[{
				"script":"put cxDerEncode(cxSign(tSeckey, tDigest)) & numToByte(1) into tSigWithType"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The DER-encoded signature."
			}],
			"description":"What a Bitcoin scriptSig or witness carries. The SIGHASH type byte is\nyours to append. A signature that is not 64 bytes throws.",
			"references":{
				"handler":["cxSign","cxBtcWitness"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-21",
			"name":"cxrlpencodelist",
			"display name":"cxRlpEncodeList",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxRlpEncodeList(<pEncodedItems>)"
			],
			"display syntax":[
				"cxRlpEncodeList(<i>pEncodedItems</i>)"
			],
			"associations":["coinxt"],
			"summary":"Wrap already-encoded RLP items as an RLP list.",
			"parameters":[{
				"name":"pEncodedItems",
				"type":"",
				"refparam":"false",
				"description":"The concatenated RLP encodings of the list's elements."
			}],
			"examples":[{
				"script":"put cxRlpEncodeList(cxRlpEncodeBytes(tA) & cxRlpEncodeBytes(tB)) into tEncoded"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The RLP encoding of the list."
			}],
			"description":"xTalk has no nested-list literal, so a list is built from pieces: encode\neach element with <cxRlpEncodeBytes> or <cxRlpEncodeList>, concatenate,\nand pass the result here. Empty in gives the empty list.",
			"references":{
				"handler":["cxRlpEncodeBytes","cxRlpDecode"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-22",
			"name":"cxmnemonicvalidate",
			"display name":"cxMnemonicValidate",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxMnemonicValidate(<pMnemonic>)"
			],
			"display syntax":[
				"cxMnemonicValidate(<i>pMnemonic</i>)"
			],
			"associations":["coinxt"],
			"summary":"Whether a mnemonic is well-formed BIP-39 with a correct checksum.",
			"parameters":[{
				"name":"pMnemonic",
				"type":"",
				"refparam":"false",
				"description":"The mnemonic words."
			}],
			"examples":[{
				"script":"if cxMnemonicValidate(field \"Backup\") then put cxMnemonicToSeed(field \"Backup\", \"\") into tSeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Answers false instead of throwing, for a restore screen that asks on\nevery keystroke. Call it on anything a person typed before\n<cxMnemonicToSeed>, which does not check the checksum.",
			"references":{
				"handler":["cxMnemonicToEntropy","cxMnemonicToSeed"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-23",
			"name":"cxbtcsighashtaproot",
			"display name":"cxBtcSighashTaproot",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcSighashTaproot(<pVersion>,<pOutpoints>,<pSequences>,<pAmountsSat>,<pScriptPubkeys>,<pOutputs>,<pIndex>,<pLocktime>,<pSighashType>,<pTapleafHex>)"
			],
			"display syntax":[
				"cxBtcSighashTaproot(<i>pVersion</i>,<i>pOutpoints</i>,<i>pSequences</i>,<i>pAmountsSat</i>,<i>pScriptPubkeys</i>,<i>pOutputs</i>,<i>pIndex</i>,<i>pLocktime</i>,<i>pSighashType</i>,<i>pTapleafHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-341 (Taproot) signature hash to sign for one input.",
			"parameters":[{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The transaction version, in digits."
			},{
				"name":"pOutpoints",
				"type":"",
				"refparam":"false",
				"description":"A comma list of outpoint hex (from cxBtcOutpoint), one per input."
			},{
				"name":"pSequences",
				"type":"",
				"refparam":"false",
				"description":"A comma list of sequence numbers, one per input."
			},{
				"name":"pAmountsSat",
				"type":"",
				"refparam":"false",
				"description":"A comma list of the amounts being spent, in satoshi, one per input."
			},{
				"name":"pScriptPubkeys",
				"type":"",
				"refparam":"false",
				"description":"A comma list of the scriptPubKeys being spent, as hex, one per input."
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of serialized-output hex (from cxBtcOutput)."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the input being signed, in digits."
			},{
				"name":"pLocktime",
				"type":"",
				"refparam":"false",
				"description":"The transaction locktime, in digits."
			},{
				"name":"pSighashType",
				"type":"",
				"refparam":"false",
				"description":"0 (default), 1, 2, 3, 129, 130 or 131 (0x81 to 0x83)."
			},{
				"name":"pTapleafHex",
				"type":"",
				"refparam":"false",
				"description":"Empty for a key-path spend, or the leaf hash from cxTapLeafHash for a script-path spend."
			}],
			"examples":[{
				"script":"put cxBtcSighashTaproot(2, tOutpoints, tSequences, tAmounts, tSpks, tOutputs, 1, 0, 0, empty) into tSighash\nput cxTaprootTweakSeckey(tSeckey, empty) into tSpendKey\nput cxSchnorrSign(tSpendKey, tSighash, empty) into tSignature"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte digest to sign with cxSchnorrSign."
			}],
			"description":"Unlike BIP-143, it commits to every spent output, so the per-input\namount and scriptPubKey lists are required and must be parallel to the\noutpoints. 0x80 alone is not a type and throws, as does SIGHASH_SINGLE\nwith no matching output. The script path covers the common case only:\nleaf version 0, no OP_CODESEPARATOR, and no annex.\n\nThis builds the digest; your app signs it after showing the user what\nthe transaction does.",
			"references":{
				"handler":["cxSchnorrSign","cxTaprootTweakSeckey","cxTapLeafHash","cxBtcTxEncode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-24",
			"name":"cxbech32encodevalues",
			"display name":"cxBech32EncodeValues",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBech32EncodeValues(<pHrp>,<pValues>,<pSpec>)"
			],
			"display syntax":[
				"cxBech32EncodeValues(<i>pHrp</i>,<i>pValues</i>,<i>pSpec</i>)"
			],
			"associations":["coinxt"],
			"summary":"A bech32 or bech32m string from a human-readable part and 5-bit values.",
			"parameters":[{
				"name":"pHrp",
				"type":"",
				"refparam":"false",
				"description":"The human-readable part, lowercase, 1 to 83 printable characters (for example \"bc\")."
			},{
				"name":"pValues",
				"type":"",
				"refparam":"false",
				"description":"The data as a comma-separated list of whole numbers from 0 to 31."
			},{
				"name":"pSpec",
				"type":"",
				"refparam":"false",
				"description":"\"bech32\" or \"bech32m\"."
			}],
			"examples":[{
				"script":"put cxBech32EncodeValues(\"bc\", \"0,14,20,15,7,13,26\", \"bech32\") into tText"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The encoded string, checksum included."
			}],
			"description":"The raw bech32 layer below the SegWit addresses; most callers want\n<cxSegwitAddressEncode> or the address builders. An uppercase\nhuman-readable part is refused (uppercase the finished string instead),\nand so is any value that is not a whole number from 0 to 31.",
			"references":{
				"handler":["cxBech32DecodeValues","cxSegwitAddressEncode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-25",
			"name":"cxbtcaddressp2tr",
			"display name":"cxBtcAddressP2TR",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcAddressP2TR(<pOutputKey>)"
			],
			"display syntax":[
				"cxBtcAddressP2TR(<i>pOutputKey</i>)"
			],
			"associations":["coinxt"],
			"summary":"A Taproot mainnet address (\"bc1p...\") for an already-tweaked output key.",
			"parameters":[{
				"name":"pOutputKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only Taproot OUTPUT key."
			}],
			"examples":[{
				"script":"put cxTaprootTweak(tInternal, empty) into tTweak\nput cxBtcAddressP2TR(tTweak[\"outputKey\"]) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address string."
			}],
			"description":"This handler encodes the key it is given and does NOT tweak it. Handing\nit a raw internal key (for example from <cxXOnlyPubkey>) produces a\nvalid-looking address nobody can spend from. If you hold an internal\nkey, call <cxBtcAddressP2TRFromInternal>; if you are not sure which you\nhold, you hold an internal key. A key that is not 32 bytes throws.",
			"references":{
				"handler":["cxBtcAddressP2TRFromInternal","cxTaprootTweak"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-26",
			"name":"cxsegwitaddressencode",
			"display name":"cxSegwitAddressEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxSegwitAddressEncode(<pHrp>,<pVersion>,<pProgram>)"
			],
			"display syntax":[
				"cxSegwitAddressEncode(<i>pHrp</i>,<i>pVersion</i>,<i>pProgram</i>)"
			],
			"associations":["coinxt"],
			"summary":"A SegWit address from a witness version and program.",
			"parameters":[{
				"name":"pHrp",
				"type":"",
				"refparam":"false",
				"description":"The human-readable part: \"bc\" for mainnet, \"tb\" for testnet."
			},{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The witness version, 0 to 16."
			},{
				"name":"pProgram",
				"type":"",
				"refparam":"false",
				"description":"The witness program bytes, 2 to 40 bytes (exactly 20 or 32 for version 0)."
			}],
			"examples":[{
				"script":"put cxSegwitAddressEncode(\"tb\", 0, cxHash160(tPubkey)) into tTestnetAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address string."
			}],
			"description":"The encoding follows from the version, per BIP-350: version 0 uses\nbech32, versions 1 to 16 use bech32m. A version or program length out of\nrange throws. For mainnet addresses from a key, the address builders\nsuch as <cxBtcAddressP2WPKH> are simpler.",
			"references":{
				"handler":["cxSegwitAddressDecode","cxBtcAddressP2WPKH","cxBech32EncodeValues"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-27",
			"name":"cxbtcaddressp2trfrominternal",
			"display name":"cxBtcAddressP2TRFromInternal",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcAddressP2TRFromInternal(<pInternalKey>,<pMerkleRoot>)"
			],
			"display syntax":[
				"cxBtcAddressP2TRFromInternal(<i>pInternalKey</i>,<i>pMerkleRoot</i>)"
			],
			"associations":["coinxt"],
			"summary":"A Taproot mainnet address (\"bc1p...\") from an internal key, tweak included.",
			"parameters":[{
				"name":"pInternalKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only internal key, for example from cxXOnlyPubkey."
			},{
				"name":"pMerkleRoot",
				"type":"",
				"refparam":"false",
				"description":"Empty for a key-path-only output, or the 32-byte script-tree root."
			}],
			"examples":[{
				"script":"put cxBtcAddressP2TRFromInternal(cxXOnlyPubkey(tSeckey), empty) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address string."
			}],
			"description":"The handler most Taproot callers want: it applies the BIP-341 tweak\n(<cxTaprootTweak>) and encodes the output key. It is a separate handler\nfrom <cxBtcAddressP2TR> because an absent xTalk parameter cannot be told\nfrom an empty one, and the two readings of the same 32 bytes give\ndifferent addresses. An empty root is not 32 zero bytes. To spend, sign\nwith the key from <cxTaprootTweakSeckey> and the same root.",
			"references":{
				"handler":["cxBtcAddressP2TR","cxTaprootTweak","cxTaprootTweakSeckey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-28",
			"name":"cxhash256",
			"display name":"cxHash256",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHash256(<pData>)"
			],
			"display syntax":[
				"cxHash256(<i>pData</i>)"
			],
			"associations":["coinxt"],
			"summary":"SHA-256 of SHA-256 of some bytes (Bitcoin's HASH256).",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash."
			}],
			"examples":[{
				"script":"put cxHash256(tRawTx) into tDigest"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte digest."
			}],
			"description":"The Base58Check checksum and the Bitcoin txid are built from it.",
			"references":{
				"handler":["cxHash160","cxSha256","cxBtcTxid"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-29",
			"name":"cxethaddressischecksummed",
			"display name":"cxEthAddressIsChecksummed",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEthAddressIsChecksummed(<pAddress>)"
			],
			"display syntax":[
				"cxEthAddressIsChecksummed(<i>pAddress</i>)"
			],
			"associations":["coinxt"],
			"summary":"Whether an Ethereum address carries a correct EIP-55 checksum.",
			"parameters":[{
				"name":"pAddress",
				"type":"",
				"refparam":"false",
				"description":"The address to check, with or without \"0x\"."
			}],
			"examples":[{
				"script":"if not cxEthAddressIsChecksummed(field \"PayTo\") then answer \"Checksum missing or wrong.\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"An all-lowercase or all-uppercase address carries no checksum, so it\nanswers false rather than being called valid. A mixed-case address\nanswers true only when its casing matches <cxEthAddressChecksum>\nexactly, compared byte for byte.",
			"references":{
				"handler":["cxEthAddressChecksum"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-30",
			"name":"cxethlegacyencode",
			"display name":"cxEthLegacyEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEthLegacyEncode(<pNonce>,<pGasPriceHex>,<pGas>,<pToHex>,<pValueHex>,<pDataHex>,<pChainId>,<pRecid>,<pRHex>,<pSHex>)"
			],
			"display syntax":[
				"cxEthLegacyEncode(<i>pNonce</i>,<i>pGasPriceHex</i>,<i>pGas</i>,<i>pToHex</i>,<i>pValueHex</i>,<i>pDataHex</i>,<i>pChainId</i>,<i>pRecid</i>,<i>pRHex</i>,<i>pSHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The signed EIP-155 legacy Ethereum transaction.",
			"parameters":[{
				"name":"pNonce",
				"type":"",
				"refparam":"false",
				"description":"The account nonce, in digits."
			},{
				"name":"pGasPriceHex",
				"type":"",
				"refparam":"false",
				"description":"The gas price in wei, as big-endian hex."
			},{
				"name":"pGas",
				"type":"",
				"refparam":"false",
				"description":"The gas limit, in digits."
			},{
				"name":"pToHex",
				"type":"",
				"refparam":"false",
				"description":"The 20-byte recipient as hex; empty for a contract creation."
			},{
				"name":"pValueHex",
				"type":"",
				"refparam":"false",
				"description":"The value in wei, as big-endian hex."
			},{
				"name":"pDataHex",
				"type":"",
				"refparam":"false",
				"description":"The call data as hex; empty for none."
			},{
				"name":"pChainId",
				"type":"",
				"refparam":"false",
				"description":"The chain id, in digits, at most 4503599627370478."
			},{
				"name":"pRecid",
				"type":"",
				"refparam":"false",
				"description":"The recovery id, 0 or 1: byte 65 of the cxSignRecoverable signature."
			},{
				"name":"pRHex",
				"type":"",
				"refparam":"false",
				"description":"r, the first 32 bytes of the signature, as hex."
			},{
				"name":"pSHex",
				"type":"",
				"refparam":"false",
				"description":"s, bytes 33 to 64 of the signature, as hex."
			}],
			"examples":[{
				"script":"put cxEthLegacyEncode(0, \"04a817c800\", 21000, tToHex, \"0de0b6b3a7640000\", \"\", 1, byteToNum(byte 65 of tSig), cxHexEncode(byte 1 to 32 of tSig), cxHexEncode(byte 33 to 64 of tSig)) into tTx\nput tTx[\"raw\"] into field \"Broadcast\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"raw\" (the signed transaction as hex) and \"txhash\" (its Keccak-256 hash as hex)."
			}],
			"description":"v is written as the recovery id plus twice the chain id plus 35. Any\nother recovery id would write another chain's v, so it throws, and so\ndoes a chain id too large for v to stay exact. Wei-scale amounts cross as big-endian hex because they exceed exact\nintegers; the counters are written in digits, at most 2^53. The fields\nmust match those passed to <cxEthLegacySighash>.",
			"references":{
				"handler":["cxEthLegacySighash","cxSignRecoverable","cxEth1559Encode"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-31",
			"name":"cxhash160",
			"display name":"cxHash160",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHash160(<pData>)"
			],
			"display syntax":[
				"cxHash160(<i>pData</i>)"
			],
			"associations":["coinxt"],
			"summary":"RIPEMD-160 of SHA-256 of some bytes (Bitcoin's HASH160).",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, usually a public key."
			}],
			"examples":[{
				"script":"put cxHexEncode(cxHash160(tPubkey)) into tKeyHash"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 20-byte digest."
			}],
			"description":"What P2PKH and P2WPKH addresses commit to. The address builders call it\nfor you.",
			"references":{
				"handler":["cxHash256","cxBtcAddressP2PKH","cxRipemd160"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-32",
			"name":"cxhdderivechild",
			"display name":"cxHdDeriveChild",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHdDeriveChild(<pNode>,<pIndex>)"
			],
			"display syntax":[
				"cxHdDeriveChild(<i>pNode</i>,<i>pIndex</i>)"
			],
			"associations":["coinxt"],
			"summary":"One BIP-32 derivation step from an HD node.",
			"parameters":[{
				"name":"pNode",
				"type":"",
				"refparam":"false",
				"description":"The parent node, as an array."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The full child number, written in digits, from 0 to 4294967295; a hardened child is 2147483648 plus its number."
			}],
			"examples":[{
				"script":"put cxHdDeriveChild(tAccount, 0) into tChain\nput cxHdDeriveChild(tChain, 5) into tNode"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The child node, as an array."
			}],
			"description":"A watch-only node derives only non-hardened children; asking it for a\nhardened one throws. The index must be a run of digits, so \"1e1\", \"3.5\"\nor an empty index throws rather than deriving a different child. In the\nrare case BIP-32 says to skip an index, this throws rather than silently\nreturning another child. Most callers want <cxHdDerivePath>.",
			"references":{
				"handler":["cxHdDerivePath","cxHdNeuter","cxSeckeyTweakAdd"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-33",
			"name":"cxbtcaddressp2pkh",
			"display name":"cxBtcAddressP2PKH",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcAddressP2PKH(<pPubkey>)"
			],
			"display syntax":[
				"cxBtcAddressP2PKH(<i>pPubkey</i>)"
			],
			"associations":["coinxt"],
			"summary":"A legacy mainnet P2PKH address (\"1...\") for a public key.",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"A 33-byte compressed or 65-byte uncompressed public key."
			}],
			"examples":[{
				"script":"put cxBtcAddressP2PKH(cxPublicKey(tSeckey, true)) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address string."
			}],
			"description":"The compressed and uncompressed forms of one key give different\naddresses. A key of the wrong length, or with the wrong prefix byte for\nits length, throws rather than producing an address nobody can spend\nfrom.",
			"references":{
				"handler":["cxBtcAddressP2WPKH","cxHash160","cxPublicKey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-34",
			"name":"cxrlpencodebytes",
			"display name":"cxRlpEncodeBytes",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxRlpEncodeBytes(<pData>)"
			],
			"display syntax":[
				"cxRlpEncodeBytes(<i>pData</i>)"
			],
			"associations":["coinxt"],
			"summary":"Encode one byte string as an RLP item.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode."
			}],
			"examples":[{
				"script":"put cxRlpEncodeBytes(tNonce) & cxRlpEncodeBytes(tGasPrice) into tFields\nput cxRlpEncodeList(tFields) into tEncoded"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The RLP encoding."
			}],
			"description":"A single byte below 0x80 is its own encoding; anything else gets a\nlength prefix. Encode each field, concatenate, and wrap the result with\n<cxRlpEncodeList>.",
			"references":{
				"handler":["cxRlpEncodeList","cxRlpDecode"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"coinxt-35",
			"name":"cxbtcaddressp2wpkh",
			"display name":"cxBtcAddressP2WPKH",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcAddressP2WPKH(<pPubkey>)"
			],
			"display syntax":[
				"cxBtcAddressP2WPKH(<i>pPubkey</i>)"
			],
			"associations":["coinxt"],
			"summary":"A native SegWit v0 mainnet address (\"bc1q...\") for a compressed public key.",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"A 33-byte compressed public key."
			}],
			"examples":[{
				"script":"put cxBtcAddressP2WPKH(cxPublicKey(tSeckey, true)) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address string."
			}],
			"description":"The key must be compressed: a SegWit v0 output built from an\nuncompressed key is unspendable by every modern wallet, so a 65-byte key\nthrows instead of being encoded.",
			"references":{
				"handler":["cxBtcAddressP2PKH","cxSegwitAddressEncode","cxPublicKey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-36",
			"name":"cxmnemonictoentropy",
			"display name":"cxMnemonicToEntropy",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxMnemonicToEntropy(<pMnemonic>)"
			],
			"display syntax":[
				"cxMnemonicToEntropy(<i>pMnemonic</i>)"
			],
			"associations":["coinxt"],
			"summary":"The entropy a BIP-39 mnemonic encodes, with its checksum verified.",
			"parameters":[{
				"name":"pMnemonic",
				"type":"",
				"refparam":"false",
				"description":"The mnemonic words."
			}],
			"examples":[{
				"script":"put cxHexEncode(cxMnemonicToEntropy(tMnemonic)) into tEntropyHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 16 to 32 bytes of entropy."
			}],
			"description":"Whitespace is normalized first (<cxMnemonicNormalize>). Throws on a word\nthat is not in the English list, a word count BIP-39 does not define,\nand a checksum mismatch, so one mistyped word is caught here. For a\nyes-or-no answer, use <cxMnemonicValidate>.",
			"references":{
				"handler":["cxMnemonicFromEntropy","cxMnemonicValidate"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-37",
			"name":"cxmnemonicnormalize",
			"display name":"cxMnemonicNormalize",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxMnemonicNormalize(<pText>)"
			],
			"display syntax":[
				"cxMnemonicNormalize(<i>pText</i>)"
			],
			"associations":["coinxt"],
			"summary":"A mnemonic's canonical whitespace: trimmed, one space between words.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The mnemonic as typed or pasted."
			}],
			"examples":[{
				"script":"put cxMnemonicNormalize(field \"Backup\") into tMnemonic"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The words separated by single spaces, with no leading or trailing whitespace."
			}],
			"description":"BIP-39 derives the seed from the mnemonic text, so a double space or a\ntrailing newline would give a different wallet. <cxMnemonicValidate>,\n<cxMnemonicToEntropy> and <cxMnemonicToSeed> all call it first. Spaces,\ntabs, returns and line feeds count as whitespace.\n\nIt does not apply Unicode NFKD. That changes nothing for the English\nwordlist, but a non-ASCII passphrase is yours to normalize.",
			"references":{
				"handler":["cxMnemonicToSeed","cxMnemonicValidate"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-38",
			"name":"cxwifencode",
			"display name":"cxWifEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxWifEncode(<pSeckeyHex>,<pNetwork>,<pCompressed>)"
			],
			"display syntax":[
				"cxWifEncode(<i>pSeckeyHex</i>,<i>pNetwork</i>,<i>pCompressed</i>)"
			],
			"associations":["coinxt"],
			"summary":"A private key as Wallet Import Format (WIF) text.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"The private key as 64 hex characters."
			},{
				"name":"pNetwork",
				"type":"",
				"refparam":"false",
				"description":"\"mainnet\" or \"testnet\"."
			},{
				"name":"pCompressed",
				"type":"",
				"refparam":"false",
				"description":"true or false: whether the wallet should use the compressed public key."
			}],
			"examples":[{
				"script":"put cxWifEncode(cxHexEncode(tSeckey), \"mainnet\", true) into tWif"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The WIF string (on mainnet it starts with 5, K or L)."
			}],
			"description":"The flag decides which address the key unlocks, so it must be literally\ntrue or false. Fails closed: a key that is not 64 hex characters, an\nunknown network, another flag value, and a key that is zero or not below\nthe group order all throw.",
			"references":{
				"handler":["cxWifDecode","cxSeckeyIsValid"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-39",
			"name":"cxbtcoutpoint",
			"display name":"cxBtcOutpoint",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcOutpoint(<pTxidHex>,<pVout>)"
			],
			"display syntax":[
				"cxBtcOutpoint(<i>pTxidHex</i>,<i>pVout</i>)"
			],
			"associations":["coinxt"],
			"summary":"A 36-byte transaction outpoint from a txid and an output index.",
			"parameters":[{
				"name":"pTxidHex",
				"type":"",
				"refparam":"false",
				"description":"The txid as 64 hex characters, in display order."
			},{
				"name":"pVout",
				"type":"",
				"refparam":"false",
				"description":"The output index, written in digits."
			}],
			"examples":[{
				"script":"put cxHexEncode(cxBtcOutpoint(tTxid, 0)) into tOutpoints"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"36 bytes: the txid byte-reversed, then the index as 4 little-endian bytes."
			}],
			"description":"The builders take outpoints as a comma-separated list of hex, one per\ninput, so encode each with <cxHexEncode>. A txid that is not 32 bytes, or\nan index not written in digits or too large for 4 bytes, throws.",
			"references":{
				"handler":["cxBtcSighashSegwit","cxBtcTxEncode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-40",
			"name":"cxhexdecode",
			"display name":"cxHexDecode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHexDecode(<pHex>)"
			],
			"display syntax":[
				"cxHexDecode(<i>pHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The bytes a hex string spells.",
			"parameters":[{
				"name":"pHex",
				"type":"",
				"refparam":"false",
				"description":"The hex text, in upper, lower or mixed case."
			}],
			"examples":[{
				"script":"put cxHexDecode(\"0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798\") into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The decoded bytes."
			}],
			"description":"Throws on an odd number of characters and on any character that is not\na hex digit, rather than skipping it.",
			"references":{
				"handler":["cxHexEncode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"coinxt-41",
			"name":"cxbtcoutput",
			"display name":"cxBtcOutput",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcOutput(<pAmountSat>,<pScriptHex>)"
			],
			"display syntax":[
				"cxBtcOutput(<i>pAmountSat</i>,<i>pScriptHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"A serialized Bitcoin transaction output.",
			"parameters":[{
				"name":"pAmountSat",
				"type":"",
				"refparam":"false",
				"description":"The amount in satoshi, written in digits."
			},{
				"name":"pScriptHex",
				"type":"",
				"refparam":"false",
				"description":"The output's scriptPubKey as hex."
			}],
			"examples":[{
				"script":"put cxHexEncode(cxBtcOutput(10000, \"0014\" & tKeyHashHex)) into tOutputs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The output bytes: the 8-byte little-endian amount, then the script with its CompactSize length."
			}],
			"description":"The transaction builders take outputs as a comma-separated list of hex,\none per output, so encode each with <cxHexEncode>. The amount must be a\nrun of digits, at most 2^53.",
			"references":{
				"handler":["cxBtcTxEncode","cxBtcSighashSegwit","cxVarInt"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-42",
			"name":"cxhexencode",
			"display name":"cxHexEncode",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHexEncode(<pData>)"
			],
			"display syntax":[
				"cxHexEncode(<i>pData</i>)"
			],
			"associations":["coinxt"],
			"summary":"Lowercase hex text for some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode."
			}],
			"examples":[{
				"script":"put cxHexEncode(cxSha256(textEncode(\"abc\", \"utf-8\"))) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The hex text, two lowercase characters per byte."
			}],
			"description":"The inverse of <cxHexDecode>. Empty in gives empty out.",
			"references":{
				"handler":["cxHexDecode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"coinxt-43",
			"name":"cxbtcsighashlegacy",
			"display name":"cxBtcSighashLegacy",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcSighashLegacy(<pVersion>,<pOutpoints>,<pSequences>,<pIndex>,<pScriptCodeHex>,<pOutputs>,<pLocktime>,<pSighashType>)"
			],
			"display syntax":[
				"cxBtcSighashLegacy(<i>pVersion</i>,<i>pOutpoints</i>,<i>pSequences</i>,<i>pIndex</i>,<i>pScriptCodeHex</i>,<i>pOutputs</i>,<i>pLocktime</i>,<i>pSighashType</i>)"
			],
			"associations":["coinxt"],
			"summary":"The pre-SegWit SIGHASH_ALL digest to sign for one input.",
			"parameters":[{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The transaction version, in digits."
			},{
				"name":"pOutpoints",
				"type":"",
				"refparam":"false",
				"description":"A comma list of outpoint hex (from cxBtcOutpoint), one per input."
			},{
				"name":"pSequences",
				"type":"",
				"refparam":"false",
				"description":"A comma list of sequence numbers, one per input."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the input being signed, in digits."
			},{
				"name":"pScriptCodeHex",
				"type":"",
				"refparam":"false",
				"description":"The bare scriptPubKey of that input, as hex; the length prefix is added for you."
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of serialized-output hex (from cxBtcOutput)."
			},{
				"name":"pLocktime",
				"type":"",
				"refparam":"false",
				"description":"The transaction locktime, in digits."
			},{
				"name":"pSighashType",
				"type":"",
				"refparam":"false",
				"description":"Must be 1 (SIGHASH_ALL)."
			}],
			"examples":[{
				"script":"put cxBtcSighashLegacy(2, tOutpoints, \"4294967293\", 1, tPrevScript, tOutputs, 0, 1) into tDigest\nput cxDerEncode(cxSign(tSeckey, tDigest)) & numToByte(1) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte digest to sign with cxSign."
			}],
			"description":"Every other input's script slot is left empty, as the legacy algorithm\nrequires. Only SIGHASH_ALL is implemented, so any other type throws\nrather than producing a digest that commits to the wrong data. Lists\nthat are not parallel, an index out of range or not in digits, and any\nnumber not written in digits also throw.\n\nThis builds the digest; your app signs it after showing the user what\nthe transaction does.",
			"references":{
				"handler":["cxBtcSighashSegwit","cxBtcTxEncode","cxSign"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-44",
			"name":"cxtaproottweak",
			"display name":"cxTaprootTweak",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxTaprootTweak(<pInternalKey>,<pMerkleRoot>)"
			],
			"display syntax":[
				"cxTaprootTweak(<i>pInternalKey</i>,<i>pMerkleRoot</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-341 Taproot output key and parity for an internal key, as an array.",
			"parameters":[{
				"name":"pInternalKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only internal key."
			},{
				"name":"pMerkleRoot",
				"type":"",
				"refparam":"false",
				"description":"Empty for a key-path-only output, or the 32-byte script-tree root."
			}],
			"examples":[{
				"script":"put cxTaprootTweak(cxXOnlyPubkey(tSeckey), empty) into tTweak\nput tTweak[\"parity\"] into tParity"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"outputKey\" (the 32-byte x-only output key, the P2TR witness program) and \"parity\" (0 for even Y, 1 for odd)."
			}],
			"description":"A named-array form of <cxTaprootTweakPubkey>. A key-path spend and an\naddress need only \"outputKey\"; a script-path spend puts \"parity\" in its\ncontrol block (<cxTapControlBlock>).\n\nAn empty pMerkleRoot is NOT 32 zero bytes: the two give different output\nkeys, and the difference is consensus. If you have no script tree, pass\nempty. Any other root length, or a key that is not 32 bytes, throws.",
			"references":{
				"handler":["cxTaprootTweakPubkey","cxBtcAddressP2TRFromInternal","cxTapControlBlock"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-45",
			"name":"cxhdfromseed",
			"display name":"cxHdFromSeed",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHdFromSeed(<pSeed>)"
			],
			"display syntax":[
				"cxHdFromSeed(<i>pSeed</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-32 master node for a seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"The seed, 16 to 64 bytes; normally the 64 bytes from cxMnemonicToSeed."
			}],
			"examples":[{
				"script":"put cxHdFromSeed(cxMnemonicToSeed(tMnemonic, \"\")) into tMaster\nput cxHdDerivePath(tMaster, \"m/84'/0'/0'/0/0\") into tNode"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The master node, as an array."
			}],
			"description":"A node is an array with keys \"seckey\" (32 bytes, or empty for a\nwatch-only node), \"pubkey\" (33 bytes, compressed), \"chaincode\",\n\"depth\", \"index\" and \"parentfp\" (the parent's 4-byte fingerprint).\nA seed outside 16 to 64 bytes throws, and so does one BIP-32 calls\ninvalid (about one in 2^127).",
			"references":{
				"handler":["cxHdDerivePath","cxMnemonicToSeed","cxXprv"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-46",
			"name":"cxbtcsighashsegwit",
			"display name":"cxBtcSighashSegwit",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcSighashSegwit(<pVersion>,<pOutpoints>,<pSequences>,<pIndex>,<pScriptCodeHex>,<pAmountSat>,<pOutputs>,<pLocktime>,<pSighashType>)"
			],
			"display syntax":[
				"cxBtcSighashSegwit(<i>pVersion</i>,<i>pOutpoints</i>,<i>pSequences</i>,<i>pIndex</i>,<i>pScriptCodeHex</i>,<i>pAmountSat</i>,<i>pOutputs</i>,<i>pLocktime</i>,<i>pSighashType</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-143 (SegWit v0) SIGHASH_ALL digest to sign for one input.",
			"parameters":[{
				"name":"pVersion",
				"type":"",
				"refparam":"false",
				"description":"The transaction version, in digits."
			},{
				"name":"pOutpoints",
				"type":"",
				"refparam":"false",
				"description":"A comma list of outpoint hex (from cxBtcOutpoint), one per input."
			},{
				"name":"pSequences",
				"type":"",
				"refparam":"false",
				"description":"A comma list of sequence numbers, one per input."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the input being signed, in digits."
			},{
				"name":"pScriptCodeHex",
				"type":"",
				"refparam":"false",
				"description":"The bare scriptCode as hex; for P2WPKH, the P2PKH script 76a914, the key hash, 88ac."
			},{
				"name":"pAmountSat",
				"type":"",
				"refparam":"false",
				"description":"The amount of the input being spent, in satoshi."
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of serialized-output hex (from cxBtcOutput); required."
			},{
				"name":"pLocktime",
				"type":"",
				"refparam":"false",
				"description":"The transaction locktime, in digits."
			},{
				"name":"pSighashType",
				"type":"",
				"refparam":"false",
				"description":"Must be 1 (SIGHASH_ALL)."
			}],
			"examples":[{
				"script":"put \"76a914\" & cxHexEncode(cxHash160(tPubkey)) & \"88ac\" into tScriptCode\nput cxBtcSighashSegwit(2, tOutpoints, tSequences, 1, tScriptCode, 50000, tOutputs, 0, 1) into tDigest\nput cxDerEncode(cxSign(tSeckey, tDigest)) & numToByte(1) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte digest to sign with cxSign."
			}],
			"description":"BIP-143 commits to the input amount and to the outputs, which binds the\nsignature to where the coins go. Only SIGHASH_ALL is implemented; any\nother type throws (Taproot's full type set is in <cxBtcSighashTaproot>).\nLists that are not parallel, an index out of range or not in digits,\nand any number not written in digits throw.\n\nThis builds the digest; your app signs it after showing the user what\nthe transaction does.",
			"references":{
				"handler":["cxBtcSighashLegacy","cxBtcWitness","cxBtcTxEncode","cxSign"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-47",
			"name":"cxtapleafhash",
			"display name":"cxTapLeafHash",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxTapLeafHash(<pLeafVersion>,<pScriptHex>)"
			],
			"display syntax":[
				"cxTapLeafHash(<i>pLeafVersion</i>,<i>pScriptHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-341 TapLeaf hash of a script.",
			"parameters":[{
				"name":"pLeafVersion",
				"type":"",
				"refparam":"false",
				"description":"The leaf version, an even byte value: 192 (0xc0) for tapscript."
			},{
				"name":"pScriptHex",
				"type":"",
				"refparam":"false",
				"description":"The script as hex, under 253 bytes."
			}],
			"examples":[{
				"script":"put cxTapLeafHash(192, tScriptHex) into tLeaf"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte leaf hash as 64 hex characters."
			}],
			"description":"The tagged TapLeaf hash over the version, the size of the script and\nthe script itself. An odd or out-of-range version throws, and so does 0x50 (80),\nwhich BIP-341 reserves. A script of 253 bytes or more throws rather than\nbeing given a wrong one-byte size prefix. Pass the result to\n<cxTapBranchHash> to build a tree, and to <cxBtcSighashTaproot> to spend\nby this leaf.",
			"references":{
				"handler":["cxTapBranchHash","cxTapControlBlock","cxBtcSighashTaproot"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-48",
			"name":"cxtapbranchhash",
			"display name":"cxTapBranchHash",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxTapBranchHash(<pAHex>,<pBHex>)"
			],
			"display syntax":[
				"cxTapBranchHash(<i>pAHex</i>,<i>pBHex</i>)"
			],
			"associations":["coinxt"],
			"summary":"The BIP-341 TapBranch hash of two child hashes.",
			"parameters":[{
				"name":"pAHex",
				"type":"",
				"refparam":"false",
				"description":"One child hash, as 64 hex characters."
			},{
				"name":"pBHex",
				"type":"",
				"refparam":"false",
				"description":"The other child hash, as 64 hex characters."
			}],
			"examples":[{
				"script":"put cxTapBranchHash(cxTapLeafHash(192, tScriptA), cxTapLeafHash(192, tScriptB)) into tRoot\nput cxBtcAddressP2TRFromInternal(tInternal, cxHexDecode(tRoot)) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte branch hash as 64 hex characters."
			}],
			"description":"The children are sorted by byte value inside the handler, as consensus\nrequires, so the argument order does not change the result. Building a\nlarger tree (choosing its shape, collecting the merkle path) is your loop\nover this handler. A child that is not 32 bytes throws.",
			"references":{
				"handler":["cxTapLeafHash","cxTapControlBlock"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-49",
			"name":"cxbech32decodevalues",
			"display name":"cxBech32DecodeValues",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBech32DecodeValues(<pText>)"
			],
			"display syntax":[
				"cxBech32DecodeValues(<i>pText</i>)"
			],
			"associations":["coinxt"],
			"summary":"Decode a bech32 or bech32m string into its parts.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The bech32 or bech32m string."
			}],
			"examples":[{
				"script":"put cxBech32DecodeValues(tText) into tParts\nput tParts[\"spec\"] into field \"Encoding\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"hrp\", \"spec\" (\"bech32\" or \"bech32m\", whichever checksum verified) and \"values\" (the data as a comma-separated list of 5-bit numbers, without the checksum)."
			}],
			"description":"Throws on anything malformed: more than 90 characters, mixed case, a\ncharacter outside the charset or printable ASCII, or a checksum that\nmatches neither encoding. It reports which encoding verified rather\nthan accepting either, which is what lets <cxSegwitAddressDecode> enforce\nthe BIP-350 pairing.",
			"references":{
				"handler":["cxBech32EncodeValues","cxSegwitAddressDecode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-50",
			"name":"cxhdderivepath",
			"display name":"cxHdDerivePath",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxHdDerivePath(<pNode>,<pPath>)"
			],
			"display syntax":[
				"cxHdDerivePath(<i>pNode</i>,<i>pPath</i>)"
			],
			"associations":["coinxt"],
			"summary":"Walk a BIP-32 path such as \"m/44'/0'/0'/0/0\" from an HD node.",
			"parameters":[{
				"name":"pNode",
				"type":"",
				"refparam":"false",
				"description":"The starting node, as an array; usually the master node."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The path: \"m\", then levels separated by \"/\", each a number below 2^31, optionally followed by ', h or H for hardened."
			}],
			"examples":[{
				"script":"put cxHdDerivePath(tMaster, \"m/44'/0'/0'/0/0\") into tNode\nput cxBtcAddressP2PKH(tNode[\"pubkey\"]) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The derived node, as an array."
			}],
			"description":"\"m\" alone returns the node unchanged. The parse is strict: a level that\nis not plain digits, an empty level or a trailing \"/\" throws, because\n\"m/1e3\" quietly becoming 1000 would be a different wallet with no error.\nThe leading \"m\" is not checked against the node being a master node.\n\nCheck your integration once: from the test mnemonic \"abandon\" eleven\ntimes then \"about\", m/44'/0'/0'/0/0 must give\n1LqBGSKuX5yYUonjxT5qGfpUsXKYYWeabA.",
			"references":{
				"handler":["cxHdDeriveChild","cxHdFromSeed","cxXprv"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-51",
			"name":"cxbtcwitness",
			"display name":"cxBtcWitness",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxBtcWitness(<pItems>)"
			],
			"display syntax":[
				"cxBtcWitness(<i>pItems</i>)"
			],
			"associations":["coinxt"],
			"summary":"A serialized SegWit witness stack for one input.",
			"parameters":[{
				"name":"pItems",
				"type":"",
				"refparam":"false",
				"description":"A comma list of the witness items as hex; empty for an input with no witness."
			}],
			"examples":[{
				"script":"put cxHexEncode(tSig) & \",\" & cxHexEncode(tPubkey) into tItems\nput cxHexEncode(cxBtcWitness(tItems)) into tWitnessHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The witness bytes: the item count, then each item with its CompactSize length."
			}],
			"description":"Pass one of these per input, hex-encoded and comma-separated, as\n<cxBtcTxEncode>'s witness list.",
			"references":{
				"handler":["cxBtcTxEncode","cxDerEncode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"coinxt-52",
			"name":"cxethlegacysighash",
			"display name":"cxEthLegacySighash",
			"library":"coinxt",
			"type":"function",
			"syntax":[
				"cxEthLegacySighash(<pNonce>,<pGasPriceHex>,<pGas>,<pToHex>,<pValueHex>,<pDataHex>,<pChainId>)"
			],
			"display syntax":[
				"cxEthLegacySighash(<i>pNonce</i>,<i>pGasPriceHex</i>,<i>pGas</i>,<i>pToHex</i>,<i>pValueHex</i>,<i>pDataHex</i>,<i>pChainId</i>)"
			],
			"associations":["coinxt"],
			"summary":"The EIP-155 signing digest for a legacy Ethereum transaction.",
			"parameters":[{
				"name":"pNonce",
				"type":"",
				"refparam":"false",
				"description":"The account nonce, in digits."
			},{
				"name":"pGasPriceHex",
				"type":"",
				"refparam":"false",
				"description":"The gas price in wei, as big-endian hex."
			},{
				"name":"pGas",
				"type":"",
				"refparam":"false",
				"description":"The gas limit, in digits."
			},{
				"name":"pToHex",
				"type":"",
				"refparam":"false",
				"description":"The 20-byte recipient as hex; empty for a contract creation."
			},{
				"name":"pValueHex",
				"type":"",
				"refparam":"false",
				"description":"The value in wei, as big-endian hex."
			},{
				"name":"pDataHex",
				"type":"",
				"refparam":"false",
				"description":"The call data as hex; empty for none."
			},{
				"name":"pChainId",
				"type":"",
				"refparam":"false",
				"description":"The chain id, in digits (1 for Ethereum mainnet)."
			}],
			"examples":[{
				"script":"put cxEthLegacySighash(0, \"04a817c800\", 21000, tToHex, \"0de0b6b3a7640000\", \"\", 1) into tDigest\nput cxSignRecoverable(tSeckey, tDigest) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte Keccak-256 digest to sign with cxSignRecoverable."
			}],
			"description":"Wei-scale amounts cross as big-endian hex because they exceed exact\nintegers; the counters are written in digits, at most 2^53. Pass the signature to <cxEthLegacyEncode> with the same\nfields. This builds the digest; your app signs it after showing the user\nwhat the transaction does.",
			"references":{
				"handler":["cxEthLegacyEncode","cxSignRecoverable","cxEth1559Sighash"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		}