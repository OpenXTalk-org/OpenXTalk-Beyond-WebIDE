{
			"id":"nostr-relay-1",
			"name":"nostr-relay",
			"display name":"NostrXT relay client",
			"library":"nostr-relay",
			"type":"library",
			"display syntax":[
				"NostrXT relay client"
			],
			"associations":["nostr-relay"],
			"description":"The NostrXT Relay Client is a websocket (RFC 6455) client over engine\nsockets that speaks the NIP-01 relay protocol: it sends REQ, CLOSE,\nEVENT and AUTH, and receives EVENT, OK, EOSE, CLOSED, NOTICE and AUTH.\nIt composes the NostrXT core library, so load that first; this library\nowns only the sockets, buffers and relay handles.\n\nEach relay is an integer handle from <nxrConnect>. Commands report\nthrough the result: empty on success, or text starting\n\"NostrXT relay:\" for a refusal. Everything that happens later arrives through the callback\nhandler you register with <nxrSetCallback>, dispatched to the object set\nby <nxrInit>.\n\nInbound events are verified (id and signature) before delivery unless\nyou turn that off with <nxrSetVerify>. Call <nxrShutdown>\nfrom closeStack: there is no automatic unload.\n\nThe library defines the engine's socketError, socketClosed and\nsocketTimeout messages and passes on any that are not for its own\nsockets. If your stack script handles those messages too, it must pass\nthe ones that are not its own, or another library will hang."
		},{
			"id":"nostr-relay-2",
			"name":"nxrsocketclosed",
			"display name":"nxrSocketClosed",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrSocketClosed(<pSocketID>)"
			],
			"display syntax":[
				"nxrSocketClosed(<i>pSocketID</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Handles a socketClosed message if it belongs to one of this library's relays.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"The socket id from the socketClosed message."
			}],
			"examples":[{
				"script":"if nxrSocketClosed(pSocketID) then exit socketClosed\npass socketClosed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" when the socket was a relay's and the close was handled, \"false\" otherwise."
			}],
			"description":"For a stack that embeds this library and defines socketClosed itself.\nFor a relay socket, the relay is torn down and the callback receives\n\"disconnected\". Ordinary apps never call it.",
			"references":{
				"handler":["nxrSocketError","nxrSocketTimeout"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-3",
			"name":"nxrshutdown",
			"display name":"nxrShutdown",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrShutdown"
			],
			"display syntax":[
				"nxrShutdown"
			],
			"associations":["nostr-relay"],
			"summary":"Closes every relay connection.",
			"examples":[{
				"script":"nxrShutdown"
			}],
			"description":"Call it from closeStack: there is no automatic unload, so the app frees\nwhat it opens. Safe to call more than once.",
			"references":{
				"handler":["nxrDisconnect","nxrOpenRelays"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-4",
			"name":"nxrauth",
			"display name":"nxrAuth",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrAuth <pRelay>,<pSignedEvent>"
			],
			"display syntax":[
				"nxrAuth <i>pRelay</i>,<i>pSignedEvent</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Answers a relay's NIP-42 authentication challenge.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pSignedEvent",
				"type":"",
				"refparam":"false",
				"description":"The signed kind 22242 event."
			}],
			"examples":[{
				"script":"put nxAuthBuild(nxrUrl(tRelay), nxrChallenge(tRelay), empty) into tAuth\nnxrAuth tRelay, nxEventSign(tAuth, tSeckey, empty)"
			}],
			"description":"Use it after an \"auth\" callback. Build the event with <nxAuthBuild> and\nsign it with <nxEventSign>. The relay must be open; the relay's answer\narrives as an \"ok\" callback.",
			"references":{
				"handler":["nxAuthBuild","nxrChallenge","nxClientAuth"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-5",
			"name":"nxrsocketerror",
			"display name":"nxrSocketError",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrSocketError(<pSocketID>,<pError>)"
			],
			"display syntax":[
				"nxrSocketError(<i>pSocketID</i>,<i>pError</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Handles a socketError message if it belongs to one of this library's relays.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"The socket id from the socketError message."
			},{
				"name":"pError",
				"type":"",
				"refparam":"false",
				"description":"The error text from the socketError message."
			}],
			"examples":[{
				"script":"if nxrSocketError(pSocketID, pError) then exit socketError\npass socketError"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" when the socket was a relay's and the error was handled, \"false\" otherwise."
			}],
			"description":"For a stack that embeds this library in its own script and so must\ndefine socketError itself: call it from your handler where you would\notherwise pass the message on. For a relay socket, the relay fails\nclosed (\"error\" and \"disconnected\" callbacks). Ordinary apps that use\nthe library as a stack never call it.",
			"references":{
				"handler":["nxrSocketClosed","nxrSocketTimeout"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-6",
			"name":"nxrping",
			"display name":"nxrPing",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrPing <pRelay>"
			],
			"display syntax":[
				"nxrPing <i>pRelay</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sends a websocket ping to a relay.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			}],
			"examples":[{
				"script":"nxrPing tRelay"
			}],
			"description":"A liveness probe. The relay must be open; its pong is consumed silently.",
			"references":{
				"handler":["nxrState"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-7",
			"name":"nxrpublish",
			"display name":"nxrPublish",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrPublish <pRelay>,<pEvent>"
			],
			"display syntax":[
				"nxrPublish <i>pRelay</i>,<i>pEvent</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sends a signed event to a relay.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The signed event array."
			}],
			"examples":[{
				"script":"put nxEventSign(nxEventBuild(1, \"Hello\", empty, empty), tSeckey, empty) into tSigned\nnxrPublish tRelay, tSigned\nif the result is not empty then answer the result"
			}],
			"description":"The relay must be open, and the event must be signed with\n<nxEventSign>. The relay's verdict arrives later as an \"ok\" callback\nwith the event id.",
			"references":{
				"handler":["nxEventSign","nxClientEvent"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-8",
			"name":"nxrconnect",
			"display name":"nxrConnect",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrConnect <pUrl>"
			],
			"display syntax":[
				"nxrConnect <i>pUrl</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Opens a connection to a Nostr relay.",
			"parameters":[{
				"name":"pUrl",
				"type":"",
				"refparam":"false",
				"description":"The relay URL, starting wss:// or ws://."
			}],
			"examples":[{
				"script":"nxrConnect \"wss://relay.example.com\"\nput the result into tRelay\nif tRelay is an integer then nxrSetCallback tRelay, \"relayEvent\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The integer relay handle, or a \"NostrXT relay:\" refusal."
			}],
			"description":"<nxrConnect> returns at once with the handle in the result; test it with\n\"is an integer\". The connection and the websocket handshake complete\nlater, and the callback receives \"open\" when the relay is usable or\n\"error\" and \"disconnected\" when it fails. A handshake that has not\nfinished within 20 seconds fails closed. Connecting also sets the\nengine's socketTimeoutInterval to 20 seconds.\n\nThe callback handler is called with the relay handle, a kind, and up to\ntwo arguments. The kinds are \"open\"; \"event\" (subscription id, the\nverified event JSON); \"invalid\" (subscription id, why the event was\nrefused); \"eose\" (subscription id); \"ok\" (event id, then \"true\" or\n\"false\", a tab and the relay's reason); \"closed\" (subscription id,\nreason); \"notice\" (the text); \"auth\" (the NIP-42 challenge); \"error\"\n(the failure); and \"disconnected\" (the reason).\n\nA wss:// connection has been made on an engine; whether a bad\ncertificate is refused has not been measured. The ws:// path has not\nyet run on an engine.",
			"references":{
				"handler":["nxrSetCallback","nxrDisconnect","nxrState"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-9",
			"name":"nxrdisconnect",
			"display name":"nxrDisconnect",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrDisconnect <pRelay>"
			],
			"display syntax":[
				"nxrDisconnect <i>pRelay</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Closes a relay connection.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			}],
			"examples":[{
				"script":"nxrDisconnect tRelay"
			}],
			"description":"Sends a websocket close frame when the connection is open, then closes\nthe socket and forgets the handle. The callback receives \"disconnected\".\nA handle that is not live is a no-op, so calling it twice is safe.",
			"references":{
				"handler":["nxrConnect","nxrShutdown"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-10",
			"name":"nxrunsubscribe",
			"display name":"nxrUnsubscribe",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrUnsubscribe <pRelay>,<pSubId>"
			],
			"display syntax":[
				"nxrUnsubscribe <i>pRelay</i>,<i>pSubId</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sends a CLOSE to end a subscription.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pSubId",
				"type":"",
				"refparam":"false",
				"description":"The subscription id."
			}],
			"examples":[{
				"script":"nxrUnsubscribe tRelay, \"my-feed\""
			}],
			"description":"The relay must be open. Refusals come back in the result.",
			"references":{
				"handler":["nxrSubscribe","nxClientClose"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-11",
			"name":"nxrversion",
			"display name":"nxrVersion",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrVersion()"
			],
			"display syntax":[
				"nxrVersion()"
			],
			"associations":["nostr-relay"],
			"summary":"Returns the relay client's version.",
			"examples":[{
				"script":"put nxrVersion() into field \"versionField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The text \"NostrXT relay\" followed by the core's version string."
			}],
			"description":"It calls <nxVersion>, so it also proves the core library is loaded.",
			"references":{
				"handler":["nxVersion"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-12",
			"name":"nxrstate",
			"display name":"nxrState",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrState(<pRelay>)"
			],
			"display syntax":[
				"nxrState(<i>pRelay</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Returns the connection state of a relay.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			}],
			"examples":[{
				"script":"if nxrState(tRelay) is \"open\" then nxrPublish tRelay, tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"connecting\", \"handshake\", \"open\" or \"closing\", or \"unknown\" for a handle that is not live."
			}],
			"description":"Only an \"open\" relay accepts subscriptions, publishes and other sends.",
			"references":{
				"handler":["nxrConnect","nxrOpenRelays"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-13",
			"name":"nxrsetcallback",
			"display name":"nxrSetCallback",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrSetCallback <pRelay>,<pHandlerName>"
			],
			"display syntax":[
				"nxrSetCallback <i>pRelay</i>,<i>pHandlerName</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Registers the handler that receives a relay's callbacks.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pHandlerName",
				"type":"",
				"refparam":"false",
				"description":"The name of the handler to dispatch to."
			}],
			"examples":[{
				"script":"nxrConnect \"wss://relay.example.com\"\nput the result into tRelay\nnxrSetCallback tRelay, \"relayEvent\""
			}],
			"description":"The handler is dispatched to the object set by <nxrInit>, with\nfour arguments: the relay handle, the kind, and two kind-specific\narguments (the kinds are listed under <nxrConnect>). Set it straight\nafter connecting, before the \"open\" callback arrives.\n\nDispatch is guarded: an error in your handler does not break the\nconnection, and a missing handler is ignored. An unknown handle returns\na refusal in the result.",
			"references":{
				"handler":["nxrConnect","nxrInit"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-14",
			"name":"nxrinit",
			"display name":"nxrInit",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrInit <pOwner>"
			],
			"display syntax":[
				"nxrInit <i>pOwner</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sets the object whose script receives relay callbacks.",
			"parameters":[{
				"name":"pOwner",
				"type":"",
				"refparam":"false",
				"description":"The long id of the object, or empty for the topStack."
			}],
			"examples":[{
				"script":"nxrInit the long id of me"
			}],
			"description":"Call it once at startup, for example in preOpenStack. Until it is set,\ncallbacks are dispatched to the topStack, which may not be the stack you\nexpect. Calling it again replaces the owner.",
			"references":{
				"handler":["nxrSetCallback","nxrConnect"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-15",
			"name":"nxrsockettimeout",
			"display name":"nxrSocketTimeout",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrSocketTimeout(<pSocketID>)"
			],
			"display syntax":[
				"nxrSocketTimeout(<i>pSocketID</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Handles a socketTimeout message if it belongs to one of this library's relays.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"The socket id from the socketTimeout message."
			}],
			"examples":[{
				"script":"if nxrSocketTimeout(pSocketID) then exit socketTimeout\npass socketTimeout"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" when the socket was a relay's, \"false\" otherwise."
			}],
			"description":"For a stack that embeds this library and defines socketTimeout itself.\nThe engine repeats socketTimeout while a read waits, so a timeout fails\nthe relay only before its handshake completes; on an open relay an idle\nread is normal and the message is simply consumed. Ordinary apps never\ncall it.",
			"references":{
				"handler":["nxrSocketError","nxrSocketClosed"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-16",
			"name":"nxrsendraw",
			"display name":"nxrSendRaw",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrSendRaw <pRelay>,<pText>"
			],
			"display syntax":[
				"nxrSendRaw <i>pRelay</i>,<i>pText</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sends one text message to a relay exactly as given.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The message text, usually a JSON array."
			}],
			"examples":[{
				"script":"nxrSendRaw tRelay, tWire"
			}],
			"description":"The escape hatch for NIPs this library does not speak yet. The text is\nsent as one websocket text frame; you are responsible for the JSON. The\nrelay must be open.",
			"references":{
				"handler":["nxrPublish","nxrSubscribe"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-17",
			"name":"nxrchallenge",
			"display name":"nxrChallenge",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrChallenge(<pRelay>)"
			],
			"display syntax":[
				"nxrChallenge(<i>pRelay</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Returns the most recent NIP-42 challenge a relay sent.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			}],
			"examples":[{
				"script":"put nxrChallenge(tRelay) into tChallenge"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The challenge text, or empty."
			}],
			"description":"The same challenge arrives with the \"auth\" callback; this keeps it for\nwhen you answer later.",
			"references":{
				"handler":["nxrAuth","nxAuthBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-18",
			"name":"nxropenrelays",
			"display name":"nxrOpenRelays",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrOpenRelays()"
			],
			"display syntax":[
				"nxrOpenRelays()"
			],
			"associations":["nostr-relay"],
			"summary":"Lists every live relay handle.",
			"examples":[{
				"script":"put nxrOpenRelays() into tHandles"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The handles, one per line, in numeric order."
			}],
			"description":"A handle leaves the list when its connection is torn down.",
			"references":{
				"handler":["nxrState","nxrShutdown"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-19",
			"name":"nxrsubscribe",
			"display name":"nxrSubscribe",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrSubscribe <pRelay>,<pSubId>,<pFiltersJson>"
			],
			"display syntax":[
				"nxrSubscribe <i>pRelay</i>,<i>pSubId</i>,<i>pFiltersJson</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Sends a REQ to open a subscription on a relay.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pSubId",
				"type":"",
				"refparam":"false",
				"description":"The subscription id, 1 to 64 characters."
			},{
				"name":"pFiltersJson",
				"type":"",
				"refparam":"false",
				"description":"One filter JSON object per line, as from nxFilterBuild."
			}],
			"examples":[{
				"script":"put tPubkey into tFilter[\"authors\"]\nput \"1\" into tFilter[\"kinds\"]\nnxrSubscribe tRelay, \"my-feed\", nxFilterBuild(tFilter)\nif the result is not empty then answer the result"
			}],
			"description":"The relay must be open. Matching events arrive as \"event\" callbacks\nwith the subscription id, followed by \"eose\" once the stored events are\nsent. A relay can end the subscription with \"closed\".",
			"references":{
				"handler":["nxrUnsubscribe","nxFilterBuild","nxClientReq"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-20",
			"name":"nxrurl",
			"display name":"nxrUrl",
			"library":"nostr-relay",
			"type":"function",
			"syntax":[
				"nxrUrl(<pRelay>)"
			],
			"display syntax":[
				"nxrUrl(<i>pRelay</i>)"
			],
			"associations":["nostr-relay"],
			"summary":"Returns the URL a relay was opened with.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			}],
			"examples":[{
				"script":"put nxrUrl(tRelay) into tUrl"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The URL, or empty for a handle that is not live."
			}],
			"description":"Useful for <nxAuthBuild>, which needs the relay URL.",
			"references":{
				"handler":["nxrConnect","nxAuthBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostr-relay-21",
			"name":"nxrsetverify",
			"display name":"nxrSetVerify",
			"library":"nostr-relay",
			"type":"command",
			"syntax":[
				"nxrSetVerify <pRelay>,<pVerify>"
			],
			"display syntax":[
				"nxrSetVerify <i>pRelay</i>,<i>pVerify</i>"
			],
			"associations":["nostr-relay"],
			"summary":"Turns event verification on or off for one relay.",
			"parameters":[{
				"name":"pRelay",
				"type":"",
				"refparam":"false",
				"description":"The relay handle."
			},{
				"name":"pVerify",
				"type":"",
				"refparam":"false",
				"description":"true to verify inbound events (the default), false to deliver them unverified."
			}],
			"examples":[{
				"script":"nxrSetVerify tRelay, false"
			}],
			"description":"Verification is on by default and fails closed: an event whose id or\nsignature does not check, or any event while CoinXT is missing, arrives\nas \"invalid\", never as \"event\". Turning it off is a per-relay decision;\nthen verify events yourself with <nxEventVerify>. A value other than\ntrue or false is refused.",
			"references":{
				"handler":["nxEventVerify","nxrSetCallback"]
			},
			"tags":["networking","nostr"]
		}