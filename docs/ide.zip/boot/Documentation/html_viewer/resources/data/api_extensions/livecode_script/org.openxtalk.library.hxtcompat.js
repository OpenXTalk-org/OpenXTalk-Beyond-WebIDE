{
			"id":"org.openxtalk.library.hxtcompat-1",
			"name":"org.openxtalk.library.hxtcompat",
			"display name":"HyperXTalk Compatibility",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"library",
			"display syntax":[
				"HyperXTalk Compatibility"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"Functions from HyperXTalk: <iff>, <quotedPrintableEncode>,\n<quotedPrintableDecode> and <microseconds>, for scripts written for\nHyperXTalk.",
			"description":"HyperXTalk, a fork of LiveCode Community, has these functions in its\nengine. Here they are handlers of a library, which come after every other\nhandler in the message path: where a script has its own handler of one of\nthese names, that handler is called, as before.\n\nThe engine has the rest of what HyperXTalk added to the language: the\n<microseconds> function (`the microseconds`) and the <matches> operator.\n\nIn a standalone application, include the \"HyperXTalk Compatibility\"\nlibrary (Standalone Application Settings, Inclusions)."
		},{
			"id":"org.openxtalk.library.hxtcompat-2",
			"name":"iff",
			"display name":"iff",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"iff(<pCondition>, <pTrue>, <pFalse>)"
			],
			"display syntax":[
				"iff(<i>pCondition</i>, <i>pTrue</i>, <i>pFalse</i>)"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"Returns one of two values, chosen by a condition.",
			"parameters":[{
				"name":"pCondition",
				"type":"",
				"refparam":"false",
				"description":"An expression that is true or false."
			},{
				"name":"pTrue",
				"type":"",
				"refparam":"false",
				"description":"The value to return when <pCondition> is true."
			},{
				"name":"pFalse",
				"type":"",
				"refparam":"false",
				"description":"The value to return when <pCondition> is false."
			}],
			"examples":[{
				"script":"put iff(tCount is 1, \"item\", \"items\") into tWord"
			},{
				"script":"answer \"The file is\" && iff(there is a file tPath, \"there\", \"missing\") & \".\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"<pTrue> if <pCondition> is true, <pFalse> if it is false."
			}],
			"description":"Use the <iff> function to choose between two values in an expression,\nwhere an <if> statement would take several lines.\n\nAs with any handler, both values are worked out before <iff> is called,\nso a value that can fail, such as `1 / tCount` when <tCount> can be 0,\nfails even when it is not the one returned: use an <if> statement for\nit. (HyperXTalk's <iff> works out only the value it returns.)\n\nIf <pCondition> is neither true nor false, the call fails with\n\"call: type conversion error\".\n\n<iff> comes from HyperXTalk. Where a script has its own <iff> handler,\nthat handler is called instead.",
			"references":{
				"constant":["true","false"],
				"control structure":["if"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-3",
			"name":"quotedprintableencode",
			"display name":"quotedPrintableEncode",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"quotedPrintableEncode(<pData>)"
			],
			"display syntax":[
				"quotedPrintableEncode(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"Encodes data as quoted-printable text, as email does.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The data to encode."
			}],
			"examples":[{
				"script":"put quotedPrintableEncode(textEncode(field \"Message\", \"UTF-8\")) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The quoted-printable text."
			}],
			"description":"Use the <quotedPrintableEncode> function to encode text or data for an\nemail message whose Content-Transfer-Encoding is quoted-printable (RFC\n2045).\n\nBytes from 33 to 126 stay as they are, but \"=\", and so do spaces and\ntabs, unless one ends a line. Line breaks (CR and LF) stay as they are.\nEvery other byte becomes \"=\" and its two hexadecimal digits, upper case.\nA longer line is broken with soft line breaks (\"=\" at the end of a line,\nthen CR LF), so that no line is longer than 76 characters.\n\nText with characters outside the ASCII range should be encoded first,\nwith <textEncode> (for example in UTF-8), and the message should say\nwhich encoding it is in.\n\n<quotedPrintableEncode> comes from HyperXTalk. HyperXTalk's can make a\nline of 77 characters, which the RFC does not allow. Where a script has\nits own <quotedPrintableEncode> handler, that handler is called instead.",
			"references":{
				"handler":["quotedPrintableDecode"],
				"function":["textEncode","base64Encode"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-4",
			"name":"microseconds",
			"display name":"microseconds",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"microseconds()"
			],
			"display syntax":[
				"microseconds()"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"Returns the number of microseconds since midnight GMT, January\n1, 1970, when it is called with brackets.",
			"examples":[{
				"script":"put microseconds() into tStart"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of microseconds since the start of the eon, a whole\nnumber."
			}],
			"description":"`microseconds()` is the <microseconds> function (`the microseconds`),\nwhich the engine has, written as HyperXTalk also allows: with brackets,\nas a call of a handler. Where a script has its own <microseconds>\nfunction handler, `microseconds()` calls that handler, as before, and\n`the microseconds` is still the engine's.",
			"references":{
				"function":["microseconds","milliseconds"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-5",
			"name":"microsecs",
			"display name":"microsecs",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"microsecs()"
			],
			"display syntax":[
				"microsecs()"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"The same as <microseconds>.",
			"examples":[{
				"script":"put microsecs() into tStart"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of microseconds since midnight GMT, January 1, 1970."
			}],
			"description":"`microsecs()` is `microseconds()`: another of its names.",
			"references":{
				"handler":["microseconds"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-6",
			"name":"microsec",
			"display name":"microsec",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"microsec()"
			],
			"display syntax":[
				"microsec()"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"The same as <microseconds>.",
			"examples":[{
				"script":"put microsec() into tStart"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of microseconds since midnight GMT, January 1, 1970."
			}],
			"description":"`microsec()` is `microseconds()`: another of its names.",
			"references":{
				"handler":["microseconds"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-7",
			"name":"quotedprintabledecode",
			"display name":"quotedPrintableDecode",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"quotedPrintableDecode(<pText>)"
			],
			"display syntax":[
				"quotedPrintableDecode(<i>pText</i>)"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"Decodes quoted-printable text, as email has it.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The quoted-printable text to decode."
			}],
			"examples":[{
				"script":"put textDecode(quotedPrintableDecode(tBody), \"UTF-8\") into field \"Message\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The data it encodes."
			}],
			"description":"Use the <quotedPrintableDecode> function to decode the body of an email\nmessage whose Content-Transfer-Encoding is quoted-printable (RFC 2045).\n\nAn \"=\" and two hexadecimal digits (in upper or lower case) become the\nbyte they encode. A soft line break (\"=\" at the end of a line) is left\nout, with its line break. Everything else stays as it is, an \"=\" that\nstarts neither included.\n\nThe result is data: decode it as text with <textDecode>, in the\nencoding the message names.\n\n<quotedPrintableDecode> comes from HyperXTalk. Where a script has its own\n<quotedPrintableDecode> handler, that handler is called instead.",
			"references":{
				"handler":["quotedPrintableEncode"],
				"function":["textDecode","base64Decode"]
			},
			"tags":["library","library"]
		},{
			"id":"org.openxtalk.library.hxtcompat-8",
			"name":"microsecond",
			"display name":"microsecond",
			"library":"org.openxtalk.library.hxtcompat",
			"type":"handler",
			"syntax":[
				"microsecond()"
			],
			"display syntax":[
				"microsecond()"
			],
			"associations":["org.openxtalk.library.hxtcompat"],
			"summary":"The same as <microseconds>.",
			"examples":[{
				"script":"put microsecond() into tStart"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of microseconds since midnight GMT, January 1, 1970."
			}],
			"description":"`microsecond()` is `microseconds()`: another of its names.",
			"references":{
				"handler":["microseconds"]
			},
			"tags":["library","library"]
		}