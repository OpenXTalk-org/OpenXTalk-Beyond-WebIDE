{
			"id":"dataChannelHelpers-1",
			"name":"datachannelhelpers",
			"display name":"DataChannelXT helpers",
			"library":"dataChannelHelpers",
			"type":"library",
			"display syntax":[
				"DataChannelXT helpers"
			],
			"associations":["datachannelhelpers"],
			"description":"The poll dispatcher and small helpers for DataChannelXT. Put the\ndataChannelHelpers stack in use (start using stack \"dataChannelHelpers\")\nand call <dcStartPolling>: a timer drains the native event queue with\n<dcPoll> and sends one message per event to your card or object, so an\napp handles plain messages instead of running its own poll loop.\n\nThe messages are dcLocalDescriptionReady, dcLocalCandidate,\ndcStateChange, dcGatheringStateChange, dcChannelIncoming, dcChannelOpen,\ndcChannelClosed, dcMessage, dcChannelError, dcBufferedLow and\ndcQueueOverflow, each with the event array as its parameter, plus a\ncatch-all dataChannelEvent for every event."
		},{
			"id":"dataChannelHelpers-2",
			"name":"dcpollclearerror",
			"display name":"dcPollClearError",
			"library":"dataChannelHelpers",
			"type":"command",
			"syntax":[
				"dcPollClearError"
			],
			"display syntax":[
				"dcPollClearError"
			],
			"associations":["datachannelhelpers"],
			"summary":"Clear the poll timer's recorded fault.",
			"examples":[{
				"script":"dcPollClearError"
			}],
			"description":"Use <dcPollClearError> after reading <dcPollLastError>, so each distinct\nfailure is reported once.",
			"references":{
				"handler":["dcPollLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-3",
			"name":"dcpolllasterror",
			"display name":"dcPollLastError",
			"library":"dataChannelHelpers",
			"type":"function",
			"syntax":[
				"dcPollLastError()"
			],
			"display syntax":[
				"dcPollLastError()"
			],
			"associations":["datachannelhelpers"],
			"summary":"The first fault the poll timer recorded since the last clear.",
			"examples":[{
				"script":"put dcPollLastError() into tNote\nif tNote is not empty then put tNote & return after field \"Log\"\ndcPollClearError"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Empty while the dispatcher is healthy; otherwise a one-line description of the first fault."
			}],
			"description":"Use <dcPollLastError> to find out why events stopped arriving. The poll\ntimer never stops on a fault; it records the first one instead: a\nfailed drain (with the drain number), a failed dispatch (naming the\nevent), or a target that no longer exists (it then falls back to the\ncurrent card). The helpers never print it; your app decides where it\ngoes. It survives a stop and restart; only <dcPollClearError> clears it.",
			"references":{
				"handler":["dcPollClearError","dcStartPolling"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-4",
			"name":"dcstartpolling",
			"display name":"dcStartPolling",
			"library":"dataChannelHelpers",
			"type":"command",
			"syntax":[
				"dcStartPolling <pTarget>,<pIntervalMs>"
			],
			"display syntax":[
				"dcStartPolling <i>pTarget</i>,<i>pIntervalMs</i>"
			],
			"associations":["datachannelhelpers"],
			"summary":"Start draining DataChannelXT events and dispatching them as messages.",
			"parameters":[{
				"name":"pTarget",
				"type":"",
				"refparam":"false",
				"description":"The object that receives the event messages; empty means the current card."
			},{
				"name":"pIntervalMs",
				"type":"",
				"refparam":"false",
				"description":"Milliseconds between drains; empty or less than 1 means 33."
			}],
			"examples":[{
				"script":"start using stack \"dataChannelHelpers\"\ndcStartPolling the long id of this card, 33"
			}],
			"description":"Use <dcStartPolling> once at startup. Every interval it calls <dcPoll>\nand dispatches each event to the target by its name, such as dcMessage\nor dcChannelOpen, followed by a catch-all dataChannelEvent message, each\nwith the event array as its parameter.\n\nThe interval is the latency knob: 16 to 33 milliseconds feels real-time,\n100 or more is fine for chat. Calling it again while polling changes the\ntarget and the interval without starting a second timer. A failed drain\nor a failed dispatch does not stop the timer; it is recorded for\n<dcPollLastError>. If the target no longer exists, events go to the\ncurrent card instead.",
			"references":{
				"handler":["dcStopPolling","dcPoll","dcPollLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-5",
			"name":"dcstatename",
			"display name":"dcStateName",
			"library":"dataChannelHelpers",
			"type":"function",
			"syntax":[
				"dcStateName(<pState>)"
			],
			"display syntax":[
				"dcStateName(<i>pState</i>)"
			],
			"associations":["datachannelhelpers"],
			"summary":"A label for a peer connection state number.",
			"parameters":[{
				"name":"pState",
				"type":"",
				"refparam":"false",
				"description":"A state number from <dcPeerState> or a dcStateChange event."
			}],
			"examples":[{
				"script":"put dcStateName(dcPeerState(sPeer)) into field \"Status\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"new\", \"connecting\", \"connected\", \"disconnected\", \"failed\", \"closed\", or \"unknown\"."
			}],
			"description":"Use <dcStateName> for status displays.",
			"references":{
				"handler":["dcPeerState","dcGatheringName"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-6",
			"name":"dcgatheringname",
			"display name":"dcGatheringName",
			"library":"dataChannelHelpers",
			"type":"function",
			"syntax":[
				"dcGatheringName(<pState>)"
			],
			"display syntax":[
				"dcGatheringName(<i>pState</i>)"
			],
			"associations":["datachannelhelpers"],
			"summary":"A label for an ICE gathering state number.",
			"parameters":[{
				"name":"pState",
				"type":"",
				"refparam":"false",
				"description":"A state number from <dcGatheringState> or a dcGatheringStateChange event."
			}],
			"examples":[{
				"script":"put dcGatheringName(dcGatheringState(sPeer)) into field \"Gathering\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"new\", \"gathering\", \"complete\", or \"unknown\"."
			}],
			"description":"Use <dcGatheringName> for status displays.",
			"references":{
				"handler":["dcGatheringState","dcStateName"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-7",
			"name":"dcformatbytes",
			"display name":"dcFormatBytes",
			"library":"dataChannelHelpers",
			"type":"function",
			"syntax":[
				"dcFormatBytes(<pBytes>)"
			],
			"display syntax":[
				"dcFormatBytes(<i>pBytes</i>)"
			],
			"associations":["datachannelhelpers"],
			"summary":"Format a byte count for display.",
			"parameters":[{
				"name":"pBytes",
				"type":"",
				"refparam":"false",
				"description":"A number of bytes."
			}],
			"examples":[{
				"script":"put dcFormatBytes(dcBufferedAmount(sChan)) into field \"Queued\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A short string such as \"512 B\", \"1.5 KiB\" or \"3.2 MiB\"; \"0 B\" when the value is empty or not a number."
			}],
			"description":"Use <dcFormatBytes> to show sizes such as a channel's buffered amount.\nIt rounds to one decimal place and uses B, KiB, MiB and GiB.",
			"references":{
				"handler":["dcBufferedAmount"]
			},
			"tags":["networking","library"]
		},{
			"id":"dataChannelHelpers-8",
			"name":"dcstoppolling",
			"display name":"dcStopPolling",
			"library":"dataChannelHelpers",
			"type":"command",
			"syntax":[
				"dcStopPolling"
			],
			"display syntax":[
				"dcStopPolling"
			],
			"associations":["datachannelhelpers"],
			"summary":"Stop the poll timer.",
			"examples":[{
				"script":"dcStopPolling\ndcCleanup"
			}],
			"description":"Use <dcStopPolling> before <dcCleanup> at quit, or whenever the app\nshould stop receiving event messages. It is safe to call when not\npolling. It stops delivery only: the native queue keeps buffering,\nbounded, until you poll again or clean up. It may be called from inside\nan event handler the timer dispatched.",
			"references":{
				"handler":["dcStartPolling","dcCleanup"]
			},
			"tags":["networking","library"]
		}