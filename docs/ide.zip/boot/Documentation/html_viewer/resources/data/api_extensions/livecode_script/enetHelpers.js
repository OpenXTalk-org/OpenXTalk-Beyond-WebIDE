{
			"id":"enetHelpers-1",
			"name":"enethelpers",
			"display name":"enetxt helpers",
			"library":"enetHelpers",
			"type":"library",
			"display syntax":[
				"enetxt helpers"
			],
			"associations":["enethelpers"],
			"description":"The poll pump and small helpers for enetxt. Put the enetHelpers stack in\nuse (start using stack \"enetHelpers\") and register each host with\n<enStartPolling>: a timer services every registered host with <enPoll>\nand sends one message per event to your card or object, so an app\nhandles plain messages instead of running its own pump.\n\nENet makes no progress unless it is pumped, so this timer is the\ntransport's heartbeat. The messages are enetConnect, enetDisconnect,\nenetReceive and enetError, each with the event array as its parameter,\nplus a catch-all enetEvent for every event."
		},{
			"id":"enetHelpers-2",
			"name":"enstoppolling",
			"display name":"enStopPolling",
			"library":"enetHelpers",
			"type":"command",
			"syntax":[
				"enStopPolling <pHost>"
			],
			"display syntax":[
				"enStopPolling <i>pHost</i>"
			],
			"associations":["enethelpers"],
			"summary":"Remove a host from the pump, or stop the pump entirely.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle to remove; empty stops pumping every host."
			}],
			"examples":[{
				"script":"enStopPolling sHost\nget enHostDestroy(sHost)"
			}],
			"description":"Use <enStopPolling> with a host when you are done with that host. A\nhost that is not pumped makes no progress at all: nothing connects,\nsends or receives. The timer stops when the last host is removed.\n\nThe pump is shared by every stack that uses the helpers, so an empty\nhost stops other stacks' hosts too; remove your own hosts one by one.\nIt may be called from inside an event handler the timer dispatched.",
			"references":{
				"handler":["enStartPolling","enHostDestroy"]
			},
			"tags":["networking","library"]
		},{
			"id":"enetHelpers-3",
			"name":"enpolllasterror",
			"display name":"enPollLastError",
			"library":"enetHelpers",
			"type":"function",
			"syntax":[
				"enPollLastError()"
			],
			"display syntax":[
				"enPollLastError()"
			],
			"associations":["enethelpers"],
			"summary":"The first failure the pump recorded since the last clear.",
			"examples":[{
				"script":"put enPollLastError() into tNote\nif tNote is not empty then put tNote & return after field \"Log\"\nenPollClearError"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Empty while the pump is healthy; otherwise a one-line description of the first failure."
			}],
			"description":"Use <enPollLastError> to find out why events stopped arriving. The pump\nnever stops on a failure; it records the first one instead, naming the\nhost for a failed poll or the event for a failed dispatch. It survives\na stop and restart; only <enPollClearError> clears it.",
			"references":{
				"handler":["enPollClearError","enStartPolling"]
			},
			"tags":["networking","library"]
		},{
			"id":"enetHelpers-4",
			"name":"enpollclearerror",
			"display name":"enPollClearError",
			"library":"enetHelpers",
			"type":"command",
			"syntax":[
				"enPollClearError"
			],
			"display syntax":[
				"enPollClearError"
			],
			"associations":["enethelpers"],
			"summary":"Clear the pump's recorded failure.",
			"examples":[{
				"script":"enPollClearError"
			}],
			"description":"Use <enPollClearError> after reading <enPollLastError>, so each\ndistinct failure is reported once.",
			"references":{
				"handler":["enPollLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"enetHelpers-5",
			"name":"enstartpolling",
			"display name":"enStartPolling",
			"library":"enetHelpers",
			"type":"command",
			"syntax":[
				"enStartPolling <pHost>,<pTarget>,<pIntervalMs>"
			],
			"display syntax":[
				"enStartPolling <i>pHost</i>,<i>pTarget</i>,<i>pIntervalMs</i>"
			],
			"associations":["enethelpers"],
			"summary":"Add a host to the pump and dispatch its events as messages.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle to service; empty or 0 is ignored."
			},{
				"name":"pTarget",
				"type":"",
				"refparam":"false",
				"description":"The object that receives the event messages; empty means the current card."
			},{
				"name":"pIntervalMs",
				"type":"",
				"refparam":"false",
				"description":"Milliseconds between pump passes; empty or less than 1 means 33."
			}],
			"examples":[{
				"script":"put enHostCreateServer(\"\", 27000, 32, 2, 0, 0) into sHost\nif sHost is not 0 then enStartPolling sHost, the long id of this card, 33"
			}],
			"description":"Use <enStartPolling> once for each host you create, server or client.\nEvery interval the timer calls <enPoll> on each registered host and\ndispatches each event to the target by its name (enetConnect,\nenetDisconnect, enetReceive or enetError), followed by a catch-all\nenetEvent message, each with the event array as its parameter.\n\nThe interval is the latency floor: 16 to 33 milliseconds feels\nreal-time, 100 or more is fine for chat. One target and one interval\nserve every host; the last call sets them. Registering a host twice has\nno effect, and only one timer ever runs. A failed poll or dispatch does\nnot stop the timer; it is recorded for <enPollLastError>.",
			"references":{
				"handler":["enStopPolling","enPoll","enPollLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"enetHelpers-6",
			"name":"enstatename",
			"display name":"enStateName",
			"library":"enetHelpers",
			"type":"function",
			"syntax":[
				"enStateName(<pState>)"
			],
			"display syntax":[
				"enStateName(<i>pState</i>)"
			],
			"associations":["enethelpers"],
			"summary":"A label for an ENet peer state number.",
			"parameters":[{
				"name":"pState",
				"type":"",
				"refparam":"false",
				"description":"The \"state\" value from <enPeerStatus>."
			}],
			"examples":[{
				"script":"put enPeerStatus(sPeer) into tStatus\nput enStateName(tStatus[\"state\"]) into field \"Status\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"disconnected\", \"connecting\", \"connected\", \"disconnecting\", \"zombie\", or \"unknown\"."
			}],
			"description":"Use <enStateName> for status displays. It folds ENet's ten states into\nfive labels: 1 to 4 are connecting, 5 is connected, and 6 to 8 are\ndisconnecting.",
			"references":{
				"handler":["enPeerStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"enetHelpers-7",
			"name":"enformatbytes",
			"display name":"enFormatBytes",
			"library":"enetHelpers",
			"type":"function",
			"syntax":[
				"enFormatBytes(<pBytes>)"
			],
			"display syntax":[
				"enFormatBytes(<i>pBytes</i>)"
			],
			"associations":["enethelpers"],
			"summary":"Format a byte count for display.",
			"parameters":[{
				"name":"pBytes",
				"type":"",
				"refparam":"false",
				"description":"A number of bytes."
			}],
			"examples":[{
				"script":"put enPeerStatus(sPeer) into tStatus\nput enFormatBytes(tStatus[\"bytesSent\"]) into field \"Sent\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A short string such as \"512 B\", \"1.5 KiB\" or \"3.2 MiB\"; \"0 B\" when the value is empty or not a number."
			}],
			"description":"Use <enFormatBytes> for dashboards. It rounds to one decimal place and\nuses B, KiB, MiB, GiB and TiB.",
			"references":{
				"handler":["enPeerStatus","enHostStatus"]
			},
			"tags":["networking","library"]
		}