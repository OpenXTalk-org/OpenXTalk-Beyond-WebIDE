{
			"id":"org.openxtalk.library.torrent-1",
			"name":"org.openxtalk.library.torrent",
			"display name":"TorrentXT",
			"library":"org.openxtalk.library.torrent",
			"type":"library",
			"display syntax":[
				"TorrentXT"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Bindings to libtorrent, the BitTorrent engine, for downloading, seeding and\nserverless peer contact.\n\nTorrentXT runs one libtorrent session per process. Start it with\n<btStartSession> and stop it with <btStopSession> before your app quits:\nthere is no automatic unload hook. Sessions and torrents are integer\nhandles; 0 means the call failed (see <btLastError>), and a stale handle is\na harmless no-op. Action handlers return 0 on success or a negative code.\n\nlibtorrent works on its own threads and never calls back into script.\nEvents wait in a queue until <btPoll> (and <btRp1Poll> for the rp1\nextension) drains them. The torrentHelpers library (btStartPolling) does\nthat on a timer and dispatches each event as a message named after it,\nsuch as metadataReceived or torrentFinished, plus a catch-all\ntorrentEvent.\n\nPayload never crosses into script: pieces move between the network and\ndisk inside libtorrent. 64-bit numbers and info-hashes come back as text.\nBesides plain downloads it covers the DHT (BEP 5 peers and the BEP 44\nkey-value store), UPnP / NAT-PMP port mapping, torrent creation and rp1, a\ncustom peer-wire extension that moves opaque bytes between peers.",
			"description":"Bindings to libtorrent, the BitTorrent engine, for downloading, seeding and\nserverless peer contact.\n\nTorrentXT runs one libtorrent session per process. Start it with\n<btStartSession> and stop it with <btStopSession> before your app quits:\nthere is no automatic unload hook. Sessions and torrents are integer\nhandles; 0 means the call failed (see <btLastError>), and a stale handle is\na harmless no-op. Action handlers return 0 on success or a negative code.\n\nlibtorrent works on its own threads and never calls back into script.\nEvents wait in a queue until <btPoll> (and <btRp1Poll> for the rp1\nextension) drains them. The torrentHelpers library (btStartPolling) does\nthat on a timer and dispatches each event as a message named after it,\nsuch as metadataReceived or torrentFinished, plus a catch-all\ntorrentEvent.\n\nPayload never crosses into script: pieces move between the network and\ndisk inside libtorrent. 64-bit numbers and info-hashes come back as text.\nBesides plain downloads it covers the DHT (BEP 5 peers and the BEP 44\nkey-value store), UPnP / NAT-PMP port mapping, torrent creation and rp1, a\ncustom peer-wire extension that moves opaque bytes between peers."
		},{
			"id":"org.openxtalk.library.torrent-2",
			"name":"btsaveresumedata",
			"display name":"btSaveResumeData",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSaveResumeData(<pTorrent>)"
			],
			"display syntax":[
				"btSaveResumeData(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Request resume data for a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btSaveResumeData tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the request was made, or a negative error code."
			}],
			"description":"Use <btSaveResumeData> before quitting or now and then, so the next launch\ncan skip hashing again. The data does not come back here: it arrives later\nas a resumeDataReady event whose resumeData key holds the bytes to save,\nor a resumeDataFailed event. Pass the saved bytes to\n<btAddTorrentWithResume>.",
			"references":{
				"handler":["btAddTorrentWithResume","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-3",
			"name":"btaddmagnet",
			"display name":"btAddMagnet",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddMagnet(<pSession>,<pURI>,<pSavePath>)"
			],
			"display syntax":[
				"btAddMagnet(<i>pSession</i>,<i>pURI</i>,<i>pSavePath</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a torrent from a magnet link.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pURI",
				"type":"",
				"refparam":"false",
				"description":"The magnet URI."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The folder to download into."
			}],
			"examples":[{
				"script":"btAddMagnet sSession, field \"magnet\", field \"savepath\"\nput the result into tH\nif tH is 0 then answer \"Add failed:\" && btLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddMagnet> to start a download from a magnet link. The torrent has\nno name or file list until its metadata arrives from peers, which a\nmetadataReceived event announces.\n\nTo add the torrent paused or with other flags, use <btAddMagnetEx>.",
			"references":{
				"handler":["btAddMagnetEx","btAddTorrentFile","btRemoveTorrent"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-4",
			"name":"btpiecebitfield",
			"display name":"btPieceBitfield",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btPieceBitfield(<pTorrent>)"
			],
			"display syntax":[
				"btPieceBitfield(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return which pieces of a torrent you have, one bit per piece.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"put btPieceBitfield(tH) into tBits\nput byteToNum(byte 1 of tBits) bitAnd 128 into tHaveFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Binary data with one bit per piece, or empty on a bad handle."
			}],
			"description":"Use <btPieceBitfield> to draw a piece map. Bits are packed most\nsignificant first: the top bit of the first byte is piece 0. Pair it with\n<btPieceAvailability> for a full map. This is a status view, never piece\ncontent.",
			"references":{
				"handler":["btPieceAvailability","btTorrentStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-5",
			"name":"btsetpiecedeadline",
			"display name":"btSetPieceDeadline",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetPieceDeadline(<pTorrent>,<pPieceIndex>,<pDeadlineMs>)"
			],
			"display syntax":[
				"btSetPieceDeadline(<i>pTorrent</i>,<i>pPieceIndex</i>,<i>pDeadlineMs</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Ask for a piece to arrive within a time limit, for streaming.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pPieceIndex",
				"type":"",
				"refparam":"false",
				"description":"The 0-based piece index."
			},{
				"name":"pDeadlineMs",
				"type":"",
				"refparam":"false",
				"description":"The deadline in milliseconds from now."
			}],
			"examples":[{
				"script":"repeat with tPiece from 0 to 9\n   btSetPieceDeadline tH, tPiece, 1000 + tPiece * 500\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetPieceDeadline> while playing media from a torrent. libtorrent\nreorders its requests so the soonest deadlines come first. Set deadlines\nacross the pieces you are about to play, and clear them with\n<btClearPieceDeadlines> after a seek.",
			"references":{
				"handler":["btClearPieceDeadlines","btSetSequentialDownload"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-6",
			"name":"btqueueposition",
			"display name":"btQueuePosition",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btQueuePosition(<pTorrent>)"
			],
			"display syntax":[
				"btQueuePosition(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a torrent's place in the download queue.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"put btQueuePosition(tH) into tPos\nif tPos is -1 then put \"not queued\" into tPos"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 0-based queue position, or -1 if the torrent is not queued or the handle is bad."
			}],
			"description":"Use <btQueuePosition> to show the queue order. This getter returns -1,\nnot 0, for no value, because 0 is the first real position.",
			"references":{
				"handler":["btQueueUp","btQueueTop","btSetAutoManaged"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-7",
			"name":"btqueuetop",
			"display name":"btQueueTop",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btQueueTop(<pTorrent>)"
			],
			"display syntax":[
				"btQueueTop(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Move a torrent to the top of the download queue.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btQueueTop tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btQueueTop> to make a torrent the next to run. The queue only matters\nfor auto-managed torrents.",
			"references":{
				"handler":["btQueueBottom","btQueueUp","btQueuePosition"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-8",
			"name":"btipfilterclear",
			"display name":"btIpFilterClear",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btIpFilterClear(<pSession>)"
			],
			"display syntax":[
				"btIpFilterClear(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Remove every IP filter rule.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"btIpFilterClear sSession"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btIpFilterClear> to return the filter to allowing every address.",
			"references":{
				"handler":["btIpFilterAdd"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-9",
			"name":"btdhtgetpeers",
			"display name":"btDhtGetPeers",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtGetPeers(<pSession>,<pId>)"
			],
			"display syntax":[
				"btDhtGetPeers(<i>pSession</i>,<i>pId</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Ask the DHT which peers announced an id.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pId",
				"type":"",
				"refparam":"false",
				"description":"The id to look up, as 40 hex characters."
			}],
			"examples":[{
				"script":"btDhtGetPeers sSession, tRendezvousHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the lookup started, or a negative error code."
			}],
			"description":"Use <btDhtGetPeers> for a classic BEP 5 get_peers lookup. The id need not\nbe a real torrent: any id both sides derive, for example from a shared\nsecret, works as a rendezvous point.\n\nThe answer arrives later as a dhtGetPeers event with keys target and\npeers, a return-separated list of ip:port entries (IPv6 addresses in\nsquare brackets).",
			"references":{
				"handler":["btDhtAnnounce","btAddInfohash","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-10",
			"name":"btqueuedown",
			"display name":"btQueueDown",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btQueueDown(<pTorrent>)"
			],
			"display syntax":[
				"btQueueDown(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Move a torrent one place down the download queue.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btQueueDown tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btQueueDown> to let other queued torrents go first. The queue only\nmatters for auto-managed torrents.",
			"references":{
				"handler":["btQueueUp","btQueueBottom","btQueuePosition"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-11",
			"name":"btcreatetorrent",
			"display name":"btCreateTorrent",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btCreateTorrent(<pContentPath>,<pPieceSize>,<pFlags>,<pTrackers>)"
			],
			"display syntax":[
				"btCreateTorrent(<i>pContentPath</i>,<i>pPieceSize</i>,<i>pFlags</i>,<i>pTrackers</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Build a .torrent file for a file or folder.",
			"parameters":[{
				"name":"pContentPath",
				"type":"",
				"refparam":"false",
				"description":"The file or folder to share."
			},{
				"name":"pPieceSize",
				"type":"",
				"refparam":"false",
				"description":"The piece size in bytes, or 0 to choose automatically."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"libtorrent create-torrent flags, passed through; 0 for the defaults."
			},{
				"name":"pTrackers",
				"type":"",
				"refparam":"false",
				"description":"Tracker announce URLs, one per line; empty for a DHT-only torrent."
			}],
			"examples":[{
				"script":"put btCreateTorrent(tFolder, 0, 0, \"udp://tr.example:1337/announce\") into tTorrent\nif tTorrent is empty then answer btLastError()\nput tTorrent into url (\"binfile:\" & tOutPath)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The bytes of the .torrent file, or empty on failure."
			}],
			"description":"Use <btCreateTorrent> to share your own content. It hashes the content,\nwhich can take a while for large files. Each tracker line becomes its own\ntier, in order.\n\nTo seed, add the bytes with <btAddTorrentFile>, saving into the folder\nthat holds the content.",
			"references":{
				"handler":["btAddTorrentFile","btInfoHash"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-12",
			"name":"btunsettorrentflags",
			"display name":"btUnsetTorrentFlags",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btUnsetTorrentFlags(<pTorrent>,<pFlags>)"
			],
			"display syntax":[
				"btUnsetTorrentFlags(<i>pTorrent</i>,<i>pFlags</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Clear libtorrent flag bits on a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"The bits to clear, as a decimal string."
			}],
			"examples":[{
				"script":"btUnsetTorrentFlags tH, \"512\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btUnsetTorrentFlags> to turn off the flags named in pFlags. The flag\nvalues are listed under <btSetTorrentFlags>. The example turns off\nsequential download.",
			"references":{
				"handler":["btSetTorrentFlags"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-13",
			"name":"btaddinfohash",
			"display name":"btAddInfohash",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddInfohash(<pSession>,<pInfoHash>,<pSavePath>)"
			],
			"display syntax":[
				"btAddInfohash(<i>pSession</i>,<i>pInfoHash</i>,<i>pSavePath</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Join a swarm from a bare info-hash, with no content.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pInfoHash",
				"type":"",
				"refparam":"false",
				"description":"The swarm id, as 40 hex characters."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"A folder for the torrent; nothing is downloaded into it."
			}],
			"examples":[{
				"script":"put btAddInfohash(sSession, tRendezvousHex, tSavePath) into tH\nbtDhtAnnounce sSession, tRendezvousHex, 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddInfohash> to make a meeting point for peers. libtorrent joins\nthe swarm and completes the BitTorrent handshake with peers, but never\nfetches metadata, so there is nothing to download.\n\nPair it with <btDhtAnnounce> and <btDhtGetPeers> on the same id, and with\nthe rp1 calls (<btRp1Enable> first), for contact between peers with no\ntracker, server or content.",
			"references":{
				"handler":["btRp1Enable","btDhtAnnounce","btDhtGetPeers"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-14",
			"name":"btsetsharemode",
			"display name":"btSetShareMode",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetShareMode(<pTorrent>,<pOn>)"
			],
			"display syntax":[
				"btSetShareMode(<i>pTorrent</i>,<i>pOn</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Turn share mode on or off for a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"true for share mode, false for normal mode."
			}],
			"examples":[{
				"script":"btSetShareMode tH, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetShareMode> to make a torrent aim at a good share ratio rather\nthan at completing the download. It sets or clears the share mode flag\nthrough <btSetTorrentFlags>.",
			"references":{
				"handler":["btSetTorrentFlags"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-15",
			"name":"btsetsuperseeding",
			"display name":"btSetSuperSeeding",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetSuperSeeding(<pTorrent>,<pOn>)"
			],
			"display syntax":[
				"btSetSuperSeeding(<i>pTorrent</i>,<i>pOn</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Turn super-seeding on or off for a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"true for super-seeding, false for normal seeding."
			}],
			"examples":[{
				"script":"btSetSuperSeeding tH, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetSuperSeeding> when you are the first seed of new content. It is\nonly meaningful on a complete torrent. It sets or clears the super seeding\nflag through <btSetTorrentFlags>.",
			"references":{
				"handler":["btSetTorrentFlags"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-16",
			"name":"btsetencryption",
			"display name":"btSetEncryption",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetEncryption(<pSession>,<pIn>,<pOut>,<pLevel>)"
			],
			"display syntax":[
				"btSetEncryption(<i>pSession</i>,<i>pIn</i>,<i>pOut</i>,<i>pLevel</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set the protocol encryption policy for peer connections.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pIn",
				"type":"",
				"refparam":"false",
				"description":"Policy for incoming connections: 0 forced, 1 enabled, 2 disabled."
			},{
				"name":"pOut",
				"type":"",
				"refparam":"false",
				"description":"Policy for outgoing connections: 0 forced, 1 enabled, 2 disabled."
			},{
				"name":"pLevel",
				"type":"",
				"refparam":"false",
				"description":"Allowed cipher level: 1 plaintext, 2 rc4, 3 both."
			}],
			"examples":[{
				"script":"btSetEncryption sSession, 1, 1, 3"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetEncryption> to set libtorrent's in_enc_policy, out_enc_policy\nand allowed_enc_level in one call. The example allows encryption both ways\nwith either cipher. You can also set the three keys one by one with\n<btSetInt>.",
			"references":{
				"handler":["btSetInt"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-17",
			"name":"btdhtloadstate",
			"display name":"btDhtLoadState",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtLoadState(<pSession>,<pData>)"
			],
			"display syntax":[
				"btDhtLoadState(<i>pSession</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Restore a saved DHT routing table.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes previously returned by btDhtSaveState."
			}],
			"examples":[{
				"script":"put url (\"binfile:\" & tStatePath) into tDhtState\nbtDhtLoadState sSession, tDhtState"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btDhtLoadState> at startup with the data from <btDhtSaveState>.\nEmpty data does nothing and returns 0.",
			"references":{
				"handler":["btDhtSaveState"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-18",
			"name":"btunmapport",
			"display name":"btUnmapPort",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btUnmapPort(<pSession>,<pMappingId>)"
			],
			"display syntax":[
				"btUnmapPort(<i>pSession</i>,<i>pMappingId</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Remove a router port mapping.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pMappingId",
				"type":"",
				"refparam":"false",
				"description":"The mapping id returned by btMapPort."
			}],
			"examples":[{
				"script":"btUnmapPort sSession, tMapId"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btUnmapPort> to withdraw a mapping made by <btMapPort>. A stale or\nunknown mapping id is a harmless no-op.",
			"references":{
				"handler":["btMapPort"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-19",
			"name":"btcleartorrenterror",
			"display name":"btClearTorrentError",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btClearTorrentError(<pTorrent>)"
			],
			"display syntax":[
				"btClearTorrentError(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Clear a torrent's error state so it can run again.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btClearTorrentError tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btClearTorrentError> after fixing the cause of a torrent error, such\nas a full disk or a permission problem. The error text is in the error key\nof <btTorrentStatus>. This is not <btClearError>, which clears the\nlibrary's last error message.",
			"references":{
				"handler":["btTorrentStatus","btClearError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-20",
			"name":"btsetfilepriority",
			"display name":"btSetFilePriority",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetFilePriority(<pTorrent>,<pFileIndex>,<pPriority>)"
			],
			"display syntax":[
				"btSetFilePriority(<i>pTorrent</i>,<i>pFileIndex</i>,<i>pPriority</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set the download priority of one file in a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pFileIndex",
				"type":"",
				"refparam":"false",
				"description":"The 0-based index of the file in the torrent's file list."
			},{
				"name":"pPriority",
				"type":"",
				"refparam":"false",
				"description":"0 to skip the file, 1 for normal, up to 7 for top priority."
			}],
			"examples":[{
				"script":"btSetFilePriority tH, 0, 7"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetFilePriority> to choose which files to download. The file list\nis only known once the torrent has metadata; see <btFileList>. To set\nevery file at once use <btSetFilePriorities>.",
			"references":{
				"handler":["btSetFilePriorities","btFileList","btSetPiecePriority"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-21",
			"name":"btremovewebseed",
			"display name":"btRemoveWebSeed",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRemoveWebSeed(<pTorrent>,<pUrl>)"
			],
			"display syntax":[
				"btRemoveWebSeed(<i>pTorrent</i>,<i>pUrl</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Remove a web seed from a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pUrl",
				"type":"",
				"refparam":"false",
				"description":"The URL of the web seed."
			}],
			"examples":[{
				"script":"btRemoveWebSeed tH, \"https://mirror.example/path/\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btRemoveWebSeed> to drop a web seed added with <btAddWebSeed> or\nlisted in the torrent.",
			"references":{
				"handler":["btAddWebSeed","btWebSeeds"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-22",
			"name":"btpoll",
			"display name":"btPoll",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btPoll(<pSession>)"
			],
			"display syntax":[
				"btPoll(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Collect every pending event from the session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"repeat for each element tEvent in btPoll(sSession)\n   if tEvent[\"name\"] is \"torrentFinished\" then answer \"Done:\" && tEvent[\"torrent\"]\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of event arrays, or an empty list when nothing is pending."
			}],
			"description":"Use <btPoll> on a timer for as long as the session lives; libtorrent never\ncalls back into script. Most apps let btStartPolling in the torrentHelpers\nlibrary do it, which dispatches each event as a message named after it.\n\nEach array has code, name (such as metadataReceived, pieceFinished,\ntorrentFinished, torrentError, resumeDataReady or dhtMutableItem), torrent\n(the handle it concerns, when there is one) and the event's own keys. rp1\nevents come from <btRp1Poll> instead.\n\nlibtorrent's alert queue has a size limit (the alert_queue_size setting).\nIf it filled between two drains and alerts were lost, the drain leaves a\nmessage starting \"alerts:\" in <btLastError>. Poll more often or raise the\nsetting with <btSetInt>.",
			"references":{
				"handler":["btRp1Poll","btLastError","btStartSession"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-23",
			"name":"btaddwebseed",
			"display name":"btAddWebSeed",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddWebSeed(<pTorrent>,<pUrl>)"
			],
			"display syntax":[
				"btAddWebSeed(<i>pTorrent</i>,<i>pUrl</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a web seed to a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pUrl",
				"type":"",
				"refparam":"false",
				"description":"The URL of the web seed."
			}],
			"examples":[{
				"script":"btAddWebSeed tH, \"https://mirror.example/path/\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btAddWebSeed> to add a plain web server that holds the torrent's\nfiles (BEP 19), so it can serve data alongside peers.",
			"references":{
				"handler":["btRemoveWebSeed","btWebSeeds"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-24",
			"name":"btrp1send",
			"display name":"btRp1Send",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRp1Send(<pSession>,<pPeer>,<pData>)"
			],
			"display syntax":[
				"btRp1Send(<i>pSession</i>,<i>pPeer</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Send one rp1 message to a peer.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer id from an rp1 event."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The message bytes, up to 60000."
			}],
			"examples":[{
				"script":"if tEvent[\"supportsRp1\"] is \"1\" then btRp1Send sSession, tEvent[\"peer\"], tHelloBytes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the message was queued, or a negative error code."
			}],
			"description":"Use <btRp1Send> to send opaque bytes to a peer; TorrentXT does not frame\nor read them. The message goes out on libtorrent's next tick for that\npeer, within about a second. In the example, tEvent is an rp1Handshake\nevent array.\n\nIt fails with -3 if the peer is unknown, gone or has not finished the rp1\nhandshake yet, or if the data is empty.",
			"references":{
				"handler":["btRp1Poll","btRp1Enable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-25",
			"name":"btpieceavailability",
			"display name":"btPieceAvailability",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btPieceAvailability(<pTorrent>)"
			],
			"display syntax":[
				"btPieceAvailability(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return how many peers have each piece of a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"put btPieceAvailability(tH) into tAvail\nput byteToNum(byte 1 of tAvail) into tPeersWithFirstPiece"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Binary data with one byte per piece, or empty."
			}],
			"description":"Use <btPieceAvailability> to draw a rarity map. Each byte counts the\nconnected peers that have that piece, up to 255. It is empty until the\ntorrent has metadata and peers. Pair it with <btPieceBitfield>.",
			"references":{
				"handler":["btPieceBitfield","btPeerList"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-26",
			"name":"btqueueup",
			"display name":"btQueueUp",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btQueueUp(<pTorrent>)"
			],
			"display syntax":[
				"btQueueUp(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Move a torrent one place up the download queue.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btQueueUp tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btQueueUp> to give a queued torrent a little more priority. The queue\nonly matters for auto-managed torrents.",
			"references":{
				"handler":["btQueueDown","btQueueTop","btQueuePosition"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-27",
			"name":"btscrapetracker",
			"display name":"btScrapeTracker",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btScrapeTracker(<pTorrent>)"
			],
			"display syntax":[
				"btScrapeTracker(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Ask the trackers for a torrent's seed and leecher counts.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btScrapeTracker tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the request was sent, or a negative error code."
			}],
			"description":"Use <btScrapeTracker> to refresh the swarm size. The answer arrives later\nas a scrapeReply event, and the counts appear as numComplete and\nnumIncomplete in <btTorrentStatus>.",
			"references":{
				"handler":["btTorrentStatus","btForceReannounce"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-28",
			"name":"btsessionresume",
			"display name":"btSessionResume",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSessionResume(<pSession>)"
			],
			"display syntax":[
				"btSessionResume(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Resume a paused session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"if btSessionIsPaused(sSession) then btSessionResume sSession"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSessionResume> to undo <btSessionPause>. It does not resume\ntorrents you paused one by one with <btPause>.",
			"references":{
				"handler":["btSessionPause","btSessionIsPaused"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-29",
			"name":"bttorrentcount",
			"display name":"btTorrentCount",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btTorrentCount(<pSession>)"
			],
			"display syntax":[
				"btTorrentCount(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return how many torrents the session holds.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"put btTorrentCount(sSession) into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of torrents."
			}],
			"description":"Use <btTorrentCount> with <btTorrentHandleAt> to walk every torrent in the\nsession.",
			"references":{
				"handler":["btTorrentHandleAt","btFindTorrent"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-30",
			"name":"btsettorrentlimits",
			"display name":"btSetTorrentLimits",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetTorrentLimits(<pTorrent>,<pDownBytesPerSec>,<pUpBytesPerSec>)"
			],
			"display syntax":[
				"btSetTorrentLimits(<i>pTorrent</i>,<i>pDownBytesPerSec</i>,<i>pUpBytesPerSec</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set a torrent's download and upload rate limits.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pDownBytesPerSec",
				"type":"",
				"refparam":"false",
				"description":"The download limit in bytes per second, as text; \"0\" means unlimited."
			},{
				"name":"pUpBytesPerSec",
				"type":"",
				"refparam":"false",
				"description":"The upload limit in bytes per second, as text; \"0\" means unlimited."
			}],
			"examples":[{
				"script":"btSetTorrentLimits tH, \"1000000\", \"0\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetTorrentLimits> to cap one torrent. The session-wide limits are\nthe download_rate_limit and upload_rate_limit settings, set with\n<btSetInt>.",
			"references":{
				"handler":["btSetInt","btSetMaxConnections"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-31",
			"name":"btaddtorrentfile",
			"display name":"btAddTorrentFile",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddTorrentFile(<pSession>,<pData>,<pSavePath>)"
			],
			"display syntax":[
				"btAddTorrentFile(<i>pSession</i>,<i>pData</i>,<i>pSavePath</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a torrent from the bytes of a .torrent file.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The contents of the .torrent file."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The folder to download into."
			}],
			"examples":[{
				"script":"put url (\"binfile:\" & tTorrentPath) into tBytes\nbtAddTorrentFile sSession, tBytes, tSavePath\nput the result into tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddTorrentFile> when you have the .torrent file itself. Read the\nfile as binary and pass its bytes. Empty data returns 0 at once, and a\nmalformed file fails with a reason in <btLastError>.",
			"references":{
				"handler":["btAddTorrentFileEx","btAddMagnet","btCreateTorrent"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-32",
			"name":"btpause",
			"display name":"btPause",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btPause(<pTorrent>)"
			],
			"display syntax":[
				"btPause(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Pause one torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btPause tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btPause> to stop a single torrent; a torrentPaused event follows.\nResume it with <btResume>. To pause everything use <btSessionPause>.",
			"references":{
				"handler":["btResume","btSessionPause"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-33",
			"name":"bttorrenthandleat",
			"display name":"btTorrentHandleAt",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btTorrentHandleAt(<pSession>,<pIndex>)"
			],
			"display syntax":[
				"btTorrentHandleAt(<i>pSession</i>,<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return the handle of the torrent at a position in the session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 0-based index."
			}],
			"examples":[{
				"script":"repeat with i = 0 to btTorrentCount(sSession) - 1\n   put btTorrentHandleAt(sSession, i) & return after tHandles\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torrent handle, or 0 for an index out of range."
			}],
			"description":"Use <btTorrentHandleAt> to enumerate the session's torrents, for example\nafter re-adding them at startup.",
			"references":{
				"handler":["btTorrentCount","btFindTorrent"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-34",
			"name":"btpeerlist",
			"display name":"btPeerList",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btPeerList(<pTorrent>)"
			],
			"display syntax":[
				"btPeerList(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a torrent's connected peers.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"repeat for each element tPeer in btPeerList(tH)\n   put tPeer[\"endpoint\"] && tPeer[\"client\"] & return after tText\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of arrays, one per peer, or an empty list on a bad handle."
			}],
			"description":"Use <btPeerList> to show who you are connected to. Each array has the keys\nendpoint (ip:port), client, downRate, upRate, progress (0 to 1) and flags.",
			"references":{
				"handler":["btTorrentStatus","btTrackers"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-35",
			"name":"btsettorrentflags",
			"display name":"btSetTorrentFlags",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetTorrentFlags(<pTorrent>,<pFlags>,<pMask>)"
			],
			"display syntax":[
				"btSetTorrentFlags(<i>pTorrent</i>,<i>pFlags</i>,<i>pMask</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set libtorrent flag bits on a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"The bits to set, as a decimal string."
			},{
				"name":"pMask",
				"type":"",
				"refparam":"false",
				"description":"The bits to touch, as a decimal string."
			}],
			"examples":[{
				"script":"btSetTorrentFlags tH, \"512\", \"512\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetTorrentFlags> to change any torrent_flags bit. Only the bits in\npMask change; each of them is set if it is also in pFlags. Add the values\nto combine flags: seed mode 1, upload mode 2, share mode 4, apply IP filter\n8, paused 16, auto managed 32, super seeding 256, sequential download 512,\nstop when ready 1024. The example turns on sequential download.\n\nThe named setters such as <btSetSequentialDownload> are built on this.",
			"references":{
				"handler":["btUnsetTorrentFlags","btSetSequentialDownload","btAddMagnetEx"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-36",
			"name":"btaddtracker",
			"display name":"btAddTracker",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddTracker(<pTorrent>,<pUrl>,<pTier>)"
			],
			"display syntax":[
				"btAddTracker(<i>pTorrent</i>,<i>pUrl</i>,<i>pTier</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a tracker to a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pUrl",
				"type":"",
				"refparam":"false",
				"description":"The tracker's announce URL."
			},{
				"name":"pTier",
				"type":"",
				"refparam":"false",
				"description":"The tier, where 0 is tried first."
			}],
			"examples":[{
				"script":"btAddTracker tH, \"udp://tracker.example:6969/announce\", 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btAddTracker> to give a torrent another tracker. A URL already in the\nlist is ignored.",
			"references":{
				"handler":["btTrackers","btForceReannounce"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-37",
			"name":"btsetuploadmode",
			"display name":"btSetUploadMode",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetUploadMode(<pTorrent>,<pOn>)"
			],
			"display syntax":[
				"btSetUploadMode(<i>pTorrent</i>,<i>pOn</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Turn upload-only mode on or off for a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"true to only upload, false to download as well."
			}],
			"examples":[{
				"script":"btSetUploadMode tH, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetUploadMode> to keep serving the pieces you have without\nrequesting any more. It sets or clears the upload mode flag through\n<btSetTorrentFlags>.",
			"references":{
				"handler":["btSetTorrentFlags"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-38",
			"name":"btfindtorrent",
			"display name":"btFindTorrent",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btFindTorrent(<pSession>,<pInfoHash>)"
			],
			"display syntax":[
				"btFindTorrent(<i>pSession</i>,<i>pInfoHash</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Find a torrent in the session by its info-hash.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pInfoHash",
				"type":"",
				"refparam":"false",
				"description":"The torrent's v1 info-hash as 40 hex characters."
			}],
			"examples":[{
				"script":"put btFindTorrent(sSession, tHashHex) into tH\nif tH is 0 then answer \"Not loaded.\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torrent handle, or 0 if the torrent is not in this session."
			}],
			"description":"Use <btFindTorrent> to recover a handle from a hash you stored earlier,\ninstead of keeping the integer handle around.",
			"references":{
				"handler":["btInfoHash","btTorrentHandleAt"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-39",
			"name":"btsessionpause",
			"display name":"btSessionPause",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSessionPause(<pSession>)"
			],
			"display syntax":[
				"btSessionPause(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Pause the whole session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"btSessionPause sSession"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSessionPause> to stop every torrent at once. To pause a single\ntorrent use <btPause> instead. Undo it with <btSessionResume>.",
			"references":{
				"handler":["btSessionResume","btSessionIsPaused","btPause"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-40",
			"name":"btlasterror",
			"display name":"btLastError",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btLastError()"
			],
			"display syntax":[
				"btLastError()"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return the text of the most recent error.",
			"examples":[{
				"script":"btAddMagnet sSession, tUri, tSavePath\nif the result is 0 then answer btLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The last error message, or empty when there is none."
			}],
			"description":"Use <btLastError> after a handler returns 0, a negative code or an empty\nvalue to learn why. The message is set by the most recent failed call and\nstays until <btClearError> or the next failure replaces it.\n\nAfter a drain, <btPoll> and <btRp1Poll> also leave a message here when\nevents were lost because a queue filled between two drains.",
			"references":{
				"handler":["btClearError","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-41",
			"name":"btaddtorrentwithresume",
			"display name":"btAddTorrentWithResume",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddTorrentWithResume(<pSession>,<pResume>,<pSavePath>)"
			],
			"display syntax":[
				"btAddTorrentWithResume(<i>pSession</i>,<i>pResume</i>,<i>pSavePath</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Re-add a torrent from saved resume data.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pResume",
				"type":"",
				"refparam":"false",
				"description":"The resume data bytes you saved from a resumeDataReady event."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The folder the torrent downloads into."
			}],
			"examples":[{
				"script":"put url (\"binfile:\" & tResumePath) into tResume\nbtAddTorrentWithResume sSession, tResume, tSavePath\nput the result into tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddTorrentWithResume> on the next launch to bring a torrent back\nwithout hashing the pieces it already has again. Get the data with\n<btSaveResumeData> and the resumeDataReady event it triggers. Empty data\nreturns 0 at once. If libtorrent rejects the data, a fastresumeRejected\nevent follows and the torrent is checked again.",
			"references":{
				"handler":["btSaveResumeData","btAddMagnet"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-42",
			"name":"btresume",
			"display name":"btResume",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btResume(<pTorrent>)"
			],
			"display syntax":[
				"btResume(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Resume a paused torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btResume tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btResume> to restart a torrent paused with <btPause> or added paused.\nA torrentResumed event follows.",
			"references":{
				"handler":["btPause","btAddMagnetEx"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-43",
			"name":"btclearerror",
			"display name":"btClearError",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btClearError()"
			],
			"display syntax":[
				"btClearError()"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Clear the last error message.",
			"examples":[{
				"script":"btClearError\nput btPoll(sSession) into tEvents\nput btLastError() into tWarning"
			}],
			"description":"Use <btClearError> before a call whose error you want to read on its own,\nsince the last error stays until something replaces it. It does not clear\na torrent's error state; that is <btClearTorrentError>.",
			"references":{
				"handler":["btLastError","btClearTorrentError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-44",
			"name":"btdhtaddbootstrap",
			"display name":"btDhtAddBootstrap",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtAddBootstrap(<pSession>,<pHost>,<pPort>)"
			],
			"display syntax":[
				"btDhtAddBootstrap(<i>pSession</i>,<i>pHost</i>,<i>pPort</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a DHT bootstrap node.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host name or address of the node."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"The node's UDP port."
			}],
			"examples":[{
				"script":"btDhtAddBootstrap sSession, \"router.bittorrent.com\", 6881"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btDhtAddBootstrap> to give the DHT a node to start from. Watch the\nnodes count of <btDhtState> climb from 0 as the routing table fills; a\ndhtBootstrap event reports when bootstrapping completes.",
			"references":{
				"handler":["btDhtState","btDhtLoadState"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-45",
			"name":"btdhtgetimmutable",
			"display name":"btDhtGetImmutable",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtGetImmutable(<pSession>,<pTarget>)"
			],
			"display syntax":[
				"btDhtGetImmutable(<i>pSession</i>,<i>pTarget</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Look up an immutable DHT item by its target.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pTarget",
				"type":"",
				"refparam":"false",
				"description":"The 40-hex target returned by btDhtPutImmutable."
			}],
			"examples":[{
				"script":"btDhtGetImmutable sSession, tTarget"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the lookup started, or a negative error code."
			}],
			"description":"Use <btDhtGetImmutable> to fetch a value published with\n<btDhtPutImmutable>. The value arrives later as a dhtImmutableItem event\nwith the keys target and value.",
			"references":{
				"handler":["btDhtPutImmutable","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-46",
			"name":"btsetint",
			"display name":"btSetInt",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetInt(<pSession>,<pKey>,<pValue>)"
			],
			"display syntax":[
				"btSetInt(<i>pSession</i>,<i>pKey</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set an integer session setting.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A libtorrent settings_pack name, such as \"download_rate_limit\"."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The value as decimal text, so 64-bit values pass without loss."
			}],
			"examples":[{
				"script":"btSetInt sSession, \"download_rate_limit\", \"5000000\"\nif the result is not 0 then answer btLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetInt> to change an integer setting of the running session.\nSettings apply at once. An unknown key fails with -3 and sets\n<btLastError>. Rate limits are bytes per second, and \"0\" means unlimited.",
			"references":{
				"handler":["btSetBool","btSetString","btGetSetting"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-47",
			"name":"btlistenport",
			"display name":"btListenPort",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btListenPort(<pSession>)"
			],
			"display syntax":[
				"btListenPort(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return the TCP port the session is listening on.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"put btListenPort(sSession) into tPort"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The port number, or 0 if the session is not listening yet or the handle is bad."
			}],
			"description":"Use <btListenPort> to learn the port libtorrent actually opened, which can\ndiffer from the one you asked for in listen_interfaces. A listenSucceeded\nevent reports the same thing when the socket opens.",
			"references":{
				"handler":["btSetString","btMapPort"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-48",
			"name":"btmapport",
			"display name":"btMapPort",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btMapPort(<pSession>,<pExternalPort>,<pLocalPort>,<pIsTcp>)"
			],
			"display syntax":[
				"btMapPort(<i>pSession</i>,<i>pExternalPort</i>,<i>pLocalPort</i>,<i>pIsTcp</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Ask the router to forward a port to this machine with UPnP or NAT-PMP.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pExternalPort",
				"type":"",
				"refparam":"false",
				"description":"The port to open on the router."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"The port on this machine to forward it to."
			},{
				"name":"pIsTcp",
				"type":"",
				"refparam":"false",
				"description":"true for TCP, false for UDP."
			}],
			"examples":[{
				"script":"put btMapPort(sSession, 8080, 8080, true) into tMapId\nif tMapId is 0 then answer \"No UPnP or NAT-PMP mapper is active.\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A mapping id greater than 0, or 0 if no mapper is active or the port is bad."
			}],
			"description":"Use <btMapPort> so others can reach a server on this machine without\nmanual port forwarding. UPnP or NAT-PMP must be enabled in the session.\n\nThe mapping happens later. A portMapped event reports the external port\nthe router actually assigned (it may differ) and which mapper won; a\nfailure arrives as portMapError, and the machine's external address as an\nexternalIp event. The address and port are public, so this path is not\nanonymous.",
			"references":{
				"handler":["btUnmapPort","btListenPort"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-49",
			"name":"btrp1poll",
			"display name":"btRp1Poll",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRp1Poll(<pSession>)"
			],
			"display syntax":[
				"btRp1Poll(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Collect pending rp1 events from the session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"repeat for each element tEvent in btRp1Poll(sSession)\n   if tEvent[\"name\"] is \"rp1Message\" then handleMessage tEvent[\"peer\"], tEvent[\"payload\"]\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of event arrays, or an empty list when nothing is pending."
			}],
			"description":"Use <btRp1Poll> on every poll tick alongside <btPoll>; btStartPolling in\nthe torrentHelpers library does both. The arrays have the same shape as\nbtPoll's: name, code, peer, infoHashV1 and the event's own keys. The names\nare rp1PeerConnected, rp1Handshake (btPeerId, endpoint, supportsRp1,\ntoken), rp1Message (payload) and rp1PeerDisconnected.\n\nEach call drains at most 64 KiB. The inbound queue is limited too; when it\noverflows, the newest events are dropped and the next drain leaves a\nmessage starting \"rp1:\" in <btLastError>.",
			"references":{
				"handler":["btPoll","btRp1Send","btRp1Enable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-50",
			"name":"btdhtstate",
			"display name":"btDhtState",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtState(<pSession>)"
			],
			"display syntax":[
				"btDhtState(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a snapshot of DHT health.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"put btDhtState(sSession) into tDht\nput \"DHT nodes:\" && tDht[\"nodes\"] into field \"dht\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the keys nodes, nodeCache, globalNodes and torrents, or an empty array on a bad handle."
			}],
			"description":"Use <btDhtState> to show whether the DHT is working. nodes is the number\nof nodes in the routing table, nodeCache the cached nodes, globalNodes an\nestimate of the whole DHT's size and torrents the torrents tracked.\n\nThe counts come from libtorrent's statistics, which are refreshed once per\n<btPoll>, so keep polling for them to change. A counter a libtorrent build\ndoes not provide stays 0.",
			"references":{
				"handler":["btDhtAddBootstrap","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-51",
			"name":"btaddmagnetex",
			"display name":"btAddMagnetEx",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddMagnetEx(<pSession>,<pURI>,<pSavePath>,<pFlags>,<pMask>)"
			],
			"display syntax":[
				"btAddMagnetEx(<i>pSession</i>,<i>pURI</i>,<i>pSavePath</i>,<i>pFlags</i>,<i>pMask</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a torrent from a magnet link with add-time flags.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pURI",
				"type":"",
				"refparam":"false",
				"description":"The magnet URI."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The folder to download into."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"The flag bits to set, as a decimal string."
			},{
				"name":"pMask",
				"type":"",
				"refparam":"false",
				"description":"The flag bits to touch, as a decimal string."
			}],
			"examples":[{
				"script":"put btAddMagnetEx(sSession, tUri, tSavePath, \"16\", \"16\") into tH\nbtSetFilePriority tH, 0, 7\nbtResume tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddMagnetEx> like <btAddMagnet> when the torrent must start with\ncertain libtorrent torrent_flags. Only the bits in pMask change; each of\nthem is set if it is also in pFlags. Add the flag values to combine them:\nseed mode 1, upload mode 2, share mode 4, apply IP filter 8, paused 16,\nauto managed 32, super seeding 256, sequential download 512, stop when\nready 1024.\n\nThe usual use is adding paused (16), so you can set file priorities before\nanything downloads.",
			"references":{
				"handler":["btAddMagnet","btAddTorrentFileEx","btSetTorrentFlags"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-52",
			"name":"bttrackers",
			"display name":"btTrackers",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btTrackers(<pTorrent>)"
			],
			"display syntax":[
				"btTrackers(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a torrent's trackers.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"repeat for each element tTracker in btTrackers(tH)\n   put tTracker[\"url\"] & return after tText\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of arrays, one per tracker, or an empty list on a bad handle."
			}],
			"description":"Use <btTrackers> to show a torrent's announce list. Each array has the\nkeys url, tier (0 is tried first), verified (1 once the tracker has\nanswered this session) and source (libtorrent's source bitmask).",
			"references":{
				"handler":["btAddTracker","btWebSeeds","btScrapeTracker"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-53",
			"name":"btrp1enable",
			"display name":"btRp1Enable",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRp1Enable(<pSession>)"
			],
			"display syntax":[
				"btRp1Enable(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Turn on the rp1 peer-wire extension for the session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"btRp1Enable sSession\nput btAddInfohash(sSession, tRendezvousHex, tSavePath) into tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btRp1Enable> before adding the swarms rp1 should apply to. It then\nadvertises rp1 on every torrent in the session. rp1 is a custom BEP 10\nextension that carries opaque bytes between peers; it is off until this\ncall, and calling it again does nothing.",
			"references":{
				"handler":["btRp1Send","btRp1Poll","btRp1SetToken"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-54",
			"name":"btqueuebottom",
			"display name":"btQueueBottom",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btQueueBottom(<pTorrent>)"
			],
			"display syntax":[
				"btQueueBottom(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Move a torrent to the bottom of the download queue.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btQueueBottom tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btQueueBottom> to make a torrent wait for all the others. The queue\nonly matters for auto-managed torrents.",
			"references":{
				"handler":["btQueueTop","btQueueDown","btQueuePosition"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-55",
			"name":"bttorrentstatus",
			"display name":"btTorrentStatus",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btTorrentStatus(<pTorrent>)"
			],
			"display syntax":[
				"btTorrentStatus(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a snapshot of a torrent's status.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"put btTorrentStatus(tH) into tStatus\nput tStatus[\"name\"] && round(tStatus[\"progress\"] * 100) & \"%\" into field \"status\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of status values, or an empty array on a bad handle."
			}],
			"description":"Use <btTorrentStatus> to refresh a dashboard. One call returns every\nvalue. Keys include name, state, progress (0 to 1), downloadRate,\nuploadRate, totalDone, totalWanted, totalSize, numPeers, numSeeds,\nsavePath, infoHashV1, infoHashV2, numPieces, pieceLength, isFinished,\nisSeeding, isPaused, error, eta and flags.\n\nEvery value is text; 64-bit totals stay exact that way. Turn state into a\nlabel with btStateName in the torrentHelpers library. Refresh a few times\na second at most, not on every pieceFinished event.",
			"references":{
				"handler":["btPeerList","btFileList","btInfoHash"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-56",
			"name":"btgetsetting",
			"display name":"btGetSetting",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btGetSetting(<pSession>,<pKey>)"
			],
			"display syntax":[
				"btGetSetting(<i>pSession</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Read a session setting back as text.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A libtorrent settings_pack name."
			}],
			"examples":[{
				"script":"put btGetSetting(sSession, \"connections_limit\") into tLimit"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The current value as text, or empty on a bad handle or unknown key."
			}],
			"description":"Use <btGetSetting> to check what a setting holds, whether it is an\ninteger, a boolean or a string. It is meant for diagnostics, not for a\ntimer loop.",
			"references":{
				"handler":["btSetInt","btSetBool","btSetString"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-57",
			"name":"btforcerecheck",
			"display name":"btForceRecheck",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btForceRecheck(<pTorrent>)"
			],
			"display syntax":[
				"btForceRecheck(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Check a torrent's data on disk against its piece hashes again.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btForceRecheck tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btForceRecheck> when files on disk may have changed outside the app.\nThe torrent goes back into the checking state while its pieces are hashed.",
			"references":{
				"handler":["btTorrentStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-58",
			"name":"btdhtgetmutable",
			"display name":"btDhtGetMutable",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtGetMutable(<pSession>,<pPublicKey>,<pSalt>)"
			],
			"display syntax":[
				"btDhtGetMutable(<i>pSession</i>,<i>pPublicKey</i>,<i>pSalt</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Look up a mutable DHT item by public key and salt.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pPublicKey",
				"type":"",
				"refparam":"false",
				"description":"The owner's 64-hex public key."
			},{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"The salt the item was stored under; empty for none."
			}],
			"examples":[{
				"script":"btDhtGetMutable sSession, tPublicKey, \"myapp\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the lookup started, or a negative error code."
			}],
			"description":"Use <btDhtGetMutable> to fetch a value published with <btDhtPutMutable> or\n<btDhtPutSigned>. It arrives later as a dhtMutableItem event with the keys\nvalue, seq, signature, salt, publicKey and authoritative.",
			"references":{
				"handler":["btDhtPutMutable","btDhtPutSigned","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-59",
			"name":"btaddtorrentfileex",
			"display name":"btAddTorrentFileEx",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btAddTorrentFileEx(<pSession>,<pData>,<pSavePath>,<pFlags>,<pMask>)"
			],
			"display syntax":[
				"btAddTorrentFileEx(<i>pSession</i>,<i>pData</i>,<i>pSavePath</i>,<i>pFlags</i>,<i>pMask</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add a torrent from .torrent bytes with add-time flags.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The contents of the .torrent file."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The folder to download into."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"The flag bits to set, as a decimal string."
			},{
				"name":"pMask",
				"type":"",
				"refparam":"false",
				"description":"The flag bits to touch, as a decimal string."
			}],
			"examples":[{
				"script":"put url (\"binfile:\" & tTorrentPath) into tBytes\nput btAddTorrentFileEx(sSession, tBytes, tSavePath, \"512\", \"512\") into tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive torrent handle, or 0 on failure."
			}],
			"description":"Use <btAddTorrentFileEx> like <btAddTorrentFile> when the torrent must\nstart with certain flags. The flags work as in <btAddMagnetEx>; the\nexample adds the torrent with sequential download (512) for streaming.\nEmpty data returns 0 at once.",
			"references":{
				"handler":["btAddTorrentFile","btAddMagnetEx"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-60",
			"name":"btsetpiecepriority",
			"display name":"btSetPiecePriority",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetPiecePriority(<pTorrent>,<pPieceIndex>,<pPriority>)"
			],
			"display syntax":[
				"btSetPiecePriority(<i>pTorrent</i>,<i>pPieceIndex</i>,<i>pPriority</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set the download priority of one piece.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pPieceIndex",
				"type":"",
				"refparam":"false",
				"description":"The 0-based piece index."
			},{
				"name":"pPriority",
				"type":"",
				"refparam":"false",
				"description":"0 to skip the piece, 1 for normal, up to 7 for top priority."
			}],
			"examples":[{
				"script":"btSetPiecePriority tH, 0, 7"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetPiecePriority> for fine control below the file level. For\nplayback in order, <btSetPieceDeadline> is usually the better tool.",
			"references":{
				"handler":["btSetFilePriority","btSetPieceDeadline"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-61",
			"name":"btsetstring",
			"display name":"btSetString",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetString(<pSession>,<pKey>,<pValue>)"
			],
			"display syntax":[
				"btSetString(<i>pSession</i>,<i>pKey</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set a text session setting.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A libtorrent settings_pack name, such as \"user_agent\" or \"listen_interfaces\"."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The new text value."
			}],
			"examples":[{
				"script":"btSetString sSession, \"listen_interfaces\", \"0.0.0.0:6881\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetString> for text settings such as the user agent or the listen\naddress list. Settings apply at once. An unknown key fails with -3 and\nsets <btLastError>.",
			"references":{
				"handler":["btSetInt","btSetBool","btGetSetting"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-62",
			"name":"btsetmaxuploads",
			"display name":"btSetMaxUploads",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetMaxUploads(<pTorrent>,<pMax>)"
			],
			"display syntax":[
				"btSetMaxUploads(<i>pTorrent</i>,<i>pMax</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Limit how many peers a torrent uploads to at once.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pMax",
				"type":"",
				"refparam":"false",
				"description":"The maximum number of unchoked upload slots."
			}],
			"examples":[{
				"script":"btSetMaxUploads tH, 6"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetMaxUploads> to cap the upload slots of one torrent.",
			"references":{
				"handler":["btSetMaxConnections","btSetTorrentLimits"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-63",
			"name":"btsetautomanaged",
			"display name":"btSetAutoManaged",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetAutoManaged(<pTorrent>,<pOn>)"
			],
			"display syntax":[
				"btSetAutoManaged(<i>pTorrent</i>,<i>pOn</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Let libtorrent queue, start and stop a torrent for you.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"true to make the torrent auto managed, false to manage it yourself."
			}],
			"examples":[{
				"script":"btSetAutoManaged tH, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetAutoManaged> to put a torrent under libtorrent's queue. The\nqueue handlers such as <btQueueUp> only matter for auto-managed torrents.\nIt sets or clears the auto managed flag through <btSetTorrentFlags>.",
			"references":{
				"handler":["btSetTorrentFlags","btQueuePosition"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-64",
			"name":"btforcereannounce",
			"display name":"btForceReannounce",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btForceReannounce(<pTorrent>)"
			],
			"display syntax":[
				"btForceReannounce(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Announce a torrent to its trackers and the DHT now.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btForceReannounce tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btForceReannounce> sparingly, for example after a network change.\nA trackerReply event follows on success, or trackerError on failure.",
			"references":{
				"handler":["btScrapeTracker","btTrackers"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-65",
			"name":"btremovetorrent",
			"display name":"btRemoveTorrent",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRemoveTorrent(<pSession>,<pTorrent>,<pDeleteFiles>)"
			],
			"display syntax":[
				"btRemoveTorrent(<i>pSession</i>,<i>pTorrent</i>,<i>pDeleteFiles</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Remove a torrent from the session.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pDeleteFiles",
				"type":"",
				"refparam":"false",
				"description":"true to delete the downloaded files too, false to keep them."
			}],
			"examples":[{
				"script":"btRemoveTorrent sSession, tH, false"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btRemoveTorrent> to stop and drop a torrent. A torrentRemoved event\nfollows when removal finishes, and the handle goes stale. With\npDeleteFiles set to true the downloaded files are deleted from disk, so\nuse it with care.",
			"references":{
				"handler":["btAddMagnet","btPause"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-66",
			"name":"btstopsession",
			"display name":"btStopSession",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btStopSession(<pSession>)"
			],
			"display syntax":[
				"btStopSession(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Stop the session and release its threads.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle from btStartSession."
			}],
			"examples":[{
				"script":"btStopPolling\nbtStopSession sSession"
			}],
			"description":"Use <btStopSession> before your app quits; call it from closeStack. It\npauses the session, flushes resume data, destroys it and joins\nlibtorrent's background threads. There is no automatic unload hook, so a\nsession that is never stopped leaks at quit.\n\nIt is idempotent: a second call, or a stale handle, does nothing. It\nreturns nothing.",
			"references":{
				"handler":["btStartSession"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-67",
			"name":"btdhtputmutable",
			"display name":"btDhtPutMutable",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtPutMutable(<pSession>,<pPublicKey>,<pSecretKey>,<pSalt>,<pData>)"
			],
			"display syntax":[
				"btDhtPutMutable(<i>pSession</i>,<i>pPublicKey</i>,<i>pSecretKey</i>,<i>pSalt</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Store a signed, updatable item in the DHT.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pPublicKey",
				"type":"",
				"refparam":"false",
				"description":"The 64-hex public key from btDhtKeypair."
			},{
				"name":"pSecretKey",
				"type":"",
				"refparam":"false",
				"description":"The 128-hex secret key from btDhtKeypair."
			},{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"An optional salt that names one item under the key; empty for none."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The value, 1 to 996 bytes."
			}],
			"examples":[{
				"script":"put btDhtKeypair(tSeed) into tKey\nbtDhtPutMutable sSession, tKey[\"publicKey\"], tKey[\"secretKey\"], \"myapp\", tBytes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btDhtPutMutable> to publish a value only the keyholder can update\n(BEP 44). The native layer signs it and raises the sequence number, so\nputting again under the same key and salt publishes a new version.\n\nThe value limit is 996 raw bytes, as for <btDhtPutImmutable>; empty data\nreturns -3. The store confirms later as a dhtPut event. To sign outside\nthis library, use <btDhtPutSigned>.",
			"references":{
				"handler":["btDhtGetMutable","btDhtKeypair","btDhtPutSigned"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-68",
			"name":"btdhtannounce",
			"display name":"btDhtAnnounce",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtAnnounce(<pSession>,<pInfoHash>,<pPort>)"
			],
			"display syntax":[
				"btDhtAnnounce(<i>pSession</i>,<i>pInfoHash</i>,<i>pPort</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Announce on the DHT that we serve peers for an info-hash.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pInfoHash",
				"type":"",
				"refparam":"false",
				"description":"The info-hash or rendezvous id, as 40 hex characters."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"The port to announce, or 0 for our listen port."
			}],
			"examples":[{
				"script":"btDhtAnnounce sSession, tHashHex, 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btDhtAnnounce> for a classic BEP 5 announce, so others can find you\nthrough the DHT. This is the peer announce, not the BEP 44 key-value\nstore. The DHT must be enabled. Other peers find you with <btDhtGetPeers>\non the same id.",
			"references":{
				"handler":["btDhtGetPeers","btAddInfohash"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-69",
			"name":"btfilelist",
			"display name":"btFileList",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btFileList(<pTorrent>)"
			],
			"display syntax":[
				"btFileList(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return the files of a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"repeat for each element tFile in btFileList(tH)\n   put tFile[\"path\"] && tFile[\"size\"] & return after tText\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of arrays, one per file, or an empty list."
			}],
			"description":"Use <btFileList> to show a torrent's files or pick which to download. Each\narray has the keys path (relative to the torrent), size in bytes, progress\n(bytes of that file downloaded) and priority (0 to 7). Files are in the\norder <btSetFilePriority> indexes them, from 0.\n\nThe list is empty until the torrent has metadata, so for a magnet it also\ntells you whether metadata has arrived.",
			"references":{
				"handler":["btSetFilePriority","btSetFilePriorities","btTorrentStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-70",
			"name":"btdhtsavestate",
			"display name":"btDhtSaveState",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtSaveState(<pSession>)"
			],
			"display syntax":[
				"btDhtSaveState(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return the DHT routing table so it can be saved.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"put btDhtSaveState(sSession) into tDhtState\nif tDhtState is not empty then put tDhtState into url (\"binfile:\" & tStatePath)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Binary DHT state, or empty on failure."
			}],
			"description":"Use <btDhtSaveState> before quitting, and pass the bytes to\n<btDhtLoadState> on the next launch so the DHT starts warm instead of\nbootstrapping from scratch. Treat the data as opaque.",
			"references":{
				"handler":["btDhtLoadState","btDhtAddBootstrap"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-71",
			"name":"btsetfilepriorities",
			"display name":"btSetFilePriorities",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetFilePriorities(<pTorrent>,<pPriorities>)"
			],
			"display syntax":[
				"btSetFilePriorities(<i>pTorrent</i>,<i>pPriorities</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set the download priority of every file in a torrent at once.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pPriorities",
				"type":"",
				"refparam":"false",
				"description":"One priority byte (0 to 7) per file, in file order."
			}],
			"examples":[{
				"script":"put empty into tBytes\nrepeat for each element tFile in btFileList(tH)\n   put numToByte(7) after tBytes\nend repeat\nbtSetFilePriorities tH, tBytes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetFilePriorities> instead of many <btSetFilePriority> calls. Each\nbyte is the priority of the file at that position. Empty data does nothing\nand returns 0.",
			"references":{
				"handler":["btSetFilePriority","btFileList"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-72",
			"name":"btstartsession",
			"display name":"btStartSession",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btStartSession()"
			],
			"display syntax":[
				"btStartSession()"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Start the one libtorrent session and return its handle.",
			"examples":[{
				"script":"btStartSession\nput the result into sSession\nif sSession is 0 then answer \"TorrentXT failed:\" && btLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive session handle, or 0 on failure."
			}],
			"description":"Use <btStartSession> once, typically on openStack, before any other call\nthat takes a session. Only one session may be live in the process at a\ntime; a second call while one is live returns 0 and sets <btLastError>.\n\nIt first checks that the loaded native library matches this binding. On a\nmismatch it throws an error asking you to rebuild and repackage the\nnative library. This is the only handler in the library that throws.\n\nPair it with <btStopSession> before your app quits.",
			"references":{
				"handler":["btStopSession","btLastError","btPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-73",
			"name":"btinfohash",
			"display name":"btInfoHash",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btInfoHash(<pTorrent>)"
			],
			"display syntax":[
				"btInfoHash(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a torrent's info-hash as hex.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"put btInfoHash(tH) into tHashHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The v1 info-hash in lower-case hex (the v2 hash if there is no v1), or empty on a bad handle."
			}],
			"description":"Use <btInfoHash> to get a stable id for a torrent, for example to store it\nand find the torrent again later with <btFindTorrent>.",
			"references":{
				"handler":["btFindTorrent","btTorrentStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-74",
			"name":"btdhtkeypair",
			"display name":"btDhtKeypair",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtKeypair(<pSeed>)"
			],
			"display syntax":[
				"btDhtKeypair(<i>pSeed</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Create or re-derive an ed25519 keypair for mutable DHT items.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"Empty to make a new keypair, or a 64-hex seed to re-derive one."
			}],
			"examples":[{
				"script":"put btDhtKeypair(\"\") into tKey\nput tKey[\"seed\"] into url (\"file:\" & tSeedPath)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the hex keys publicKey, secretKey and seed, or an empty array on failure."
			}],
			"description":"Use <btDhtKeypair> to get the key that owns your mutable items. The same\nseed always gives the same keypair, so save the seed (or the secret key)\nto keep one identity across launches. publicKey is 64 hex characters,\nsecretKey 128 and seed 64.",
			"references":{
				"handler":["btDhtPutMutable","btDhtGetMutable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-75",
			"name":"btclearpiecedeadlines",
			"display name":"btClearPieceDeadlines",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btClearPieceDeadlines(<pTorrent>)"
			],
			"display syntax":[
				"btClearPieceDeadlines(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Remove all piece deadlines from a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"btClearPieceDeadlines tH"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btClearPieceDeadlines> to drop the deadlines set with\n<btSetPieceDeadline>, for example when playback stops or seeks.",
			"references":{
				"handler":["btSetPieceDeadline"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-76",
			"name":"btsetmaxconnections",
			"display name":"btSetMaxConnections",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetMaxConnections(<pTorrent>,<pMax>)"
			],
			"display syntax":[
				"btSetMaxConnections(<i>pTorrent</i>,<i>pMax</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Limit how many peer connections a torrent may have.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pMax",
				"type":"",
				"refparam":"false",
				"description":"The maximum, 2 or more, or -1 for unlimited."
			}],
			"examples":[{
				"script":"btSetMaxConnections tH, 80"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetMaxConnections> to cap one torrent's connections. The\nsession-wide cap is the connections_limit setting.",
			"references":{
				"handler":["btSetMaxUploads","btSetTorrentLimits"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-77",
			"name":"btdhtputimmutable",
			"display name":"btDhtPutImmutable",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtPutImmutable(<pSession>,<pData>)"
			],
			"display syntax":[
				"btDhtPutImmutable(<i>pSession</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Store an immutable item in the DHT.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The value, 1 to 996 bytes."
			}],
			"examples":[{
				"script":"put btDhtPutImmutable(sSession, tBytes) into tTarget\nif tTarget is empty then answer btLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The item's target hash in hex, or empty on failure."
			}],
			"description":"Use <btDhtPutImmutable> to publish a small value that never changes\n(BEP 44). The item is addressed by the hash of its value, so anyone with\nthe target can fetch it with <btDhtGetImmutable>.\n\nThe limit is 996 raw bytes: BEP 44 caps the encoded value at 1000 bytes,\nand the encoding adds up to 4. Empty data returns empty. The store\nconfirms later as a dhtPut event.",
			"references":{
				"handler":["btDhtGetImmutable","btDhtPutMutable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-78",
			"name":"btsessionispaused",
			"display name":"btSessionIsPaused",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSessionIsPaused(<pSession>)"
			],
			"display syntax":[
				"btSessionIsPaused(<i>pSession</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Report whether the session is paused.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			}],
			"examples":[{
				"script":"if btSessionIsPaused(sSession) then put \"Paused\" into field \"status\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the session is paused, false otherwise or when there is no session."
			}],
			"description":"Use <btSessionIsPaused> to show or toggle the session-wide pause state set\nby <btSessionPause>.",
			"references":{
				"handler":["btSessionPause","btSessionResume"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-79",
			"name":"btsetsequentialdownload",
			"display name":"btSetSequentialDownload",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetSequentialDownload(<pTorrent>,<pOn>)"
			],
			"display syntax":[
				"btSetSequentialDownload(<i>pTorrent</i>,<i>pOn</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Turn in-order download on or off for a torrent.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"true to download pieces in order, false for the normal order."
			}],
			"examples":[{
				"script":"btSetSequentialDownload tH, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetSequentialDownload> to stream a file while it downloads. It sets\nor clears the sequential download flag through <btSetTorrentFlags>.",
			"references":{
				"handler":["btSetTorrentFlags","btSetPieceDeadline"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-80",
			"name":"btsetbool",
			"display name":"btSetBool",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btSetBool(<pSession>,<pKey>,<pValue>)"
			],
			"display syntax":[
				"btSetBool(<i>pSession</i>,<i>pKey</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set a true/false session setting.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A libtorrent settings_pack name, such as \"enable_dht\"."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"true or false."
			}],
			"examples":[{
				"script":"btSetBool sSession, \"enable_dht\", true\nbtSetBool sSession, \"enable_lsd\", true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btSetBool> to switch a session feature on or off, for example the\nDHT, local service discovery, UPnP or NAT-PMP. Settings apply at once. An\nunknown key fails with -3 and sets <btLastError>.",
			"references":{
				"handler":["btSetInt","btSetString","btGetSetting"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-81",
			"name":"btipfilteradd",
			"display name":"btIpFilterAdd",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btIpFilterAdd(<pSession>,<pStartIp>,<pEndIp>,<pBlock>)"
			],
			"display syntax":[
				"btIpFilterAdd(<i>pSession</i>,<i>pStartIp</i>,<i>pEndIp</i>,<i>pBlock</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Add an IP address range rule to the session's filter.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pStartIp",
				"type":"",
				"refparam":"false",
				"description":"The first address of the range."
			},{
				"name":"pEndIp",
				"type":"",
				"refparam":"false",
				"description":"The last address of the range, of the same family as the first."
			},{
				"name":"pBlock",
				"type":"",
				"refparam":"false",
				"description":"true to block the range, false to allow it."
			}],
			"examples":[{
				"script":"btIpFilterAdd sSession, \"1.2.3.0\", \"1.2.3.255\", true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btIpFilterAdd> to keep peers in an address range from connecting.\nThe range is inclusive, and both ends must be IPv4 or both IPv6. Rules\nadd up; an empty filter allows everything. Clear them all with\n<btIpFilterClear>.",
			"references":{
				"handler":["btIpFilterClear"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-82",
			"name":"btdhtbep44signbuf",
			"display name":"btDhtBep44SignBuf",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtBep44SignBuf(<pSalt>,<pSeq>,<pValue>)"
			],
			"display syntax":[
				"btDhtBep44SignBuf(<i>pSalt</i>,<i>pSeq</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Build the exact bytes to sign for a BEP 44 mutable item.",
			"parameters":[{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"The salt; empty for none."
			},{
				"name":"pSeq",
				"type":"",
				"refparam":"false",
				"description":"The sequence number as decimal text."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The value, already bencoded."
			}],
			"examples":[{
				"script":"put btDhtBep44SignBuf(\"rp-prekeys\", \"1\", tValue) into tToSign\n-- sign tToSign with your own ed25519 key, then:\nbtDhtPutSigned sSession, tPublicKey, \"rp-prekeys\", \"1\", tValue, tSignatureHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The bytes to sign, or empty on failure."
			}],
			"description":"Use <btDhtBep44SignBuf> when the signing key must stay in another library,\nfor example a SodiumXT identity key. Sign the returned bytes with an\ned25519 detached signature and pass the signature to <btDhtPutSigned>, so\nno secret key ever reaches TorrentXT.\n\nUnlike <btDhtPutMutable>, pValue must already be bencoded, and it may be up\nto 1000 bytes.",
			"references":{
				"handler":["btDhtPutSigned","btDhtPutMutable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-83",
			"name":"btdhtputsigned",
			"display name":"btDhtPutSigned",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btDhtPutSigned(<pSession>,<pPublicKey>,<pSalt>,<pSeq>,<pValue>,<pSignature>)"
			],
			"display syntax":[
				"btDhtPutSigned(<i>pSession</i>,<i>pPublicKey</i>,<i>pSalt</i>,<i>pSeq</i>,<i>pValue</i>,<i>pSignature</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Store a mutable DHT item signed outside this library.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pPublicKey",
				"type":"",
				"refparam":"false",
				"description":"The signer's 64-hex ed25519 public key."
			},{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"The salt; empty for none."
			},{
				"name":"pSeq",
				"type":"",
				"refparam":"false",
				"description":"The sequence number as decimal text."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The value, already bencoded, exactly as signed."
			},{
				"name":"pSignature",
				"type":"",
				"refparam":"false",
				"description":"The 128-hex ed25519 signature over the bytes from btDhtBep44SignBuf."
			}],
			"examples":[{
				"script":"put btDhtBep44SignBuf(\"rp-prekeys\", \"1\", tValue) into tToSign\n-- sign tToSign elsewhere, then:\nbtDhtPutSigned sSession, tPublicKey, \"rp-prekeys\", \"1\", tValue, tSignatureHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btDhtPutSigned> with <btDhtBep44SignBuf> to publish under a key that\nnever enters this library. The value is stored as given, so it matches\nwhat was signed. The signature is checked against the public key first:\na bad signature returns -3 here instead of vanishing on the network, and\nempty data returns -3 too. The store confirms later as a dhtPut event.",
			"references":{
				"handler":["btDhtBep44SignBuf","btDhtGetMutable","btDhtPutMutable"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-84",
			"name":"btwebseeds",
			"display name":"btWebSeeds",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btWebSeeds(<pTorrent>)"
			],
			"display syntax":[
				"btWebSeeds(<i>pTorrent</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Return a torrent's web seeds.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			}],
			"examples":[{
				"script":"repeat for each element tUrl in btWebSeeds(tH)\n   put tUrl & return after tText\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of URL strings, or an empty list on a bad handle."
			}],
			"description":"Use <btWebSeeds> to list the HTTP seeds of a torrent. Unlike\n<btTrackers>, each element is a plain URL, not an array.",
			"references":{
				"handler":["btAddWebSeed","btRemoveWebSeed","btTrackers"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-85",
			"name":"btrp1settoken",
			"display name":"btRp1SetToken",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btRp1SetToken(<pSession>,<pToken>)"
			],
			"display syntax":[
				"btRp1SetToken(<i>pSession</i>,<i>pToken</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Set the token sent to peers in the rp1 handshake.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle."
			},{
				"name":"pToken",
				"type":"",
				"refparam":"false",
				"description":"The token bytes; empty to clear it."
			}],
			"examples":[{
				"script":"btRp1SetToken sSession, tSignedToken"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error code."
			}],
			"description":"Use <btRp1SetToken> to tell peers who you are, for example with a signed\nrecognition token. It goes out in the rp1_tok field of handshakes made\nafter this call. A peer's own token appears as the token key of its\nrp1Handshake event. rp1 must be enabled with <btRp1Enable>.",
			"references":{
				"handler":["btRp1Enable","btRp1Poll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.torrent-86",
			"name":"btmovestorage",
			"display name":"btMoveStorage",
			"library":"org.openxtalk.library.torrent",
			"type":"handler",
			"syntax":[
				"btMoveStorage(<pTorrent>,<pSavePath>)"
			],
			"display syntax":[
				"btMoveStorage(<i>pTorrent</i>,<i>pSavePath</i>)"
			],
			"associations":["org.openxtalk.library.torrent"],
			"summary":"Move a torrent's downloaded files to another folder.",
			"parameters":[{
				"name":"pTorrent",
				"type":"",
				"refparam":"false",
				"description":"The torrent handle."
			},{
				"name":"pSavePath",
				"type":"",
				"refparam":"false",
				"description":"The new folder."
			}],
			"examples":[{
				"script":"btMoveStorage tH, \"/mnt/big/downloads\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 if the move was started, or a negative error code."
			}],
			"description":"Use <btMoveStorage> to relocate a torrent's data. The move happens inside\nlibtorrent; a storageMoved event reports success and a fileError event\nreports failure.",
			"references":{
				"handler":["btTorrentStatus"]
			},
			"tags":["networking","library"]
		}