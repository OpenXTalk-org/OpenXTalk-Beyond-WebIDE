# TinySynth Player: OpenXTalk LCB widget (native layer, power switch)

A separate, self-contained widget: **webaudio-tinysynth + glue are embedded inside the one `.lcb` file** as
base64. No soundfont, no WASM, no external files. The widget's UI is a single **power switch** (an SVG power
symbol) that is attached as the widget's *native layer*; pressing it is a real DOM click, which is what lets the
browser start audio.

```
src/widget.template.lcb   widget source (properties, handlers, native layer, events)
src/glue.js               per-widget JS instance: the switch element + player (embedded in the payload)
build-widget.mjs          builds the single self-contained .lcb
test/                     mock library + end-to-end test of the glue (node test/run-test.mjs)
example/                  sample generated output (built from the MOCK library, only to show the shape)
```

## Build

1. Get the library (Apache-2.0): `webaudio-tinysynth.min.js` from https://github.com/g200kg/webaudio-tinysynth
   (or `https://cdn.jsdelivr.net/npm/webaudio-tinysynth`).
2. `node build-widget.mjs webaudio-tinysynth.min.js` -> `tinysynth-player.lcb`
3. Install/compile that file as an extension like any other LCB widget.

## How it works

* On create, the widget decodes the embedded payload in LCB (base64 -> Data -> UTF-8), injects it into the outermost
  page once (a global `window.XTalkTiny`), then calls `XTalkTiny.create()` for **its own** player instance
  (several widgets = several independent synths).
* The instance's switch element is converted with `PointerFromJSObject` and set as `my native layer`.
* **Power off**: no audio context running. **Power on** (click): the synth is created inside the click, the audio
  context resumes, and any loaded MIDI is handed to the synth. Power off stops playback, silences all channels and
  suspends the audio context.
* `play` while powered off is remembered: the switch flashes, a `needPower` event is posted, and playback starts
  the moment the user presses the switch.

## Properties

| property | notes |
|---|---|
| `midi` | base64 text, `data:` URL, or a URL of a `.mid`; can be set while powered off |
| `volume` 0..1, `reverb` 0..1, `quality` 0/1, `loop`, `onColor` | settings (TinySynth: quality 0 = chiptune, 1 = FM) |
| `powered`, `playing` | settable, but audio only starts after a real click on the switch |
| `position`, `length` | read-only, in **ticks** (TinySynth reports ticks, not seconds) |
| `status` | `off` / `ready` / `loaded` / `playing` / `paused` |

Commands: `PowerOn`, `PowerOff`, `Play`, `Pause`, `Stop`, `SeekTicks n`. Pause is implemented as stop + remembered
tick (TinySynth has no pause).

Event message to the widget's script: `on tinySynthEvent pName, pDetail`, where `pName` is one of
`powerOn`, `powerOff`, `needPower`, `loaded`, `playing`, `paused`, `stopped`, `ended`, `error`.

```
on tinySynthEvent pName, pDetail
   if pName is "ended" then ... next track
end tinySynthEvent

set the midi of widget "synth" to base64Encode(tMidiVar)   -- MIDI bytes held in an xTalk variable
set the loop of widget "synth" to true
set the playing of widget "synth" to true                   -- plays once the user has pressed the switch
```

## Status / unverified

* Tested: the generated payload round-trips and the glue (power, pending play, pause/resume, ended, volume, quality,
  suspend) passes 21 checks against a **mock** of the TinySynth API from its README (`node test/run-test.mjs`).
* **Not** tested: the real webaudio-tinysynth file (I did not have it offline), a real browser, or compiling the LCB.
* LCB lines marked `UNVERIFIED`: `base64 decode <string>` and `decode <data> using "utf-8"`. Also unchecked: the
  `post ... with [...]` form, `formatted as string` / `parsed as number`, that public handlers (`Play` etc.) are
  callable from xTalk, and that the engine sizes the native layer to the widget rect.
* Inline script injection can be blocked by a strict page CSP (`script-src` without `'unsafe-inline'`).
* Keep the TinySynth license notice (Apache-2.0, (c) g200kg) when redistributing the built file.
