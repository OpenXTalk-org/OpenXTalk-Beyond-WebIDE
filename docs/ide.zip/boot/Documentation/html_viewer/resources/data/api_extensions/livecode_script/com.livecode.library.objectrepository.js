{
			"id":"com.livecode.library.objectrepository-1",
			"name":"com.livecode.library.objectrepository",
			"display name":"Object Repository Library",
			"library":"com.livecode.library.objectrepository",
			"type":"library",
			"display syntax":[
				"Object Repository Library"
			],
			"associations":["com.livecode.library.objectrepository"],
			"summary":"This library provides support persistent object references within a session",
			"description":"This library provides support persistent object references within a session"
		},{
			"id":"com.livecode.library.objectrepository-2",
			"name":"objectrepositorystore",
			"display name":"objectRepositoryStore",
			"library":"com.livecode.library.objectrepository",
			"type":"handler",
			"syntax":[
				"objectRepositoryStore(<pObject>)"
			],
			"display syntax":[
				"objectRepositoryStore(<i>pObject</i>)"
			],
			"associations":["com.livecode.library.objectrepository"],
			"summary":"Store an object in the object repository and get its ID",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"An object long ID"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An object repository ID which can be used to get the current long id of\nthe object"
			}],
			"description":"As long ID of an object may mutate during a session the IDE needs an\nobject reference that can handle that mutation."
		},{
			"id":"com.livecode.library.objectrepository-3",
			"name":"objectrepositoryflush",
			"display name":"objectRepositoryFlush",
			"library":"com.livecode.library.objectrepository",
			"type":"handler",
			"syntax":[
				"objectRepositoryFlush()"
			],
			"display syntax":[
				"objectRepositoryFlush()"
			],
			"associations":["com.livecode.library.objectrepository"],
			"summary":"Flush deleted objects from the repository",
			"description":"As long ID of an object may mutate during a session the IDE needs an\nobject reference that can handle that mutation."
		},{
			"id":"com.livecode.library.objectrepository-4",
			"name":"objectrepositoryretrieve",
			"display name":"objectRepositoryRetrieve",
			"library":"com.livecode.library.objectrepository",
			"type":"handler",
			"syntax":[
				"objectRepositoryRetrieve(<pID>)"
			],
			"display syntax":[
				"objectRepositoryRetrieve(<i>pID</i>)"
			],
			"associations":["com.livecode.library.objectrepository"],
			"summary":"Retrieve an object long id from the object repository",
			"parameters":[{
				"name":"pID",
				"type":"",
				"refparam":"false",
				"description":"An object repository ID"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An object long ID or empty if the object is not in the repository or\nno longer exists"
			}],
			"description":"As long ID of an object may mutate during a session the IDE needs an\nobject reference that can handle that mutation."
		},{
			"id":"com.livecode.library.objectrepository-5",
			"name":"objectrepositoryremove",
			"display name":"objectRepositoryRemove",
			"library":"com.livecode.library.objectrepository",
			"type":"handler",
			"syntax":[
				"objectRepositoryRemove(<pID>)"
			],
			"display syntax":[
				"objectRepositoryRemove(<i>pID</i>)"
			],
			"associations":["com.livecode.library.objectrepository"],
			"summary":"Remove and object from the object repository",
			"parameters":[{
				"name":"pID",
				"type":"",
				"refparam":"false",
				"description":"An object repository ID\n"
			}],
			"description":"As long ID of an object may mutate during a session the IDE needs an\nobject reference that can handle that mutation."
		}