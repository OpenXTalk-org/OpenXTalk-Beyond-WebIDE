{
			"id":"com.livecode.library.drawing-1",
			"name":"com.livecode.library.drawing",
			"display name":"Drawing Library",
			"library":"com.livecode.library.drawing",
			"type":"library",
			"display syntax":[
				"Drawing Library"
			],
			"associations":["com.livecode.library.drawing"],
			"description":"This script library implements an SVG compiler for turning SVG files into\n'drawing metafiles'. A simple and efficient binary format for representing\ncomplex vector graphics, supported directly by the LiveCode image object."
		},{
			"id":"com.livecode.library.drawing-2",
			"name":"drawingdecode",
			"display name":"drawingDecode",
			"library":"com.livecode.library.drawing",
			"type":"function",
			"syntax":[
				"drawingDecode(<pDrawing>)"
			],
			"display syntax":[
				"drawingDecode(<i>pDrawing</i>)"
			],
			"associations":["com.livecode.library.drawing"],
			"summary":"Read a drawing back into its shapes.",
			"parameters":[{
				"name":"pDrawing",
				"type":"",
				"refparam":"false",
				"description":"A drawing, such as the text of an image made from an SVG."
			}],
			"examples":[{
				"script":"local tDrawing\nput drawingDecode(the text of image \"logo\") into tDrawing\nanswer the number of elements in tDrawing[\"shapes\"] && \"shapes\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The drawing's size and shapes, or empty if pDrawing is not a drawing."
			},{
				"name":"the result",
				"type":"",
				"description":"An error string if pDrawing is not a drawing or is damaged."
			}],
			"description":"Use <drawingDecode> to read a drawing, the binary string that\n<drawingSvgCompile> and <drawingSvgCompileFile> make and that an image shows\nas its text, back into an array of the shapes it draws. It reads drawings made\nby any version, including those saved in old stacks.\n\nThe array has these keys:\n\n  - width, height: the size of the drawing\n  - shapes: one element for each shape, in the order they are drawn\n\nEach shape has the key \"type\", one of rect, circle, ellipse, line, polyline,\npolygon and path, and the geometry of that type: x, y, width, height, rx and ry\nfor a rect; cx, cy and r for a circle; cx, cy, rx and ry for an ellipse; x1, y1,\nx2 and y2 for a line; points (x,y pairs separated by spaces) for a polyline or\npolygon; and d (SVG path data, every command absolute) for a path.\n\nEach shape also has the state it is drawn with: transform (six numbers a,b,c,d,e,f\nas SVG's matrix(), empty when there is none), fill and stroke (paints, below),\nfill-opacity, fill-rule, stroke-opacity, stroke-width, stroke-linejoin,\nstroke-linecap, stroke-dasharray, stroke-dashoffset and stroke-miterlimit.\n\nA paint is an array whose \"type\" is none, current (the current color), color,\nlinear, radial or conical. A color has \"color\", the red, green, blue and alpha as\nnumbers from 0 to 1 separated by commas. A gradient has \"spread\" (pad, reflect or\nrepeat), \"transform\" (its unit gradient, from 0,0 to 1,0 or about 0,0 with radius\n1, mapped by six numbers as above) and \"stops\", one line for each stop: its offset\nthen its red, green, blue and alpha, from 0 to 1. A conical gradient also has fx,\nfy and fr, its focal point and radius.",
			"references":{
				"function":["drawingFlatten","drawingSvgCompile"]
			}
		},{
			"id":"com.livecode.library.drawing-3",
			"name":"drawingsvgcompile",
			"display name":"drawingSvgCompile",
			"library":"com.livecode.library.drawing",
			"type":"function",
			"syntax":[
				"drawingSvgCompile(<pXmlText>,<pOptions>)"
			],
			"display syntax":[
				"drawingSvgCompile(<i>pXmlText</i>,<i>pOptions</i>)"
			],
			"associations":["com.livecode.library.drawing"],
			"summary":"Compile an SVG XML file to a drawing metafile.",
			"parameters":[{
				"name":"pXmlText",
				"type":"",
				"refparam":"false",
				"description":"The text of the SVG XML document to compile."
			},{
				"name":"pOptions",
				"type":"",
				"refparam":"false",
				"description":"Optional. A list of the compile options to use, separated by commas, or an\narray whose keys are the options and whose values are true. With none, the\ndrawing is compiled as it always was. Unknown options are ignored.\n\n  - styles: the rules of the SVG's style sheets (style elements), with type,\n    class (.name), id (#name) and * selectors, so colours an SVG gives by\n    class come through\n  - opacity: the opacity attribute and property, of shapes and of groups\n  - ids: references to ids with - _ . or a leading digit, such as\n    url(#grad-1), and quoted ones; without it such a gradient draws black\n  - gradients: a radial gradient with no fx or fy has its focal point at its\n    centre (cx, cy), as SVG says; without it the focal point is at 50%, so a\n    gradient centred elsewhere draws lopsided\n  - clip: clip-path and clipPath elements (in user space; clip-rule, and\n    clipPathUnits=\"objectBoundingBox\", are not supported). A drawing with a\n    clip draws only on OXT-Beyond 0.2.7-rc.6.12 and later: an older engine stops\n    at the clip\n  - all: every option. The IDE's import of an SVG uses it"
			}],
			"examples":[{
				"script":"on mouseUp\n\tset the text of image 1 to drawingSvgCompile(url (\"file:clock.svg\"))\nend mouseUp"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A binary string containing the encoded drawing - this can be used as the text\nof an image directly."
			},{
				"name":"the result",
				"type":"",
				"description":"An error string if an error occurred."
			}],
			"description":"Use <drawingSvgCompile> to build a binary string representing an SVG file\nwhich can be used as the 'text' of an image object for display.\n\nThe text of the SVG XML document is parsed using revXML and then stripped of all\nattributes and elements not currently understood by the SVG compiler. The\nresulting SVG is then converted to a lower-level form and encoded. This form can\nbe used as the text of an image.\n\nThe following SVG features are currently supported:\n\n  - 'svg' elements (percentage width/height only allowed on the root element)\n  - 'g' and 'defs' elements\n  - 'use' elements\n  - 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon' and 'path' elements\n  - 'fill', 'fill-opacity', fill-rule' properties\n  - 'stroke', 'stroke-opacity', stroke-width', 'stroke-dash-array',\n    'stroke-dash-offset', 'stroke-line-cap', 'stroke-line-join' and\n    'stroke-miter-limit' properties\n  - 'solidColor', 'linearGradient', 'radialGradient' paint servers\n  - 'solid-color' and 'solid-opacity' solid color server properties\n  - 'stop-color' and 'stop-opacity' gradient ramp properties\n  - absolute unit specifiers in, cm, mm, pt, pc, px\n\nColor values of the following forms are supported:\n\n  - &#35;rgb\n  - &#35;rrggbb\n  - rgb(rrr, ggg, bbb)\n  - standard SVG 1.1 named colors (https://www.w3.org/TR/SVG/types.html#ColorKeywords)\n\nRadial gradients support focal point (fx, fy) and SVG2's focal radius (fr).\n\nThe rendering of an SVG file inside an image object respects the width, height,\nviewBox and preserveAspectRatio attributes on the root SVG node in the document.\n\nIf the width and height attributes are specified, and they are not percentages,\nthen they are taken to be the formattedWidth/Height of the image object. In this\ncase the SVG will always display at that fixed size, clipped to the rect of the\nimage.\n\nIf the width and height attributes are not specified, or are percentages, and\na viewBox attribute is specified then the width and height of the viewBox are\ntaken to be the formattedWidth/Height of the image object. In this case the SVG\nwill scale to fit within the rect of the image object, respecting the setting\nof the SVG's preserveAspectRatio attribute.\n\nFinally if the width and height are not specified, or are percentages and there\nis no viewBox attribute then the intrinsic width and height are taken to be\n256.\n\n>*Note:* The drawing binary format is not currently considered stable and is\n> subject to change until the end of the RC cycle for 9. At present it is advised\n> that SVG files be compiled as needed when developing in the IDE, and then\n> compiled ahead-of-time when building a standalone.\n\n\n>*Note:* To use this function in a standalone, you must include the XML \n> extension.",
			"references":{
				"function":["drawingSvgCompileFile"]
			}
		},{
			"id":"com.livecode.library.drawing-4",
			"name":"drawingsvgcompilefile",
			"display name":"drawingSvgCompileFile",
			"library":"com.livecode.library.drawing",
			"type":"function",
			"syntax":[
				"drawingSvgCompileFile(<pXmlFile>,<pOptions>)"
			],
			"display syntax":[
				"drawingSvgCompileFile(<i>pXmlFile</i>,<i>pOptions</i>)"
			],
			"associations":["com.livecode.library.drawing"],
			"summary":"Compile an SVG XML file to a drawing metafile.",
			"parameters":[{
				"name":"pXmlFile",
				"type":"",
				"refparam":"false",
				"description":"The filename of the SVG XML file to load."
			},{
				"name":"pOptions",
				"type":"",
				"refparam":"false",
				"description":"Optional. A list of the compile options to use, separated by commas, or an\narray whose keys are the options and whose values are true. With none, the\ndrawing is compiled as it always was. Unknown options are ignored.\n\n  - styles: the rules of the SVG's style sheets (style elements), with type,\n    class (.name), id (#name) and * selectors, so colours an SVG gives by\n    class come through\n  - opacity: the opacity attribute and property, of shapes and of groups\n  - ids: references to ids with - _ . or a leading digit, such as\n    url(#grad-1), and quoted ones; without it such a gradient draws black\n  - gradients: a radial gradient with no fx or fy has its focal point at its\n    centre (cx, cy), as SVG says; without it the focal point is at 50%, so a\n    gradient centred elsewhere draws lopsided\n  - clip: clip-path and clipPath elements (in user space; clip-rule, and\n    clipPathUnits=\"objectBoundingBox\", are not supported). A drawing with a\n    clip draws only on OXT-Beyond 0.2.7-rc.6.12 and later: an older engine stops\n    at the clip\n  - all: every option. The IDE's import of an SVG uses it"
			}],
			"examples":[{
				"script":"on mouseUp\n\tset the text of image 1 to drawingSvgCompileFile(\"clock.svg\")\nend mouseUp"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A binary string containing the encoded drawing - this can be used as the text\nof an image directly."
			},{
				"name":"the result",
				"type":"",
				"description":"An error string if an error occurred."
			}],
			"description":"Use <drawingSvgCompileFile> to build a binary string representing an SVG file\nwhich can be used as the 'text' of an image object for display.\n\nThe SVG XML file is parsed using revXML and then stripped of all attributes\nand elements not currently understood by the SVG compiler. The resulting SVG\nis then converted to a lower-level form and encoded. This form can be used\nas the text of an image.\n\nThe following SVG features are currently supported:\n\n  - 'svg' elements (percentage width/height only allowed on the root element)\n  - 'g' and 'defs' elements\n  - 'use' elements\n  - 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon' and 'path' elements\n  - 'fill', 'fill-opacity', fill-rule' properties\n  - 'stroke', 'stroke-opacity', stroke-width', 'stroke-dash-array',\n    'stroke-dash-offset', 'stroke-line-cap', 'stroke-line-join' and\n    'stroke-miter-limit' properties\n  - 'solidColor', 'linearGradient', 'radialGradient' paint servers\n  - 'solid-color' and 'solid-opacity' solid color server properties\n  - 'stop-color' and 'stop-opacity' gradient ramp properties\n  - absolute unit specifiers in, cm, mm, pt, pc, px\n\nColor values of the following forms are supported:\n\n  - &#35;rgb\n  - &#35;rrggbb\n  - rgb(rrr, ggg, bbb)\n  - standard SVG 1.1 named colors (https://www.w3.org/TR/SVG/types.html#ColorKeywords)\n\nRadial gradients support focal point (fx, fy) and SVG2's focal radius (fr).\n\nThe rendering of an SVG file inside an image object respects the width, height,\nviewBox and preserveAspectRatio attributes on the root SVG node in the document.\n\nIf the width and height attributes are specified, and they are not percentages,\nthen they are taken to be the formattedWidth/Height of the image object. In this\ncase the SVG will always display at that fixed size, clipped to the rect of the\nimage.\n\nIf the width and height attributes are not specified, or are percentages, and\na viewBox attribute is specified then the width and height of the viewBox are\ntaken to be the formattedWidth/Height of the image object. In this case the SVG\nwill scale to fit within the rect of the image object, respecting the setting\nof the SVG's preserveAspectRatio attribute.\n\nFinally if the width and height are not specified, or are percentages and there\nis no viewBox attribute then the intrinsic width and height are taken to be\n256.\n\n>*Note:* The drawing binary format is not currently considered stable and is\nsubject to change until the end of the RC cycle for 9. At present it is advised\nthat SVG files be compiled as needed when developing in the IDE, and then\ncompiled ahead-of-time when building a standalone.\n\n\n>*Note:* To use this function in a standalone, you must include the XML \nextension.\n\n\n>*Note:* The <XML library> (and by extension, this function) can not load \n> files from the resources folder on Android. You must either copy the \n> resources to the documents folder or use the <drawingSvgCompile>\n> function instead.",
			"references":{
				"function":["drawingSvgCompile"],
				"library":["XML library"]
			}
		},{
			"id":"com.livecode.library.drawing-5",
			"name":"drawingflatten",
			"display name":"drawingFlatten",
			"library":"com.livecode.library.drawing",
			"type":"function",
			"syntax":[
				"drawingFlatten(<pDrawing>,<pTolerance>)"
			],
			"display syntax":[
				"drawingFlatten(<i>pDrawing</i>,<i>pTolerance</i>)"
			],
			"associations":["com.livecode.library.drawing"],
			"summary":"Turn the shapes of a drawing into lists of points.",
			"parameters":[{
				"name":"pDrawing",
				"type":"",
				"refparam":"false",
				"description":"A drawing, such as the text of an image made from an SVG."
			},{
				"name":"pTolerance",
				"type":"",
				"refparam":"false",
				"description":"How far, in the drawing's units, a line may stray from the curve it stands\nfor. Smaller gives more points. The default is 0.25."
			}],
			"examples":[{
				"script":"local tFlat\nput drawingFlatten(the text of image \"logo\", 0.25) into tFlat\nrepeat for each element tShape in tFlat[\"shapes\"]\n   create graphic\n   set the style of it to \"polygon\"\n   set the points of it to tShape[\"points\"]\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The drawing's size and flattened shapes, or empty if pDrawing is not a drawing."
			},{
				"name":"the result",
				"type":"",
				"description":"An error string if pDrawing is not a drawing or is damaged."
			}],
			"description":"Use <drawingFlatten> to get each shape of a drawing as the points of a polygon,\nin the drawing's own coordinates, the way a graphic holds them. Curves, arcs,\ncircles, ellipses and rounded corners become runs of short straight lines, no\nfurther than pTolerance from the true curve, and each shape's transform is\napplied to its points. The IDE's Convert to Graphics uses it.\n\nThe array has the keys width and height, the size of the drawing, and shapes,\none element for each shape, with the keys:\n\n  - points: one x,y pair a line; an empty line between the runs of a shape\n    with more than one, and a run that is closed ends at the point it starts at\n  - fill, fill-opacity, fill-rule, stroke, stroke-opacity, stroke-linejoin,\n    stroke-linecap and stroke-miterlimit, as <drawingDecode> gives them\n  - stroke-width, stroke-dasharray and stroke-dashoffset, scaled by the\n    shape's transform\n  - a gradient paint's transform is in the drawing's coordinates too",
			"references":{
				"function":["drawingDecode"]
			}
		},{
			"id":"com.livecode.library.drawing-6",
			"name":"drawingsvgdecompile",
			"display name":"drawingSvgDecompile",
			"library":"com.livecode.library.drawing",
			"type":"function",
			"syntax":[
				"drawingSvgDecompile(<pDrawing>)"
			],
			"display syntax":[
				"drawingSvgDecompile(<i>pDrawing</i>)"
			],
			"associations":["com.livecode.library.drawing"],
			"summary":"Turn a drawing back into SVG.",
			"parameters":[{
				"name":"pDrawing",
				"type":"",
				"refparam":"false",
				"description":"A drawing, such as the text of an image made from an SVG."
			}],
			"examples":[{
				"script":"set the clipboardData[\"text\"] to drawingSvgDecompile(the text of image \"logo\")"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An SVG document, or empty if pDrawing is not a drawing."
			},{
				"name":"the result",
				"type":"",
				"description":"An error string if pDrawing is not a drawing or is damaged."
			}],
			"description":"Use <drawingSvgDecompile> to get SVG text from a drawing, the binary string\nthat <drawingSvgCompile> and <drawingSvgCompileFile> make and that an image\nmade from an SVG holds as its text. The drawing does not keep the SVG it was\nmade from, so this is a new SVG that draws the same: every shape with its\ntransform, colors, gradients, opacity and line style written out on it, and\neach path's data with absolute commands. Groups, ids, classes, style sheets and\nanything the compiler left out of the drawing are not in it.",
			"references":{
				"function":["drawingDecode","drawingSvgCompile"]
			}
		}