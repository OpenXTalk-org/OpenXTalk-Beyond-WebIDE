{
			"id":"torrentHelpers-1",
			"name":"torrenthelpers",
			"display name":"TorrentXT helpers",
			"library":"torrentHelpers",
			"type":"library",
			"display syntax":[
				"TorrentXT helpers"
			],
			"associations":["torrenthelpers"],
			"description":"The script-side poll loop and formatting helpers for TorrentXT. Put this\nstack in the message path with start using stack \"torrentHelpers\" (or use\nits script as a behavior), then call btStartPolling once the session is\nrunning.\n\nlibtorrent never calls back into script. The helper drains the session's\nevents on a timer with btPoll and btRp1Poll and dispatches each one to\nyour target as a message named after the event, such as metadataReceived,\ntorrentFinished or rp1Message, with the event array as its one parameter.\nEvery event is also sent as torrentEvent, a catch-all. When a drain\nreports that events were lost because a queue filled, the target also gets\na torrentPollWarning message.\n\nbtFormatBytes and btStateName turn raw numbers into labels for a\ndashboard."
		},{
			"id":"torrentHelpers-2",
			"name":"btstoppolling",
			"display name":"btStopPolling",
			"library":"torrentHelpers",
			"type":"command",
			"syntax":[
				"btStopPolling"
			],
			"display syntax":[
				"btStopPolling"
			],
			"associations":["torrenthelpers"],
			"summary":"Stop the event polling timer.",
			"examples":[{
				"script":"btStopPolling\nbtStopSession sSession"
			}],
			"description":"Use <btStopPolling> before <btStopSession>; call both from closeStack. The\npass already scheduled sees the flag and does nothing. It is safe to call\nwhen polling is not running.",
			"references":{
				"handler":["btStartPolling","btStopSession"]
			}
		},{
			"id":"torrentHelpers-3",
			"name":"btstartpolling",
			"display name":"btStartPolling",
			"library":"torrentHelpers",
			"type":"command",
			"syntax":[
				"btStartPolling <pSession>,<pTarget>,<pIntervalMs>"
			],
			"display syntax":[
				"btStartPolling <i>pSession</i>,<i>pTarget</i>,<i>pIntervalMs</i>"
			],
			"associations":["torrenthelpers"],
			"summary":"Start draining a session's events on a timer and dispatching them as messages.",
			"parameters":[{
				"name":"pSession",
				"type":"",
				"refparam":"false",
				"description":"The session handle from btStartSession."
			},{
				"name":"pTarget",
				"type":"",
				"refparam":"false",
				"description":"The object that receives the event messages; empty for the current card."
			},{
				"name":"pIntervalMs",
				"type":"",
				"refparam":"false",
				"description":"Milliseconds between drains; empty for 250."
			}],
			"examples":[{
				"script":"btStartSession\nput the result into sSession\nbtStartPolling sSession, the long id of this card, 250"
			}],
			"description":"Use <btStartPolling> once the session is running. Each pass runs\n<btTorrentPollOnce>: it drains <btPoll> and then <btRp1Poll> and\ndispatches each event to the target as a message named after the event,\nwith the event array as its one parameter, and also as torrentEvent.\n\nHandle the events you need with handlers such as on torrentFinished\npEvent, and read the keys of pEvent.\n\nCalling it again while polling changes the session, target and interval;\nit does not start a second timer. The interval trades latency for CPU, but\nboth event queues are limited, so a very slow interval can lose events.",
			"references":{
				"handler":["btStopPolling","btTorrentPollOnce","btPoll"]
			}
		},{
			"id":"torrentHelpers-4",
			"name":"btformatbytes",
			"display name":"btFormatBytes",
			"library":"torrentHelpers",
			"type":"function",
			"syntax":[
				"btFormatBytes(<pBytes>)"
			],
			"display syntax":[
				"btFormatBytes(<i>pBytes</i>)"
			],
			"associations":["torrenthelpers"],
			"summary":"Format a byte count as text such as 1.5 MiB.",
			"parameters":[{
				"name":"pBytes",
				"type":"",
				"refparam":"false",
				"description":"A number of bytes."
			}],
			"examples":[{
				"script":"put btTorrentStatus(tH) into tStatus\nput btFormatBytes(tStatus[\"totalDone\"]) into field \"done\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The size with one decimal place and a unit: B, KiB, MiB, GiB or TiB."
			}],
			"description":"Use <btFormatBytes> for dashboard labels. It divides by 1024 per unit.\nEmpty or non-numeric input returns 0 B.",
			"references":{
				"handler":["btStateName","btTorrentStatus"]
			}
		},{
			"id":"torrentHelpers-5",
			"name":"bttorrentpollonce",
			"display name":"btTorrentPollOnce",
			"library":"torrentHelpers",
			"type":"command",
			"syntax":[
				"btTorrentPollOnce"
			],
			"display syntax":[
				"btTorrentPollOnce"
			],
			"associations":["torrenthelpers"],
			"summary":"Run one drain pass of the polling loop.",
			"examples":[{
				"script":"btStartPolling sSession, the long id of this card, 250"
			}],
			"description":"<btTorrentPollOnce> is the timer message <btStartPolling> schedules; you\nnormally do not call it yourself. It does nothing unless polling is on and\na session is set.\n\nEach pass clears the last error, drains <btPoll>, and dispatches every\nevent by its name and as torrentEvent. It then does the same with\n<btRp1Poll>, which returns nothing when rp1 is not enabled. Finally it\nschedules the next pass.\n\nIf <btLastError> is not empty right after a drain, the queue overflowed.\nThe pass then dispatches a torrentPollWarning event (and torrentEvent)\nwhose array has the keys name, torrent (0), source (btPoll or btRp1Poll)\nand message (the text from btLastError).",
			"references":{
				"handler":["btStartPolling","btStopPolling","btPoll","btRp1Poll"]
			}
		},{
			"id":"torrentHelpers-6",
			"name":"btstatename",
			"display name":"btStateName",
			"library":"torrentHelpers",
			"type":"function",
			"syntax":[
				"btStateName(<pState>)"
			],
			"display syntax":[
				"btStateName(<i>pState</i>)"
			],
			"associations":["torrenthelpers"],
			"summary":"Turn a torrent state number into a label.",
			"parameters":[{
				"name":"pState",
				"type":"",
				"refparam":"false",
				"description":"The state value from the state key of btTorrentStatus."
			}],
			"examples":[{
				"script":"put btTorrentStatus(tH) into tStatus\nput btStateName(tStatus[\"state\"]) into field \"state\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"checking, fetching metadata, downloading, finished, seeding, checking resume or queued."
			}],
			"description":"Use <btStateName> to show libtorrent's torrent state. 1 is checking, 2\nfetching metadata, 3 downloading, 4 finished, 5 seeding and 7 checking\nresume; any other value, 0 and 6 included, gives queued.",
			"references":{
				"handler":["btTorrentStatus","btFormatBytes"]
			}
		}