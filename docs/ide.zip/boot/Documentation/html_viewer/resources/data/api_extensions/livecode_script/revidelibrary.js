{
			"id":"revidelibrary-1",
			"name":"revidelibrary",
			"display name":"IDE Library",
			"library":"revidelibrary",
			"type":"library",
			"display syntax":[
				"IDE Library"
			],
			"associations":["revidelibrary"],
			"summary":"Main IDE library providing functionality for palettes and other IDE add-ons.",
			"description":"Main IDE library providing functionality for palettes and other IDE add-ons."
		},{
			"id":"revidelibrary-2",
			"name":"idenewcontrol",
			"display name":"ideNewControl",
			"library":"revidelibrary",
			"type":"message",
			"syntax":[
				"on ideNewControl"
			],
			"display syntax":[
				"on ideNewControl"
			],
			"associations":["revidelibrary"],
			"summary":"Sent when a control is created in the IDE",
			"description":"Handle the <ideNewControl> message to respond to the creation of controls using one of the\nIDE palettes, or the create command.\n\n>*Note:* The <ideNewControl> message is only sent to objects which have subscribed to it.\nSee the <revIDESubscribe> command for more details.",
			"references":{
				"command":["revIDESubscribe"]
			}
		},{
			"id":"revidelibrary-3",
			"name":"idesubscribe",
			"display name":"ideSubscribe",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"ideSubscribe <pMessage>,<pObjectList>"
			],
			"display syntax":[
				"ideSubscribe <i>pMessage</i>,<i>pObjectList</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Subscribes the calling object to receive the specified IDE message",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message to subscribe to."
			},{
				"name":"pObjectList",
				"type":"",
				"refparam":"false",
				"description":"A list of objects, one per line, determining which calling objects the message should be restricted to."
			}],
			"examples":[{
				"script":"on preOpenStack\n   ideSubscribe \"ideSelectedObjectsChanged\"\nend preOpenStack\n\non ideSelectedObjectsChanged\n   # Handle the notification\nend ideSelectedObjectsChanged"
			},{
				"script":"-- When the selection changes, subscribe to the idePropertyChanged message for the newly selected objects\non ideSelectedObjectsChanged\n   ideSubscribe \"idePropertyChanged\", revIDESelectedObjects()\nend ideSelectedObjectsChanged"
			}],
			"description":"Subscribe to messages to have a notification sent for particular IDE actions."
		},{
			"id":"revidelibrary-4",
			"name":"ideusermainstacks",
			"display name":"ideUserMainStacks",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideUserMainStacks()"
			],
			"display syntax":[
				"ideUserMainStacks()"
			],
			"associations":["revidelibrary"],
			"summary":"A list of the current user mainstacks",
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of the names of the user mainstacks currently in memory, one per line"
			}],
			"description":"Use the <ideUserMainStacks> function to retrieve a list of the names of the mainstacks\nin memory, excluding those which are part of the IDE.\n\nSee the <revIDEStackNameIsIDEStack> function for details of when a stack is considered\npart of the IDE.",
			"references":{
				"function":["revIDEStackNameIsIDEStack"]
			}
		},{
			"id":"revidelibrary-5",
			"name":"ideobjecttypefromobject",
			"display name":"ideObjectTypeFromObject",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideObjectTypeFromObject(<pObjectID>)"
			],
			"display syntax":[
				"ideObjectTypeFromObject(<i>pObjectID</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"The IDE object type corresponding to the given object",
			"parameters":[{
				"name":"pObjectID",
				"type":"",
				"refparam":"false",
				"description":"An object ID"
			}],
			"examples":[{
				"script":"create field\nput ideObjectTypeFromObject(it)  -- outputs com.livecode.interface.classic.Field\nset the listBehavior of it to true\nput ideObjectTypeFromObject(it)  -- outputs com.livecode.interface.classic.ListField"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The IDE object type associated with the objects <pObjectID>"
			}],
			"description":">*Note:* The type returned by <ideObjectTypeFromObject> can depend\non the values of the object's properties."
		},{
			"id":"revidelibrary-6",
			"name":"revideunsubscribe",
			"display name":"revIDEUnsubscribe",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEUnsubscribe <pMessage>,<pObject>,<pObjectList>"
			],
			"display syntax":[
				"revIDEUnsubscribe <i>pMessage</i>,<i>pObject</i>,<i>pObjectList</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Unsubscribes the calling object from the given message",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message to unsubscribe from."
			},{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"The long ID of the object you wish to unsubscribe from the message. This is an optional parameter, if not specified, the calling object will be used."
			},{
				"name":"pObjectList",
				"type":"",
				"refparam":"false",
				"description":"A list of objects, one per line."
			}],
			"description":"Unsubscribes the calling object from the given message"
		},{
			"id":"revidelibrary-7",
			"name":"revidesubscriptions",
			"display name":"revIDESubscriptions",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDESubscriptions()"
			],
			"display syntax":[
				"revIDESubscriptions()"
			],
			"associations":["revidelibrary"],
			"summary":"Use to find out which messages the calling object is subscribed to.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"Return delimited list of messages, 1 per line."
			}],
			"description":"Use to find out which messages the calling object is subscribed to."
		},{
			"id":"revidelibrary-8",
			"name":"revidelookuperror",
			"display name":"revIDELookupError",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDELookupError(<pType>,<pError>)"
			],
			"display syntax":[
				"revIDELookupError(<i>pType</i>,<i>pError</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Returns the error description associated with the given \nerror code.\npCode:the id of the error as returned by the engine.",
			"parameters":[{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"either \"compilation\", \"execution\" or \"warning\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The description of the specified error.\n\n>*Note:* if <pType> is \"warning\", this function will currently return \nempty."
			}],
			"description":"Returns the error description associated with the given \nerror code.\npCode:the id of the error as returned by the engine."
		},{
			"id":"revidelibrary-9",
			"name":"reviderunedittools",
			"display name":"revIDERunEditTools",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDERunEditTools()"
			],
			"display syntax":[
				"revIDERunEditTools()"
			],
			"associations":["revidelibrary"],
			"summary":"Returns information about the run and edit tools.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"an array, keyed by the run and edit tool type IDs,\nof properties associated with each of those tools."
			}],
			"description":"Returns information about the run and edit tools."
		},{
			"id":"revidelibrary-10",
			"name":"revideglobalvariables",
			"display name":"revIDEGlobalVariables",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGlobalVariables()"
			],
			"display syntax":[
				"revIDEGlobalVariables()"
			],
			"associations":["revidelibrary"],
			"summary":"Use to get a list of of all the global variables.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"A comma delimited list of global variable names"
			}],
			"description":"Use to get a list of of all the global variables."
		},{
			"id":"revidelibrary-11",
			"name":"idemainstacks",
			"display name":"ideMainStacks",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideMainStacks()"
			],
			"display syntax":[
				"ideMainStacks()"
			],
			"associations":["revidelibrary"],
			"summary":"A list of the current mainstacks",
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of the names of the mainstacks currently in memory, one per line"
			}],
			"description":"Use the <ideMainStacks> function to retrieve a list of the names of the mainstacks\nin memory, taking into account the Show IDE Stacks preference."
		},{
			"id":"revidelibrary-12",
			"name":"revideeditablestacks",
			"display name":"revIDEEditableStacks",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEEditableStacks()"
			],
			"display syntax":[
				"revIDEEditableStacks()"
			],
			"associations":["revidelibrary"],
			"summary":"Use to get a complete list of all editable stacks in the IDE.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"A return delimited list of stack names"
			}],
			"description":"Use to get a complete list of all editable stacks in the IDE."
		},{
			"id":"revidelibrary-13",
			"name":"revidemakesubstackmainstack",
			"display name":"revIDEMakeSubstackMainstack",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEMakeSubstackMainstack <pObj>"
			],
			"display syntax":[
				"revIDEMakeSubstackMainstack <i>pObj</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Used by the PI to make a substack into a mainstack",
			"description":"Used by the PI to make a substack into a mainstack"
		},{
			"id":"revidelibrary-14",
			"name":"revidegetallplugins",
			"display name":"revIDEGetAllPlugins",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGetAllPlugins()"
			],
			"display syntax":[
				"revIDEGetAllPlugins()"
			],
			"associations":["revidelibrary"],
			"summary":"Lists the plugin stacks of the IDE.",
			"examples":[{
				"script":"put revIDEGetAllPlugins() -- the plugin stacks, one per line"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The full paths of the stacks in the plugins folders of the IDE and\nof the user, and in the development plugins folder when there is one, one\nper line."
			}],
			"description":"Lists the plugin stacks of the IDE.",
			"references":{
				"function":["revIDEPlugins"]
			}
		},{
			"id":"revidelibrary-15",
			"name":"idesetwindowboundingrect",
			"display name":"ideSetWindowBoundingRect",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"ideSetWindowBoundingRect"
			],
			"display syntax":[
				"ideSetWindowBoundingRect"
			],
			"associations":["revidelibrary"],
			"summary":"Update the window bounding rect for the current IDE palette layout",
			"description":"Update the window bounding rect for the current IDE palette layout"
		},{
			"id":"revidelibrary-16",
			"name":"revidepushdefaultfolder",
			"display name":"revIDEPushDefaultFolder",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEPushDefaultFolder <pFolder>"
			],
			"display syntax":[
				"revIDEPushDefaultFolder <i>pFolder</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Stores the current default folder.",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"The new defaultFolder"
			}],
			"examples":[{
				"script":"on myHandler\n   revIDEPushDefaultFolder \"/\"\n   repeat for each line tLine in the files\n      # Do something to the files\n   end repeat\n   revIDEPopDefaultFolder\nend myHandler"
			}],
			"description":"Pushes the current defaultFolder onto a list of defaultFolders.\nIf <pFolder> is specified, then the defaultFolder is set to <pFolder>.\nrevIDEPopDefaultFolder then pops the list and sets the \ndefault folder to the popped value."
		},{
			"id":"revidelibrary-17",
			"name":"revidestacknameisidestack",
			"display name":"revIDEStackNameIsIDEStack",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEStackNameIsIDEStack(<pStackName>)"
			],
			"display syntax":[
				"revIDEStackNameIsIDEStack(<i>pStackName</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Determines whether a stack is considered part of the IDE",
			"parameters":[{
				"name":"pStackName",
				"type":"",
				"refparam":"false",
				"description":"The short name of the stack"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":""
			}],
			"description":"Use the <revIDEStackNameIsIDEStack> function to determine whether a stack is\nconsidered part of the IDE, according to the name of the stack.\n\nA stack is considered part of the IDE if any of the following are satisfied:\n* Its name begins with \"rev\"\n* It was loaded by the initialisation library\n* Its name begins with \"com.livecode.\"\n* Its name is \"message box, answer dialog, ask dialog, or home\"\n* Its _ideoverride property is true"
		},{
			"id":"revidelibrary-18",
			"name":"revidepopdefaultfolder",
			"display name":"revIDEPopDefaultFolder",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEPopDefaultFolder"
			],
			"display syntax":[
				"revIDEPopDefaultFolder"
			],
			"associations":["revidelibrary"],
			"summary":"Restores the default folder to the last saved path.",
			"examples":[{
				"script":"on myHandler\n   revIDEPushDefaultFolder\n   set the defaultfolder to \"/\"\n   repeat for each line tLine in the files\n      # Do something to the files\n   end repeat\n   revIDEPopDefaultFolder\nend myHandler"
			}],
			"description":"Pops the last stored defaultFolder and sets the \ndefault folder to the popped value."
		},{
			"id":"revidelibrary-19",
			"name":"revideobjectpropertyinfo",
			"display name":"revIDEObjectPropertyInfo",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEObjectPropertyInfo(<pObjectType>,<pPropName>)"
			],
			"display syntax":[
				"revIDEObjectPropertyInfo(<i>pObjectType</i>,<i>pPropName</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Information pertaining to the property <pPropName> in the context of <pObjectType>.",
			"parameters":[{
				"name":"pPropName",
				"type":"",
				"refparam":"false",
				"description":"One of the IDE canonical object property names."
			},{
				"name":"pObjectType",
				"type":"",
				"refparam":"false",
				"description":"One of the IDE's object types."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of information pertaining to the given property."
			}],
			"description":"This function returns the information pertaining to the object property <pPropName>,\nparsed from the files in Toolset/resources/supporting_files/. In some cases an individual\nproperty's data can be overridden for a particular object type.\n\nFor a list of the canonical property names which are valid inputs to this function, see the\n<idePropertyNames> function. For a list of the object type IDs which are valid inputs\nto this function, see the <ideObjectTypes> function.",
			"references":{
				"function":["idePropertyNames","ideObjectTypes"]
			}
		},{
			"id":"revidelibrary-20",
			"name":"ideobjecttypesfromobjectlist",
			"display name":"ideObjectTypesFromObjectList",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideObjectTypesFromObjectList(<pObjectIDs>)"
			],
			"display syntax":[
				"ideObjectTypesFromObjectList(<i>pObjectIDs</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"A list of the IDE object types corresponding to the list of objects given",
			"parameters":[{
				"name":"pObjectIDs",
				"type":"",
				"refparam":"false",
				"description":"A list, one per line, of object IDs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list, one per line, of the IDE object types associated with\nthe objects in <pObjectIDs>"
			}],
			"description":"A list of the IDE object types corresponding to the list of objects given"
		},{
			"id":"revidelibrary-21",
			"name":"revideisfilesetstale",
			"display name":"revIDEIsFilesetStale",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEIsFilesetStale(pInputs, pOutputs, pRecursive, rError)"
			],
			"display syntax":[
				"revIDEIsFilesetStale(pInputs, pOutputs, pRecursive, rError)"
			],
			"associations":["revidelibrary"],
			"summary":"Compute whether derived files are up-to-date",
			"parameters":[{
				"name":"pInputs",
				"type":"",
				"refparam":"false",
				"description":"A numerically-keyed array of filenames, or a filename"
			},{
				"name":"pOutputs",
				"type":"",
				"refparam":"false",
				"description":"A numerically-keyed array of filenames, or a filename"
			},{
				"name":"pRecursive",
				"type":"",
				"refparam":"false",
				"description":"True if folders should be checked recursively"
			},{
				"name":"rError",
				"type":"",
				"refparam":"false",
				"description":"Set to a string describing an error, if necessary."
			}],
			"description":"Checks whether the <pOutputs> are up-to-date relative to the\n<pInputs>, by checking the modification times on the files.  Returns\ntrue if any of the <pInputs> are newer than any of the <pOutputs>, or\nif any of the <pOutputs> are missing.  Returns false if all of the\n<pOutputs> are up-to-date.\n\nIf an error occurs, returns empty and sets <rError> to a descriptive\nstring.\n\nThe <pInputs> and the <pOutputs> are file sets, and can either be a\nsingle filename as a string, or a numerically-keyed array of filenames.\nIt is an error for either file set is an array with non-numeric keys, or\nfor any filename to be the empty string.\n\nIf either file set is empty, the return value is true.  It is an error\nfor any of the input filenames to be missing.\n\nIf <pRecursive> is true, any filename in the <pInputs> or <pOutputs>\nthat is a directory is scanned recursively and its files are added to\nthe fileset.  If <pRecursive> is false, it is an error for either file\nset to contain directories."
		},{
			"id":"revidelibrary-22",
			"name":"revidegroupobjects",
			"display name":"revIDEGroupObjects",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEGroupObjects <objectList>"
			],
			"display syntax":[
				"revIDEGroupObjects <i>objectList</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Group a list of objects in their layer order",
			"parameters":[{
				"name":"objectList",
				"type":"string",
				"refparam":"false",
				"description":"A return delimited list of long object IDs"
			}],
			"value":[{
				"name":"it",
				"type":"",
				"description":"The new group long ID or empty in the case the group could not be created"
			},{
				"name":"the result",
				"type":"",
				"description":"An error string"
			}],
			"description":"Group a list of objects in the order they are layered in"
		},{
			"id":"revidelibrary-23",
			"name":"revidegetpreference",
			"display name":"revIDEGetPreference",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGetPreference(<pPreferenceName>)"
			],
			"display syntax":[
				"revIDEGetPreference(<i>pPreferenceName</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Gets a preference.",
			"parameters":[{
				"name":"pPreferenceName",
				"type":"",
				"refparam":"false",
				"description":"The name of the preference"
			}],
			"examples":[{
				"script":"set the textsize of field 1 to revIDEGetPreference(\"text size\")"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value of the preference"
			}],
			"description":"Gets a preference.",
			"tags":["preferences"]
		},{
			"id":"revidelibrary-24",
			"name":"revidetypeofobject",
			"display name":"revIDETypeOfObject",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDETypeOfObject(<pObject>)"
			],
			"display syntax":[
				"revIDETypeOfObject(<i>pObject</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"The type of an object, from its name or its long id",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"The name, the long name or the long id of an object, as the\nengine gives them"
			}],
			"examples":[{
				"script":"put revIDETypeOfObject(the long id of button 1)  -- outputs button"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The type of the object, such as button, field, image, card or\nstack"
			}],
			"description":"The type of an object is the first word of its name, but in a stack\nwhose hcAddressing is true, as every stack imported from HyperCard is,\nthe engine names a control as HyperCard did: card button \"OK\", or bkgnd\nfield id 12 of group id 3 of card id 1002 of stack \"Address\" for a\ncontrol of a background. The type is then the word after card or bkgnd.\nA card's name and long id (card \"Index\", card id 1002 of ...) never have\na control's type after the word card, and a group's never begin with\ncard or bkgnd."
		},{
			"id":"revidelibrary-25",
			"name":"revidegetpropertiesofobjects",
			"display name":"revIDEGetPropertiesOfObjects",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGetPropertiesOfObjects(<pObjects>)"
			],
			"display syntax":[
				"revIDEGetPropertiesOfObjects(<i>pObjects</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"For a given list of objects, returns a structured array of properties, values and other meta data.\n\npObjects (string list): A list of IDs of the objects to obtain the properties for.",
			"examples":[{
				"script":"local tPropsArray\ncreate button\nput revIDEGetPropertiesOfObjects(it) into tPropsArray\n\n# Get a list of the sections needed to display this object's property inspector\nlocal tSections\nput the keys of tPropsArray into tSections"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of data about the objects' properties."
			}],
			"description":"<revIDEGetPropertiesOfObjects> returns an array of data about the given objects'\nshared properties, in a form used by the property inspector. The array has a sub-array\nfor each section of the inspector in which one of the shared properties falls. Each of\nthese sub-arrays has a sub-array for each group within the section in which one of the\nshared properties falls, each of which in turn has a sub-array for each property,\ncontaining the values and metadata associated with it."
		},{
			"id":"revidelibrary-26",
			"name":"revidepropertyinfo",
			"display name":"revIDEPropertyInfo",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEPropertyInfo(<pPropName>)"
			],
			"display syntax":[
				"revIDEPropertyInfo(<i>pPropName</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Information pertaining to the property <pPropName>.",
			"parameters":[{
				"name":"pPropName",
				"type":"",
				"refparam":"false",
				"description":"One of the IDE canonical object property names."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of information pertaining to the given property."
			}],
			"description":"This function returns the information pertaining to the object property <pPropName>,\nparsed from the file Toolset/resources/supporting_files/property_definitions.\n\nInformation about synonyms is not returned by this function. For a list of the canonical\nproperty names which are valid inputs to this function, see the <idePropertyNames>\nfunction.",
			"references":{
				"function":["idePropertyNames"]
			}
		},{
			"id":"revidelibrary-27",
			"name":"extensioninitialize",
			"display name":"extensionInitialize",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"extensionInitialize"
			],
			"display syntax":[
				"extensionInitialize"
			],
			"associations":["revidelibrary"],
			"summary":"Called when loading the IDE library",
			"description":"Called when loading the IDE library"
		},{
			"id":"revidelibrary-28",
			"name":"revidegraphictools",
			"display name":"revIDEGraphicTools",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGraphicTools()"
			],
			"display syntax":[
				"revIDEGraphicTools()"
			],
			"associations":["revidelibrary"],
			"summary":"Returns information about the graphic creation tools.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"an array, keyed by the graphic creation tool types that appear\nin the Tools palette, of properties associated with the objects created\nby each of those graphic creation tools."
			}],
			"description":"Returns information about the graphic creation tools."
		},{
			"id":"revidelibrary-29",
			"name":"idemainstackofobject",
			"display name":"ideMainStackOfObject",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideMainStackOfObject(<pLongID>)"
			],
			"display syntax":[
				"ideMainStackOfObject(<i>pLongID</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"The mainstack containing an object",
			"parameters":[{
				"name":"pLongID",
				"type":"",
				"refparam":"false",
				"description":"The long id of an object"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"the long id of the mainstack containing <pLongID>"
			}],
			"description":"Returns the long id of the mainstack of the object with long id <pLongID>.\nTo retrieve the immediate parent stack of an object which may be a substack, \nuse the <ideStackOfObject> function.",
			"references":{
				"function":["ideStackOfObject"]
			}
		},{
			"id":"revidelibrary-30",
			"name":"revideclassiccontrols",
			"display name":"revIDEClassicControls",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEClassicControls()"
			],
			"display syntax":[
				"revIDEClassicControls()"
			],
			"associations":["revidelibrary"],
			"summary":"Returns information about the classic control tools.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"an array, keyed by the classic control tool types that appear\nin the Tools palette, of properties associated with each of those classic \ncontrol tools."
			}],
			"description":"Returns information about the classic control tools."
		},{
			"id":"revidelibrary-31",
			"name":"revidestackisidestack",
			"display name":"revIDEStackIsIDEStack",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEStackIsIDEStack(<pLongID>)"
			],
			"display syntax":[
				"revIDEStackIsIDEStack(<i>pLongID</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Determines whether a stack is considered part of the IDE",
			"parameters":[{
				"name":"pLongID",
				"type":"",
				"refparam":"false",
				"description":"The long id of the stack."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":""
			}],
			"description":"Use the <revIDEStackIsIDEStack> function to determine whether a stack is\nconsidered part of the IDE.\n\nA stack is considered part of the IDE if it exists, and\n* Its name begins with \"rev\"\n* Its name begins with \"com.livecode.\"\n* Its name is \"message box, answer dialog, ask dialog, or home\"\n\n>*Note:* If the name of the stack is already available, it is more efficient to\nuse the <revIDEStackNameIsIDEStack> function.",
			"references":{
				"function":["revIDEStackNameIsIDEStack"]
			}
		},{
			"id":"revidelibrary-32",
			"name":"idecompilecheck",
			"display name":"ideCompileCheck",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"ideCompileCheck <pScript>"
			],
			"display syntax":[
				"ideCompileCheck <i>pScript</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Attempts to compile the target script",
			"value":[{
				"name":"the result",
				"type":"",
				"description":"If the compilation fails, the result is set to the description of the compile error"
			}],
			"description":"Attempts to compile the target script"
		},{
			"id":"revidelibrary-33",
			"name":"revidegraphics",
			"display name":"revIDEGraphics",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEGraphics()"
			],
			"display syntax":[
				"revIDEGraphics()"
			],
			"associations":["revidelibrary"],
			"summary":"Returns information about the predefined graphic objects.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"an array, keyed by the predefined graphic object types that\nappear in the Tools palette, of properties associated with each of those\ngraphic objects."
			}],
			"description":"Returns information about the predefined graphic objects."
		},{
			"id":"revidelibrary-34",
			"name":"idestackofobject",
			"display name":"ideStackOfObject",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideStackOfObject(<pLongID>)"
			],
			"display syntax":[
				"ideStackOfObject(<i>pLongID</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"The parent stack of an object",
			"parameters":[{
				"name":"pLongID",
				"type":"",
				"refparam":"false",
				"description":"The long id of an object"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"the long id of the parent stack of <pLongID>"
			}],
			"description":"Returns the long id of the (immediate) parent stack of the object with long id <pLongID>.\nTo retrieve the mainstack of an object, use the <ideMainStackOfObject> function.",
			"references":{
				"function":["ideMainStackOfObject"]
			}
		},{
			"id":"revidelibrary-35",
			"name":"ideobjecttypes",
			"display name":"ideObjectTypes",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"ideObjectTypes()"
			],
			"display syntax":[
				"ideObjectTypes()"
			],
			"associations":["revidelibrary"],
			"summary":"A list of the object types, in 'type ID' form",
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of the object types, one per line."
			}],
			"description":"This function returns a list of the object types in the form used by the IDE."
		},{
			"id":"revidelibrary-36",
			"name":"revidepainttools",
			"display name":"revIDEPaintTools",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEPaintTools()"
			],
			"display syntax":[
				"revIDEPaintTools()"
			],
			"associations":["revidelibrary"],
			"summary":"Returns information about the paint tools.",
			"value":[{
				"name":"return",
				"type":"",
				"description":"an array, keyed by the paint tool types that appear\nin the Tools palette, of properties associated with each of\nthose paint tools."
			}],
			"description":"Returns information about the paint tools."
		},{
			"id":"revidelibrary-37",
			"name":"idepropertynames",
			"display name":"idePropertyNames",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"idePropertyNames(<pObjectType>)"
			],
			"display syntax":[
				"idePropertyNames(<i>pObjectType</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"A list of the object property names considered canonical by the IDE",
			"parameters":[{
				"name":"pObjectType",
				"type":"",
				"refparam":"false",
				"description":"One of the IDE's object type IDs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of the object property names, one per line."
			}],
			"description":"This function returns a list of the object property names considered canonical by\nthe IDE, as parsed from the file Toolset/resources/supporting_files/property_definitions.txt.\n\nIf the <pObjectType> parameter is used, this returns a list of the properties specific to\nthat object type, as parsed from the files in Toolset/resources/supporting_files/.\n\nFor a list of the object type IDs which are valid inputs to this function, see the <ideObjectTypes>\nfunction.",
			"references":{
				"function":["ideObjectTypes"]
			}
		},{
			"id":"revidelibrary-38",
			"name":"revideunsubscribeall",
			"display name":"revIDEUnsubscribeAll",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"revIDEUnsubscribeAll <pObject>"
			],
			"display syntax":[
				"revIDEUnsubscribeAll <i>pObject</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Unsubscribes the object from all messages",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"The long ID of the object you wish to unsubscribe from all message. This is an optional parameter, if not specified, the calling object will be used."
			}],
			"description":"Unsubscribes the object from all messages"
		},{
			"id":"revidelibrary-39",
			"name":"revideplugins",
			"display name":"revIDEPlugins",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEPlugins()"
			],
			"display syntax":[
				"revIDEPlugins()"
			],
			"associations":["revidelibrary"],
			"summary":"Information about the plugins of the IDE.",
			"examples":[{
				"script":"put the keys of revIDEPlugins() -- the names of the plugins"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with an element for each plugin"
			}],
			"description":"The array that <revIDEPlugins> returns is keyed by the names of the\nplugin stacks. The element of a plugin has the \"path\" of its stack, and\ntrue in \"menu\" when it is in the Plugins menu, in \"startup\" when it opens\nwhen the IDE starts and in \"shutdown\" when it opens when the IDE quits.",
			"references":{
				"function":["revIDEGetAllPlugins"]
			}
		},{
			"id":"revidelibrary-40",
			"name":"revideobjectsareselectable",
			"display name":"revIDEObjectsAreSelectable",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEObjectsAreSelectable(<pObjects>)"
			],
			"display syntax":[
				"revIDEObjectsAreSelectable(<i>pObjects</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Determine if a list of objects are selectable using\nthe select command",
			"parameters":[{
				"name":"pObjects",
				"type":"",
				"refparam":"false",
				"description":"A return delimited list of object references"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"True if the objects can be selected"
			}],
			"description":"Returns true if all objects exist, are on an editable open stack and\nhave the same owner."
		},{
			"id":"revidelibrary-41",
			"name":"revidesubscribedobjects",
			"display name":"revIDESubscribedObjects",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDESubscribedObjects(<pMessage>)"
			],
			"display syntax":[
				"revIDESubscribedObjects(<i>pMessage</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Use to find out which objects are subscribed to a given message",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The name of the message."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Return delimited list of object ID's, 1 per line."
			}],
			"description":"Use to find out which objects are subscribed to a given message"
		},{
			"id":"revidelibrary-42",
			"name":"idemessagesendwithparameters",
			"display name":"ideMessageSendWithParameters",
			"library":"revidelibrary",
			"type":"command",
			"syntax":[
				"ideMessageSendWithParameters <pMessage>,<pTriggeringObjects>,<pParamsArray>"
			],
			"display syntax":[
				"ideMessageSendWithParameters <i>pMessage</i>,<i>pTriggeringObjects</i>,<i>pParamsArray</i>"
			],
			"associations":["revidelibrary"],
			"summary":"Sends the given message to all subscribed objects.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message to send"
			},{
				"name":"pTriggeringObjects",
				"type":"",
				"refparam":"false",
				"description":"A list, one per line, of the long ids of the objects triggering the message.\nThis is used for example with the <idePropertyChanged> message to\nconvey which objects had properties changed."
			},{
				"name":"pParamsArray",
				"type":"",
				"refparam":"false",
				"description":"A numerically keyed aray (starting at 1) of the parameters to pass along with the message."
			}],
			"description":"Sends <pMessage> to all objects which have subscribed to it using\n<revIDESubscribe>.",
			"references":{
				"command":["ideSubscribe"],
				"message":["idePropertyChanged"]
			}
		},{
			"id":"revidelibrary-43",
			"name":"revideobjectisonidestack",
			"display name":"revIDEObjectIsOnIDEStack",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEObjectIsOnIDEStack(<pLongID>)"
			],
			"display syntax":[
				"revIDEObjectIsOnIDEStack(<i>pLongID</i>)"
			],
			"associations":["revidelibrary"],
			"summary":"Determines whether an object is considered part of the IDE",
			"parameters":[{
				"name":"pLongID",
				"type":"",
				"refparam":"false",
				"description":"The long id of the object."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":""
			}],
			"description":"Use the <revIDEObjectIsOnIDEStack> function to determine whether an object is\nconsidered part of the IDE, that is if it is on a stack whose mainstack is part\nof the IDE, according to the <revIDEStackIsIDEStack> function.",
			"references":{
				"function":["revIDEStackIsIDEStack"]
			}
		},{
			"id":"revidelibrary-44",
			"name":"revidemessages",
			"display name":"revIDEMessages",
			"library":"revidelibrary",
			"type":"function",
			"syntax":[
				"revIDEMessages()"
			],
			"display syntax":[
				"revIDEMessages()"
			],
			"associations":["revidelibrary"],
			"summary":"Use to get a list of all the messages that the IDE allows subscriptions for",
			"value":[{
				"name":"return",
				"type":"",
				"description":"Return delimited list of message names, 1 per line."
			}],
			"description":"Use to get a list of all the messages that the IDE allows subscriptions for",
			"references":{
				"command":["revIDEUnsubscribe","revIDESubscribe"],
				"function":["revIDESubscribedObjects","revIDESubscriptions"]
			}
		}