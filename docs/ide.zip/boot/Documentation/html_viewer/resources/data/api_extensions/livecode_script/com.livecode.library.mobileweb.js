{
			"id":"com.livecode.library.mobileweb-1",
			"name":"com.livecode.library.mobileweb",
			"display name":"Mobile Web Library",
			"library":"com.livecode.library.mobileweb",
			"type":"library",
			"display syntax":[
				"Mobile Web Library"
			],
			"associations":["com.livecode.library.mobileweb"],
			"description":"The Mobile Web library helps a stack work in the browser of a phone or a\ntablet when it is built as an HTML5 standalone. It fills the screen with\nthe stack and keeps it filled when the phone turns, tells the stack how\nmuch of it the on-screen keyboard covers, reports swipes, pinches and\nlong presses, and scrolls a field or group with a finger.\n\nIt also lays one stack out for a phone, a tablet and a desktop\n(mwResponsive): rules on the controls say where each goes at each size,\na group can arrange its controls in columns (mwFlow), and the stack is\ntold when it crosses from one layout to another (layoutChanged).\n\nOn a desktop it answers as a desktop would and sends no gestures, so a\nstack that uses it can be made and tried in the IDE. Nothing changes for\na stack that does not call it."
		},{
			"id":"com.livecode.library.mobileweb-2",
			"name":"mwsetbreakpoints",
			"display name":"mwSetBreakpoints",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwSetBreakpoints <pTablet>,<pDesktop>"
			],
			"display syntax":[
				"mwSetBreakpoints <i>pTablet</i>,<i>pDesktop</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Change the widths at which <mwLayoutClass> changes.",
			"parameters":[{
				"name":"pTablet",
				"type":"",
				"refparam":"false",
				"description":"The width, in pixels, from which a stack is laid out as a tablet's."
			},{
				"name":"pDesktop",
				"type":"",
				"refparam":"false",
				"description":"The width from which it is laid out as a desktop's: more than pTablet."
			}],
			"examples":[{
				"script":"-- a stack whose desktop layout needs more room\nmwSetBreakpoints 600, 1200"
			},{
				"script":"-- back to 600 and 1024\nmwSetBreakpoints"
			}],
			"description":"With no parameters, the widths go back to 600 and 1024. The breakpoints\nare the same for every stack. The stacks that <mwResponsive> lays out\nare laid out again for the new widths, and get layoutChanged if their\nclass changes.\n\nIf the widths are not two whole numbers, the second more than the first,\nnothing changes and the result is \"bad breakpoints\".",
			"references":{
				"command":["mwResponsive"],
				"function":["mwBreakpoints","mwLayoutClass"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-3",
			"name":"mwstart",
			"display name":"mwStart",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwStart <pStack>,<pGestures>,<pScreen>"
			],
			"display syntax":[
				"mwStart <i>pStack</i>,<i>pGestures</i>,<i>pScreen</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Make a stack ready for a phone's browser: the screen, and the gestures.",
			"parameters":[{
				"name":"pStack",
				"type":"",
				"refparam":"false",
				"description":"The name of the stack. Empty for the default stack."
			},{
				"name":"pGestures",
				"type":"",
				"refparam":"false",
				"description":"A comma-separated list of the gestures to report: any of \"swipe\",\n\"pinch\", \"longpress\" and \"touch\" (the touch messages, one finger each).\nEmpty for all four; \"none\" for none."
			},{
				"name":"pScreen",
				"type":"",
				"refparam":"false",
				"description":"How the stack meets the browser's window: \"fill\" (the stack is made as\nbig as the window), \"fit\" (the stack keeps its size and is scaled to\nthe window, see <mwFitStack>), \"none\" (the stack is left as it is), or\nempty to choose: \"fill\" for a resizable stack, and for a stack of a\nfixed size, \"fit\" while it is too big for the window."
			}],
			"examples":[{
				"script":"on openStack\n   mwStart\nend openStack\n\n-- in a card's script: a swipe anywhere on the card\non swipe pDirection\n   if pDirection is \"left\" then go next card\n   if pDirection is \"right\" then go previous card\nend swipe"
			},{
				"script":"-- in the script of a graphic \"Photo\": a pinch over it\non pinch pScale\n   set the width of me to round(200 * pScale)\nend pinch"
			}],
			"description":"One line in openStack makes a stack ready for a phone. A resizable\nstack fills the browser's window, and fills it again when the phone\nturns; it gets resizeStack each time, as on a desktop, so the Geometry\nManager or a resizeStack handler lays it out (see <mwFillScreen>). A\nstack of a fixed size that is too big for the window, such as one made\nfor a desktop, is scaled down to fit, and taps still reach the controls\nunder them (see <mwFitStack>).\n\nAfter <mwStart> the stack gets these messages. The gestures go to the\ncontrol under the finger, as mouseDown does: a control that has no\nhandler for one, or passes it, sends it on to its group, its card and\nits stack, so a card's script can handle every swipe on the card.\n\n- swipe pDirection: a quick stroke of one finger: \"left\", \"right\", \"up\"\n  or \"down\" (the way the finger went). It goes to the control where the\n  stroke began.\n- pinchStart pX, pY, then pinch pScale, pX, pY as two fingers move,\n  and pinchEnd pScale: pScale is the distance between the fingers over\n  their distance at the start, and pX, pY the point between them. All\n  three go to the control under that point when the pinch began.\n- longPress pX, pY: a finger held still for about half a second.\n- touchStart pId, pX, pY when a finger touches the stack, touchMove\n  pId, pX, pY as it moves (at most once a frame), and touchEnd pId, pX,\n  pY when it lets go (touchRelease when the browser takes the touch away,\n  as it can for a call). pId is a number of the finger's own, the same\n  in all its messages, so two or more fingers can be followed at once,\n  for drawing or a game. All of them go to the control the finger\n  touched first, as LiveCode's iOS and Android engines send them.\n\nThese go to the current card, as LiveCode's iOS and Android engines send\nthem:\n\n- orientationChanged: the phone turned (after the stack has been filled\n  or fitted again). <mwViewport> says which way it is now.\n- keyboardActivated: the on-screen keyboard came up, or changed its\n  height while up. <mwViewport> says how much of the page it covers.\n- keyboardDeactivated: the keyboard went away.\n\nPoints are in the card's coordinates. The gestures come in addition to\nthe mouse messages that a touch already sends: a swipe is also a drag of\nthe mouse, and a long press ends in a mouseUp. A stack can ask\n<mwLongPressed> in its mouseUp to tell one from a click.\n\nOn a desktop, <mwStart> only remembers the stack: the stack keeps its\nsize, and no gestures are sent, so a stack that calls it can be made and\ntried in the IDE.",
			"references":{
				"command":["mwStop","mwFillScreen","mwFitStack"],
				"function":["mwViewport"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-4",
			"name":"mwisfullscreen",
			"display name":"mwIsFullScreen",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwIsFullScreen()"
			],
			"display syntax":[
				"mwIsFullScreen()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the stack is on the whole screen, without the browser's bars.",
			"examples":[{
				"script":"if mwIsFullScreen() then\n   set the label of button \"Full\" to \"Show the bars\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true after <mwFullScreen> true, until the user or <mwFullScreen> false\nputs the bars back; false on a desktop."
			}],
			"description":"Whether the stack is on the whole screen, without the browser's bars.",
			"references":{
				"command":["mwFullScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-5",
			"name":"mwpointer",
			"display name":"mwPointer",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwPointer()"
			],
			"display syntax":[
				"mwPointer()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"What the stack is used with: a finger, a mouse, or both.",
			"examples":[{
				"script":"-- bigger targets for a finger, hover effects for a mouse\nif mwPointer() is \"touch\" then\n   set the height of button \"Save\" to 48\nelse\n   set the height of button \"Save\" to 32\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"touch\", \"mouse\" or \"both\"."
			}],
			"description":"In a browser, \"touch\" is a phone or a tablet, \"mouse\" a computer with a\nmouse or a trackpad, and \"both\" a computer with a touch screen or a\ntablet with a trackpad, as the browser reports them (the CSS any-pointer\nmedia feature). On a desktop it is \"mouse\".\n\nThe pointer and the size go apart: a tablet on its side is as wide as a\nsmall computer's window. Use <mwLayoutClass> to arrange the controls, and\n<mwPointer> to size them for a finger and to choose whether hovering\nshows anything.",
			"references":{
				"function":["mwLayoutClass","mwIsTouchScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-6",
			"name":"mwappearance",
			"display name":"mwAppearance",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwAppearance()"
			],
			"display syntax":[
				"mwAppearance()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the browser or the computer is set to a dark look.",
			"examples":[{
				"script":"if mwAppearance() is \"dark\" then\n   set the backColor of this stack to \"#111827\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"dark\" or \"light\"."
			}],
			"description":"In a browser, <mwAppearance> is what the browser asks pages for (the CSS\nprefers-color-scheme), whatever the standalone's settings. On a desktop\nit is the <systemAppearance>.\n\nThe <systemAppearanceChanged> message says when it changes: on a desktop,\nand in an HTML5 standalone built with Appearance set to \"Follow the\nbrowser\" in the Web pane of the Standalone Application Settings.",
			"references":{
				"property":["systemAppearance"],
				"message":["systemAppearanceChanged"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-7",
			"name":"mwfitstack",
			"display name":"mwFitStack",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwFitStack <pStack>,<pMode>"
			],
			"display syntax":[
				"mwFitStack <i>pStack</i>,<i>pMode</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Show a stack made for a big screen at a size that fits the browser's\nwindow.",
			"parameters":[{
				"name":"pStack",
				"type":"",
				"refparam":"false",
				"description":"The stack to fit. Empty for the stack that <mwStart> named, or else the\ndefault stack."
			},{
				"name":"pMode",
				"type":"",
				"refparam":"false",
				"description":"How to fit it, one of the <fullscreenMode> values: \"showAll\" (the whole\nstack, as big as fits, with bars at the sides or the top and bottom;\nthe default), \"letterbox\", \"exactFit\" or \"noBorder\"."
			}],
			"examples":[{
				"script":"on openStack\n   if mwIsTouchScreen() then mwFitStack\nend openStack"
			}],
			"description":"<mwStart> fits a stack of a fixed size that is too big for the window\nby itself; use <mwFitStack> to fit one whatever its size, or with\nanother mode. The engine\nscales the whole stack, and taps still land on the right controls,\nbecause the engine does the scaling. It sets the stack's\n<fullscreenMode> to <pMode> and its <fullscreen> to true, and fits it\nagain when the phone turns.\n\nOn a desktop, <mwFitStack> does nothing.",
			"references":{
				"command":["mwFillScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-8",
			"name":"mwresponsive",
			"display name":"mwResponsive",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwResponsive <pStack>,<pOn>"
			],
			"display syntax":[
				"mwResponsive <i>pStack</i>,<i>pOn</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Lay a stack out for a phone, a tablet or a desktop, and again whenever its\nsize changes.",
			"parameters":[{
				"name":"pStack",
				"type":"",
				"refparam":"false",
				"description":"The name of the stack. Empty for the <defaultStack>."
			},{
				"name":"pOn",
				"type":"",
				"refparam":"false",
				"description":"false to stop. Empty or true to start."
			}],
			"examples":[{
				"script":"on preOpenStack\n   mwStart -- fill a phone's screen (does nothing on a desktop)\n   mwResponsive -- and lay the stack out for its size\nend preOpenStack\n\non layoutChanged pClass, pOrientation\n   -- \"phone\", \"tablet\" or \"desktop\"; \"portrait\" or \"landscape\"\n   set the label of button \"Menu\" to pClass\nend layoutChanged"
			},{
				"script":"-- rules that the library follows: a sidebar on a desktop, none on a phone\nset the mwLayout[\"desktop\"] of group \"Sidebar\" to \"left 0, top 0, bottom 0, width 240\"\nset the mwLayout[\"phone\"] of group \"Sidebar\" to \"hidden\"\nset the mwLayout[\"desktop\"] of group \"Cards\" to \"left 256, top 16, right 16, bottom 16, flow 3\"\nset the mwLayout[\"all\"] of group \"Cards\" to \"left 16, top 16, right 16, bottom 72, flow\""
			}],
			"description":"<mwResponsive> makes one stack fit a phone, a tablet and a desktop, as a\nweb page does. Each time the stack's size changes, on a desktop or in a\nbrowser, it does two things:\n\n1. It lays out the controls that have rules: the keys of their mwLayout\n   custom property set, below.\n2. When the stack's layout class (<mwLayoutClass>) or orientation has\n   changed, it sends layoutChanged pClass, pOrientation to the current\n   card, so a script can do the rest. It is sent once at once, when\n   <mwResponsive> starts.\n\nA rule is a key of a control's mwLayout custom property set: \"phone\",\n\"tablet\" or \"desktop\", any of them followed by a space and \"portrait\" or\n\"landscape\" (\"phone landscape\"), or \"all\". The most particular key that\nthe control has is used: \"phone landscape\", then \"phone\", then \"all\". A\ncontrol with no key that fits is left alone. A rule is a list of these,\nseparated by commas:\n\n- left N, top N, right N, bottom N: the distance from that edge of the\n  card (right and bottom from the right and bottom edges). N is in\n  pixels, or a percentage of the card's width or height (\"50%\").\n- width N, height N: the size. With left and right both given, the\n  width follows from them; with neither, the control keeps its place.\n  The same goes for top, bottom and height.\n- hidden: the control is hidden in this layout. In a layout whose rule\n  does not say hidden, it is shown again; a control that a script hid\n  stays hidden.\n- within: measure from the group the control is in, not from the card:\n  for the controls of a card in a grid, or of a panel.\n- bleed: an edge at 0 reaches on past the safe area to the edge of the\n  screen (or of the group, with within). The distances are measured\n  inside the safe area, out of a phone's notch and home bar, once\n  <mwStart> fills the screen (on a desktop there is none); a bar's\n  background with \"bleed, top 0, height 56\" fills the notch above it,\n  while the title in it stays below the notch.\n- flow N, and gap N: for a group, arrange the controls in it in N\n  columns, as <mwFlow> does; flow alone chooses 1, 2 or 3 columns by\n  the class.\n\nThe rules are followed for every card of the stack, and a control\nshared by cards (a group placed on them) once. A group's controls move\nwith it, and a group placed by a rule keeps the rectangle it is given\n(its lockLocation is set to true); the rules within a group are followed\nafter the group is placed and its controls flowed.\n\nThe stack's size changes reach the library as resizeStack: if the stack\nhas a resizeStack handler, it must pass the message, as for the Geometry\nManager. A resizeStack handler that wants the rules followed first, so\nas to place other controls by the ones they moved, calls\n<mwApplyLayout> before it does so.\n\nOn its own, <mwResponsive> neither fills a phone's screen nor sends the\ngestures:<mwStart> does those. Together, a resizable stack fills the\nbrowser's window and is laid out for it again as the phone turns.\n\nIf the stack does not exist, the result is \"no such stack:\" and its name.",
			"references":{
				"command":["mwApplyLayout","mwFlow","mwSetBreakpoints","mwStart"],
				"function":["mwLayoutClass","mwPointer"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-9",
			"name":"mwfillscreen",
			"display name":"mwFillScreen",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwFillScreen <pStack>"
			],
			"display syntax":[
				"mwFillScreen <i>pStack</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Make a stack fill the browser's window, and keep it filling it.",
			"parameters":[{
				"name":"pStack",
				"type":"",
				"refparam":"false",
				"description":"The stack to fill the page with. Empty for the stack that <mwStart>\nnamed, or else the default stack."
			}],
			"examples":[{
				"script":"on openStack\n   mwStart the short name of me, empty, \"none\"\n   mwFillScreen\nend openStack\n\non resizeStack pWidth, pHeight\n   set the rect of group \"Content\" to 0, 60, pWidth, pHeight - 56\nend resizeStack"
			}],
			"description":"<mwStart> fills the screen with a resizable stack by itself; use\n<mwFillScreen> for a stack whose size is fixed, or after\nmwStart with \"none\". The stack becomes\nas big as the browser's window, its page loses its margins and reaches\nthe screen's edges (use the insets of <mwViewport> to keep controls out\nof the notch), and the stack is resized again when the phone turns.\nThe stack gets resizeStack each time, as a resizable desktop stack does,\nso it lays itself out there.\n\nThe page itself keeps still: a finger cannot scroll or zoom it.\n<mwStop> gives the page back its margins and lets it scroll again.\n\nOn a desktop, <mwFillScreen> does nothing: the stack keeps its size, as\nit would in the IDE. Nor does it in a page that shows the stack inside\nits own frame, such as the Stack Player's, which says so with the\nattribute data-mobile-web-fill=\"no\" on its html or body element: there\nthe result is \"the page keeps its own layout\" and the stack keeps its\nsize.\n\nTo show a stack that was laid out for a big screen, use <mwFitStack>.",
			"references":{
				"command":["mwFitStack","mwStart"],
				"function":["mwViewport"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-10",
			"name":"mwsensoravailable",
			"display name":"mwSensorAvailable",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwSensorAvailable(<pSensor>)"
			],
			"display syntax":[
				"mwSensorAvailable(<i>pSensor</i>)"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the phone has a sensor the browser can read.",
			"parameters":[{
				"name":"pSensor",
				"type":"",
				"refparam":"false",
				"description":"\"location\", \"heading\", \"acceleration\" or \"rotation rate\"."
			}],
			"examples":[{
				"script":"if mwSensorAvailable(\"location\") then\n   show button \"Where am I\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true where the browser has a way to read the sensor; false on a desktop,\nin a browser without one, and for a name that is not a sensor."
			}],
			"description":"Use <mwSensorAvailable> to show only what the phone can do. A browser\nthat has the way may still find no sensor, or the user may say no: then\n<mwStartSensor> sends trackingError.",
			"references":{
				"command":["mwStartSensor"],
				"function":["mwSensorReading"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-11",
			"name":"mwvibrate",
			"display name":"mwVibrate",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwVibrate <pMilliseconds>"
			],
			"display syntax":[
				"mwVibrate <i>pMilliseconds</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Buzz the phone.",
			"parameters":[{
				"name":"pMilliseconds",
				"type":"",
				"refparam":"false",
				"description":"How long to buzz, from 1 to 5000 milliseconds. Empty for 50."
			}],
			"examples":[{
				"script":"on mouseUp\n   mwVibrate 30\nend mouseUp"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the browser buzzed the phone; false where it cannot (iPhone and\niPad browsers, desktops)."
			}],
			"description":"Use <mwVibrate> to give a short buzz when something happens, such as a\nwrong answer in a game. The result is false where the browser has no way\nto buzz the phone; the stack goes on as before.",
			"references":{
				"function":["mwIsTouchScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-12",
			"name":"mwflow",
			"display name":"mwFlow",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwFlow <pGroup>,<pColumns>,<pGap>"
			],
			"display syntax":[
				"mwFlow <i>pGroup</i>,<i>pColumns</i>,<i>pGap</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Arrange the controls in a group in columns, as a grid of cards.",
			"parameters":[{
				"name":"pGroup",
				"type":"",
				"refparam":"false",
				"description":"A reference to the group, such as the long id of a group."
			},{
				"name":"pColumns",
				"type":"",
				"refparam":"false",
				"description":"The number of columns. Empty for one on a phone, two on a tablet and\nthree on a desktop, by the <mwLayoutClass> of the group's stack."
			},{
				"name":"pGap",
				"type":"",
				"refparam":"false",
				"description":"The space between the controls, and around them, in pixels. Empty for\n12."
			}],
			"examples":[{
				"script":"-- a grid of cards that reflows by the width of the window\non resizeStack pWidth, pHeight\n   set the rect of group \"Cards\" to 0, 56, pWidth, pHeight\n   mwFlow the long id of group \"Cards\"\n   pass resizeStack\nend resizeStack"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The height that the controls take up, from the top of the group, in\nthe result."
			}],
			"description":"<mwFlow> places the visible controls that are directly in the group, in\nthe order of their layers, left to right in rows: every control is made\nas wide as a column, keeps its height, and a row is as tall as its\ntallest control. A hidden control is left out. Then the rules \"within\" the\ncontrols it placed are followed (see <mwResponsive>), so a group in the\ngrid can lay out its own controls for its new width. The group keeps its\nrectangle (its lockLocation is set to true); if the controls need more\nheight than it has, give it a scroll bar or use <mwDragScroll> on it. Its\nscroll is kept, as far as the new height allows.\n\nA rule of the mwLayout custom property set with \"flow\" does the same each\ntime the stack's size changes (see <mwResponsive>).\n\nIf pGroup is not a group, the result is \"no such group\".",
			"references":{
				"command":["mwResponsive","mwDragScroll"],
				"function":["mwLayoutClass"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-13",
			"name":"mwfullscreen",
			"display name":"mwFullScreen",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwFullScreen <pFull>"
			],
			"display syntax":[
				"mwFullScreen <i>pFull</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Show the stack on the whole screen, without the browser's bars, or put\nthe bars back.",
			"parameters":[{
				"name":"pFull",
				"type":"",
				"refparam":"false",
				"description":"true for the whole screen, false for the browser's bars back."
			}],
			"examples":[{
				"script":"on mouseUp\n   mwFullScreen not mwIsFullScreen()\nend mouseUp"
			}],
			"description":"A phone's browser keeps its address bar (and on some phones, buttons)\nover part of the screen. <mwFullScreen> true asks for the whole screen,\nas a video does; the stack gets resizeStack (when <mwStart> fills the\nscreen with it) and is laid out for the new size. The user can leave\nwith the phone's back gesture.\n\nCall it from a tap: a browser gives the whole screen only then. The\nresult is \"not supported\" where the browser cannot, such as on an iPhone\n(an iPad can) and on a desktop outside a browser, and \"not from a tap\"\nwhen it was not called from a tap. On an iPhone, a page added to the\nhome screen opens without the bars instead (see <mwIsInstalled>).",
			"references":{
				"command":["mwStart"],
				"function":["mwIsFullScreen","mwIsInstalled"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-14",
			"name":"mwstopsensor",
			"display name":"mwStopSensor",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwStopSensor <pSensor>"
			],
			"display syntax":[
				"mwStopSensor <i>pSensor</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Stop reading a sensor.",
			"parameters":[{
				"name":"pSensor",
				"type":"",
				"refparam":"false",
				"description":"\"location\", \"heading\", \"acceleration\" or \"rotation rate\"."
			}],
			"examples":[{
				"script":"on closeCard\n   mwStopSensor \"acceleration\"\nend closeCard"
			}],
			"description":"After <mwStopSensor> the card gets no more of that sensor's messages.\nStop a sensor when it is not needed: reading one uses the battery.\n<mwStop> stops them all.",
			"references":{
				"command":["mwStartSensor"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-15",
			"name":"mwkeepawake",
			"display name":"mwKeepAwake",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwKeepAwake <pAwake>"
			],
			"display syntax":[
				"mwKeepAwake <i>pAwake</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Keep the phone's screen on, or let it turn off again.",
			"parameters":[{
				"name":"pAwake",
				"type":"",
				"refparam":"false",
				"description":"true to keep the screen on, false to let it turn off as usual."
			}],
			"examples":[{
				"script":"-- a recipe, read while cooking\non openCard\n   mwKeepAwake true\nend openCard\n\non closeCard\n   mwKeepAwake false\nend closeCard"
			}],
			"description":"A phone turns its screen off after a while without a touch. Use\n<mwKeepAwake> for a stack that is read or watched without being touched:\na recipe, a timer, a game played with the sensors. The screen stays on\nwhile the page is in front, and again when the user comes back to it.\n<mwStop> lets it go.\n\nThe result is \"not supported\" where the browser cannot keep the screen\non, as on a desktop or a page not served over https.",
			"references":{
				"command":["mwStop"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-16",
			"name":"mwsensorreading",
			"display name":"mwSensorReading",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwSensorReading(<pSensor>,<pDetailed>)"
			],
			"display syntax":[
				"mwSensorReading(<i>pSensor</i>,<i>pDetailed</i>)"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"A sensor's last reading.",
			"parameters":[{
				"name":"pSensor",
				"type":"",
				"refparam":"false",
				"description":"\"location\", \"heading\", \"acceleration\" or \"rotation rate\"."
			},{
				"name":"pDetailed",
				"type":"",
				"refparam":"false",
				"description":"true for an array with every value the browser gave; empty or false for\nthe main values, separated by commas."
			}],
			"examples":[{
				"script":"put mwSensorReading(\"location\") into tWhere\nif tWhere is not empty then\n   put \"Latitude:\" && item 1 of tWhere into field \"Where\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"For \"location\", the latitude, longitude and altitude; for \"heading\",\nthe heading; for \"acceleration\" and \"rotation rate\", x, y and z. With\npDetailed, an array: \"latitude\", \"longitude\", \"altitude\", \"horizontal\naccuracy\", \"vertical accuracy\", \"speed\", \"course\" and \"timestamp\" for a\nlocation; \"heading\", \"accuracy\" and \"timestamp\" for a heading; \"x\", \"y\",\n\"z\" and \"timestamp\" for the others. Empty before the first reading."
			}],
			"description":"Use <mwSensorReading> to look at a sensor's reading when it is needed,\ninstead of keeping each message's. The sensor must be started with\n<mwStartSensor>; its reading is kept until it is stopped.",
			"references":{
				"command":["mwStartSensor"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-17",
			"name":"mwviewport",
			"display name":"mwViewport",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwViewport()"
			],
			"display syntax":[
				"mwViewport()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"The part of the page that the stack can be seen in.",
			"examples":[{
				"script":"local tView\nput mwViewport() into tView\nset the bottom of group \"Form\" to tView[\"height\"] - 8"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"- \"width\" and \"height\": the size of the part of the page that can be\n  seen, in pixels, without what the on-screen keyboard covers\n- \"keyboard\": how many pixels at the bottom the keyboard covers (0 when\n  it is not up)\n- \"top\", \"right\", \"bottom\" and \"left\": the safe-area insets, the pixels\n  at each edge under a notch, a rounded corner or the home bar (0 when\n  the page does not reach those edges, or there are none)\n- \"orientation\": \"portrait\" or \"landscape\""
			}],
			"description":"Use <mwViewport> to keep what matters where it can be seen: above the\nkeyboard, inside the safe area. The insets are 0 unless the page reaches\nthe edges of the screen, which <mwFillScreen> asks for.\n\nOn a desktop, the width and height are those of the screen the stack is\non, and the keyboard and insets are 0.",
			"references":{
				"command":["mwStart","mwFillScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-18",
			"name":"mwlayoutclass",
			"display name":"mwLayoutClass",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwLayoutClass(<pWidthOrStack>)"
			],
			"display syntax":[
				"mwLayoutClass(<i>pWidthOrStack</i>)"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Which kind of screen a stack's size is laid out for: a phone's, a\ntablet's or a desktop's.",
			"parameters":[{
				"name":"pWidthOrStack",
				"type":"",
				"refparam":"false",
				"description":"A width in pixels, or the name of a stack (its width is used). Empty\nfor the <defaultStack>."
			}],
			"examples":[{
				"script":"if mwLayoutClass() is \"phone\" then\n   hide group \"Sidebar\"\nelse\n   show group \"Sidebar\"\nend if"
			},{
				"script":"put mwLayoutClass(700) -- \"tablet\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"phone\", \"tablet\" or \"desktop\"."
			}],
			"description":"Use <mwLayoutClass> to lay a stack out by the room it has, as a web page\ndoes with its breakpoints. It goes by the width alone: under 600 pixels\nis \"phone\" (a phone held upright), 600 to 1023 is \"tablet\" (a tablet, or\na phone on its side), and 1024 and over is \"desktop\" (a computer's\nwindow, or a big tablet on its side). <mwSetBreakpoints> changes the two\nwidths.\n\nIt answers the same on a desktop, in the IDE and in a browser, so a\nstack can be tried in all three layouts in the IDE by making its window\nnarrower or wider. <mwResponsive> sends layoutChanged when the class\nchanges, and lays out the controls that have rules for it.",
			"references":{
				"command":["mwResponsive","mwSetBreakpoints"],
				"function":["mwBreakpoints","mwPointer"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-19",
			"name":"mwapplylayout",
			"display name":"mwApplyLayout",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwApplyLayout <pStack>"
			],
			"display syntax":[
				"mwApplyLayout <i>pStack</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Follow a stack's layout rules now.",
			"parameters":[{
				"name":"pStack",
				"type":"",
				"refparam":"false",
				"description":"The name of the stack. Empty for the <defaultStack>."
			}],
			"examples":[{
				"script":"on resizeStack\n   mwApplyLayout -- the rules first\n   -- then a control placed by one that a rule moved\n   set the top of field \"Note\" to the bottom of group \"Header\" + 8\n   pass resizeStack\nend resizeStack"
			}],
			"description":"<mwApplyLayout> lays out the controls of every card of the stack that\nhave rules for its size now, the keys of their mwLayout custom property\nset (see <mwResponsive>). <mwResponsive> does it each time the stack's\nsize changes; call it to have it done before your own code, or after\nmaking controls or changing their rules. It sends no message.\n\nIt works on any stack, whether <mwResponsive> started or not, and on a\ndesktop as in a browser.\n\nA rule that cannot be read is left out, and the result is \"bad rule:\",\nthe control's name and the rule; otherwise the result is empty.",
			"references":{
				"command":["mwResponsive","mwFlow"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-20",
			"name":"mwlongpressed",
			"display name":"mwLongPressed",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwLongPressed()"
			],
			"display syntax":[
				"mwLongPressed()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the touch that ended was a long press.",
			"examples":[{
				"script":"on mouseUp\n   if mwLongPressed() then exit mouseUp\n   go next card\nend mouseUp"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true from the moment longPress is sent until the finger has been let\ngo and the mouseUp it makes has been handled; false otherwise."
			}],
			"description":"A long press is still a touch, so it ends in a mouseUp, as a click does.\nUse <mwLongPressed> in a mouseUp to leave out what a click would do.",
			"references":{
				"command":["mwStart"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-21",
			"name":"mwshare",
			"display name":"mwShare",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwShare <pText>,<pURL>,<pTitle>"
			],
			"display syntax":[
				"mwShare <i>pText</i>,<i>pURL</i>,<i>pTitle</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Share text or a link through the phone's share sheet.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to share."
			},{
				"name":"pURL",
				"type":"",
				"refparam":"false",
				"description":"A link to share. Empty for none."
			},{
				"name":"pTitle",
				"type":"",
				"refparam":"false",
				"description":"A title, which some apps show. Empty for none."
			}],
			"examples":[{
				"script":"on mouseUp\n   mwShare \"My best score is\" && field \"Score\", \"https://example.com/game\"\n   if the result is \"copied\" then answer \"Copied, ready to paste.\"\nend mouseUp"
			}],
			"description":"On a phone, <mwShare> opens the share sheet, where the user picks an\napp (a message, an email, a note) to share with. Call it from a tap: a\nbrowser opens the sheet only then. Where the browser has no share sheet,\nas on most desktops, the text and the link are copied instead, ready to\npaste, and the result is \"copied\". It is \"not supported\" where neither\ncan be done, \"nothing to share\" when the text and the link are empty,\nand \"not from a tap\" when it was not called from a tap and the browser\ncan tell that it would not open the sheet.",
			"references":{
				"command":["mwVibrate"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-22",
			"name":"mwisweb",
			"display name":"mwIsWeb",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwIsWeb()"
			],
			"display syntax":[
				"mwIsWeb()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the stack runs in a web browser.",
			"examples":[{
				"script":"if mwIsWeb() then\n   mwStart\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true in an HTML5 standalone and the web IDE, false everywhere else."
			}],
			"description":"Use <mwIsWeb> to choose between what a stack does in a browser and what it\ndoes on a desktop. It is the same as asking whether <platform> is \"HTML5\".",
			"references":{
				"command":["mwStart"],
				"function":["mwIsTouchScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-23",
			"name":"mwstop",
			"display name":"mwStop",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwStop"
			],
			"display syntax":[
				"mwStop"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Stop the library's messages.",
			"examples":[{
				"script":"on closeStack\n   mwStop\nend closeStack"
			}],
			"description":"After <mwStop> no more of the library's messages are sent, and the\nbrowser's listeners that <mwStart> added are removed. The sensors that\n<mwStartSensor> started are stopped, the screen kept on by\n<mwKeepAwake> is let go, and an <mwPickPhoto> still waiting is\ncancelled. A stack that was\nfilling the screen keeps the size it has, and the page gets back its\nmargins and its scrolling.",
			"references":{
				"command":["mwStart"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-24",
			"name":"mwisinstalled",
			"display name":"mwIsInstalled",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwIsInstalled()"
			],
			"display syntax":[
				"mwIsInstalled()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the page was opened from the home screen, as an app.",
			"examples":[{
				"script":"if mwIsTouchScreen() and not mwIsInstalled() then\n   answer \"Tip: add this page to your home screen to keep your work.\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when the browser shows the page as an installed app, without its\nown bar; false in an ordinary tab and on a desktop."
			}],
			"description":"On iPhone and iPad, Safari deletes what a page keeps (the files a stack\nsaves) after some days without a visit, unless the page was added to the\nhome screen. Use <mwIsInstalled> to suggest adding it.",
			"references":{
				"function":["mwIsTouchScreen"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-25",
			"name":"mwdragscroll",
			"display name":"mwDragScroll",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwDragScroll <pObject>"
			],
			"display syntax":[
				"mwDragScroll <i>pObject</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Scroll a field or group with a finger, or with the mouse.",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"The long id of a field or group that scrolls."
			}],
			"examples":[{
				"script":"-- in the script of a field \"List\"\non mouseDown\n   mwDragScroll the long id of me\nend mouseDown"
			}],
			"description":"On a phone, a finger dragged over a field selects its text instead of\nscrolling it. Call <mwDragScroll> in the mouseDown of a field or group:\nwhile the finger (or the mouse's button) is down, the object follows it\nup and down, and when it lets go quickly the object glides on and slows\nto a stop. A tap that does not move scrolls nothing.\n\nThe result is \"moved\" when the finger moved the object, and empty for a\ntap that did not. A mouseUp follows either way, and the engine may send\nit before <mwDragScroll> has returned, so a list that takes a tap as\npicking a line asks <mwDragMoved> in its mouseUp and leaves out a drag.\n\nIt works the same on a desktop, with the mouse.",
			"references":{
				"command":["mwStart"],
				"function":["mwDragMoved"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-26",
			"name":"mwistouchscreen",
			"display name":"mwIsTouchScreen",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwIsTouchScreen()"
			],
			"display syntax":[
				"mwIsTouchScreen()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the stack runs on a touch screen.",
			"examples":[{
				"script":"if mwIsTouchScreen() then\n   set the textSize of field \"Notes\" to 18\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true in a browser on a phone, a tablet, or a computer with a touch\nscreen; false on a desktop and in a browser that has no touch screen."
			}],
			"description":"Use <mwIsTouchScreen> to make controls bigger, or to show hints such as\n\"swipe to go on\", where a finger is used. In a browser, it is true when\nthe browser reports one touch point or more.",
			"references":{
				"function":["mwIsWeb"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-27",
			"name":"mwstartsensor",
			"display name":"mwStartSensor",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwStartSensor <pSensor>,<pLoosely>"
			],
			"display syntax":[
				"mwStartSensor <i>pSensor</i>,<i>pLoosely</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Start reading a sensor: where the phone is, which way it points, how it\nis tilted or turning.",
			"parameters":[{
				"name":"pSensor",
				"type":"",
				"refparam":"false",
				"description":"\"location\", \"heading\", \"acceleration\" or \"rotation rate\"."
			},{
				"name":"pLoosely",
				"type":"",
				"refparam":"false",
				"description":"true to read it less often or less exactly, which saves the battery:\nthe location from the network rather than the GPS, the heading when it\nchanges by 5 degrees, the motion five times a second. Empty for false."
			}],
			"examples":[{
				"script":"on mouseUp\n   mwStartSensor \"location\"\nend mouseUp\n\non locationChanged pLatitude, pLongitude\n   put \"You are at\" && pLatitude & comma & pLongitude into field \"Where\"\n   mwStopSensor \"location\"\nend locationChanged"
			},{
				"script":"-- a ball that rolls as the phone tilts\non openCard\n   mwStartSensor \"acceleration\"\nend openCard\n\non accelerationChanged pX, pY\n   set the loc of graphic \"Ball\" to \\\n         item 1 of the loc of graphic \"Ball\" + round(pX * -10), \\\n         item 2 of the loc of graphic \"Ball\" + round(pY * 10)\nend accelerationChanged"
			}],
			"description":"After <mwStartSensor> the current card of the stack that was the\ndefault stack gets a message each time the sensor has a new reading,\nby the names LiveCode's iOS and Android engines use:\n\n- locationChanged pLatitude, pLongitude, pAltitude (degrees, and meters;\n  the altitude is empty where the phone does not know it)\n- headingChanged pHeading (degrees from north, clockwise)\n- accelerationChanged pX, pY, pZ, pTime: in g, gravity included, so a\n  phone lying flat reads about 0, 0 and 1 or -1; pTime in seconds\n- rotationRateChanged pX, pY, pZ, pTime: how fast it turns about each\n  axis, in radians a second\n\nIf the sensor cannot be read, the card gets trackingError pSensor,\npError (\"permission denied\" when the user said no) and the sensor is\nstopped. <mwSensorReading> gives the last reading at any time.\n\nBrowsers ask the user before they give the location, and an iPhone\nasks before the motion and the heading too; an iPhone asks only when\n<mwStartSensor> is called from a tap (in mouseUp). The location needs a\npage served over https (or from the same computer).\n\nThe result is \"not available\" where the browser has no way to read the\nsensor, as on a desktop, and \"unknown sensor: \" and the name for a name\nthat is not one.",
			"references":{
				"command":["mwStopSensor"],
				"function":["mwSensorReading","mwSensorAvailable"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-28",
			"name":"mwdragmoved",
			"display name":"mwDragMoved",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwDragMoved()"
			],
			"display syntax":[
				"mwDragMoved()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Whether the last drag of <mwDragScroll> moved its object.",
			"examples":[{
				"script":"-- in the script of a field \"List\"\non mouseDown\n   mwDragScroll the long id of me\nend mouseDown\n\non mouseUp\n   if mwDragMoved() then exit mouseUp\n   answer \"You picked\" && the value of the clickLine\nend mouseUp"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when the finger (or the mouse) has moved more than 4 pixels up or\ndown since the last <mwDragScroll> began, false when it has not."
			}],
			"description":"A drag ends in a mouseUp, as a tap does, and the engine may send that\nmouseUp while <mwDragScroll> is still waiting for the finger to let go.\nAsk <mwDragMoved> in the mouseUp to leave out what a tap would do: it\nalso counts the move that ended the drag, which <mwDragScroll> has not\nseen yet.",
			"references":{
				"command":["mwDragScroll"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-29",
			"name":"mwpickphoto",
			"display name":"mwPickPhoto",
			"library":"com.livecode.library.mobileweb",
			"type":"command",
			"syntax":[
				"mwPickPhoto <pSource>,<pMaxWidth>,<pMaxHeight>"
			],
			"display syntax":[
				"mwPickPhoto <i>pSource</i>,<i>pMaxWidth</i>,<i>pMaxHeight</i>"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"Take a photo with the camera, or choose one of the phone's pictures, as\na new image on the card.",
			"parameters":[{
				"name":"pSource",
				"type":"",
				"refparam":"false",
				"description":"\"camera\" or \"rear camera\" (the camera on the back), \"front camera\", or\n\"library\" (a picture the phone has). Empty for \"library\"."
			},{
				"name":"pMaxWidth",
				"type":"",
				"refparam":"false",
				"description":"The widest the image may be, in pixels. Empty for 1280."
			},{
				"name":"pMaxHeight",
				"type":"",
				"refparam":"false",
				"description":"The tallest the image may be, in pixels. Empty for 1280."
			}],
			"examples":[{
				"script":"on mouseUp\n   mwPickPhoto \"camera\", 600, 600\n   if the result is \"cancel\" then exit mouseUp\n   -- the photo is the card's last image\n   set the rect of last image to the rect of graphic \"Frame\"\nend mouseUp"
			}],
			"description":"<mwPickPhoto> opens the phone's camera, or its pictures, and waits until\nthe user has taken or chosen a photo. The photo becomes a new image on\nthe current card, the last image, made smaller to fit in pMaxWidth by\npMaxHeight (a phone's photo is far bigger than its screen); the result\nis empty. When the user closes the camera without one, no image is made\nand the result is \"cancel\". The stack goes on getting its messages while\n<mwPickPhoto> waits.\n\nCall it from a tap: a browser opens the camera only then. Called\notherwise, the result is \"not from a tap\" at once where the browser can\ntell (Safari 16.4 and later, Chrome, Firefox), and no image is made. A\nbrowser that cannot open the camera itself, as on a desktop, shows its\nfile chooser instead. In the IDE, \"library\" asks for a picture file and the\ncameras give \"not supported\".",
			"references":{
				"command":["mwShare"]
			},
			"tags":["html5","mobile","touch"]
		},{
			"id":"com.livecode.library.mobileweb-30",
			"name":"mwbreakpoints",
			"display name":"mwBreakpoints",
			"library":"com.livecode.library.mobileweb",
			"type":"function",
			"syntax":[
				"mwBreakpoints()"
			],
			"display syntax":[
				"mwBreakpoints()"
			],
			"associations":["com.livecode.library.mobileweb"],
			"summary":"The widths at which <mwLayoutClass> changes.",
			"examples":[{
				"script":"put item 2 of mwBreakpoints() into tDesktopWidth"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Two numbers, separated by a comma: the width from which a stack is laid\nout as a tablet's, and the width from which it is laid out as a\ndesktop's. \"600,1024\" unless <mwSetBreakpoints> changed them."
			}],
			"description":"The widths at which <mwLayoutClass> changes.",
			"references":{
				"command":["mwSetBreakpoints"],
				"function":["mwLayoutClass"]
			},
			"tags":["html5","mobile","touch"]
		}