{
			"id":"com.livecode.widget.piechart-1",
			"name":"com.livecode.widget.piechart",
			"display name":"Pie Chart",
			"library":"com.livecode.widget.piechart",
			"type":"widget",
			"display syntax":[
				"Pie Chart"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"A pie chart control. A pie chart displays a set of values and labels as sectors of a circular chart. The labels are displayed alongside the chart, and can be shown or hidden.",
			"description":"A pie chart control. A pie chart displays a set of values and labels as sectors of a circular chart. The labels are displayed alongside the chart, and can be shown or hidden."
		},{
			"id":"com.livecode.widget.piechart-2",
			"name":"sectorclicked",
			"display name":"sectorClicked",
			"library":"com.livecode.widget.piechart",
			"type":"message",
			"syntax":[
				"sectorClicked <pSectorNumber>"
			],
			"display syntax":[
				"sectorClicked <i>pSectorNumber</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"Sent when a sector of the pie chart is clicked.",
			"parameters":[{
				"name":"pSectorNumber",
				"type":"",
				"refparam":"false",
				"description":"The sector number of the clicked segment."
			}],
			"description":"The <sectorClicked> message is sent when a sector in the pie chart is clicked. The <pSectorNumber> parameter number of the sector which was clicked."
		},{
			"id":"com.livecode.widget.piechart-3",
			"name":"sectorvalues",
			"display name":"sectorValues",
			"library":"com.livecode.widget.piechart",
			"type":"property",
			"syntax":[
				"get the sectorValues of <widget>",
				"set the sectorValues of <widget> to <pValueList>"
			],
			"display syntax":[
				"get the sectorValues of <i>widget</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"The list of values to be displayed on the pie chart.",
			"parameters":[{
				"name":"pValueList",
				"type":"",
				"refparam":"false",
				"description":"A comma separated string of values."
			}],
			"description":"Use the <sectorValues> property to set the values to be displayed in the pie chart."
		},{
			"id":"com.livecode.widget.piechart-4",
			"name":"sectorlabels",
			"display name":"sectorLabels",
			"library":"com.livecode.widget.piechart",
			"type":"property",
			"syntax":[
				"get the sectorLabels of <widget>",
				"set the sectorLabels of <widget> to <pLabelList>"
			],
			"display syntax":[
				"get the sectorLabels of <i>widget</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"The list of labels associated with the pie chart sectors.",
			"parameters":[{
				"name":"pLabelList",
				"type":"",
				"refparam":"false",
				"description":"A comma separated string of labels."
			}],
			"description":"Use the <sectorLabels> property to set the labels to be displayed in the pie chart."
		},{
			"id":"com.livecode.widget.piechart-5",
			"name":"showlabels",
			"display name":"showLabels",
			"library":"com.livecode.widget.piechart",
			"type":"property",
			"syntax":[
				"get the showLabels of <widget>",
				"set the showLabels of <widget> to { true | false }"
			],
			"display syntax":[
				"get the showLabels of <i>widget</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"Whether the sector labels are shown or not.",
			"description":"Use the <showLabels> property to control whether the sector labels are shown or not."
		},{
			"id":"com.livecode.widget.piechart-6",
			"name":"sectorcolors",
			"display name":"sectorColors",
			"library":"com.livecode.widget.piechart",
			"type":"property",
			"syntax":[
				"get the sectorColors of <widget>",
				"set the sectorColors of <widget> to <pColorList>"
			],
			"display syntax":[
				"get the sectorColors of <i>widget</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"The colors of the pie chart sectors.",
			"parameters":[{
				"name":"pColorList",
				"type":"",
				"refparam":"false",
				"description":"A return-delimited list of colors, one for each sector, each as red,green,blue (0 to 255)."
			}],
			"description":"Use the <sectorColors> property to set the colors of the sectors, in the order of <sectorValues>. When there are more sectors than colors, the colors start again from the first. Set it to empty to go back to the default colors."
		},{
			"id":"com.livecode.widget.piechart-7",
			"name":"themedlabels",
			"display name":"themedLabels",
			"library":"com.livecode.widget.piechart",
			"type":"property",
			"syntax":[
				"get the themedLabels of <widget>",
				"set the themedLabels of <widget> to { true | false }"
			],
			"display syntax":[
				"get the themedLabels of <i>widget</i>"
			],
			"associations":["com.livecode.widget.piechart"],
			"summary":"Whether the sector labels follow the widget's text colour and font.",
			"description":"When <themedLabels> is true, the sector labels are drawn in the widget's foreground colour and text font, so they stay readable in dark mode. When it is false, they are drawn in black in the default font, as pie charts were before version 1.0.1. A new pie chart starts with true; a pie chart saved before version 1.0.1 opens with false, so it looks as it did.\n"
		}