{
			"id":"onion-httpd-1",
			"name":"onion-httpd",
			"display name":"OnionXT HTTP server",
			"library":"onion-httpd",
			"type":"library",
			"display syntax":[
				"OnionXT HTTP server"
			],
			"associations":["onion-httpd"],
			"description":"A small HTTP/1.1 server for Tor onion services, built entirely on OnionXT's\naccept loop, so it runs wherever OnionXT runs and needs no other HTTP\nlibrary. Load OnionXT too, connect and authenticate its control port, then\ncall <oxhServe> to publish an onion that answers HTTP.\n\nRequests go to a registered route (<oxhRoute>) first, then to static files\nunder a folder (<oxhSetRoot> or <oxhServeFiles>), and otherwise get a 404.\nEach connection serves one request and is closed after the response\n(Connection: close). OnionXT has already refused non-loopback peers before\na request reaches this module."
		},{
			"id":"onion-httpd-2",
			"name":"oxhservefiles",
			"display name":"oxhServeFiles",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhServeFiles <pFolder>"
			],
			"display syntax":[
				"oxhServeFiles <i>pFolder</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Share a folder, with generated directory listings.",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"the folder to share; empty turns static serving off."
			}],
			"examples":[{
				"script":"oxhServeFiles specialFolderPath(\"documents\") & \"/shared\""
			}],
			"description":"Like <oxhSetRoot>, but a folder without its own index.html gets a page\nlisting its files and subfolders with links, so visitors can browse and\ndownload.",
			"references":{
				"handler":["oxhSetRoot","oxhUnroute"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-3",
			"name":"oxhunroute",
			"display name":"oxhUnroute",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhUnroute <pMethod>,<pPath>"
			],
			"display syntax":[
				"oxhUnroute <i>pMethod</i>,<i>pPath</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Remove a route registered with oxhRoute.",
			"parameters":[{
				"name":"pMethod",
				"type":"",
				"refparam":"false",
				"description":"the HTTP method of the route."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"the exact path of the route."
			}],
			"examples":[{
				"script":"oxhUnroute \"GET\", \"/\""
			}],
			"description":"Removing a route that is not registered is a no-op. Once removed, that path\nfalls through to static files, if any, or a 404.",
			"references":{
				"handler":["oxhRoute"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-4",
			"name":"oxhserve",
			"display name":"oxhServe",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhServe <pVirtualPort>,<pLocalPort>"
			],
			"display syntax":[
				"oxhServe <i>pVirtualPort</i>,<i>pLocalPort</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Publish an onion service that answers HTTP.",
			"parameters":[{
				"name":"pVirtualPort",
				"type":"",
				"refparam":"false",
				"description":"the port visitors connect to on the .onion address, usually 80."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"the loopback port OnionXT listens on."
			}],
			"examples":[{
				"script":"oxhServe 80, 8090\nput the result into tService"
			}],
			"description":"Needs an authenticated OnionXT control connection. It points OnionXT's peer\ncallback at this module, replacing any peer callback you set, then calls\n<oxCreateService>. The result is the service handle, or the error\n<oxCreateService> reported; the address arrives through OnionXT's status\ncallback and <oxServiceAddress>.",
			"references":{
				"handler":["oxhStop","oxhRoute","oxhSetRoot","oxCreateService"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-5",
			"name":"oxhstop",
			"display name":"oxhStop",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhStop <pService>"
			],
			"display syntax":[
				"oxhStop <i>pService</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Stop serving one onion.",
			"parameters":[{
				"name":"pService",
				"type":"",
				"refparam":"false",
				"description":"the service handle that oxhServe reported."
			}],
			"examples":[{
				"script":"oxhStop tService"
			}],
			"description":"Calls <oxRemoveService>: the service is unpublished and its listener\nclosed. Routes and the file root stay registered.",
			"references":{
				"handler":["oxhServe","oxRemoveService"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-6",
			"name":"oxhroute",
			"display name":"oxhRoute",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhRoute <pMethod>,<pPath>,<pHandler>"
			],
			"display syntax":[
				"oxhRoute <i>pMethod</i>,<i>pPath</i>,<i>pHandler</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Register a handler for one HTTP method and exact path.",
			"parameters":[{
				"name":"pMethod",
				"type":"",
				"refparam":"false",
				"description":"the HTTP method, such as GET or POST (case does not matter)."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"the exact request path, such as /hello, without the query string."
			},{
				"name":"pHandler",
				"type":"",
				"refparam":"false",
				"description":"the name of a command in the route owner's script."
			}],
			"examples":[{
				"script":"oxhRoute \"GET\", \"/hello\", \"myHello\""
			}],
			"description":"The handler is called with two parameters: the stream handle and an array\ndescribing the request. The array holds the request headers under\nlowercase names, plus \"__method\", \"__path\", \"__query\", \"__resource\" and\n\"__body\" (the raw body bytes, limited to Content-Length). Answer with\n<oxhReply>. Registering the same method and path again replaces the\nhandler.",
			"references":{
				"handler":["oxhReply","oxhUnroute","oxhInit"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-7",
			"name":"oxhreply",
			"display name":"oxhReply",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhReply <pStream>,<pCode>,<pBodyText>,<pHeaders>"
			],
			"display syntax":[
				"oxhReply <i>pStream</i>,<i>pCode</i>,<i>pBodyText</i>,<i>pHeaders</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Send a text response from a route handler.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"the stream handle the route handler received."
			},{
				"name":"pCode",
				"type":"",
				"refparam":"false",
				"description":"the HTTP status code, such as 200 or 404."
			},{
				"name":"pBodyText",
				"type":"",
				"refparam":"false",
				"description":"the response body as text; it is sent UTF-8 encoded."
			},{
				"name":"pHeaders",
				"type":"",
				"refparam":"false",
				"description":"extra header lines such as \"Content-Type: text/html\", or empty."
			}],
			"examples":[{
				"script":"oxhReply pStream, 200, \"hello\", \"Content-Type: text/plain\""
			}],
			"description":"Content-Length and Connection: close are set for you, and any copies of\nthem in the headers you pass are dropped. The connection closes shortly\nafter the response is written, so answer each request once.",
			"references":{
				"handler":["oxhRoute"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-8",
			"name":"oxhinit",
			"display name":"oxhInit",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhInit <pOwner>"
			],
			"display syntax":[
				"oxhInit <i>pOwner</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Name the object whose script holds your HTTP route handlers.",
			"parameters":[{
				"name":"pOwner",
				"type":"",
				"refparam":"false",
				"description":"the long id of the object that holds the route handlers."
			}],
			"examples":[{
				"script":"oxhInit the long id of me"
			}],
			"description":"Route handlers are sent with dispatch to this object. If you never set it\nthey go to the topStack.",
			"references":{
				"handler":["oxhRoute","oxhServe"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onion-httpd-9",
			"name":"oxhsetroot",
			"display name":"oxhSetRoot",
			"library":"onion-httpd",
			"type":"command",
			"syntax":[
				"oxhSetRoot <pFolder>"
			],
			"display syntax":[
				"oxhSetRoot <i>pFolder</i>"
			],
			"associations":["onion-httpd"],
			"summary":"Serve static files from a folder, without directory listings.",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"the folder to serve; empty turns static serving off."
			}],
			"examples":[{
				"script":"oxhSetRoot specialFolderPath(\"documents\") & \"/site\""
			}],
			"description":"A GET request maps its path onto pFolder, and \"/\" maps to index.html. A\nfolder with no index.html is a 404. Paths containing \"..\" are refused with\na 403. Registered routes are checked first.",
			"references":{
				"handler":["oxhServeFiles","oxhRoute"]
			},
			"tags":["networking","tor"]
		}