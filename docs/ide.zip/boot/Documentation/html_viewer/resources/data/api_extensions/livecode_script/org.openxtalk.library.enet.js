{
			"id":"org.openxtalk.library.enet-1",
			"name":"org.openxtalk.library.enet",
			"display name":"enetxt",
			"library":"org.openxtalk.library.enet",
			"type":"library",
			"display syntax":[
				"enetxt"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Bindings to ENet, reliable UDP networking for games and real-time apps.\n\nenetxt wraps ENet 1.3.18. A host is a socket: a server host listens on a\nport, a client host only connects out. A peer is one connection on a host.\nHosts and peers are integer handles; 0 means the call failed (see\n<enLastError>), and a handle that has gone stale is a harmless no-op.\n\nENet has no threads of its own. Nothing connects, sends or receives until\n<enPoll> services the host, so call it on a timer for as long as a host\nlives. The enetHelpers library (enStartPolling) does that for you and\ndispatches each event as a message: enetConnect, enetDisconnect,\nenetReceive and enetError.\n\nCall <enInitialize> once at startup and <enDeinitialize> once at quit.",
			"description":"Bindings to ENet, reliable UDP networking for games and real-time apps.\n\nenetxt wraps ENet 1.3.18. A host is a socket: a server host listens on a\nport, a client host only connects out. A peer is one connection on a host.\nHosts and peers are integer handles; 0 means the call failed (see\n<enLastError>), and a handle that has gone stale is a harmless no-op.\n\nENet has no threads of its own. Nothing connects, sends or receives until\n<enPoll> services the host, so call it on a timer for as long as a host\nlives. The enetHelpers library (enStartPolling) does that for you and\ndispatches each event as a message: enetConnect, enetDisconnect,\nenetReceive and enetError.\n\nCall <enInitialize> once at startup and <enDeinitialize> once at quit."
		},{
			"id":"org.openxtalk.library.enet-2",
			"name":"enresetpeer",
			"display name":"enResetPeer",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enResetPeer(<pPeer>)"
			],
			"display syntax":[
				"enResetPeer(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Drop a connection without telling either side.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"get enResetPeer(sPeer)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enResetPeer> to forget a connection silently. No notice is sent and\nno event follows; the handle retires immediately and the remote side\ntimes the connection out.",
			"references":{
				"handler":["enDisconnect","enDisconnectNow"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-3",
			"name":"enhoststatus",
			"display name":"enHostStatus",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enHostStatus(<pHost>)"
			],
			"display syntax":[
				"enHostStatus(<i>pHost</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Report the state of a host.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			}],
			"examples":[{
				"script":"local tStatus\nput enHostStatus(sServer) into tStatus\nput tStatus[\"address\"] into field \"Listening on\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the keys \"host\", \"address\" and \"peerCount\", or an\nempty array when the host is gone."
			}],
			"description":"Use <enHostStatus> to find the address a host is bound to, including the\nport the system chose for port 0, and how many peers it has. A client\nhost shows \"0.0.0.0:0\".",
			"references":{
				"handler":["enPeerStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-4",
			"name":"enpoll",
			"display name":"enPoll",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enPoll(<pHost>)"
			],
			"display syntax":[
				"enPoll(<i>pHost</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Service a host and return its pending events.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			}],
			"examples":[{
				"script":"local tEvents\nput enPoll(sHost) into tEvents\nrepeat for each element tEvent in tEvents\n   if tEvent[\"name\"] is \"enetReceive\" then\n      put textDecode(tEvent[\"payload\"], \"UTF-8\") & return after field \"Chat\"\n   end if\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of event arrays. Each has \"code\", \"name\" (enetConnect,\nenetDisconnect, enetReceive or enetError) and the event's own keys:\n\"host\", \"peer\", \"address\", \"data\", \"channel\", \"payload\" or \"error\"."
			}],
			"description":"Use <enPoll> on a timer for as long as a host lives: connecting, sending,\nresending and receiving all happen inside it, and nothing happens without\nit. Its interval sets the latency, 16 to 33 milliseconds for real-time\nplay or 100 or more for chat. Every pending event comes back in one call,\nin order.\n\nThe enetHelpers library runs this loop for you with enStartPolling and\nsends each event to your stack as a message of the same name.",
			"references":{
				"handler":["enConnect","enSend","enFlush"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-5",
			"name":"enhostcreateserver",
			"display name":"enHostCreateServer",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enHostCreateServer(<pBindHost>,<pPort>,<pMaxPeers>,<pChannels>,<pInBW>,<pOutBW>)"
			],
			"display syntax":[
				"enHostCreateServer(<i>pBindHost</i>,<i>pPort</i>,<i>pMaxPeers</i>,<i>pChannels</i>,<i>pInBW</i>,<i>pOutBW</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Create a host that listens for connections on a port.",
			"parameters":[{
				"name":"pBindHost",
				"type":"",
				"refparam":"false",
				"description":"The address to listen on: empty or \"*\" for every interface,\nor one IP address or name."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"The UDP port to listen on, or 0 for any free port."
			},{
				"name":"pMaxPeers",
				"type":"",
				"refparam":"false",
				"description":"The most peers that may connect at once, 1 to 4095."
			},{
				"name":"pChannels",
				"type":"",
				"refparam":"false",
				"description":"The number of channels each connection has, 1 to 255. It is\nfixed for the host's life."
			},{
				"name":"pInBW",
				"type":"",
				"refparam":"false",
				"description":"The incoming bandwidth in bytes per second, or 0 for unlimited."
			},{
				"name":"pOutBW",
				"type":"",
				"refparam":"false",
				"description":"The outgoing bandwidth in bytes per second, or 0 for unlimited."
			}],
			"examples":[{
				"script":"local tServer\nput enHostCreateServer(\"\", 27000, 32, 2, 0, 0) into tServer"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive host handle, or 0 on failure (see <enLastError>)."
			}],
			"description":"Use <enHostCreateServer> to accept connections from other machines. A\nserver host can also connect out with <enConnect>. Peers that connect\narrive as enetConnect events from <enPoll>. With port 0, <enHostStatus>\nreports the port the system chose.",
			"references":{
				"handler":["enHostCreateClient","enHostDestroy","enPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-6",
			"name":"enconnect",
			"display name":"enConnect",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enConnect(<pHost>,<pRemoteHost>,<pPort>,<pChannels>,<pData>)"
			],
			"display syntax":[
				"enConnect(<i>pHost</i>,<i>pRemoteHost</i>,<i>pPort</i>,<i>pChannels</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Start connecting a host to a remote host.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The local host handle."
			},{
				"name":"pRemoteHost",
				"type":"",
				"refparam":"false",
				"description":"The IP address or name of the remote host."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"The remote port."
			},{
				"name":"pChannels",
				"type":"",
				"refparam":"false",
				"description":"The number of channels to open, no more than the host has."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"A number from 0 to 2147483647 that the remote side receives in\nits enetConnect event, such as a protocol version."
			}],
			"examples":[{
				"script":"put enConnect(sClient, \"192.168.1.10\", 27000, 2, 1) into sPeer"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A peer handle at once, or 0 on failure (see <enLastError>)."
			}],
			"description":"Use <enConnect> to open a connection. The handle is returned before the\nconnection exists: an enetConnect event from <enPoll> confirms it, and an\nenetDisconnect event reports a failure or time-out. A name is looked up\nbefore the call returns, which can block briefly; pass an IP address when\nthat matters.",
			"references":{
				"handler":["enDisconnect","enPoll"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-7",
			"name":"enhostdestroy",
			"display name":"enHostDestroy",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enHostDestroy(<pHost>)"
			],
			"display syntax":[
				"enHostDestroy(<i>pHost</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Close a host and every connection on it.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			}],
			"examples":[{
				"script":"if sHost is not empty and sHost is not 0 then\n   enHostDestroy sHost\nend if\nput empty into sHost"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0."
			}],
			"description":"Use <enHostDestroy> when you are finished with a host. Its socket closes\nand every peer handle on it retires. Destroying a host twice is\nharmless, but the handle must be a number: passing empty throws an\nerror, so guard any variable that may have been cleared, as the example\ndoes.",
			"references":{
				"handler":["enHostCreateServer","enHostCreateClient"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-8",
			"name":"endisconnect",
			"display name":"enDisconnect",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enDisconnect(<pPeer>,<pData>)"
			],
			"display syntax":[
				"enDisconnect(<i>pPeer</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Close a connection politely.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"A number the remote side receives in its enetDisconnect event."
			}],
			"examples":[{
				"script":"get enDisconnect(sPeer, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enDisconnect> to end a connection cleanly. Packets already queued\nare sent first and the remote side is told. Your own enetDisconnect event\narrives from <enPoll>, and the peer handle retires then.",
			"references":{
				"handler":["enDisconnectNow","enResetPeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-9",
			"name":"enflush",
			"display name":"enFlush",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enFlush(<pHost>)"
			],
			"display syntax":[
				"enFlush(<i>pHost</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Send queued packets now.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			}],
			"examples":[{
				"script":"get enSend(sPeer, 0, tData, 0)\nget enFlush(sHost)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enFlush> after a burst of sends when the next <enPoll> is too far\naway. It sends without reading incoming traffic.",
			"references":{
				"handler":["enPoll","enSend"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-10",
			"name":"enpeerstatus",
			"display name":"enPeerStatus",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enPeerStatus(<pPeer>)"
			],
			"display syntax":[
				"enPeerStatus(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Report the state of one connection.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"local tStatus\nput enPeerStatus(sPeer) into tStatus\nif tStatus[\"state\"] is 5 then put tStatus[\"rtt\"] && \"ms\" into field \"Ping\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the keys \"host\", \"peer\", \"address\", \"state\",\n\"rtt\", \"packetLoss\", \"packetsSent\", \"packetsLost\", \"bytesSent\" and\n\"bytesReceived\", or an empty array when the peer is gone."
			}],
			"description":"Use <enPeerStatus> to show a connection's health. \"state\" is 5 when\nconnected (0 disconnected, 1 to 4 connecting, 6 to 8 disconnecting, 9\nzombie), \"rtt\" is the round trip in milliseconds and \"packetLoss\" is from\n0 to 1.",
			"references":{
				"handler":["enHostStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-11",
			"name":"ensendtext",
			"display name":"enSendText",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enSendText(<pPeer>,<pChannel>,<pText>,<pFlags>)"
			],
			"display syntax":[
				"enSendText(<i>pPeer</i>,<i>pChannel</i>,<i>pText</i>,<i>pFlags</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Queue a packet of text to one peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel, from 0 to one less than the channel count."
			},{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to send, encoded as UTF-8."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"0 reliable, 1 unreliable or 2 unsequenced, as for <enSend>."
			}],
			"examples":[{
				"script":"get enSendText(sPeer, 0, \"hello\", 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error, as for <enSend>."
			}],
			"description":"Use <enSendText> to send text. It arrives as bytes: decode it with\ntextDecode(tEvent[\"payload\"], \"UTF-8\") on the receiving side.",
			"references":{
				"handler":["enSend"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-12",
			"name":"endisconnectnow",
			"display name":"enDisconnectNow",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enDisconnectNow(<pPeer>,<pData>)"
			],
			"display syntax":[
				"enDisconnectNow(<i>pPeer</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Close a connection at once.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"A number the remote side receives in its enetDisconnect event."
			}],
			"examples":[{
				"script":"get enDisconnectNow(sPeer, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enDisconnectNow> when you cannot wait for queued packets. One last\nnotice goes to the remote side, no local event follows, and the handle\nretires immediately.",
			"references":{
				"handler":["enDisconnect","enResetPeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-13",
			"name":"enlibraryversion",
			"display name":"enLibraryVersion",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enLibraryVersion()"
			],
			"display syntax":[
				"enLibraryVersion()"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"The version of the ENet library that enetxt was built with.",
			"examples":[{
				"script":"put enLibraryVersion() into field \"Version\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A string such as \"enet 1.3.18\"."
			}],
			"description":"Use <enLibraryVersion> to report which ENet the installed native library\nlinks, for example in an about box or a bug report.",
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-14",
			"name":"ensetpeerpinginterval",
			"display name":"enSetPeerPingInterval",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enSetPeerPingInterval(<pPeer>,<pMs>)"
			],
			"display syntax":[
				"enSetPeerPingInterval(<i>pPeer</i>,<i>pMs</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Set how often an idle peer is pinged.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pMs",
				"type":"",
				"refparam":"false",
				"description":"The interval in milliseconds."
			}],
			"examples":[{
				"script":"get enSetPeerPingInterval(sPeer, 500)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enSetPeerPingInterval> to keep round-trip times fresh and routers'\nNAT entries open while nothing else is being sent.",
			"references":{
				"handler":["enSetPeerTimeout","enPeerStatus"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-15",
			"name":"eninitialize",
			"display name":"enInitialize",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enInitialize()"
			],
			"display syntax":[
				"enInitialize()"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Initialize the ENet library before any other call.",
			"examples":[{
				"script":"if enInitialize() is not 0 then answer \"ENet failed:\" && enLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <enInitialize> once at startup, before creating a host. It checks\nthat the installed native library matches this binding and throws an\nerror naming both versions if it does not. Calls are counted: each\n<enInitialize> needs one matching <enDeinitialize>, and extra calls are\ncheap.",
			"references":{
				"handler":["enDeinitialize","enLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-16",
			"name":"enhostcreateclient",
			"display name":"enHostCreateClient",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enHostCreateClient(<pMaxPeers>,<pChannels>,<pInBW>,<pOutBW>)"
			],
			"display syntax":[
				"enHostCreateClient(<i>pMaxPeers</i>,<i>pChannels</i>,<i>pInBW</i>,<i>pOutBW</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Create a host that only makes outgoing connections.",
			"parameters":[{
				"name":"pMaxPeers",
				"type":"",
				"refparam":"false",
				"description":"The most connections the host may make at once; a plain\nclient wants 1."
			},{
				"name":"pChannels",
				"type":"",
				"refparam":"false",
				"description":"The number of channels each connection has, 1 to 255."
			},{
				"name":"pInBW",
				"type":"",
				"refparam":"false",
				"description":"The incoming bandwidth in bytes per second, or 0 for unlimited."
			},{
				"name":"pOutBW",
				"type":"",
				"refparam":"false",
				"description":"The outgoing bandwidth in bytes per second, or 0 for unlimited."
			}],
			"examples":[{
				"script":"local tClient, tPeer\nput enHostCreateClient(1, 2, 0, 0) into tClient\nput enConnect(tClient, \"192.168.1.10\", 27000, 2, 0) into tPeer"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive host handle, or 0 on failure (see <enLastError>)."
			}],
			"description":"Use <enHostCreateClient> for the side of a game or chat that joins a\nserver. The host is not bound to a known port, so nobody can connect to\nit.",
			"references":{
				"handler":["enHostCreateServer","enConnect"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-17",
			"name":"enclearerror",
			"display name":"enClearError",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enClearError()"
			],
			"display syntax":[
				"enClearError()"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Clear the last error message.",
			"examples":[{
				"script":"enClearError"
			}],
			"description":"Use <enClearError> before a call when you want <enLastError> to report\nonly that call's failure.",
			"references":{
				"handler":["enLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-18",
			"name":"ensend",
			"display name":"enSend",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enSend(<pPeer>,<pChannel>,<pData>,<pFlags>)"
			],
			"display syntax":[
				"enSend(<i>pPeer</i>,<i>pChannel</i>,<i>pData</i>,<i>pFlags</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Queue a packet of binary data to one peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel, from 0 to one less than the channel count."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to send, 0 to 60000 of them."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"0 for reliable delivery, 1 for unreliable (sequenced, may be\ndropped) or 2 for unsequenced (may be dropped or arrive out of order)."
			}],
			"examples":[{
				"script":"get enSend(sPeer, 0, textEncode(\"hello\", \"UTF-8\"), 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error: -2 the peer is gone, -3 a bad channel or\nflag, -4 more than 60000 bytes."
			}],
			"description":"Use <enSend> to send one message. It goes out on the next <enPoll> or\n<enFlush>, and arrives whole, as one enetReceive event, or not at all.\nUse 0 (reliable) unless the data is soon replaced, like a position\nupdate.",
			"references":{
				"handler":["enSendText","enBroadcast","enFlush"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-19",
			"name":"enbroadcast",
			"display name":"enBroadcast",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enBroadcast(<pHost>,<pChannel>,<pData>,<pFlags>)"
			],
			"display syntax":[
				"enBroadcast(<i>pHost</i>,<i>pChannel</i>,<i>pData</i>,<i>pFlags</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Queue a packet of binary data to every peer of a host.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			},{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to send, 0 to 60000 of them."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"0 reliable, 1 unreliable or 2 unsequenced, as for <enSend>."
			}],
			"examples":[{
				"script":"get enBroadcast(sServer, 1, tStateData, 1)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error, as for <enSend>."
			}],
			"description":"Use <enBroadcast> on a server to send the same message to every\nconnected peer in one call.",
			"references":{
				"handler":["enBroadcastText","enSend"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-20",
			"name":"ensetpeertimeout",
			"display name":"enSetPeerTimeout",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enSetPeerTimeout(<pPeer>,<pLimit>,<pMinMs>,<pMaxMs>)"
			],
			"display syntax":[
				"enSetPeerTimeout(<i>pPeer</i>,<i>pLimit</i>,<i>pMinMs</i>,<i>pMaxMs</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Set how long a peer may go unanswered before it times out.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pLimit",
				"type":"",
				"refparam":"false",
				"description":"How many times the average round trip to wait before giving up,\nor 0 for ENet's default."
			},{
				"name":"pMinMs",
				"type":"",
				"refparam":"false",
				"description":"The shortest time-out in milliseconds, or 0 for ENet's default."
			},{
				"name":"pMaxMs",
				"type":"",
				"refparam":"false",
				"description":"The longest time-out in milliseconds, or 0 for ENet's default."
			}],
			"examples":[{
				"script":"get enSetPeerTimeout(sPeer, 0, 5000, 30000)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enSetPeerTimeout> to notice a lost connection sooner, or to be more\npatient on a slow network.",
			"references":{
				"handler":["enSetPeerPingInterval"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-21",
			"name":"ensethostbandwidth",
			"display name":"enSetHostBandwidth",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enSetHostBandwidth(<pHost>,<pInBW>,<pOutBW>)"
			],
			"display syntax":[
				"enSetHostBandwidth(<i>pHost</i>,<i>pInBW</i>,<i>pOutBW</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Change a host's bandwidth limits.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			},{
				"name":"pInBW",
				"type":"",
				"refparam":"false",
				"description":"The incoming bandwidth in bytes per second, or 0 for unlimited."
			},{
				"name":"pOutBW",
				"type":"",
				"refparam":"false",
				"description":"The outgoing bandwidth in bytes per second, or 0 for unlimited."
			}],
			"examples":[{
				"script":"get enSetHostBandwidth(sHost, 0, 64000)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error."
			}],
			"description":"Use <enSetHostBandwidth> to throttle a live host. ENet paces its own\nsends and tells its peers the limit.",
			"references":{
				"handler":["enHostCreateServer","enHostCreateClient"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-22",
			"name":"enlasterror",
			"display name":"enLastError",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enLastError()"
			],
			"display syntax":[
				"enLastError()"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"The last error message from the native layer.",
			"examples":[{
				"script":"local tHost\nput enHostCreateServer(\"\", 27000, 32, 2, 0, 0) into tHost\nif tHost is 0 then answer \"Could not listen:\" && enLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The message, or empty when there is no error."
			}],
			"description":"Use <enLastError> after a call returns 0 or a negative number to find out\nwhy. The message stays until the next error or <enClearError>.",
			"references":{
				"handler":["enClearError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-23",
			"name":"enbroadcasttext",
			"display name":"enBroadcastText",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enBroadcastText(<pHost>,<pChannel>,<pText>,<pFlags>)"
			],
			"display syntax":[
				"enBroadcastText(<i>pHost</i>,<i>pChannel</i>,<i>pText</i>,<i>pFlags</i>)"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Queue a packet of text to every peer of a host.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host handle."
			},{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel."
			},{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to send, encoded as UTF-8."
			},{
				"name":"pFlags",
				"type":"",
				"refparam":"false",
				"description":"0 reliable, 1 unreliable or 2 unsequenced, as for <enSend>."
			}],
			"examples":[{
				"script":"get enBroadcastText(sServer, 0, \"Game starts in 5 seconds\", 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0, or a negative error, as for <enSend>."
			}],
			"description":"Use <enBroadcastText> on a server to send the same text to every\nconnected peer.",
			"references":{
				"handler":["enBroadcast","enSendText"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.enet-24",
			"name":"endeinitialize",
			"display name":"enDeinitialize",
			"library":"org.openxtalk.library.enet",
			"type":"handler",
			"syntax":[
				"enDeinitialize()"
			],
			"display syntax":[
				"enDeinitialize()"
			],
			"associations":["org.openxtalk.library.enet"],
			"summary":"Release the ENet library when your app is done with it.",
			"examples":[{
				"script":"on closeStack\n   enDeinitialize\nend closeStack"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success."
			}],
			"description":"Use <enDeinitialize> once for each <enInitialize> your stack made,\ntypically on closeStack. The last one destroys every host still alive and\nretires its peers, so an app cannot leak sockets. There is no automatic\nunload hook: an app that quits without it leaves the sockets to the\noperating system.\n\nWrite it as a bare command. The count is shared by the whole process, so\na stack must give back only the holds it took: an extra call can destroy\nthe hosts of another window that uses ENet.",
			"references":{
				"handler":["enInitialize"]
			},
			"tags":["networking","library"]
		}