/* glue.js : per-widget TinySynth player instance with a power-switch element.
 * Embedded (after webaudio-tinysynth.js) into the widget and injected into the outermost page.
 * window.XTalkTiny.create() -> instance { el, power, play, pause, stop, ... }   (one per widget) */
(function () {
  if (window.XTalkTiny) return;
  var NS = 'http://www.w3.org/2000/svg';
  var ARC = 'M6.343 6.343A8 8 0 1 0 17.657 6.343', BAR = 'M12 3v8';   // power symbol

  function toBuf(b64) {
    var s = atob(String(b64).replace(/^data:[^,]*,/, '').replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/'));
    var u = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
    return u.buffer;
  }

  function create() {
    var S = { synth: null, on: false, buf: null, name: '', vol: 0.5, rev: 0.3, q: 1, loop: 0, paused: 0,
              playing: false, wantPlay: false, cb: null, timer: 0, color: '#2fbf71', off: '#8a8f98' };
    var inst = {};

    /* ---- the switch (this element becomes the widget's native layer) ---- */
    var el = document.createElement('div');
    el.style.cssText = 'width:100%;height:100%;margin:0;padding:0;line-height:0;cursor:pointer;user-select:none;' +
      '-webkit-tap-highlight-color:transparent;touch-action:manipulation;box-sizing:border-box;transition:filter .15s,opacity .15s;';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '100%'); svg.setAttribute('height', '100%');
    var arc = document.createElementNS(NS, 'path'), bar = document.createElementNS(NS, 'path');
    arc.setAttribute('d', ARC); bar.setAttribute('d', BAR);
    [arc, bar].forEach(function (p) {
      p.setAttribute('fill', 'none'); p.setAttribute('stroke-width', '2.2'); p.setAttribute('stroke-linecap', 'round');
      svg.appendChild(p);
    });
    el.appendChild(svg);
    inst.el = el;

    function paint() {
      var c = S.on ? S.color : S.off;
      arc.setAttribute('stroke', c); bar.setAttribute('stroke', c);
      el.style.filter = S.on ? 'drop-shadow(0 0 3px ' + S.color + ')' : 'none';
      el.title = S.on ? 'Power: on (click to turn off)' : 'Power: off (click to turn on)';
    }
    function emit(name, detail) {
      if (!S.cb) return;
      try { S.cb({ name: String(name), detail: (detail === undefined || detail === null) ? '' : String(detail) }); } catch (e) {}
    }
    function fail(where, e) { emit('error', where + ': ' + ((e && e.message) || e)); }
    function flash() {                       // ask the user to press the switch
      var n = 0, t = setInterval(function () { el.style.opacity = (n++ % 2) ? '1' : '0.35'; if (n > 5) { clearInterval(t); el.style.opacity = '1'; } }, 160);
    }

    /* ---- power ---- */
    inst.power = function (on) {
      on = !!on;
      if (on === S.on) return S.on;
      try {
        if (on) {
          var Ctor = window.WebAudioTinySynth;
          if (!Ctor) throw new Error('WebAudioTinySynth is not loaded');
          if (!S.synth) {                    // created inside the click => the audio context may start running
            S.synth = new Ctor({ quality: S.q, useReverb: 1 });
            S.synth.setMasterVol(S.vol); S.synth.setReverbLev(S.rev); S.synth.setLoop(S.loop);
          }
          var ac = S.synth.getAudioContext();
          if (ac && ac.resume) ac.resume();
          if (S.buf) S.synth.loadMIDI(S.buf.slice(0));
          S.on = true; S.paused = 0; S.playing = false;
          S.timer = setInterval(tick, 100);
          paint(); emit('powerOn');
          if (S.wantPlay) { S.wantPlay = false; inst.play(); }
        } else {
          S.on = false; S.playing = false; S.wantPlay = false; S.paused = 0;
          clearInterval(S.timer); S.timer = 0;
          if (S.synth) {
            S.synth.stopMIDI();
            for (var ch = 0; ch < 16; ch++) S.synth.allSoundOff(ch);
            var ac2 = S.synth.getAudioContext();
            if (ac2 && ac2.suspend) ac2.suspend();
          }
          paint(); emit('powerOff');
        }
      } catch (e) { fail('power', e); }
      return S.on;
    };
    el.addEventListener('click', function () { inst.power(!S.on); });

    /* ---- MIDI ---- */
    function setBuf(buf, name) {
      S.buf = buf; S.name = name || ''; S.paused = 0; S.playing = false;
      var len = '';
      if (S.on && S.synth) { S.synth.stopMIDI(); S.synth.loadMIDI(buf.slice(0)); len = S.synth.getPlayStatus().maxTick; }
      emit('loaded', len);
    }
    inst.loadMidi = function (src) {                  // base64 string, data: URL, or http(s)/blob/relative URL
      try {
        src = String(src).trim();
        if (/^[A-Za-z0-9+\/=_\-\s]+$/.test(src) || /^data:/i.test(src)) { setBuf(toBuf(src), 'data'); return true; }
        fetch(src).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); })
          .then(function (b) { setBuf(b, src.split('/').pop()); }).catch(function (e) { fail('loadMidi', e); });
        return true;
      } catch (e) { fail('loadMidi', e); return false; }
    };
    inst.play = function () {
      try {
        if (!S.buf) throw new Error('No MIDI loaded');
        if (!S.on) { S.wantPlay = true; flash(); emit('needPower'); return false; }   // starts as soon as the switch is pressed
        if (S.paused) { S.synth.locateMIDI(S.paused); S.paused = 0; }
        S.synth.playMIDI(); S.playing = true; emit('playing'); return true;
      } catch (e) { fail('play', e); return false; }
    };
    inst.pause = function () {
      if (!S.on || !S.playing) return false;
      S.paused = S.synth.getPlayStatus().curTick; S.synth.stopMIDI(); S.playing = false; emit('paused'); return true;
    };
    inst.stop = function () {
      S.wantPlay = false;
      if (!S.on) return false;
      S.synth.stopMIDI(); S.synth.locateMIDI(0); S.paused = 0; S.playing = false; emit('stopped'); return true;
    };
    inst.seekTicks = function (t) { if (S.on) S.synth.locateMIDI(Math.max(0, +t || 0)); S.paused = S.playing ? 0 : Math.max(0, +t || 0); return true; };
    function tick() {
      if (!S.on || !S.playing) return;
      try { if (!S.synth.getPlayStatus().play) { S.playing = false; S.paused = 0; emit('ended'); } } catch (e) {}
    }

    /* ---- settings ---- */
    inst.setVolume  = function (v) { S.vol = Math.min(1, Math.max(0, +v || 0)); if (S.synth) S.synth.setMasterVol(S.vol); };
    inst.setReverb  = function (v) { S.rev = Math.min(1, Math.max(0, +v || 0)); if (S.synth) S.synth.setReverbLev(S.rev); };
    inst.setQuality = function (q) { S.q = (+q === 0) ? 0 : 1; if (S.synth) S.synth.setQuality(S.q); };
    inst.setLoop    = function (b) { S.loop = (b === true || b === 'true' || +b === 1) ? 1 : 0; if (S.synth) S.synth.setLoop(S.loop); };
    inst.setColor   = function (c) { S.color = String(c); paint(); };
    inst.setCallback = function (fn) { S.cb = (typeof fn === 'function') ? fn : null; };

    /* ---- synchronous getters (safe to poll) ---- */
    function st() { try { return (S.on && S.synth) ? S.synth.getPlayStatus() : null; } catch (e) { return null; } }
    inst.powered  = function () { return S.on; };
    inst.isPlaying = function () { return S.on && S.playing; };
    inst.position = function () { var s = st(); return s ? s.curTick : S.paused; };   // ticks
    inst.length   = function () { var s = st(); return s ? s.maxTick : 0; };          // ticks
    inst.status   = function () { return !S.on ? 'off' : (S.playing ? 'playing' : (S.paused ? 'paused' : (S.buf ? 'loaded' : 'ready'))); };
    inst.info     = function () { return [inst.status(), inst.position(), inst.length()].join(','); };

    inst.destroy = function () { inst.power(false); S.cb = null; if (el.remove) el.remove(); };
    paint();
    return inst;
  }

  window.XTalkTiny = { version: '1.0.0', create: create };
})();
