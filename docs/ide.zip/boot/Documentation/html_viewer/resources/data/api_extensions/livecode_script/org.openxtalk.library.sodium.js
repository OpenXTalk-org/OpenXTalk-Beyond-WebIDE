{
			"id":"org.openxtalk.library.sodium-1",
			"name":"org.openxtalk.library.sodium",
			"display name":"SodiumXT",
			"library":"org.openxtalk.library.sodium",
			"type":"library",
			"display syntax":[
				"SodiumXT"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Modern, authenticated cryptography for xTalk, built on libsodium.\n\nSodiumXT covers secure randomness, BLAKE2b hashing, hex and base64\nencoding, constant-time comparison, Argon2id password hashing, key\nderivation, secret-key and AEAD encryption, streaming and whole-file\nencryption, X25519 public-key boxes, ed25519 signatures, key exchange,\npadding, HMAC-SHA256, SHA3-256 and the ristretto255 group.\n\nBytes cross as Data and text as String: pass text through\ntextEncode(theText, \"utf-8\") and decode recovered plaintext with\ntextDecode. Hex, base64 and password hash strings come back as Data\nholding ASCII bytes. Failures throw an error that starts with the\nhandler name, so wrap calls that can fail in try ... catch. The one-shot\nencryption calls draw and prepend a random nonce for you. Compare secrets\nwith <sxMemEqual>, never with is.",
			"description":"Modern, authenticated cryptography for xTalk, built on libsodium.\n\nSodiumXT covers secure randomness, BLAKE2b hashing, hex and base64\nencoding, constant-time comparison, Argon2id password hashing, key\nderivation, secret-key and AEAD encryption, streaming and whole-file\nencryption, X25519 public-key boxes, ed25519 signatures, key exchange,\npadding, HMAC-SHA256, SHA3-256 and the ristretto255 group.\n\nBytes cross as Data and text as String: pass text through\ntextEncode(theText, \"utf-8\") and decode recovered plaintext with\ntextDecode. Hex, base64 and password hash strings come back as Data\nholding ASCII bytes. Failures throw an error that starts with the\nhandler name, so wrap calls that can fail in try ... catch. The one-shot\nencryption calls draw and prepend a random nonce for you. Compare secrets\nwith <sxMemEqual>, never with is."
		},{
			"id":"org.openxtalk.library.sodium-2",
			"name":"sxinit",
			"display name":"sxInit",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxInit()"
			],
			"display syntax":[
				"sxInit()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Check the native library and initialize libsodium now.",
			"examples":[{
				"script":"try\n   sxInit\ncatch tError\n   answer \"SodiumXT could not start:\" && tError\nend try"
			}],
			"description":"Optional. Every SodiumXT handler checks the native library version and\ninitializes libsodium on first use, so you only call <sxInit> to fail\nfast at startup. It throws when the installed native library does not\nmatch this extension or libsodium fails to initialize.",
			"references":{
				"handler":["sxVersion","sxLastError"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-3",
			"name":"sxhashfilekeyed",
			"display name":"sxHashFileKeyed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashFileKeyed(<pPath>,<pKey>,<pOutLen>)"
			],
			"display syntax":[
				"sxHashFileKeyed(<i>pPath</i>,<i>pKey</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return a keyed BLAKE2b digest of a whole file.",
			"parameters":[{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The file path."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, as Data (16 to 64 bytes)."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64."
			}],
			"examples":[{
				"script":"put sxHashFileKeyed(\"/path/to/report.pdf\", tKey, 32) into tMac"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The keyed digest as pOutLen bytes of Data."
			}],
			"description":"A file MAC or domain-separated checksum, streamed like <sxHashFile>.\nCompare results with <sxMemEqual>.",
			"references":{
				"handler":["sxHashFile","sxHashKeyed"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-4",
			"name":"sxmemequal",
			"display name":"sxMemEqual",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxMemEqual(<pA>,<pB>)"
			],
			"display syntax":[
				"sxMemEqual(<i>pA</i>,<i>pB</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Compare two byte strings in constant time.",
			"parameters":[{
				"name":"pA",
				"type":"",
				"refparam":"false",
				"description":"The first bytes."
			},{
				"name":"pB",
				"type":"",
				"refparam":"false",
				"description":"The second bytes."
			}],
			"examples":[{
				"script":"if not sxMemEqual(tExpectedMac, tReceivedMac) then\n   throw \"message was altered\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when both hold the same bytes, otherwise false."
			}],
			"description":"Use <sxMemEqual> for every comparison of a MAC, tag, hash, key or other\nsecret. Comparing secrets with is or = can leak timing information.\nInputs of different lengths return false (the length is not treated as\nsecret). Two empty inputs are equal. It never throws on content.",
			"references":{
				"handler":["sxHashKeyed","sxHmacSha256"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-5",
			"name":"sxristrettosub",
			"display name":"sxRistrettoSub",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoSub(<pP>,<pQ>)"
			],
			"display syntax":[
				"sxRistrettoSub(<i>pP</i>,<i>pQ</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Subtract one ristretto255 point from another.",
			"parameters":[{
				"name":"pP",
				"type":"",
				"refparam":"false",
				"description":"The point to subtract from."
			},{
				"name":"pQ",
				"type":"",
				"refparam":"false",
				"description":"The point to subtract."
			}],
			"examples":[{
				"script":"put sxRistrettoSub(tP, tQ) into tDiff"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte difference as Data."
			}],
			"description":"Same failure rules as <sxRistrettoAdd>: an invalid input point throws,\nand subtracting a point from itself gives the identity (32 zero bytes).",
			"references":{
				"handler":["sxRistrettoAdd"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-6",
			"name":"sxristrettoscalarmultbase",
			"display name":"sxRistrettoScalarMultBase",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarMultBase(<pScalar>)"
			],
			"display syntax":[
				"sxRistrettoScalarMultBase(<i>pScalar</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Multiply the ristretto255 base point by a scalar.",
			"parameters":[{
				"name":"pScalar",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte scalar."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarMultBase(tSecretScalar) into tPublicPoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte result point as Data."
			}],
			"description":"Uses the standard generator of RFC 9496, as proofs such as Chaum-Pedersen\nDLEQ need. A zero scalar throws, as in <sxRistrettoScalarMultPoint>.",
			"references":{
				"handler":["sxRistrettoScalarMultPoint","sxRistrettoAdd"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-7",
			"name":"sxchacha20ietfxor",
			"display name":"sxChaCha20IetfXor",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxChaCha20IetfXor(<pKey>,<pNonce>,<pData>)"
			],
			"display syntax":[
				"sxChaCha20IetfXor(<i>pKey</i>,<i>pNonce</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"XOR bytes with the raw ChaCha20 keystream (no authentication).",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte key."
			},{
				"name":"pNonce",
				"type":"",
				"refparam":"false",
				"description":"The 12-byte nonce."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encrypt or decrypt (may be empty)."
			}],
			"examples":[{
				"script":"put sxChaCha20IetfXor(tKey, tNonce, tPlain) into tCipher\nput sxChaCha20IetfXor(tKey, tNonce, tCipher) into tPlainAgain"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Data of the same length as pData."
			}],
			"description":"A building block for published constructions such as NIP-44, not a way\nto encrypt your own data: the output is NOT authenticated, and reusing\na nonce with a key breaks it. To encrypt, use <sxSecretBox> or\n<sxAeadEncrypt>. Uses RFC 8439 with the block counter starting at 0. The\nsame call encrypts and decrypts. A key or nonce of any other length\nthrows.",
			"references":{
				"handler":["sxSecretBox","sxAeadEncrypt","sxHmacSha256"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-8",
			"name":"sxdecryptfile",
			"display name":"sxDecryptFile",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxDecryptFile(<pSrcPath>,<pDstPath>,<pKey>)"
			],
			"display syntax":[
				"sxDecryptFile(<i>pSrcPath</i>,<i>pDstPath</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decrypt a file made by sxEncryptFile.",
			"parameters":[{
				"name":"pSrcPath",
				"type":"",
				"refparam":"false",
				"description":"The path of the encrypted file."
			},{
				"name":"pDstPath",
				"type":"",
				"refparam":"false",
				"description":"The path to write the decrypted file to."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key it was encrypted with."
			}],
			"examples":[{
				"script":"try\n   sxDecryptFile \"/path/to/big.mov.enc\", \"/path/to/restored.mov\", tKey\ncatch tError\n   answer \"Could not decrypt:\" && tError\nend try"
			}],
			"description":"Throws on a wrong key, a tampered, corrupt or truncated input, or a read\nor write error.",
			"references":{
				"handler":["sxEncryptFile"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-9",
			"name":"sxsecretstreaminitpull",
			"display name":"sxSecretStreamInitPull",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretStreamInitPull(<pKey>,<pHeader>)"
			],
			"display syntax":[
				"sxSecretStreamInitPull(<i>pKey</i>,<i>pHeader</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Open a stream for decrypting chunks.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			},{
				"name":"pHeader",
				"type":"",
				"refparam":"false",
				"description":"The header the sender got from sxSecretStreamInitPush."
			}],
			"examples":[{
				"script":"put sxSecretStreamInitPull(tKey, tHeader) into tStream"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A stream handle for sxSecretStreamPull."
			}],
			"description":"Throws on a wrong key length or a malformed header. Free the handle with\n<sxFreeStream> when you are done.",
			"references":{
				"handler":["sxSecretStreamPull","sxFreeStream"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-10",
			"name":"sxhmacsha256",
			"display name":"sxHmacSha256",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHmacSha256(<pKey>,<pMessage>)"
			],
			"display syntax":[
				"sxHmacSha256(<i>pKey</i>,<i>pMessage</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the HMAC-SHA256 of a message.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, of any length."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to authenticate."
			}],
			"examples":[{
				"script":"put sxHmacSha256(tKey, tMessage) into tMac\nif sxMemEqual(tMac, tReceivedMac) then put true into tAuthentic"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte MAC as Data."
			}],
			"description":"The standard keyed MAC, for protocols that name HMAC-SHA256 (such as\nTor's control-port SAFECOOKIE handshake). Compare MACs with\n<sxMemEqual>, never with is. For a MAC of your own design,\n<sxHashKeyed> also works.",
			"references":{
				"handler":["sxMemEqual","sxHashKeyed"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-11",
			"name":"sxristrettoscalarrandom",
			"display name":"sxRistrettoScalarRandom",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarRandom()"
			],
			"display syntax":[
				"sxRistrettoScalarRandom()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return a random non-zero ristretto255 scalar.",
			"examples":[{
				"script":"put sxRistrettoScalarRandom() into tMask"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 32-byte scalar as Data."
			}],
			"description":"Uniformly random below the group order, from the secure random\ngenerator.",
			"references":{
				"handler":["sxRistrettoScalarInvert","sxRistrettoScalarMultPoint"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-12",
			"name":"sxboxkeypair",
			"display name":"sxBoxKeypair",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBoxKeypair(<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxBoxKeypair(<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Generate a random X25519 keypair for public-key boxes.",
			"parameters":[{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the secret key."
			}],
			"examples":[{
				"script":"sxBoxKeypair tPublic, tSecret"
			}],
			"description":"Share the public key; keep the secret key private. Use the pair with\n<sxBox>, <sxBoxOpen> and the sealed-box calls.",
			"references":{
				"handler":["sxBoxKeypairFromSeed","sxBox","sxSeal"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-13",
			"name":"sxsignopen",
			"display name":"sxSignOpen",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignOpen(<pSignedMessage>,<pPublicKey>)"
			],
			"display syntax":[
				"sxSignOpen(<i>pSignedMessage</i>,<i>pPublicKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Verify a signed message and return the message.",
			"parameters":[{
				"name":"pSignedMessage",
				"type":"",
				"refparam":"false",
				"description":"The signed message from sxSign."
			},{
				"name":"pPublicKey",
				"type":"",
				"refparam":"false",
				"description":"The signer's public key."
			}],
			"examples":[{
				"script":"try\n   put sxSignOpen(tSigned, tPublic) into tMessage\ncatch tError\n   answer \"Bad signature.\"\nend try"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original message as Data."
			}],
			"description":"Throws when the signature does not verify, the input is too short or the\npublic key has the wrong length.",
			"references":{
				"handler":["sxSign"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-14",
			"name":"sxfreestream",
			"display name":"sxFreeStream",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxFreeStream(<pHandle>)"
			],
			"display syntax":[
				"sxFreeStream(<i>pHandle</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Release a stream handle.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"A handle from sxSecretStreamInitPush or sxSecretStreamInitPull."
			}],
			"examples":[{
				"script":"sxFreeStream tStream"
			}],
			"description":"Call it once you are done with a stream; nothing frees handles for you.\nFreeing a handle twice is harmless.",
			"references":{
				"handler":["sxSecretStreamInitPush","sxSecretStreamInitPull"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-15",
			"name":"sxhashfinal",
			"display name":"sxHashFinal",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashFinal(<pHandle>,<pOutLen>)"
			],
			"display syntax":[
				"sxHashFinal(<i>pHandle</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Finish a multipart hash and return the digest.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"The handle from sxHashInit or sxHashInitKeyed."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The same digest length given when the hash was started."
			}],
			"examples":[{
				"script":"put sxHashFinal(tHash, 32) into tDigest"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The digest as Data."
			}],
			"description":"Releases the handle, so it cannot be used again. A bad or already\nfinished handle throws.",
			"references":{
				"handler":["sxHashInit","sxHashUpdate","sxFreeHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-16",
			"name":"sxkeyexchangeclient",
			"display name":"sxKeyExchangeClient",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxKeyExchangeClient(<pClientPk>,<pClientSk>,<pServerPk>,<rRx>,<rTx>)"
			],
			"display syntax":[
				"sxKeyExchangeClient(<i>pClientPk</i>,<i>pClientSk</i>,<i>pServerPk</i>,<i>rRx</i>,<i>rTx</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive the client's session keys.",
			"parameters":[{
				"name":"pClientPk",
				"type":"",
				"refparam":"false",
				"description":"The client's public key."
			},{
				"name":"pClientSk",
				"type":"",
				"refparam":"false",
				"description":"The client's secret key."
			},{
				"name":"pServerPk",
				"type":"",
				"refparam":"false",
				"description":"The server's public key."
			},{
				"name":"rRx",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the key for data the client receives."
			},{
				"name":"rTx",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the key for data the client sends."
			}],
			"examples":[{
				"script":"sxKeyExchangeClient tMyPublic, tMySecret, tServerPublic, tRx, tTx\nput sxSecretBox(tMessage, tTx) into tOut"
			}],
			"description":"Both sides derive the same pair: the client's receive key equals the\nserver's send key and the other way round. Throws on a wrong key length\nor when the server's public key is rejected.",
			"references":{
				"handler":["sxKeyExchangeServer","sxKeyExchangeKeypair"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-17",
			"name":"sxbox",
			"display name":"sxBox",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBox(<pMessage>,<pRecipientPk>,<pSenderSk>)"
			],
			"display syntax":[
				"sxBox(<i>pMessage</i>,<i>pRecipientPk</i>,<i>pSenderSk</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt a message from one keypair holder to another.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encrypt."
			},{
				"name":"pRecipientPk",
				"type":"",
				"refparam":"false",
				"description":"The recipient's public key."
			},{
				"name":"pSenderSk",
				"type":"",
				"refparam":"false",
				"description":"The sender's secret key."
			}],
			"examples":[{
				"script":"put sxBox(textEncode(\"hi\", \"utf-8\"), tTheirPublic, tMySecret) into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The box as Data, with a random nonce prepended."
			}],
			"description":"The recipient opens it with <sxBoxOpen> and the sender's public key,\nwhich also proves who sent it. To send without a sender identity, use\n<sxSeal>. A wrong key length throws.",
			"references":{
				"handler":["sxBoxOpen","sxBoxKeypair","sxSeal"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-18",
			"name":"sxristrettoscalaradd",
			"display name":"sxRistrettoScalarAdd",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarAdd(<pX>,<pY>)"
			],
			"display syntax":[
				"sxRistrettoScalarAdd(<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Add two ristretto255 scalars modulo the group order.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The first 32-byte scalar."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The second 32-byte scalar."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarAdd(tW, sxRistrettoScalarMul(tC, tK)) into tZ"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte reduced sum as Data."
			}],
			"description":"Each input is read as a little-endian number and the result is fully\nreduced. Zero is allowed, so only a wrong length throws.",
			"references":{
				"handler":["sxRistrettoScalarMul"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-19",
			"name":"sxkeyexchangeserver",
			"display name":"sxKeyExchangeServer",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxKeyExchangeServer(<pServerPk>,<pServerSk>,<pClientPk>,<rRx>,<rTx>)"
			],
			"display syntax":[
				"sxKeyExchangeServer(<i>pServerPk</i>,<i>pServerSk</i>,<i>pClientPk</i>,<i>rRx</i>,<i>rTx</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive the server's session keys.",
			"parameters":[{
				"name":"pServerPk",
				"type":"",
				"refparam":"false",
				"description":"The server's public key."
			},{
				"name":"pServerSk",
				"type":"",
				"refparam":"false",
				"description":"The server's secret key."
			},{
				"name":"pClientPk",
				"type":"",
				"refparam":"false",
				"description":"The client's public key."
			},{
				"name":"rRx",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the key for data the server receives."
			},{
				"name":"rTx",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the key for data the server sends."
			}],
			"examples":[{
				"script":"sxKeyExchangeServer tMyPublic, tMySecret, tClientPublic, tRx, tTx\nput sxSecretBoxOpen(tIn, tRx) into tMessage"
			}],
			"description":"The server's receive key equals the client's send key and the other way\nround. Throws on a wrong key length or when the client's public key is\nrejected.",
			"references":{
				"handler":["sxKeyExchangeClient","sxKeyExchangeKeypair"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-20",
			"name":"sxunpad",
			"display name":"sxUnpad",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxUnpad(<pData>,<pBlockSize>)"
			],
			"display syntax":[
				"sxUnpad(<i>pData</i>,<i>pBlockSize</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Remove padding added by sxPad.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The padded bytes."
			},{
				"name":"pBlockSize",
				"type":"",
				"refparam":"false",
				"description":"The same block size given to sxPad."
			}],
			"examples":[{
				"script":"put sxUnpad(sxSecretBoxOpen(tBox, tKey), 64) into tMessage"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original bytes as Data."
			}],
			"description":"Throws on malformed padding or a bad block size.",
			"references":{
				"handler":["sxPad"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-21",
			"name":"sxfreehash",
			"display name":"sxFreeHash",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxFreeHash(<pHandle>)"
			],
			"display syntax":[
				"sxFreeHash(<i>pHandle</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Abandon a multipart hash without finishing it.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"The handle from sxHashInit or sxHashInitKeyed."
			}],
			"examples":[{
				"script":"sxFreeHash tHash"
			}],
			"description":"Only needed for a hash you will not pass to <sxHashFinal>, which already\nreleases the handle. Freeing twice is harmless.",
			"references":{
				"handler":["sxHashInit","sxHashFinal"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-22",
			"name":"sxsealopen",
			"display name":"sxSealOpen",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSealOpen(<pSealed>,<pRecipientPk>,<pRecipientSk>)"
			],
			"display syntax":[
				"sxSealOpen(<i>pSealed</i>,<i>pRecipientPk</i>,<i>pRecipientSk</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Open a sealed box made by sxSeal.",
			"parameters":[{
				"name":"pSealed",
				"type":"",
				"refparam":"false",
				"description":"The sealed box."
			},{
				"name":"pRecipientPk",
				"type":"",
				"refparam":"false",
				"description":"The recipient's public key."
			},{
				"name":"pRecipientSk",
				"type":"",
				"refparam":"false",
				"description":"The recipient's secret key."
			}],
			"examples":[{
				"script":"put sxSealOpen(tSealed, tMyPublic, tMySecret) into tPlain"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original message as Data."
			}],
			"description":"Needs the recipient's full keypair. Throws on a wrong key, a box that is\ntoo short or any tampering.",
			"references":{
				"handler":["sxSeal","sxBoxKeypair"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-23",
			"name":"sxristrettoscalarmultpoint",
			"display name":"sxRistrettoScalarMultPoint",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarMultPoint(<pScalar>,<pPoint>)"
			],
			"display syntax":[
				"sxRistrettoScalarMultPoint(<i>pScalar</i>,<i>pPoint</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Multiply a ristretto255 point by a scalar.",
			"parameters":[{
				"name":"pScalar",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte scalar."
			},{
				"name":"pPoint",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte point encoding."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarRandom() into tMask\nput sxRistrettoScalarMultPoint(tMask, tPoint) into tMasked"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte result point as Data."
			}],
			"description":"Throws when the point is not a valid encoding or when the result would\nbe the identity (a zero scalar); libsodium reports both as one failure.\nTreat the throw as the detection of a bad input.",
			"references":{
				"handler":["sxRistrettoScalarMultBase","sxRistrettoScalarMultBatch","sxRistrettoScalarInvert"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-24",
			"name":"sxhashkeyed",
			"display name":"sxHashKeyed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashKeyed(<pData>,<pKey>,<pOutLen>)"
			],
			"display syntax":[
				"sxHashKeyed(<i>pData</i>,<i>pKey</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return a keyed BLAKE2b digest (a MAC).",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, as Data (16 to 64 bytes; 32 is typical)."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64."
			}],
			"examples":[{
				"script":"put sxRandomBytes(32) into tKey\nput sxHashKeyed(tMessage, tKey, 32) into tMac"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The keyed digest as pOutLen bytes of Data."
			}],
			"description":"Use a keyed hash as a message authentication code or a domain-separated\nhash. Check a received MAC with <sxMemEqual>, never with is. A key or\ndigest length out of range throws.",
			"references":{
				"handler":["sxHash","sxHmacSha256","sxMemEqual"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-25",
			"name":"sxristrettopointvalid",
			"display name":"sxRistrettoPointValid",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoPointValid(<pPoint>)"
			],
			"display syntax":[
				"sxRistrettoPointValid(<i>pPoint</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Tell whether bytes are a valid ristretto255 point.",
			"parameters":[{
				"name":"pPoint",
				"type":"",
				"refparam":"false",
				"description":"The bytes to check."
			}],
			"examples":[{
				"script":"if not sxRistrettoPointValid(tPoint) then throw \"bad point from peer\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true for a canonical 32-byte point encoding, otherwise false."
			}],
			"description":"A predicate: malformed or wrong-length input returns false instead of\nthrowing, so you can check untrusted input before using it.",
			"references":{
				"handler":["sxRistrettoFromHash","sxRistrettoAdd"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-26",
			"name":"sxaeaddecrypt",
			"display name":"sxAeadDecrypt",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxAeadDecrypt(<pBox>,<pAd>,<pKey>)"
			],
			"display syntax":[
				"sxAeadDecrypt(<i>pBox</i>,<i>pAd</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decrypt and verify a box made by sxAeadEncrypt.",
			"parameters":[{
				"name":"pBox",
				"type":"",
				"refparam":"false",
				"description":"The sealed box."
			},{
				"name":"pAd",
				"type":"",
				"refparam":"false",
				"description":"The same associated data that was given when sealing."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			}],
			"examples":[{
				"script":"put sxAeadDecrypt(tBox, tHeader, tKey) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original message as Data."
			}],
			"description":"Throws when the key is wrong, the box was altered or the associated data\ndoes not match what was sealed.",
			"references":{
				"handler":["sxAeadEncrypt"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-27",
			"name":"sxaeadencrypt",
			"display name":"sxAeadEncrypt",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxAeadEncrypt(<pMessage>,<pAd>,<pKey>)"
			],
			"display syntax":[
				"sxAeadEncrypt(<i>pMessage</i>,<i>pAd</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt a message and authenticate extra data with it.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encrypt."
			},{
				"name":"pAd",
				"type":"",
				"refparam":"false",
				"description":"Associated data to authenticate but not encrypt, such as a header (may be empty)."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			}],
			"examples":[{
				"script":"put textEncode(\"msg-id:42\", \"utf-8\") into tHeader\nput sxAeadEncrypt(tBody, tHeader, tKey) into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sealed box as Data, with the random nonce prepended."
			}],
			"description":"Like <sxSecretBox>, but the associated data is bound to the ciphertext:\ndecrypting with different associated data fails. Uses\nXChaCha20-Poly1305 IETF. The associated data is not stored in the box;\nsend it alongside. A key that is not 32 bytes throws.",
			"references":{
				"handler":["sxAeadDecrypt","sxSecretBox"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-28",
			"name":"sxristrettoadd",
			"display name":"sxRistrettoAdd",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoAdd(<pP>,<pQ>)"
			],
			"display syntax":[
				"sxRistrettoAdd(<i>pP</i>,<i>pQ</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Add two ristretto255 points.",
			"parameters":[{
				"name":"pP",
				"type":"",
				"refparam":"false",
				"description":"The first 32-byte point."
			},{
				"name":"pQ",
				"type":"",
				"refparam":"false",
				"description":"The second 32-byte point."
			}],
			"examples":[{
				"script":"put sxRistrettoAdd(tP, tQ) into tSum"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte sum as Data."
			}],
			"description":"Throws when either input is not a valid point. The identity point is a\nlegal input and result here.",
			"references":{
				"handler":["sxRistrettoSub","sxRistrettoScalarMultBase"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-29",
			"name":"sxsecretboxopen",
			"display name":"sxSecretBoxOpen",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretBoxOpen(<pBox>,<pKey>)"
			],
			"display syntax":[
				"sxSecretBoxOpen(<i>pBox</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decrypt and verify a box made by sxSecretBox.",
			"parameters":[{
				"name":"pBox",
				"type":"",
				"refparam":"false",
				"description":"The sealed box."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key it was sealed with."
			}],
			"examples":[{
				"script":"try\n   put textDecode(sxSecretBoxOpen(tBox, tKey), \"utf-8\") into tText\ncatch tError\n   answer \"Wrong key or damaged data.\"\nend try"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original message as Data."
			}],
			"description":"Throws on a wrong key, any tampering or a box that is too short. It\nnever returns garbage.",
			"references":{
				"handler":["sxSecretBox"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-30",
			"name":"sxpwsaltbytes",
			"display name":"sxPwSaltBytes",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwSaltBytes()"
			],
			"display syntax":[
				"sxPwSaltBytes()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the salt length Argon2id expects.",
			"examples":[{
				"script":"put sxRandomBytes(sxPwSaltBytes()) into tSalt"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The salt length in bytes, as read from libsodium."
			}],
			"description":"Size the salt for <sxPwHash> with this value rather than a hardcoded\nnumber.",
			"references":{
				"handler":["sxPwHash","sxRandomBytes"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-31",
			"name":"sxristrettofromhash",
			"display name":"sxRistrettoFromHash",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoFromHash(<pHash>)"
			],
			"display syntax":[
				"sxRistrettoFromHash(<i>pHash</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Map a 64-byte hash to a ristretto255 group point.",
			"parameters":[{
				"name":"pHash",
				"type":"",
				"refparam":"false",
				"description":"Exactly 64 bytes, usually sxHash(theLabel, 64)."
			}],
			"examples":[{
				"script":"put sxRistrettoFromHash(sxHash(textEncode(\"card-1\", \"utf-8\"), 64)) into tPoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte point encoding as Data."
			}],
			"description":"Every 64-byte input maps to a valid point, so only a wrong length\nthrows. Use domain-separated labels to make independent points.",
			"references":{
				"handler":["sxRistrettoScalarMultPoint","sxRistrettoPointValid","sxHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-32",
			"name":"sxristrettoscalarinvert",
			"display name":"sxRistrettoScalarInvert",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarInvert(<pScalar>)"
			],
			"display syntax":[
				"sxRistrettoScalarInvert(<i>pScalar</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the inverse of a ristretto255 scalar.",
			"parameters":[{
				"name":"pScalar",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte scalar to invert."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarInvert(tMask) into tUnmask\nput sxRistrettoScalarMultPoint(tUnmask, tMasked) into tPoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte inverse as Data."
			}],
			"description":"Multiplying a point by the scalar and then by its inverse gives the\noriginal point. A zero scalar has no inverse and throws.",
			"references":{
				"handler":["sxRistrettoScalarRandom","sxRistrettoScalarMultPoint"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-33",
			"name":"sxhashinitkeyed",
			"display name":"sxHashInitKeyed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashInitKeyed(<pKey>,<pOutLen>)"
			],
			"display syntax":[
				"sxHashInitKeyed(<i>pKey</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Start a keyed BLAKE2b hash of data that arrives in pieces.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, as Data (16 to 64 bytes)."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64."
			}],
			"examples":[{
				"script":"put sxHashInitKeyed(tKey, 32) into tHash"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A hash handle for sxHashUpdate and sxHashFinal."
			}],
			"description":"The keyed form of <sxHashInit>; the result equals <sxHashKeyed> of all\nthe pieces joined.",
			"references":{
				"handler":["sxHashInit","sxHashUpdate","sxHashFinal"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-34",
			"name":"sxpwmeminteractive",
			"display name":"sxPwMemInteractive",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwMemInteractive()"
			],
			"display syntax":[
				"sxPwMemInteractive()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the interactive Argon2id memory limit.",
			"examples":[{
				"script":"put sxPwHash(tPass, tSalt, 32, \"2\", sxPwMemInteractive()) into tKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The memory limit as a decimal string."
			}],
			"description":"The fastest preset, for interactive logins. Pair it with the ops limit\n\"2\". Store the limits you used beside the data so you can re-derive the\nkey and raise the cost later.",
			"references":{
				"handler":["sxPwMemModerate","sxPwMemSensitive","sxPwHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-35",
			"name":"sxpwmemsensitive",
			"display name":"sxPwMemSensitive",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwMemSensitive()"
			],
			"display syntax":[
				"sxPwMemSensitive()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the sensitive Argon2id memory limit.",
			"examples":[{
				"script":"put sxPwHash(tPass, tSalt, 32, \"4\", sxPwMemSensitive()) into tKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The memory limit as a decimal string."
			}],
			"description":"The slowest preset, for high-value secrets. Pair it with the ops limit\n\"4\". It needs a large amount of memory; a derivation that cannot get it\nthrows.",
			"references":{
				"handler":["sxPwMemInteractive","sxPwMemModerate","sxPwHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-36",
			"name":"sxhash",
			"display name":"sxHash",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHash(<pData>,<pOutLen>)"
			],
			"display syntax":[
				"sxHash(<i>pData</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the BLAKE2b digest of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64 (32 is typical)."
			}],
			"examples":[{
				"script":"put sxBin2Hex(sxHash(textEncode(\"hello\", \"utf-8\"), 32)) into tHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The digest as pOutLen bytes of Data."
			}],
			"description":"An unkeyed BLAKE2b hash. A digest length outside 16 to 64 throws. For a\nfile use <sxHashFile>; for data that arrives in pieces use <sxHashInit>.\nCompare digests with <sxMemEqual>.",
			"references":{
				"handler":["sxHashKeyed","sxHashFile","sxHashInit"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-37",
			"name":"sxsignverifydetached",
			"display name":"sxSignVerifyDetached",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignVerifyDetached(<pSig>,<pMessage>,<pPublicKey>)"
			],
			"display syntax":[
				"sxSignVerifyDetached(<i>pSig</i>,<i>pMessage</i>,<i>pPublicKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Check a detached ed25519 signature.",
			"parameters":[{
				"name":"pSig",
				"type":"",
				"refparam":"false",
				"description":"The signature."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message that was signed."
			},{
				"name":"pPublicKey",
				"type":"",
				"refparam":"false",
				"description":"The signer's public key."
			}],
			"examples":[{
				"script":"if not sxSignVerifyDetached(tSig, tMessage, tPublic) then\n   answer \"Signature does not match.\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when the signature is valid, otherwise false."
			}],
			"description":"A bad signature, or input of the wrong length, gives false; it does not\nthrow.",
			"references":{
				"handler":["sxSignDetached"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-38",
			"name":"sxlasterror",
			"display name":"sxLastError",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxLastError()"
			],
			"display syntax":[
				"sxLastError()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the last native error message.",
			"examples":[{
				"script":"try\n   put sxSecretBoxOpen(tBox, tKey) into tPlain\ncatch tError\n   put sxLastError() into tDetail\nend try"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The last error message from the native layer on this thread, or\nempty when there is none."
			}],
			"description":"The message thrown by a failing handler already includes this text, so\n<sxLastError> is mainly for logging. It never throws.",
			"references":{
				"handler":["sxInit"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-39",
			"name":"sxversion",
			"display name":"sxVersion",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxVersion()"
			],
			"display syntax":[
				"sxVersion()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the SodiumXT and libsodium version text.",
			"examples":[{
				"script":"put sxVersion() into field \"version\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A string such as \"SodiumXT 0.1.0 (libsodium 1.0.22)\"."
			}],
			"description":"Use <sxVersion> to show or log which build is loaded. It throws if the\nnative library does not match this extension.",
			"references":{
				"handler":["sxInit"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-40",
			"name":"sxhex2bin",
			"display name":"sxHex2Bin",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHex2Bin(<pHex>)"
			],
			"display syntax":[
				"sxHex2Bin(<i>pHex</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decode hex text back to bytes.",
			"parameters":[{
				"name":"pHex",
				"type":"",
				"refparam":"false",
				"description":"The hex text, as Data (for example textEncode(theHex, \"ascii\"))."
			}],
			"examples":[{
				"script":"put sxHex2Bin(textEncode(field \"key\", \"ascii\")) into tKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The decoded bytes as Data."
			}],
			"description":"The reverse of <sxBin2Hex>. Malformed hex throws.",
			"references":{
				"handler":["sxBin2Hex","sxBase642Bin"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-41",
			"name":"sxbin2hex",
			"display name":"sxBin2Hex",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBin2Hex(<pData>)"
			],
			"display syntax":[
				"sxBin2Hex(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encode bytes as lowercase hex.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode."
			}],
			"examples":[{
				"script":"put textDecode(sxBin2Hex(tDigest), \"ascii\") into field \"digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The hex text as Data (ASCII bytes)."
			}],
			"description":"The result is Data; use textDecode(theHex, \"ascii\") when you need a\nString. <sxHex2Bin> reverses it.",
			"references":{
				"handler":["sxHex2Bin","sxBin2Base64"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-42",
			"name":"sxbase642bin",
			"display name":"sxBase642Bin",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBase642Bin(<pB64>)"
			],
			"display syntax":[
				"sxBase642Bin(<i>pB64</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decode URL-safe, unpadded base64 back to bytes.",
			"parameters":[{
				"name":"pB64",
				"type":"",
				"refparam":"false",
				"description":"The base64 text, as Data (for example textEncode(theText, \"ascii\"))."
			}],
			"examples":[{
				"script":"put sxBase642Bin(textEncode(field \"code\", \"ascii\")) into tRaw"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The decoded bytes as Data."
			}],
			"description":"The reverse of <sxBin2Base64>. It expects the URL-safe alphabet without\npadding; malformed input throws.",
			"references":{
				"handler":["sxBin2Base64","sxHex2Bin"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-43",
			"name":"sxisfinaltag",
			"display name":"sxIsFinalTag",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxIsFinalTag(<pTag>)"
			],
			"display syntax":[
				"sxIsFinalTag(<i>pTag</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Tell whether a stream tag marks the final chunk.",
			"parameters":[{
				"name":"pTag",
				"type":"",
				"refparam":"false",
				"description":"The tag filled in by sxSecretStreamPull."
			}],
			"examples":[{
				"script":"if sxIsFinalTag(tTag) then put true into tStreamDone"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true for the final tag, otherwise false."
			}],
			"description":"A stream that ends without a final tag was cut short.",
			"references":{
				"handler":["sxSecretStreamPull"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-44",
			"name":"sxsignkeypair",
			"display name":"sxSignKeypair",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignKeypair(<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxSignKeypair(<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Generate a random ed25519 signing keypair.",
			"parameters":[{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the 32-byte public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the 64-byte secret key."
			}],
			"examples":[{
				"script":"sxSignKeypair tPublic, tSecret\nput sxSignDetached(tMessage, tSecret) into tSig"
			}],
			"description":"Sign with the secret key; anyone with the public key can verify.",
			"references":{
				"handler":["sxSignKeypairFromSeed","sxSignDetached","sxSign"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-45",
			"name":"sxsha3_256",
			"display name":"sxSha3_256",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSha3_256(<pData>)"
			],
			"display syntax":[
				"sxSha3_256(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the SHA3-256 digest of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash (may be empty)."
			}],
			"examples":[{
				"script":"put sxBin2Hex(sxSha3_256(textEncode(\"abc\", \"utf-8\"))) into tHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte digest as Data."
			}],
			"description":"SHA3-256 as defined by NIST FIPS 202. It is not Ethereum's Keccak-256,\nwhich pads differently and gives a different result. It exists so a Tor\nv3 .onion address can be computed offline from an ed25519 public key.",
			"references":{
				"handler":["sxHash","sxSignSeedToExpandedKey"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-46",
			"name":"sxsecretstreamrekey",
			"display name":"sxSecretStreamRekey",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretStreamRekey(<pHandle>)"
			],
			"display syntax":[
				"sxSecretStreamRekey(<i>pHandle</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Rekey an open stream for forward secrecy.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"An open push or pull stream handle."
			}],
			"examples":[{
				"script":"sxSecretStreamRekey tStream"
			}],
			"description":"Both the sending and the receiving side must call <sxSecretStreamRekey>\nat the same point in the stream; a one-sided rekey makes the next chunk\nfail to open. A bad handle throws.",
			"references":{
				"handler":["sxSecretStreamPush","sxSecretStreamPull"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-47",
			"name":"sxpwmemmoderate",
			"display name":"sxPwMemModerate",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwMemModerate()"
			],
			"display syntax":[
				"sxPwMemModerate()"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the moderate Argon2id memory limit.",
			"examples":[{
				"script":"put sxPwHash(tPass, tSalt, 32, \"3\", sxPwMemModerate()) into tKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The memory limit as a decimal string."
			}],
			"description":"A middle preset. Pair it with the ops limit \"3\".",
			"references":{
				"handler":["sxPwMemInteractive","sxPwMemSensitive","sxPwHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-48",
			"name":"sxhashfile",
			"display name":"sxHashFile",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashFile(<pPath>,<pOutLen>)"
			],
			"display syntax":[
				"sxHashFile(<i>pPath</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the BLAKE2b digest of a whole file.",
			"parameters":[{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The file path."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64 (32 is typical)."
			}],
			"examples":[{
				"script":"put sxBin2Hex(sxHashFile(\"/path/to/big.iso\", 32)) into tChecksum"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The digest as pOutLen bytes of Data."
			}],
			"description":"The file is read in chunks inside the native library, so its bytes never\nload into a variable and any size works. The digest equals <sxHash> of\nthe same bytes. A read error or a digest length out of range throws.",
			"references":{
				"handler":["sxHashFileKeyed","sxHash","sxEncryptFile"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-49",
			"name":"sxsigndetached",
			"display name":"sxSignDetached",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignDetached(<pMessage>,<pSecretKey>)"
			],
			"display syntax":[
				"sxSignDetached(<i>pMessage</i>,<i>pSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Sign a message and return the signature alone.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to sign."
			},{
				"name":"pSecretKey",
				"type":"",
				"refparam":"false",
				"description":"The 64-byte ed25519 secret key."
			}],
			"examples":[{
				"script":"put sxSignDetached(tMessage, tSecret) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 64-byte signature as Data."
			}],
			"description":"Send the signature alongside the message; check it with\n<sxSignVerifyDetached>. A wrong key length throws.",
			"references":{
				"handler":["sxSignVerifyDetached","sxSign","sxSignKeypair"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-50",
			"name":"sxsecretstreampull",
			"display name":"sxSecretStreamPull",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretStreamPull(<pHandle>,<pCipherChunk>,<pAd>,<rTag>)"
			],
			"display syntax":[
				"sxSecretStreamPull(<i>pHandle</i>,<i>pCipherChunk</i>,<i>pAd</i>,<i>rTag</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decrypt and verify one chunk of a stream.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"The handle from sxSecretStreamInitPull."
			},{
				"name":"pCipherChunk",
				"type":"",
				"refparam":"false",
				"description":"One encrypted chunk, as produced by sxSecretStreamPush."
			},{
				"name":"pAd",
				"type":"",
				"refparam":"false",
				"description":"The associated data given when this chunk was pushed (may be empty)."
			},{
				"name":"rTag",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the chunk's tag."
			}],
			"examples":[{
				"script":"put sxSecretStreamPull(tStream, tCipherChunk, empty, tTag) into tPlain\nif sxIsFinalTag(tTag) then sxFreeStream tStream"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The decrypted chunk as Data."
			}],
			"description":"Pull the chunks in the order they were pushed. Throws on a wrong key, a\ntampered or reordered chunk, or a bad handle. If the data ends before a\nchunk whose tag passes <sxIsFinalTag>, the stream was truncated.",
			"references":{
				"handler":["sxIsFinalTag","sxSecretStreamInitPull","sxFreeStream"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-51",
			"name":"sxpwhash",
			"display name":"sxPwHash",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwHash(<pPassphrase>,<pSalt>,<pKeyLen>,<pOpsLimit>,<pMemLimit>)"
			],
			"display syntax":[
				"sxPwHash(<i>pPassphrase</i>,<i>pSalt</i>,<i>pKeyLen</i>,<i>pOpsLimit</i>,<i>pMemLimit</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive a key from a passphrase with Argon2id.",
			"parameters":[{
				"name":"pPassphrase",
				"type":"",
				"refparam":"false",
				"description":"The passphrase as Data (textEncode it as UTF-8)."
			},{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"A random salt of sxPwSaltBytes() bytes."
			},{
				"name":"pKeyLen",
				"type":"",
				"refparam":"false",
				"description":"The length of the key to derive, in bytes (32 for the encryption calls)."
			},{
				"name":"pOpsLimit",
				"type":"",
				"refparam":"false",
				"description":"The ops limit as a decimal string: \"2\", \"3\" or \"4\"."
			},{
				"name":"pMemLimit",
				"type":"",
				"refparam":"false",
				"description":"The memory limit as a decimal string, from a preset handler."
			}],
			"examples":[{
				"script":"put sxRandomBytes(sxPwSaltBytes()) into tSalt\nput sxPwHash(textEncode(tPass, \"utf-8\"), tSalt, 32, \"2\", sxPwMemInteractive()) into tKey\nput sxSecretBox(textEncode(tText, \"utf-8\"), tKey) into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The derived key as pKeyLen bytes of Data."
			}],
			"description":"The same passphrase, salt and limits always give the same key. The salt\nis not secret: store it, and the limits you used, beside the ciphertext.\nA wrong salt length or a key length out of range throws, as does a\nderivation that runs out of memory. To store a login password, use\n<sxPwHashStr> instead.",
			"references":{
				"handler":["sxPwSaltBytes","sxPwMemInteractive","sxPwHashStr","sxSecretBox"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-52",
			"name":"sxpad",
			"display name":"sxPad",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPad(<pData>,<pBlockSize>)"
			],
			"display syntax":[
				"sxPad(<i>pData</i>,<i>pBlockSize</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Pad bytes up to a multiple of a block size.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to pad."
			},{
				"name":"pBlockSize",
				"type":"",
				"refparam":"false",
				"description":"The block size in bytes (1 or more)."
			}],
			"examples":[{
				"script":"put sxSecretBox(sxPad(tMessage, 64), tKey) into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The padded bytes as Data."
			}],
			"description":"Adds 1 to pBlockSize bytes so the length becomes a multiple of the block\nsize. Pad before encrypting to hide a message's exact length. A block\nsize below 1 throws. <sxUnpad> removes the padding.",
			"references":{
				"handler":["sxUnpad"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-53",
			"name":"sxhashinit",
			"display name":"sxHashInit",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashInit(<pOutLen>)"
			],
			"display syntax":[
				"sxHashInit(<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Start a BLAKE2b hash of data that arrives in pieces.",
			"parameters":[{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"The digest length in bytes, 16 to 64."
			}],
			"examples":[{
				"script":"put sxHashInit(32) into tHash\nsxHashUpdate tHash, textEncode(\"part one \", \"utf-8\")\nsxHashUpdate tHash, textEncode(\"part two\", \"utf-8\")\nput sxHashFinal(tHash, 32) into tDigest"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A hash handle for sxHashUpdate and sxHashFinal."
			}],
			"description":"The result equals <sxHash> of all the pieces joined. Pass the same\ndigest length to <sxHashFinal>. <sxHashFinal> releases the handle; call\n<sxFreeHash> only to abandon a hash you will not finish.",
			"references":{
				"handler":["sxHashUpdate","sxHashFinal","sxHashInitKeyed","sxFreeHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-54",
			"name":"sxkeyexchangekeypairfromseed",
			"display name":"sxKeyExchangeKeypairFromSeed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxKeyExchangeKeypairFromSeed(<pSeed>,<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxKeyExchangeKeypairFromSeed(<i>pSeed</i>,<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive a key-exchange keypair from a 32-byte seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte seed."
			},{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the secret key."
			}],
			"examples":[{
				"script":"sxKeyExchangeKeypairFromSeed tSeed, tPublic, tSecret"
			}],
			"description":"The same seed always gives the same keypair. A seed that is not 32 bytes\nthrows.",
			"references":{
				"handler":["sxKeyExchangeKeypair","sxBoxKeypairFromSeed"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-55",
			"name":"sxhashupdate",
			"display name":"sxHashUpdate",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxHashUpdate(<pHandle>,<pData>)"
			],
			"display syntax":[
				"sxHashUpdate(<i>pHandle</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Add bytes to a multipart hash.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"The handle from sxHashInit or sxHashInitKeyed."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The next bytes."
			}],
			"examples":[{
				"script":"sxHashUpdate tHash, tChunk"
			}],
			"description":"A bad or finished handle throws.",
			"references":{
				"handler":["sxHashInit","sxHashFinal"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-56",
			"name":"sxboxkeypairfromseed",
			"display name":"sxBoxKeypairFromSeed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBoxKeypairFromSeed(<pSeed>,<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxBoxKeypairFromSeed(<i>pSeed</i>,<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive an X25519 keypair from a 32-byte seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte seed."
			},{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the secret key."
			}],
			"examples":[{
				"script":"put sxKdfDerive(tMaster, \"2\", textEncode(\"MyApp-v1\", \"ascii\"), 32) into tSeed\nsxBoxKeypairFromSeed tSeed, tPublic, tSecret"
			}],
			"description":"The same seed always gives the same keypair, so one backed-up master\nseed can rebuild an encryption identity. A seed that is not 32 bytes\nthrows.",
			"references":{
				"handler":["sxBoxKeypair","sxKdfDerive"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-57",
			"name":"sxbin2base64",
			"display name":"sxBin2Base64",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBin2Base64(<pData>)"
			],
			"display syntax":[
				"sxBin2Base64(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encode bytes as URL-safe base64 without padding.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode."
			}],
			"examples":[{
				"script":"put textDecode(sxBin2Base64(tSalt & tBox), \"ascii\") into tShareCode"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The base64 text as Data (ASCII bytes)."
			}],
			"description":"Uses the URL-safe alphabet (- and _) with no = padding, which suits\nshare codes and file names. This is not the encoding the engine's\nbase64Encode produces; decode it with <sxBase642Bin>.",
			"references":{
				"handler":["sxBase642Bin","sxBin2Hex"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-58",
			"name":"sxsign",
			"display name":"sxSign",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSign(<pMessage>,<pSecretKey>)"
			],
			"display syntax":[
				"sxSign(<i>pMessage</i>,<i>pSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Sign a message and return signature and message together.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to sign."
			},{
				"name":"pSecretKey",
				"type":"",
				"refparam":"false",
				"description":"The 64-byte ed25519 secret key."
			}],
			"examples":[{
				"script":"put sxSign(tMessage, tSecret) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The signed message as Data: the signature followed by the message."
			}],
			"description":"The attached form. <sxSignOpen> verifies it and returns the message. A\nwrong key length throws.",
			"references":{
				"handler":["sxSignOpen","sxSignDetached"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-59",
			"name":"sxrandomuniform",
			"display name":"sxRandomUniform",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRandomUniform(<pUpperBound>)"
			],
			"display syntax":[
				"sxRandomUniform(<i>pUpperBound</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return an unbiased random integer below an upper bound.",
			"parameters":[{
				"name":"pUpperBound",
				"type":"",
				"refparam":"false",
				"description":"The exclusive upper bound (1 or more)."
			}],
			"examples":[{
				"script":"put sxRandomUniform(6) + 1 into tDie"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A random integer from 0 to pUpperBound - 1."
			}],
			"description":"Draws from the secure random generator without modulo bias. An upper\nbound below 1 throws.",
			"references":{
				"handler":["sxRandomBytes"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-60",
			"name":"sxboxopen",
			"display name":"sxBoxOpen",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxBoxOpen(<pBox>,<pSenderPk>,<pRecipientSk>)"
			],
			"display syntax":[
				"sxBoxOpen(<i>pBox</i>,<i>pSenderPk</i>,<i>pRecipientSk</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Decrypt and verify a box made by sxBox.",
			"parameters":[{
				"name":"pBox",
				"type":"",
				"refparam":"false",
				"description":"The box."
			},{
				"name":"pSenderPk",
				"type":"",
				"refparam":"false",
				"description":"The sender's public key."
			},{
				"name":"pRecipientSk",
				"type":"",
				"refparam":"false",
				"description":"The recipient's secret key."
			}],
			"examples":[{
				"script":"put textDecode(sxBoxOpen(tBox, tTheirPublic, tMySecret), \"utf-8\") into tText"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The original message as Data."
			}],
			"description":"Throws on a wrong key or any tampering.",
			"references":{
				"handler":["sxBox"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-61",
			"name":"sxsecretstreampush",
			"display name":"sxSecretStreamPush",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretStreamPush(<pHandle>,<pChunk>,<pAd>,<pFinal>)"
			],
			"display syntax":[
				"sxSecretStreamPush(<i>pHandle</i>,<i>pChunk</i>,<i>pAd</i>,<i>pFinal</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt one chunk of a stream.",
			"parameters":[{
				"name":"pHandle",
				"type":"",
				"refparam":"false",
				"description":"The handle from sxSecretStreamInitPush."
			},{
				"name":"pChunk",
				"type":"",
				"refparam":"false",
				"description":"The bytes of this chunk."
			},{
				"name":"pAd",
				"type":"",
				"refparam":"false",
				"description":"Associated data to authenticate with this chunk (may be empty)."
			},{
				"name":"pFinal",
				"type":"",
				"refparam":"false",
				"description":"true for the last chunk of the stream, otherwise false."
			}],
			"examples":[{
				"script":"put sxSecretStreamPush(tStream, tLastChunk, empty, true) into tOut"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The encrypted chunk as Data."
			}],
			"description":"Mark the last chunk final: the final tag is what lets the receiver\ndetect a truncated stream. Keep chunk boundaries, since each encrypted\nchunk is decrypted on its own by <sxSecretStreamPull>. A bad or freed\nhandle throws.",
			"references":{
				"handler":["sxSecretStreamInitPush","sxSecretStreamPull"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-62",
			"name":"sxpwhashstr",
			"display name":"sxPwHashStr",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwHashStr(<pPassphrase>,<pOpsLimit>,<pMemLimit>)"
			],
			"display syntax":[
				"sxPwHashStr(<i>pPassphrase</i>,<i>pOpsLimit</i>,<i>pMemLimit</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Hash a password into a self-describing string for storage.",
			"parameters":[{
				"name":"pPassphrase",
				"type":"",
				"refparam":"false",
				"description":"The password as Data (textEncode it as UTF-8)."
			},{
				"name":"pOpsLimit",
				"type":"",
				"refparam":"false",
				"description":"The ops limit as a decimal string: \"2\", \"3\" or \"4\"."
			},{
				"name":"pMemLimit",
				"type":"",
				"refparam":"false",
				"description":"The memory limit as a decimal string, from a preset handler."
			}],
			"examples":[{
				"script":"put textDecode(sxPwHashStr(textEncode(tPassword, \"utf-8\"), \"2\", sxPwMemInteractive()), \"ascii\") into tStored"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The hash string as Data (ASCII bytes)."
			}],
			"description":"The string packs a fresh random salt and the cost settings, so it is all\nyou need to store. Check a login with <sxPwHashStrVerify>. Never store a\npassword or a plain hash.",
			"references":{
				"handler":["sxPwHashStrVerify","sxPwHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-63",
			"name":"sxpwhashstrverify",
			"display name":"sxPwHashStrVerify",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxPwHashStrVerify(<pHash>,<pPassphrase>)"
			],
			"display syntax":[
				"sxPwHashStrVerify(<i>pHash</i>,<i>pPassphrase</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Check a password against a stored hash string.",
			"parameters":[{
				"name":"pHash",
				"type":"",
				"refparam":"false",
				"description":"The stored hash from sxPwHashStr, as a String."
			},{
				"name":"pPassphrase",
				"type":"",
				"refparam":"false",
				"description":"The candidate password as Data (textEncode it as UTF-8)."
			}],
			"examples":[{
				"script":"if sxPwHashStrVerify(tStored, textEncode(field \"password\", \"utf-8\")) then\n   answer \"Welcome back.\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when the password matches, otherwise false."
			}],
			"description":"The check runs in constant time. Pass the stored hash as a String\n(textDecode the Data <sxPwHashStr> returned).",
			"references":{
				"handler":["sxPwHashStr"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-64",
			"name":"sxrandombytes",
			"display name":"sxRandomBytes",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRandomBytes(<pCount>)"
			],
			"display syntax":[
				"sxRandomBytes(<i>pCount</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return cryptographically secure random bytes.",
			"parameters":[{
				"name":"pCount",
				"type":"",
				"refparam":"false",
				"description":"The number of bytes to return (zero or more)."
			}],
			"examples":[{
				"script":"put sxRandomBytes(32) into tKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"pCount random bytes as Data."
			}],
			"description":"<sxRandomBytes> is the source to use for keys, salts and nonces. Never\nuse the engine random() function for anything that must be unguessable.\nA negative count throws.",
			"references":{
				"handler":["sxRandomUniform","sxPwSaltBytes"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-65",
			"name":"sxsignkeypairfromseed",
			"display name":"sxSignKeypairFromSeed",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignKeypairFromSeed(<pSeed>,<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxSignKeypairFromSeed(<i>pSeed</i>,<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive an ed25519 signing keypair from a 32-byte seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte seed."
			},{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the 32-byte public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the 64-byte secret key (seed followed by public key)."
			}],
			"examples":[{
				"script":"sxSignKeypairFromSeed tSeed, tPublic, tSecret"
			}],
			"description":"The same seed always gives the same keypair (BEP44-compatible), so a\nsigning identity can be rebuilt from one backed-up seed. A wrong seed\nlength throws.",
			"references":{
				"handler":["sxSignKeypair","sxSignSeedToExpandedKey"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-66",
			"name":"sxsecretbox",
			"display name":"sxSecretBox",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretBox(<pMessage>,<pKey>)"
			],
			"display syntax":[
				"sxSecretBox(<i>pMessage</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt and authenticate a message with a secret key.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encrypt."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			}],
			"examples":[{
				"script":"put sxRandomBytes(32) into tKey\nput sxSecretBox(textEncode(\"meet at noon\", \"utf-8\"), tKey) into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sealed box as Data: the random nonce, the MAC and the ciphertext."
			}],
			"description":"Uses XSalsa20-Poly1305. A random nonce is generated and prepended for\nyou, so the result is all you need to store or send. A key that is not\n32 bytes throws. Open the box with <sxSecretBoxOpen>.",
			"references":{
				"handler":["sxSecretBoxOpen","sxAeadEncrypt","sxPwHash"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-67",
			"name":"sxkdfderive",
			"display name":"sxKdfDerive",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxKdfDerive(<pMasterKey>,<pSubkeyId>,<pContext>,<pSubkeyLen>)"
			],
			"display syntax":[
				"sxKdfDerive(<i>pMasterKey</i>,<i>pSubkeyId</i>,<i>pContext</i>,<i>pSubkeyLen</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Derive a numbered subkey from a master key.",
			"parameters":[{
				"name":"pMasterKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte master key."
			},{
				"name":"pSubkeyId",
				"type":"",
				"refparam":"false",
				"description":"The subkey number, as a decimal string (\"0\", \"1\", ...)."
			},{
				"name":"pContext",
				"type":"",
				"refparam":"false",
				"description":"An 8-byte context label, as Data (for example textEncode(\"MyApp-v1\", \"ascii\"))."
			},{
				"name":"pSubkeyLen",
				"type":"",
				"refparam":"false",
				"description":"The subkey length in bytes, 16 to 64."
			}],
			"examples":[{
				"script":"put sxKdfDerive(tMaster, \"1\", textEncode(\"MyApp-v1\", \"ascii\"), 32) into tFileKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The subkey as pSubkeyLen bytes of Data."
			}],
			"description":"One master key can yield many independent keys: each subkey number and\ncontext gives a different key, and none reveals the master. The context\nmust be exactly 8 bytes. A wrong master key or context length, a subkey\nlength out of range, or a subkey id that is not a decimal number throws.",
			"references":{
				"handler":["sxRandomBytes","sxBoxKeypairFromSeed"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-68",
			"name":"sxkeyexchangekeypair",
			"display name":"sxKeyExchangeKeypair",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxKeyExchangeKeypair(<rPublicKey>,<rSecretKey>)"
			],
			"display syntax":[
				"sxKeyExchangeKeypair(<i>rPublicKey</i>,<i>rSecretKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Generate a random key-exchange keypair.",
			"parameters":[{
				"name":"rPublicKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the public key."
			},{
				"name":"rSecretKey",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the secret key."
			}],
			"examples":[{
				"script":"sxKeyExchangeKeypair tPublic, tSecret"
			}],
			"description":"Each side makes a keypair and shares its public key, then calls\n<sxKeyExchangeClient> or <sxKeyExchangeServer> to derive session keys.",
			"references":{
				"handler":["sxKeyExchangeClient","sxKeyExchangeServer","sxKeyExchangeKeypairFromSeed"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-69",
			"name":"sxsignseedtoexpandedkey",
			"display name":"sxSignSeedToExpandedKey",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSignSeedToExpandedKey(<pSeed>)"
			],
			"display syntax":[
				"sxSignSeedToExpandedKey(<i>pSeed</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Return the 64-byte expanded ed25519 secret key for a seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte ed25519 seed."
			}],
			"examples":[{
				"script":"put sxSignSeedToExpandedKey(tSeed) into tExpanded"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The expanded secret key as 64 bytes of Data."
			}],
			"description":"The expanded key is SHA-512 of the seed, clamped: the form a Tor v3\nonion service takes, so one seed can fix a reproducible .onion address.\nIt is not the secret key <sxSignKeypairFromSeed> returns (seed followed\nby public key). A wrong seed length throws.",
			"references":{
				"handler":["sxSignKeypairFromSeed","sxSha3_256"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-70",
			"name":"sxristrettoscalarmultbatch",
			"display name":"sxRistrettoScalarMultBatch",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarMultBatch(<pScalar>,<pPoints>)"
			],
			"display syntax":[
				"sxRistrettoScalarMultBatch(<i>pScalar</i>,<i>pPoints</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Multiply many ristretto255 points by one scalar in one call.",
			"parameters":[{
				"name":"pScalar",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte scalar."
			},{
				"name":"pPoints",
				"type":"",
				"refparam":"false",
				"description":"One or more 32-byte point encodings joined together."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarMultBatch(tMask, tDeckPoints) into tMaskedDeck\nput byte 1 to 32 of tMaskedDeck into tFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The results joined in the same order, as Data of the same length."
			}],
			"description":"All or nothing: one invalid point, or an identity result from a zero\nscalar, throws for the whole call, and the message gives the 1-based\nindex of the failing point. Empty input throws.",
			"references":{
				"handler":["sxRistrettoScalarMultPoint"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-71",
			"name":"sxseal",
			"display name":"sxSeal",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSeal(<pMessage>,<pRecipientPk>)"
			],
			"display syntax":[
				"sxSeal(<i>pMessage</i>,<i>pRecipientPk</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt a message anonymously to a public key.",
			"parameters":[{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encrypt."
			},{
				"name":"pRecipientPk",
				"type":"",
				"refparam":"false",
				"description":"The recipient's public key."
			}],
			"examples":[{
				"script":"put sxSeal(textEncode(\"tip\", \"utf-8\"), tTheirPublic) into tSealed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sealed box as Data."
			}],
			"description":"The sender needs only the recipient's public key and is not identified;\nthe recipient opens it with <sxSealOpen>. A wrong key length throws.",
			"references":{
				"handler":["sxSealOpen","sxBox"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-72",
			"name":"sxristrettoscalarmul",
			"display name":"sxRistrettoScalarMul",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxRistrettoScalarMul(<pX>,<pY>)"
			],
			"display syntax":[
				"sxRistrettoScalarMul(<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Multiply two ristretto255 scalars modulo the group order.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The first 32-byte scalar."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The second 32-byte scalar."
			}],
			"examples":[{
				"script":"put sxRistrettoScalarMul(tC, tK) into tCK"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte reduced product as Data."
			}],
			"description":"Same reduction rules and failures as <sxRistrettoScalarAdd>: only a\nwrong length throws.",
			"references":{
				"handler":["sxRistrettoScalarAdd","sxRistrettoScalarInvert"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-73",
			"name":"sxsecretstreaminitpush",
			"display name":"sxSecretStreamInitPush",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxSecretStreamInitPush(<pKey>,<rHeader>)"
			],
			"display syntax":[
				"sxSecretStreamInitPush(<i>pKey</i>,<i>rHeader</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Open a stream for encrypting data in chunks.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			},{
				"name":"rHeader",
				"type":"",
				"refparam":"false",
				"description":"A variable that receives the stream header; store or send it before the chunks."
			}],
			"examples":[{
				"script":"put sxSecretStreamInitPush(tKey, tHeader) into tStream\nput sxSecretStreamPush(tStream, tChunk1, empty, false) into tOut1\nput sxSecretStreamPush(tStream, tChunk2, empty, true) into tOut2\nsxFreeStream tStream"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A stream handle for sxSecretStreamPush."
			}],
			"description":"Use the secretstream calls for data too large to hold twice in memory or\nthat arrives over time. The receiver needs the header to open the stream\nwith <sxSecretStreamInitPull>. Free the handle with <sxFreeStream> when\nyou are done. A wrong key length throws.",
			"references":{
				"handler":["sxSecretStreamPush","sxSecretStreamInitPull","sxFreeStream"]
			},
			"tags":["cryptography","library"]
		},{
			"id":"org.openxtalk.library.sodium-74",
			"name":"sxencryptfile",
			"display name":"sxEncryptFile",
			"library":"org.openxtalk.library.sodium",
			"type":"handler",
			"syntax":[
				"sxEncryptFile(<pSrcPath>,<pDstPath>,<pKey>)"
			],
			"display syntax":[
				"sxEncryptFile(<i>pSrcPath</i>,<i>pDstPath</i>,<i>pKey</i>)"
			],
			"associations":["org.openxtalk.library.sodium"],
			"summary":"Encrypt a whole file to another file.",
			"parameters":[{
				"name":"pSrcPath",
				"type":"",
				"refparam":"false",
				"description":"The path of the file to encrypt."
			},{
				"name":"pDstPath",
				"type":"",
				"refparam":"false",
				"description":"The path to write the encrypted file to."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte secret key."
			}],
			"examples":[{
				"script":"put sxRandomBytes(32) into tKey\nsxEncryptFile \"/path/to/big.mov\", \"/path/to/big.mov.enc\", tKey"
			}],
			"description":"The file is streamed in chunks inside the native library, so its bytes\nnever load into a variable and any size works. The output is\nauthenticated; decrypt it with <sxDecryptFile>. Throws on a wrong key\nlength or a read or write error.",
			"references":{
				"handler":["sxDecryptFile","sxHashFile"]
			},
			"tags":["cryptography","library"]
		}