# xtalk-midi-extension

```
xtalk-midi-extension/
  midi-player.lcb                    thin widget wrapper (sketch; see "Unverified")
  code/js/xtalk-midi-ext.js          the module: loader + engine + injected SVG button + API
  code/js/libfluidsynth-2.4.6-with-libsndfile.js    <- you add (from npm js-synthesizer/externals/)
  code/js/js-synthesizer.min.js                     <- you add (from npm js-synthesizer/dist/)
  resources/                         optional alternative location for those two files
```

Get the two vendor files with `npm pack js-synthesizer@1.11.0` (or `npm i js-synthesizer`) and copy them
from `externals/` and `dist/`. The module looks for them next to itself (when loaded by `<script src>`),
then `code/js/`, then `resources/`; override with `XTalkMidi.configure({baseUrl:'https://.../'})`.

## Injecting the module into the outer page

Either a script tag in your HTML shell:

    <script src="extensions/midiplayer/code/js/xtalk-midi-ext.js"></script>

or from xTalk, once at startup: read the file's text and `do tText as javascript`
(then set `baseUrl`, since `document.currentScript` is not available that way):

    do "XTalkMidi.configure({baseUrl:'extensions/midiplayer/code/js/'})" as javascript

## The click requirement and the native layer

The play triangle (`M8 5v14l11-7z`, swapping to pause while playing) is an HTML element created by
`XTalkMidi.createButton()`. The widget attaches it with `PointerFromJSObject` and
`set my native layer to ...`, so the engine positions, sizes, shows and hides it like any control.
Its click handler calls `unlock()` synchronously and then queues play/pause, so the user's first real
tap on it unlocks audio (scripted clicks cannot). It is dimmed until a MIDI and a soundfont are loaded.

Pure-JS use without the widget: `XTalkMidi.place(x,y,w,h)` instead injects a fixed-position overlay
into the outer page (coordinates relative to the engine `<canvas>`; `configure({relativeToCanvas:false})`
for page coordinates). In widget mode call `createButton()` before `init()`/`load*()`.

## Properties (XTalkMidi.set / get)

`midi`, `soundfont` (base64, data: URL, http(s) URL or engine path), `volume` 0..1, `tempo`
(multiplier), `loop`, `autoplay`, `position` (seconds), read-only `duration`, `playing`, `state`;
UI: `color`, `visible`, `x`, `y`, `width`, `height`. Commands: `init`, `play`, `pause`, `stop`, `seek`,
`unlock`. Polling: `XTalkMidi.info()` -> `"state,pos,dur,tick,totalTicks,audioState"`.
Push events: `XTalkMidi.onEvent = function(name, data){...}` (`ready`, `midiLoaded`, `soundfontLoaded`,
`playing`, `paused`, `stopped`, `ended`, `looped`, `error`).

## Events back into xTalk (widget)

The widget registers an LCB handler with `HandlerAsJSFunction` and hands it to `XTalkMidi.setCallback`.
JS calls it with one object `{name, detail}`; the widget then posts one message to the widget's script object:

    on midiEvent pName, pDetail
       switch pName
          case "ended"            -- also: ready, midiLoaded, soundfontLoaded, playing,
             -- next track...     --       paused, stopped, looped, error (pDetail = message)
       end switch
    end midiEvent

For plain JS use there is also `XTalkMidi.setCallback(fn)` (fn receives `{name, detail}`) and `XTalkMidi.onEvent(name, data)`.

## Using it from xTalk without relying on the LCB bridge

    do "XTalkMidi.place(20,20,48,48)" as javascript
    do "XTalkMidi.set('soundfont','extensions/midiplayer/resources/gm.sf2')" as javascript
    do "XTalkMidi.set('midi','" & base64Encode(tMidiVar) & "')" as javascript
    do "XTalkMidi.set('loop',true)" as javascript

## Unverified

* `midi-player.lcb` has not been compiled. It calls the JS module through com.livecode.emscripten's
  `EvalJavaScript(pScript)`. Still to check: its return type (the getters convert with
  `formatted as string` / `parsed as number`), and the Path/SVG-from-string call in `OnPaint`.
* The JS module passes a syntax check only: not run against the real WASM files or a browser.
* If the engine already defines a global `Module`, loading the FluidSynth glue could clash with it.
  If so, load the module inside an iframe.
