/* xtalk-midi-ext.js : MIDI player module for the OpenXTalk WASM engine.
 *
 * Loads libfluidsynth-2.4.6-with-libsndfile.js + js-synthesizer.min.js from the extension's
 * code/js/ (or resources/) folder, injects an SVG play/pause button into the OUTER page
 * (a real DOM click satisfies the browser's autoplay/user-gesture rule), and exposes
 * window.XTalkMidi for use from xTalk via:  do "XTalkMidi.set('midi', ...)" as javascript
 */
(function () {
  if (window.XTalkMidi) return;

  var FLUID_FILE = 'libfluidsynth-2.4.6-with-libsndfile.js';   // must load first
  var JSSYNTH_FILE = 'js-synthesizer.min.js';                  // exposes global JSSynth
  var SVG_PLAY  = 'M8 5v14l11-7z';                              // play triangle (24x24 viewBox)
  var SVG_PAUSE = 'M6 5h4v14H6zM14 5h4v14h-4z';

  var cfg = { baseUrl: '', relativeToCanvas: true };
  var here = (document.currentScript && document.currentScript.src) || '';
  if (here) cfg.baseUrl = here.replace(/[^\/]*$/, '');

  var S = { state: 'idle', error: '', ac: null, gain: null, synth: null, node: null,
            sfont: null, midi: null, ppq: 480, tempoUs: 500000, mul: 1, total: 0,
            paused: 0, cur: 0, loop: false, autoplay: false, vol: 0.7, timer: 0,
            midiName: '', sfName: '' };
  var api = {};
  var chain = Promise.resolve();

  /* ---------------------------------------------------------------- helpers */
  function enqueue(fn) {
    chain = chain.then(fn).catch(function (e) {
      S.error = String(e && e.message || e); S.state = 'error'; console.error('[XTalkMidi]', e);
      emit('error', S.error); paint();
    });
    return chain;
  }
  var cb = null;   // single-argument callback, e.g. an LCB handler wrapped by HandlerAsJSFunction
  function emit(name, data) {
    try { if (typeof api.onEvent === 'function') api.onEvent(name, data); } catch (e) {}
    try { if (cb) cb({ name: String(name), detail: (data === undefined || data === null) ? '' : String(data) }); } catch (e) {}
  }
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = src; s.async = false; s.onload = res;
      s.onerror = function () { s.remove(); rej(new Error('Failed to load ' + src)); };
      document.head.appendChild(s);
    });
  }
  async function loadFromFolders(file) {                  // code/js/ first, then resources/
    var bases = [cfg.baseUrl, 'code/js/', 'resources/', './', ''].filter(function (b, i, a) { return a.indexOf(b) === i; });
    var last;
    for (var i = 0; i < bases.length; i++) {
      try { await loadScript(bases[i] + file); return; } catch (e) { last = e; }
    }
    throw new Error(file + ' not found in code/js/ or resources/ (' + (last && last.message) + ')');
  }
  function b64(s) {
    var bin = atob(String(s).replace(/^data:[^,]*,/, '').replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/'));
    var u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  }
  function spt() { return (S.tempoUs / S.ppq) / 1e6 / S.mul; }

  /* ---------------------------------------------------------- audio unlock */
  function ensureCtx() {
    if (!S.ac) {
      S.ac = new (window.AudioContext || window.webkitAudioContext)();
      S.gain = S.ac.createGain(); S.gain.gain.value = S.vol; S.gain.connect(S.ac.destination);
    }
    return S.ac;
  }
  function unlock() {
    try { var p = ensureCtx().resume(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
    return S.ac ? S.ac.state : 'none';
  }

  /* ------------------------------------------------------------ byte source */
  async function getBytes(src) {
    if (src instanceof ArrayBuffer) return src.slice(0);
    if (ArrayBuffer.isView(src)) return src.buffer.slice(src.byteOffset, src.byteOffset + src.byteLength);
    src = String(src).trim();
    if (/^data:/i.test(src)) return b64(src);
    if (/^[A-Za-z0-9+\/=_\-\s]+$/.test(src)) return b64(src);        // bare base64
    var hasScheme = /^[a-z][a-z0-9+.\-]*:/i.test(src), d = null;
    if (!hasScheme) {                                                 // engine filesystem path
      try {
        if (typeof api.fsRead === 'function') d = api.fsRead(src);
        else { var fs = window.FS || (window.Module && window.Module.FS); if (fs && fs.analyzePath(src).exists) d = fs.readFile(src); }
      } catch (e) {}
      if (d) return d instanceof ArrayBuffer ? d.slice(0) : d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength);
    }
    var r = await fetch(src);
    if (!r.ok) throw new Error('HTTP ' + r.status + ' loading ' + src);
    return r.arrayBuffer();
  }

  /* ----------------------------------------------------------------- engine */
  async function init() {
    if (S.synth) return;
    S.state = 'loading'; paint();
    if (!window.JSSynth) {
      await loadFromFolders(FLUID_FILE);       // WASM glue first
      await loadFromFolders(JSSYNTH_FILE);
    }
    await JSSynth.waitForReady();
    if (JSSynth.Synthesizer.waitForWasmInitialized) await JSSynth.Synthesizer.waitForWasmInitialized();
    ensureCtx();
    S.synth = new JSSynth.Synthesizer();
    S.synth.init(S.ac.sampleRate);
    S.synth.setGain(5.0);
    S.node = S.synth.createAudioNode(S.ac, 2048);
    S.node.connect(S.gain);
    S.timer = setInterval(tick, 100);
    S.state = 'ready'; paint(); emit('ready');
  }
  async function tick() {
    if (!S.synth) return;
    if (S.state !== 'playing') { S.cur = S.paused; return; }
    try {
      var t = await S.synth.retrievePlayerCurrentTick();
      S.cur = t || 0;
      var stopped = !(await S.synth.isPlayerPlaying());
      if (stopped || (S.total && t >= S.total - 1)) {
        await rewind();
        if (S.loop) { await play(); emit('looped'); } else { S.state = 'ended'; paint(); emit('ended'); }
      }
    } catch (e) {}
  }
  async function rewind() {
    await S.synth.stopPlayer(); await S.synth.resetPlayer();
    await S.synth.addSMFDataToPlayer(S.midi.slice(0));
    S.paused = 0; S.cur = 0;
  }
  async function loadSoundfont(src) {
    await init();
    var buf = await getBytes(src);
    var was = S.state === 'playing', pos = S.cur;
    if (was) await pause();
    if (S.sfont != null) { try { await S.synth.unloadSFont(S.sfont); } catch (e) {} }
    S.sfont = await S.synth.loadSFont(buf);
    if (S.midi) { await rewind(); S.paused = pos; }
    if (was) await play();
    paint(); emit('soundfontLoaded');
  }
  async function loadMidi(src) {
    await init();
    var buf = await getBytes(src), dv = new DataView(buf);
    if (buf.byteLength < 14 || dv.getUint32(0) !== 0x4D546864) throw new Error('Not a Standard MIDI File');
    var div = dv.getInt16(12); S.ppq = (div & 0x8000) ? 480 : (div || 480);
    S.midi = buf; await rewind();
    S.total = (await S.synth.retrievePlayerTotalTicks()) || 0;
    S.tempoUs = (await S.synth.retrievePlayerMIDITempo()) || 500000;
    S.state = 'stopped'; paint(); emit('midiLoaded');
    if (S.autoplay && S.sfont != null) await play();
  }
  async function play() {
    if (!S.midi) throw new Error('No MIDI loaded');
    if (S.sfont == null) throw new Error('No soundfont loaded');
    var p = S.ac.resume(); if (p && p.catch) p.catch(function () {});   // do NOT await: may stay pending until a real click
    if (S.paused) S.synth.seekPlayer(S.paused);
    await S.synth.playPlayer();
    if (!S.total) S.total = (await S.synth.retrievePlayerTotalTicks()) || 0;
    S.state = 'playing'; paint(); emit('playing');
  }
  async function pause() {
    if (S.state !== 'playing') return;
    S.paused = (await S.synth.retrievePlayerCurrentTick()) || 0; S.cur = S.paused;
    S.state = 'paused'; await S.synth.stopPlayer(); paint(); emit('paused');
  }
  async function stop() { if (S.midi) { await rewind(); S.state = 'stopped'; paint(); emit('stopped'); } }

  /* ---------------------------------------- injected SVG button (outer page) */
  var ui = { box: null, svg: null, path: null, native: false, x: 0, y: 0, w: 48, h: 48, visible: true, color: '#2f6fed' };
  // native=true: element is handed to the widget (set my native layer to ...), the engine positions it.
  // native=false: fixed-position overlay injected into the outer page (pure-JS use).
  function buildUi(native) {
    if (ui.box) return;
    ui.native = !!native;
    var NS = 'http://www.w3.org/2000/svg';
    var box = document.createElement('div');
    box.setAttribute('data-xtalk-midi', '');
    box.style.cssText = (ui.native ? 'position:relative;width:100%;height:100%;' : 'position:fixed;z-index:2147483000;') +
                        'margin:0;padding:0;line-height:0;cursor:pointer;' +
                        '-webkit-tap-highlight-color:transparent;user-select:none;touch-action:manipulation;';
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '100%'); svg.setAttribute('height', '100%');
    var path = document.createElementNS(NS, 'path');
    path.setAttribute('d', SVG_PLAY);
    svg.appendChild(path); box.appendChild(svg);
    // Real user gesture: unlock audio SYNCHRONOUSLY, then queue the transport command.
    box.addEventListener('click', function (ev) {
      ev.stopPropagation();
      unlock();
      if (S.state === 'playing') api.pause(); else api.play();
    });
    ui.box = box; ui.svg = svg; ui.path = path;
    if (!ui.native) {
      (document.body || document.documentElement).appendChild(box);
      window.addEventListener('resize', reposition);
      window.addEventListener('scroll', reposition, true);
      reposition();
    }
    paint();
  }
  function reposition() {
    if (!ui.box || ui.native) return;
    var ox = 0, oy = 0;
    if (cfg.relativeToCanvas) {                      // xTalk coords are relative to the engine's <canvas>
      var c = document.querySelector('canvas');
      if (c) { var r = c.getBoundingClientRect(); ox = r.left; oy = r.top; }
    }
    var s = ui.box.style;
    s.left = (ox + ui.x) + 'px'; s.top = (oy + ui.y) + 'px';
    s.width = ui.w + 'px'; s.height = ui.h + 'px';
    s.display = ui.visible ? 'block' : 'none';
  }
  function paint() {
    if (!ui.box) return;
    ui.path.setAttribute('d', S.state === 'playing' ? SVG_PAUSE : SVG_PLAY);
    ui.path.setAttribute('fill', ui.color);
    var ready = S.midi && S.sfont != null;
    ui.box.style.opacity = S.state === 'error' ? '0.35' : (ready ? '1' : '0.5');
    ui.box.title = S.state === 'error' ? S.error : (ready ? (S.state === 'playing' ? 'Pause' : 'Play')
                   : (S.midi ? 'Load a soundfont' : 'Load a MIDI file'));
  }

  /* ------------------------------------------------------------ properties */
  var PROPS = {
    midi:       { set: function (v) { if (v) { S.midiName = String(v).slice(0, 80); api.loadMidi(v); } } },
    soundfont:  { set: function (v) { if (v) { S.sfName = String(v).slice(0, 80); api.loadSoundfont(v); } } },
    volume:     { set: function (v) { api.setVolume(v); },  get: function () { return S.vol; } },
    tempo:      { set: function (v) { api.setTempo(v); },   get: function () { return S.mul; } },
    loop:       { set: function (v) { api.setLoop(v); },    get: function () { return S.loop; } },
    autoplay:   { set: function (v) { S.autoplay = (v === true || v === 'true'); }, get: function () { return S.autoplay; } },
    position:   { set: function (v) { api.seek(+v); },      get: function () { return api.position(); } },
    duration:   { get: function () { return api.duration(); } },
    playing:    { get: function () { return S.state === 'playing'; } },
    state:      { get: function () { return S.state; } },
    color:      { set: function (v) { ui.color = String(v); paint(); }, get: function () { return ui.color; } },
    visible:    { set: function (v) { ui.visible = (v === true || v === 'true'); reposition(); }, get: function () { return ui.visible; } },
    x: { set: function (v) { ui.x = +v; reposition(); }, get: function () { return ui.x; } },
    y: { set: function (v) { ui.y = +v; reposition(); }, get: function () { return ui.y; } },
    width:  { set: function (v) { ui.w = +v; reposition(); }, get: function () { return ui.w; } },
    height: { set: function (v) { ui.h = +v; reposition(); }, get: function () { return ui.h; } }
  };

  /* ------------------------------------------------------------ public API */
  api.configure = function (o) { for (var k in o) cfg[k] = o[k]; };    // {baseUrl, relativeToCanvas}
  api.place = function (x, y, w, h) { ui.x = +x; ui.y = +y; ui.w = +w; ui.h = +h; buildUi(false); reposition(); };
  // Widget mode: returns the button element (an HTMLDivElement holding the SVG) to use as a native layer.
  // Call this BEFORE init()/load*(), which would otherwise create the fixed-position overlay.
  api.createButton = function () { buildUi(true); return ui.box; };
  api.set = function (name, value) {
    var p = PROPS[name];
    if (!p || !p.set) { S.error = 'Unknown or read-only property: ' + name; return false; }
    buildUi(); p.set(value); return true;
  };
  api.get = function (name) { var p = PROPS[name]; return p && p.get ? p.get() : ''; };
  api.unlock = unlock;                                                  // call from a real click handler
  api.init = function () { buildUi(); return enqueue(init); };
  // Each source may be base64, data: URL, http(s)/blob/relative URL, or an engine-FS path
  api.loadMidi      = function (src) { buildUi(); return enqueue(function () { return loadMidi(src); }); };
  api.loadSoundfont = function (src) { buildUi(); return enqueue(function () { return loadSoundfont(src); }); };
  api.play  = function () { return enqueue(play); };
  api.pause = function () { return enqueue(pause); };
  api.stop  = function () { return enqueue(stop); };
  api.seek  = function (sec) {
    S.paused = Math.max(0, Math.round(sec / spt())); S.cur = S.paused;
    return enqueue(async function () { if (S.state === 'playing') S.synth.seekPlayer(S.paused); });
  };
  api.setVolume = function (v) { S.vol = Math.min(1, Math.max(0, +v || 0)); if (S.gain) S.gain.gain.value = S.vol; };
  api.setTempo  = function (m) { S.mul = Math.min(1000, Math.max(0.001, +m || 1)); if (S.synth) S.synth.setPlayerTempo(0, S.mul); };
  api.setLoop   = function (b) { S.loop = (b === true || b === 'true'); };
  // synchronous getters (cache refreshed every 100 ms) for optional xTalk polling
  api.status     = function () { return S.state; };
  api.error      = function () { return S.error; };
  api.position   = function () { return S.cur * spt(); };
  api.ticks      = function () { return S.cur; };
  api.duration   = function () { return S.total * spt(); };
  api.isPlaying  = function () { return S.state === 'playing'; };
  api.audioState = function () { return S.ac ? S.ac.state : 'none'; };
  api.info       = function () { return [S.state, api.position().toFixed(2), api.duration().toFixed(2), S.cur, S.total, api.audioState()].join(','); };
  api.setCallback = function (fn) { cb = (typeof fn === 'function') ? fn : null; };   // fn({name, detail})
  api.onEvent = null;                                                   // optional push events

  window.XTalkMidi = api;
})();
