{
			"id":"nostrxt-1",
			"name":"nostrxt",
			"display name":"NostrXT",
			"library":"nostrxt",
			"type":"library",
			"display syntax":[
				"NostrXT"
			],
			"associations":["nostrxt"],
			"description":"NostrXT is the client side of the Nostr protocol for OpenXTalk, written in\npure script: NIP-01 events (build, canonical serialization, id, BIP-340 sign\nand verify), NIP-19 bech32 entities and NIP-21 nostr: URIs, NIP-44 v2\nencrypted payloads, NIP-01 filters and relay messages, NIP-13 proof of\nwork, NIP-05 and NIP-11 parsing, and the pure-compute half of an RFC 6455\nwebsocket client.\n\nThis core library does no I/O and holds no connection state. The relay\nclient (the NostrXT Relay Client library, nxr handlers) owns the sockets\nand composes it, so load this library first.\n\nIt adds no cryptography of its own. SHA-256, Schnorr signatures, x-only\nkeys, ECDH and HMAC come from CoinXT; randomness, constant-time compare\nand the NIP-44 cipher come from SodiumXT. A missing extension disables\nexactly the features that need it (see <nxProbeCapabilities>).\n\nNo handler here ever throws. A function that fails returns empty (or\nfalse for a predicate) and records the reason, which <nxLastError>\nreturns. Ids, pubkeys, secret keys and signatures cross this API as\nlowercase hex strings."
		},{
			"id":"nostrxt-2",
			"name":"nxwsacceptfor",
			"display name":"nxWsAcceptFor",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxWsAcceptFor(<pKeyB64>)"
			],
			"display syntax":[
				"nxWsAcceptFor(<i>pKeyB64</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the Sec-WebSocket-Accept value a server must answer with.",
			"parameters":[{
				"name":"pKeyB64",
				"type":"",
				"refparam":"false",
				"description":"The Sec-WebSocket-Key the client sent, base64."
			}],
			"examples":[{
				"script":"put nxWsAcceptFor(tKeyB64) into tExpected"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The expected accept value, base64."
			}],
			"description":"Base64 of SHA-1 over the key followed by the RFC 6455 GUID, using the\nengine's own sha1Digest. Compare the server's answer with it byte for\nbyte.",
			"references":{
				"handler":["nxWsHandshakeRequest"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-3",
			"name":"nxunixnow",
			"display name":"nxUnixNow",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxUnixNow()"
			],
			"display syntax":[
				"nxUnixNow()"
			],
			"associations":["nostrxt"],
			"summary":"Returns the current unix time in seconds.",
			"examples":[{
				"script":"put nxUnixNow() into tNow"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of seconds since the unix epoch."
			}],
			"description":"This is the timestamp the event builders use for \"created_at\" when you\npass an empty created-at argument.",
			"references":{
				"handler":["nxEventBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-4",
			"name":"nxpowcheck",
			"display name":"nxPowCheck",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxPowCheck(<pEvent>,<pMinBits>)"
			],
			"display syntax":[
				"nxPowCheck(<i>pEvent</i>,<i>pMinBits</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether an event meets a NIP-13 proof-of-work target.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			},{
				"name":"pMinBits",
				"type":"",
				"refparam":"false",
				"description":"The minimum number of leading zero bits, 0 to 256."
			}],
			"examples":[{
				"script":"if not nxPowCheck(tEvent, 20) then put \"not enough work\" into tVerdict"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"The id must have at least pMinBits leading zero bits, and a target the\nevent committed to in its \"nonce\" tag must itself be at least pMinBits,\nso a low-target miner that got lucky is refused, as NIP-13 asks. A\ncommitted target that is not a number refuses.",
			"references":{
				"handler":["nxPowDifficulty"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-5",
			"name":"nxprobecapabilities",
			"display name":"nxProbeCapabilities",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxProbeCapabilities()"
			],
			"display syntax":[
				"nxProbeCapabilities()"
			],
			"associations":["nostrxt"],
			"summary":"Reports which extensions NostrXT can use, as a cached array.",
			"examples":[{
				"script":"put nxProbeCapabilities() into tCaps\nif tCaps[\"canSign\"] is not true then answer \"CoinXT is not installed: signing is unavailable\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"hasCoin\", \"hasSodium\", \"canSign\",\n\"canNip44Cipher\" (each true or false) and \"version\"."
			}],
			"description":"Each extension is probed with a real round trip (a known hash, a real\nrandom byte), not a version check. \"hasCoin\" and \"canSign\" need CoinXT;\n\"hasSodium\" needs SodiumXT; \"canNip44Cipher\" is false when the installed\nSodiumXT is older than ABI 10, which added the NIP-44 cipher.\n\nThe answer is cached for the session after the first call. To notice a\nSodiumXT upgraded while the app runs, use <nxNip44HasCipher>, which\nprobes the cipher live.",
			"references":{
				"handler":["nxNip44HasCipher","nxLastError"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-6",
			"name":"nxeventverify",
			"display name":"nxEventVerify",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventVerify(<pEvent>)"
			],
			"display syntax":[
				"nxEventVerify(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Checks an event's id and signature.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			}],
			"examples":[{
				"script":"put nxEventFromJson(tJson) into tEvent\nif tEvent is not empty then put nxEventVerify(tEvent) into tTrusted"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true only when the id and the signature both check out."
			}],
			"description":"Needs CoinXT. <nxEventVerify> recomputes the id from the event's fields,\ncompares it with the id the event carries, and verifies the BIP-340\nsignature over it. Anything else returns false with the reason recorded,\nincluding a missing CoinXT.\n\nAn event from anywhere is untrusted text until this returns true.",
			"references":{
				"handler":["nxEventFromJson","nxEventSign","nxEventId"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-7",
			"name":"nxuriencode",
			"display name":"nxUriEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxUriEncode(<pEntity>)"
			],
			"display syntax":[
				"nxUriEncode(<i>pEntity</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-21 nostr: URI for a shareable entity.",
			"parameters":[{
				"name":"pEntity",
				"type":"",
				"refparam":"false",
				"description":"An npub, note, nprofile, nevent or naddr string."
			}],
			"examples":[{
				"script":"put nxUriEncode(nxNpubEncode(tPubkey)) into tUri"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The URI, or empty."
			}],
			"description":"The entity is decoded first, so an invalid one refuses. An nsec\nalways refuses: a secret key in a URI ends up in somebody's chat\nlog. An input that already starts with nostr: comes back unchanged.",
			"references":{
				"handler":["nxUriDecode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-8",
			"name":"nxnoteencode",
			"display name":"nxNoteEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNoteEncode(<pIdHex>)"
			],
			"display syntax":[
				"nxNoteEncode(<i>pIdHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes an event id as a note.",
			"parameters":[{
				"name":"pIdHex",
				"type":"",
				"refparam":"false",
				"description":"The event id as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNoteEncode(tSigned[\"id\"]) into tNote"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The note1 string, or empty."
			}],
			"description":"A bare pointer to an event. To add relay hints, the author or the kind,\nuse <nxNeventEncode>.",
			"references":{
				"handler":["nxNoteDecode","nxNeventEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-9",
			"name":"nxbech32decode",
			"display name":"nxBech32Decode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxBech32Decode(<pText>)"
			],
			"display syntax":[
				"nxBech32Decode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes a bech32 or bech32m string.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The encoded string."
			}],
			"examples":[{
				"script":"put nxBech32Decode(tText) into tDecoded\nput tDecoded[\"hrp\"] into tPrefix"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"hrp\", \"spec\" and \"hex\", or empty."
			}],
			"description":"Accepts either spec and reports which in \"spec\". \"hex\" holds the data\nbytes, without the checksum, as lowercase hex. Mixed case, a bad\nchecksum, a character outside the charset, bad padding bits and strings\nover 5000 characters all refuse.",
			"references":{
				"handler":["nxBech32Encode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-10",
			"name":"nxcontactsparse",
			"display name":"nxContactsParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxContactsParse(<pEvent>)"
			],
			"display syntax":[
				"nxContactsParse(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the followed public keys of a kind 3 contact list.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"A kind 3 event array."
			}],
			"examples":[{
				"script":"put nxContactsParse(tEvent) into tFollowList"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The pubkeys, one per line, or empty for another kind."
			}],
			"description":"Reads the value of every \"p\" tag. Any other kind returns empty and\nrecords the reason.",
			"references":{
				"handler":["nxContactsBuild","nxTagValues"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-11",
			"name":"nxrelaylistparse",
			"display name":"nxRelayListParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxRelayListParse(<pEvent>)"
			],
			"display syntax":[
				"nxRelayListParse(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the relays of a kind 10002 relay list.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"A kind 10002 event array."
			}],
			"examples":[{
				"script":"put nxRelayListParse(tEvent) into tRelayLines"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"One relay per line, with a tab and its marker when it has one."
			}],
			"description":"Reads every \"r\" tag. Any other kind returns empty and records the\nreason.",
			"references":{
				"handler":["nxRelayListBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-12",
			"name":"nxnip44encrypt",
			"display name":"nxNip44Encrypt",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44Encrypt(<pSeckeyHex>,<pPubkeyHex>,<pPlaintext>,<pNonceHex>)"
			],
			"display syntax":[
				"nxNip44Encrypt(<i>pSeckeyHex</i>,<i>pPubkeyHex</i>,<i>pPlaintext</i>,<i>pNonceHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encrypts a message for another Nostr key with NIP-44 v2.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"Your secret key as 64 hex characters."
			},{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The recipient's public key as 64 hex characters."
			},{
				"name":"pPlaintext",
				"type":"",
				"refparam":"false",
				"description":"The message, 1 to 65535 bytes."
			},{
				"name":"pNonceHex",
				"type":"",
				"refparam":"false",
				"description":"Empty for a fresh random nonce, or 64 hex characters for test vectors only."
			}],
			"examples":[{
				"script":"put nxNip44Encrypt(tSeckey, tTheirPubkey, \"meet at noon\", empty) into tPayload\nif tPayload is empty then answer \"could not encrypt:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The versioned payload in standard base64, or empty."
			}],
			"description":"Needs CoinXT, and SodiumXT ABI 10 or later for the cipher and the nonce.\nWith an older SodiumXT it fails closed with a reason naming\nsxChaCha20IetfXor. Plaintext longer than 65535 bytes refuses.\n\nAlways pass empty for pNonceHex in an app: reusing a nonce breaks the\nencryption. A fixed nonce exists only to reproduce published vectors.",
			"references":{
				"handler":["nxNip44Decrypt","nxNip44HasCipher"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-13",
			"name":"nxclientreq",
			"display name":"nxClientReq",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxClientReq(<pSubId>,<pFiltersJson>)"
			],
			"display syntax":[
				"nxClientReq(<i>pSubId</i>,<i>pFiltersJson</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-01 REQ message.",
			"parameters":[{
				"name":"pSubId",
				"type":"",
				"refparam":"false",
				"description":"The subscription id, 1 to 64 characters."
			},{
				"name":"pFiltersJson",
				"type":"",
				"refparam":"false",
				"description":"One filter JSON object per line; at least one."
			}],
			"examples":[{
				"script":"put nxClientReq(\"my-feed\", nxFilterBuild(tFilter)) into tWire"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The REQ message text, or empty."
			}],
			"description":"<nxrSubscribe> builds and sends the same message itself; use this for a\ntransport of your own. Each line must be a JSON object.",
			"references":{
				"handler":["nxFilterBuild","nxClientClose","nxrSubscribe"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-14",
			"name":"nxnip44conversationkey",
			"display name":"nxNip44ConversationKey",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44ConversationKey(<pSeckeyHex>,<pPubkeyHex>)"
			],
			"display syntax":[
				"nxNip44ConversationKey(<i>pSeckeyHex</i>,<i>pPubkeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Derives the NIP-44 v2 conversation key between two keys.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"Your secret key as 64 hex characters."
			},{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The other party's public key as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNip44ConversationKey(tSeckey, tTheirPubkey) into tConvKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The conversation key as 64 hex characters, or empty."
			}],
			"description":"Needs CoinXT (cxEcdh and cxHmacSha256). The key is HKDF-extract with the\nsalt \"nip44-v2\" over the shared ECDH x coordinate, and it is the same\nfrom both sides. <nxNip44Encrypt> and <nxNip44Decrypt> derive it\nthemselves; call this to inspect or cache it.",
			"references":{
				"handler":["nxNip44MessageKeys","nxNip44Encrypt"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-15",
			"name":"nxnsecencode",
			"display name":"nxNsecEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNsecEncode(<pSeckeyHex>)"
			],
			"display syntax":[
				"nxNsecEncode(<i>pSeckeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes a secret key as an nsec.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"The secret key as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNsecEncode(tSeckey) into tBackupText"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The nsec1 string, or empty."
			}],
			"description":"For explicit backup flows only. Never show or log an nsec casually, and\nnote that <nxUriEncode> refuses to wrap one.",
			"references":{
				"handler":["nxNsecDecode","nxKeyGenerate"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-16",
			"name":"nxreplybuild",
			"display name":"nxReplyBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxReplyBuild(<pParentEvent>,<pContent>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxReplyBuild(<i>pParentEvent</i>,<i>pContent</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 1 reply with NIP-10 marked tags.",
			"parameters":[{
				"name":"pParentEvent",
				"type":"",
				"refparam":"false",
				"description":"The event being replied to, with its id and pubkey."
			},{
				"name":"pContent",
				"type":"",
				"refparam":"false",
				"description":"The reply text."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxReplyBuild(tParent, \"Agreed!\", empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"The reply carries an \"e\" tag marked \"root\" for the thread root (the\nparent's own root tag, or the parent itself when it has none), an \"e\"\ntag marked \"reply\" for the parent when it is not the root, and \"p\" tags\nfor the parent's author and the people the parent tagged, without\nduplicates.",
			"references":{
				"handler":["nxReactionBuild","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-17",
			"name":"nxnotedecode",
			"display name":"nxNoteDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNoteDecode(<pText>)"
			],
			"display syntax":[
				"nxNoteDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes a note to a hex event id.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The note1 string."
			}],
			"examples":[{
				"script":"put nxNoteDecode(tNote) into tId"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The event id as 64 hex characters, or empty."
			}],
			"description":"A string with another prefix, the bech32m spec or a payload that is not\n32 bytes refuses.",
			"references":{
				"handler":["nxNoteEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-18",
			"name":"nxb64decode",
			"display name":"nxB64Decode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxB64Decode(<pText>)"
			],
			"display syntax":[
				"nxB64Decode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes strict standard base64 back to binary data.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The base64 text, with padding."
			}],
			"examples":[{
				"script":"put nxB64Decode(\"aGVsbG8=\") into tData\nif tData is empty then answer \"not valid base64\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The decoded bytes, or empty when the text is malformed."
			}],
			"description":"<nxB64Decode> refuses characters outside the base64 alphabet, data after\nthe padding, misplaced or extra padding, and a length that is not a\nmultiple of 4. A malformed payload is an error, never a partial decode.\nEmpty input returns empty.",
			"references":{
				"handler":["nxB64Encode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-19",
			"name":"nxnip44decrypt",
			"display name":"nxNip44Decrypt",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44Decrypt(<pSeckeyHex>,<pPubkeyHex>,<pPayload>)"
			],
			"display syntax":[
				"nxNip44Decrypt(<i>pSeckeyHex</i>,<i>pPubkeyHex</i>,<i>pPayload</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decrypts a NIP-44 v2 payload.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"Your secret key as 64 hex characters."
			},{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The sender's public key as 64 hex characters."
			},{
				"name":"pPayload",
				"type":"",
				"refparam":"false",
				"description":"The base64 payload."
			}],
			"examples":[{
				"script":"put nxNip44Decrypt(tSeckey, tSenderPubkey, tPayload) into tMessage\nif tMessage is empty then answer \"could not decrypt:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The plaintext, or empty."
			}],
			"description":"Needs CoinXT, and SodiumXT ABI 10 or later. The MAC is checked first,\nover the nonce and ciphertext, with a constant-time compare, and the\ncipher runs only if it matches. Every step is strict: an unknown version,\na short payload, bad base64, a wrong key or tampering, or padding that\ndoes not agree all refuse with the reason recorded.",
			"references":{
				"handler":["nxNip44Encrypt","nxNip44ConversationKey"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-20",
			"name":"nxnprofileencode",
			"display name":"nxNprofileEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNprofileEncode(<pPubkeyHex>,<pRelayLines>)"
			],
			"display syntax":[
				"nxNprofileEncode(<i>pPubkeyHex</i>,<i>pRelayLines</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes a public key and relay hints as an nprofile.",
			"parameters":[{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The public key as 64 hex characters."
			},{
				"name":"pRelayLines",
				"type":"",
				"refparam":"false",
				"description":"Relay URLs that may know the profile, one per line, or empty."
			}],
			"examples":[{
				"script":"put nxNprofileEncode(tPubkey, \"wss://relay.example.com\") into tProfile"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The nprofile1 string, or empty."
			}],
			"description":"A NIP-19 TLV entity. The pubkey is required; the relay hints are\noptional.",
			"references":{
				"handler":["nxNprofileDecode","nxNpubEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-21",
			"name":"nxhexdecode",
			"display name":"nxHexDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxHexDecode(<pHex>)"
			],
			"display syntax":[
				"nxHexDecode(<i>pHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Converts hex text (either case) to binary data.",
			"parameters":[{
				"name":"pHex",
				"type":"",
				"refparam":"false",
				"description":"The hex text."
			}],
			"examples":[{
				"script":"put nxHexDecode(\"616263\") into tData"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The bytes, or empty when the text is not valid hex."
			}],
			"description":"<nxHexDecode> accepts upper and lower case digits. Text of odd length or\nwith a character that is not a hex digit returns empty and records the\nreason for <nxLastError>.",
			"references":{
				"handler":["nxHexEncode","nxIsHex"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-22",
			"name":"nxwsframedecode",
			"display name":"nxWsFrameDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxWsFrameDecode(<pBuffer>)"
			],
			"display syntax":[
				"nxWsFrameDecode(<i>pBuffer</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Parses one websocket frame at the start of a buffer.",
			"parameters":[{
				"name":"pBuffer",
				"type":"",
				"refparam":"false",
				"description":"The received bytes."
			}],
			"examples":[{
				"script":"put nxWsFrameDecode(tBuffer) into tFrame\nif tFrame[\"complete\"] is true then put byte (tFrame[\"consumed\"] + 1) to -1 of tBuffer into tBuffer"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array describing the frame (see the description)."
			}],
			"description":"When \"complete\" is false, read more: \"needMore\" says how many bytes are\nmissing, or 0 when not yet known. When it is true, \"fin\", \"opcode\",\n\"masked\", \"payload\" (unmasked) and \"consumed\" (the bytes to drop from\nthe buffer) are set.\n\nA non-empty \"error\" means the stream cannot recover (reserved bits, a\nlength over the 8 MB cap, an oversized or fragmented control frame):\nclose the connection.",
			"references":{
				"handler":["nxWsFrameEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-23",
			"name":"nxclientevent",
			"display name":"nxClientEvent",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxClientEvent(<pEvent>)"
			],
			"display syntax":[
				"nxClientEvent(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-01 EVENT message for a signed event.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The signed event array."
			}],
			"examples":[{
				"script":"put nxClientEvent(tSigned) into tWire"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The EVENT message text, or empty."
			}],
			"description":"Refuses an event without an id and signature: sign it with\n<nxEventSign> first. <nxrPublish> builds and sends the same message\nitself.",
			"references":{
				"handler":["nxEventSign","nxrPublish"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-24",
			"name":"nxnsecdecode",
			"display name":"nxNsecDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNsecDecode(<pText>)"
			],
			"display syntax":[
				"nxNsecDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes an nsec to a hex secret key.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The nsec1 string."
			}],
			"examples":[{
				"script":"put nxNsecDecode(tBackupText) into tSeckey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The secret key as 64 hex characters, or empty."
			}],
			"description":"A string with another prefix, the bech32m spec or a payload that is not\n32 bytes refuses.",
			"references":{
				"handler":["nxNsecEncode","nxKeyIsValid"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-25",
			"name":"nxversion",
			"display name":"nxVersion",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxVersion()"
			],
			"display syntax":[
				"nxVersion()"
			],
			"associations":["nostrxt"],
			"summary":"Returns the NostrXT name and version.",
			"examples":[{
				"script":"put nxVersion() into field \"versionField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The text \"NostrXT\" followed by a space and the version number."
			}],
			"description":"Use <nxVersion> to confirm the core library is loaded and to show which\nversion an app is running.",
			"references":{
				"handler":["nxrVersion","nxProbeCapabilities"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-26",
			"name":"nxnip44paddedlen",
			"display name":"nxNip44PaddedLen",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44PaddedLen(<pLen>)"
			],
			"display syntax":[
				"nxNip44PaddedLen(<i>pLen</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the NIP-44 v2 padded length for a plaintext length.",
			"parameters":[{
				"name":"pLen",
				"type":"",
				"refparam":"false",
				"description":"The plaintext length in bytes, a positive integer."
			}],
			"examples":[{
				"script":"put nxNip44PaddedLen(100) into tPadded"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The padded length in bytes, or empty."
			}],
			"description":"Lengths up to 32 pad to 32; longer ones round up in chunks that grow\nwith the length, as NIP-44 defines. This is arithmetic only: the 1 to\n65535 byte limit is enforced when <nxNip44Encrypt> pads.",
			"references":{
				"handler":["nxNip44Encrypt"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-27",
			"name":"nxlasterror",
			"display name":"nxLastError",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxLastError()"
			],
			"display syntax":[
				"nxLastError()"
			],
			"associations":["nostrxt"],
			"summary":"Returns the reason the most recent failing nx call recorded.",
			"examples":[{
				"script":"put nxNpubDecode(field \"npubField\") into tPubkey\nif tPubkey is empty then answer \"Not an npub:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The reason text, or empty when nothing has failed yet."
			}],
			"description":"Core handlers never throw. A function that fails returns empty (or false\nfor a predicate) and records why. Check the return first, then read\n<nxLastError> straight away: any later failing call overwrites the\nreason, and a successful call does not clear it.\n\nA missing extension gives a reason that names the handler it needs, for\nexample \"nxEventId needs CoinXT cxSha256\".",
			"references":{
				"handler":["nxProbeCapabilities"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-28",
			"name":"nxb64encode",
			"display name":"nxB64Encode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxB64Encode(<pData>)"
			],
			"display syntax":[
				"nxB64Encode(<i>pData</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes binary data as standard base64 on one line.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to encode."
			}],
			"examples":[{
				"script":"put nxB64Encode(textEncode(\"hello\", \"UTF-8\")) into tText"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The base64 text, with no line breaks."
			}],
			"description":"The engine's base64Encode can wrap its output across lines. Every wire\nformat NostrXT uses (NIP-44 payloads, the websocket key) is single-line,\nso <nxB64Encode> removes both line-break characters.",
			"references":{
				"handler":["nxB64Decode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-29",
			"name":"nxeventhasvalidshape",
			"display name":"nxEventHasValidShape",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventHasValidShape(<pEvent>)"
			],
			"display syntax":[
				"nxEventHasValidShape(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Checks that an event array has the structure NIP-01 requires.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			}],
			"examples":[{
				"script":"if not nxEventHasValidShape(tEvent) then answer nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Checks that the kind is a plain integer from 0 to 65535 and created_at a\nplain non-negative integer, that id, pubkey and sig (when present) are\nhex of the right length, that content is a string, and that tags is an\narray of 1-based, gap-free arrays of strings, each with a name.\n\nIt checks structure only, not the id or signature: that is\n<nxEventVerify>. A failure records the specific reason.",
			"references":{
				"handler":["nxEventBuild","nxEventVerify"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-30",
			"name":"nxctequalhex",
			"display name":"nxCtEqualHex",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxCtEqualHex(<pAHex>,<pBHex>)"
			],
			"display syntax":[
				"nxCtEqualHex(<i>pAHex</i>,<i>pBHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Compares two hex strings without exiting early on the first difference.",
			"parameters":[{
				"name":"pAHex",
				"type":"",
				"refparam":"false",
				"description":"The first hex string."
			},{
				"name":"pBHex",
				"type":"",
				"refparam":"false",
				"description":"The second hex string."
			}],
			"examples":[{
				"script":"if nxCtEqualHex(tExpectedId, tEvent[\"id\"]) then put \"match\" into tVerdict"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when both strings hold the same hex value, false otherwise."
			}],
			"description":"Use <nxCtEqualHex> to compare MACs and ids, rather than a bare is, which\ncan compare number-like text as numbers. Case is ignored. With SodiumXT\nthe decoded bytes are compared by sxMemEqual; without it, a loop over\nevery character that never exits early stands in.\n\nThis guards against the gross early-exit timing leak, not a lab-grade\nside channel: script timing is noisy either way. Strings of different\nlengths return false at once.",
			"references":{
				"handler":["nxIsHex"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-31",
			"name":"nxnip44messagekeys",
			"display name":"nxNip44MessageKeys",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44MessageKeys(<pConvKeyHex>,<pNonceHex>)"
			],
			"display syntax":[
				"nxNip44MessageKeys(<i>pConvKeyHex</i>,<i>pNonceHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Derives the NIP-44 v2 per-message keys from a conversation key and nonce.",
			"parameters":[{
				"name":"pConvKeyHex",
				"type":"",
				"refparam":"false",
				"description":"The conversation key as 64 hex characters."
			},{
				"name":"pNonceHex",
				"type":"",
				"refparam":"false",
				"description":"The message nonce as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNip44MessageKeys(tConvKey, tNonceHex) into tKeys\nput tKeys[\"hmacKey\"] into tMacKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"chachaKey\", \"chachaNonce\" and \"hmacKey\" (hex), or empty."
			}],
			"description":"Needs CoinXT (cxHmacSha256). HKDF-expand to 76 bytes, split into a\n32-byte ChaCha20 key, a 12-byte ChaCha20 nonce and a 32-byte HMAC key.\nExposed for test vectors and for building your own NIP-44 tooling.",
			"references":{
				"handler":["nxNip44ConversationKey","nxNip44Encrypt"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-32",
			"name":"nxnip05url",
			"display name":"nxNip05Url",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip05Url(<pIdentifier>)"
			],
			"display syntax":[
				"nxNip05Url(<i>pIdentifier</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the URL to fetch to check a NIP-05 identifier.",
			"parameters":[{
				"name":"pIdentifier",
				"type":"",
				"refparam":"false",
				"description":"The identifier, name@domain, or a bare domain."
			}],
			"examples":[{
				"script":"put nxNip05Url(\"alice@example.com\") into tUrl\nput URL tUrl into tBody\nput nxNip05Verify(tBody, \"alice\", tPubkey) into tVerified"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The https URL of the domain's nostr.json, or empty."
			}],
			"description":"A bare domain means the name \"_\". This library does no I/O, so the\nfetch is yours. A malformed identifier, or a domain containing /, ?, #\nor @, refuses.",
			"references":{
				"handler":["nxNip05Verify"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-33",
			"name":"nxfiltermatches",
			"display name":"nxFilterMatches",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxFilterMatches(<pFilterJson>,<pEvent>)"
			],
			"display syntax":[
				"nxFilterMatches(<i>pFilterJson</i>,<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether an event matches a NIP-01 filter.",
			"parameters":[{
				"name":"pFilterJson",
				"type":"",
				"refparam":"false",
				"description":"The filter JSON object."
			},{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			}],
			"examples":[{
				"script":"if nxFilterMatches(tFilterJson, tEvent) then put tEvent[\"content\"] & return after field \"feedField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Every condition in the filter must hold. List conditions (ids, authors,\nkinds, tag filters) need one exact match; since and until are inclusive.\nAnything doubtful, including a filter that is not a JSON object or an\nevent with a bad shape, returns false.",
			"references":{
				"handler":["nxFilterBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-34",
			"name":"nxnaddrdecode",
			"display name":"nxNaddrDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNaddrDecode(<pText>)"
			],
			"display syntax":[
				"nxNaddrDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes an naddr.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The naddr1 string."
			}],
			"examples":[{
				"script":"put nxNaddrDecode(tText) into tFields\nput tFields[\"kind\"] && tFields[\"identifier\"] into field \"coordField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"type\", \"identifier\", \"pubkey\", \"kind\" and \"relays\", or empty."
			}],
			"description":"An naddr without an author or a kind refuses, as does another entity\ntype.",
			"references":{
				"handler":["nxNaddrEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-35",
			"name":"nxkeypublic",
			"display name":"nxKeyPublic",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxKeyPublic(<pSeckeyHex>)"
			],
			"display syntax":[
				"nxKeyPublic(<i>pSeckeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Derives the Nostr public key for a secret key.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"The secret key as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxKeyPublic(tSeckey) into tPubkey\nput nxNpubEncode(tPubkey) into field \"npubField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 64-hex x-only public key, or empty."
			}],
			"description":"Needs CoinXT (cxXOnlyPubkey). Returns empty, with the reason recorded,\nwhen the secret key is not 64 hex characters or CoinXT refuses it.",
			"references":{
				"handler":["nxKeyGenerate","nxNpubEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-36",
			"name":"nxpowdifficulty",
			"display name":"nxPowDifficulty",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxPowDifficulty(<pIdHex>)"
			],
			"display syntax":[
				"nxPowDifficulty(<i>pIdHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the NIP-13 proof-of-work difficulty of an event id.",
			"parameters":[{
				"name":"pIdHex",
				"type":"",
				"refparam":"false",
				"description":"The event id as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxPowDifficulty(tEvent[\"id\"]) into tBits"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of leading zero bits, or empty."
			}],
			"description":"NIP-13 measures work as the leading zero bits of the id.",
			"references":{
				"handler":["nxPowCheck"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-37",
			"name":"nxkeygenerate",
			"display name":"nxKeyGenerate",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxKeyGenerate()"
			],
			"display syntax":[
				"nxKeyGenerate()"
			],
			"associations":["nostrxt"],
			"summary":"Generates a new Nostr secret key.",
			"examples":[{
				"script":"put nxKeyGenerate() into tSeckey\nif tSeckey is empty then answer \"no key:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The secret key as 64 lowercase hex characters, or empty."
			}],
			"description":"<nxKeyGenerate> draws 32 random bytes from SodiumXT and checks with\nCoinXT that they form a valid secp256k1 secret key. It needs both\nextensions and refuses without them: it never falls back to weaker\nrandomness.\n\nThe key is a plain script value. OXT variables are not locked memory, so\nhow and where to store a key is the app's decision.",
			"references":{
				"handler":["nxKeyPublic","nxKeyIsValid","nxNsecEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-38",
			"name":"nxcontactsbuild",
			"display name":"nxContactsBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxContactsBuild(<pPubkeyLines>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxContactsBuild(<i>pPubkeyLines</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 3 contact list.",
			"parameters":[{
				"name":"pPubkeyLines",
				"type":"",
				"refparam":"false",
				"description":"The followed public keys, one 64-hex pubkey per line."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxContactsBuild(tFollowList, empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"Each pubkey becomes a \"p\" tag. A line that is not a 64-hex pubkey\nrefuses. A kind 3 list replaces the previous one, so publish the whole\nlist every time.",
			"references":{
				"handler":["nxContactsParse","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-39",
			"name":"nxeventbuild",
			"display name":"nxEventBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventBuild(<pKind>,<pContent>,<pTags>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxEventBuild(<i>pKind</i>,<i>pContent</i>,<i>pTags</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned Nostr event.",
			"parameters":[{
				"name":"pKind",
				"type":"",
				"refparam":"false",
				"description":"The event kind, an integer from 0 to 65535."
			},{
				"name":"pContent",
				"type":"",
				"refparam":"false",
				"description":"The event content text."
			},{
				"name":"pTags",
				"type":"",
				"refparam":"false",
				"description":"A nested tag array, or empty for no tags."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put \"t\" into tTags[1][1]\nput \"openxtalk\" into tTags[1][2]\nput nxEventBuild(1, \"Hello, Nostr\", tTags, empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"The event array has keys \"kind\", \"created_at\", \"content\", \"tags\", and\n\"id\", \"pubkey\" and \"sig\", which stay empty until <nxEventSign> fills\nthem. Tags are 1-based both ways: tTags[1][1] is the first tag's name and\ntTags[1][2] its value. <nxTagsFromText> builds the array from text.\n\nThe kind and created-at must be plain digit runs (no leading zero, no\nexponent); the shape is checked by <nxEventHasValidShape>, and a refusal\nreturns empty with the reason recorded.",
			"references":{
				"handler":["nxEventSign","nxTagsFromText","nxEventHasValidShape"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-40",
			"name":"nxeventtojson",
			"display name":"nxEventToJson",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventToJson(<pEvent>)"
			],
			"display syntax":[
				"nxEventToJson(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Converts an event array to its wire-format JSON object.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			}],
			"examples":[{
				"script":"put nxEventToJson(tSigned) into field \"wireField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The JSON object text, or empty."
			}],
			"description":"Use it for storage or a transport of your own; <nxrPublish> and\n<nxClientEvent> call it for you. The id never depends on this form,\nonly on <nxEventSerialize>. Refuses an event that fails\n<nxEventHasValidShape>.",
			"references":{
				"handler":["nxEventFromJson","nxClientEvent"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-41",
			"name":"nxrelayinfoparse",
			"display name":"nxRelayInfoParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxRelayInfoParse(<pJsonBody>)"
			],
			"display syntax":[
				"nxRelayInfoParse(<i>pJsonBody</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Reads the common NIP-11 relay information fields.",
			"parameters":[{
				"name":"pJsonBody",
				"type":"",
				"refparam":"false",
				"description":"The relay information document the app fetched."
			}],
			"examples":[{
				"script":"put nxRelayInfoParse(tBody) into tInfo\nput tInfo[\"name\"] && tInfo[\"supportedNips\"] into field \"relayField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of the fields, or empty."
			}],
			"description":"The keys are \"name\", \"description\", \"pubkey\", \"contact\", \"software\",\n\"version\" and \"supportedNips\", a comma list. An absent field is empty. A\nbody that is not a JSON object refuses. The fetch is yours: this\nlibrary does no I/O.",
			"references":{
				"handler":["nxJsonGet"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-42",
			"name":"nxtagvalues",
			"display name":"nxTagValues",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagValues(<pEvent>,<pTagName>)"
			],
			"display syntax":[
				"nxTagValues(<i>pEvent</i>,<i>pTagName</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the values of every tag with a given name.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			},{
				"name":"pTagName",
				"type":"",
				"refparam":"false",
				"description":"The tag name, for example \"e\" or \"p\"."
			}],
			"examples":[{
				"script":"put nxTagValues(tEvent, \"p\") into field \"mentionsField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The values, one per line."
			}],
			"description":"Each matching tag contributes its second item. Names compare byte for\nbyte, so \"p\" and \"P\" are different tags.",
			"references":{
				"handler":["nxTagFirst","nxContactsParse"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-43",
			"name":"nxnaddrencode",
			"display name":"nxNaddrEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNaddrEncode(<pIdentifier>,<pPubkeyHex>,<pKind>,<pRelayLines>)"
			],
			"display syntax":[
				"nxNaddrEncode(<i>pIdentifier</i>,<i>pPubkeyHex</i>,<i>pKind</i>,<i>pRelayLines</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes the coordinate of an addressable event as an naddr.",
			"parameters":[{
				"name":"pIdentifier",
				"type":"",
				"refparam":"false",
				"description":"The event's \"d\" tag value, which may be empty."
			},{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The author's public key as 64 hex characters."
			},{
				"name":"pKind",
				"type":"",
				"refparam":"false",
				"description":"The event kind, an integer from 0 to 65535."
			},{
				"name":"pRelayLines",
				"type":"",
				"refparam":"false",
				"description":"Relay URLs that may have the event, one per line, or empty."
			}],
			"examples":[{
				"script":"put nxNaddrEncode(\"my-article\", tPubkey, 30023, empty) into tAddr"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The naddr1 string, or empty."
			}],
			"description":"The author and the kind are required. An identifier longer than 255\nbytes refuses rather than being dropped.",
			"references":{
				"handler":["nxNaddrDecode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-44",
			"name":"nxjsontype",
			"display name":"nxJsonType",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxJsonType(<pJson>,<pPath>)"
			],
			"display syntax":[
				"nxJsonType(<i>pJson</i>,<i>pPath</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the JSON type of the value at a path.",
			"parameters":[{
				"name":"pJson",
				"type":"",
				"refparam":"false",
				"description":"The JSON text."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The path to test, or empty for the root."
			}],
			"examples":[{
				"script":"if nxJsonType(tJson, \"names/alice\") is \"string\" then put nxJsonGet(tJson, \"names/alice\") into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"object\", \"array\", \"string\", \"number\", \"boolean\", \"null\", or \"missing\"."
			}],
			"description":"\"missing\" means the path does not resolve, which includes JSON that does\nnot parse; the parse error is recorded for <nxLastError>.",
			"references":{
				"handler":["nxJsonGet","nxJsonCount"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-45",
			"name":"nxneventencode",
			"display name":"nxNeventEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNeventEncode(<pIdHex>,<pRelayLines>,<pAuthorHex>,<pKind>)"
			],
			"display syntax":[
				"nxNeventEncode(<i>pIdHex</i>,<i>pRelayLines</i>,<i>pAuthorHex</i>,<i>pKind</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes an event pointer as an nevent.",
			"parameters":[{
				"name":"pIdHex",
				"type":"",
				"refparam":"false",
				"description":"The event id as 64 hex characters."
			},{
				"name":"pRelayLines",
				"type":"",
				"refparam":"false",
				"description":"Relay URLs that may have the event, one per line, or empty."
			},{
				"name":"pAuthorHex",
				"type":"",
				"refparam":"false",
				"description":"The author's public key as 64 hex characters, or empty."
			},{
				"name":"pKind",
				"type":"",
				"refparam":"false",
				"description":"The event kind, or empty."
			}],
			"examples":[{
				"script":"put nxNeventEncode(tSigned[\"id\"], \"wss://relay.example.com\", tSigned[\"pubkey\"], 1) into tPointer\nput nxUriEncode(tPointer) into tUri"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The nevent1 string, or empty."
			}],
			"description":"A NIP-19 TLV entity. The id is required; relays, author and kind are\noptional hints.",
			"references":{
				"handler":["nxNeventDecode","nxNoteEncode","nxUriEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-46",
			"name":"nxclientauth",
			"display name":"nxClientAuth",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxClientAuth(<pEvent>)"
			],
			"display syntax":[
				"nxClientAuth(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-42 AUTH message for a signed authentication event.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The signed kind 22242 event array."
			}],
			"examples":[{
				"script":"put nxClientAuth(tSignedAuth) into tWire"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The AUTH message text, or empty."
			}],
			"description":"Refuses anything but a signed kind 22242 event, as built by\n<nxAuthBuild> and signed by <nxEventSign>. <nxrAuth> builds and sends\nthe same message itself.",
			"references":{
				"handler":["nxAuthBuild","nxrAuth"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-47",
			"name":"nxmetadatabuild",
			"display name":"nxMetadataBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxMetadataBuild(<pName>,<pAbout>,<pPicture>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxMetadataBuild(<i>pName</i>,<i>pAbout</i>,<i>pPicture</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 0 user metadata event.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The display name."
			},{
				"name":"pAbout",
				"type":"",
				"refparam":"false",
				"description":"The profile description."
			},{
				"name":"pPicture",
				"type":"",
				"refparam":"false",
				"description":"The picture URL."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxMetadataBuild(\"alice\", \"I write xTalk\", \"https://example.com/a.png\", empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"The content is a JSON object with the \"name\", \"about\" and \"picture\"\nfields. Sign the result with <nxEventSign>.",
			"references":{
				"handler":["nxMetadataParse","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-48",
			"name":"nxjsoncount",
			"display name":"nxJsonCount",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxJsonCount(<pJson>,<pPath>)"
			],
			"display syntax":[
				"nxJsonCount(<i>pJson</i>,<i>pPath</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Counts the elements of a JSON array or the members of a JSON object.",
			"parameters":[{
				"name":"pJson",
				"type":"",
				"refparam":"false",
				"description":"The JSON text."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The path to the array or object, or empty for the root."
			}],
			"examples":[{
				"script":"put nxJsonCount(tInfoJson, \"supported_nips\") into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, or empty when the path does not resolve or names a scalar."
			}],
			"description":"An empty container returns 0. A scalar at the path returns empty and\nrecords the reason for <nxLastError>.",
			"references":{
				"handler":["nxJsonGet","nxJsonType"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-49",
			"name":"nxbech32encode",
			"display name":"nxBech32Encode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxBech32Encode(<pHrp>,<pHex>,<pSpec>)"
			],
			"display syntax":[
				"nxBech32Encode(<i>pHrp</i>,<i>pHex</i>,<i>pSpec</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes hex data as a bech32 or bech32m string.",
			"parameters":[{
				"name":"pHrp",
				"type":"",
				"refparam":"false",
				"description":"The human-readable prefix, in lowercase."
			},{
				"name":"pHex",
				"type":"",
				"refparam":"false",
				"description":"The data bytes as hex."
			},{
				"name":"pSpec",
				"type":"",
				"refparam":"false",
				"description":"\"bech32\" (or empty) or \"bech32m\"."
			}],
			"examples":[{
				"script":"put nxBech32Encode(\"npub\", tPubkey, \"bech32\") into tNpub"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The encoded string in lowercase, or empty."
			}],
			"description":"The generic encoder behind the NIP-19 handlers, which use bech32. An\nuppercase prefix refuses: uppercase the finished string instead. Results\nlonger than the NIP-19 cap of 5000 characters refuse; the 90-character\nlimit of BIP-173 does not apply.",
			"references":{
				"handler":["nxBech32Decode","nxNpubEncode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-50",
			"name":"nxrelaylistbuild",
			"display name":"nxRelayListBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxRelayListBuild(<pRelayLines>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxRelayListBuild(<i>pRelayLines</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 10002 relay list (NIP-65).",
			"parameters":[{
				"name":"pRelayLines",
				"type":"",
				"refparam":"false",
				"description":"One relay per line: a URL, or a URL, a tab and \"read\" or \"write\"."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put \"wss://relay.example.com\" & return & \"wss://inbox.example.com\" & tab & \"read\" into tLines\nput nxRelayListBuild(tLines, empty) into tEvent"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"Each line becomes an \"r\" tag. A URL with no marker means read and write.\nAt least one relay is required, and any marker other than \"read\" or\n\"write\" refuses.",
			"references":{
				"handler":["nxRelayListParse","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-51",
			"name":"nxdeletebuild",
			"display name":"nxDeleteBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxDeleteBuild(<pIdLines>,<pReason>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxDeleteBuild(<i>pIdLines</i>,<i>pReason</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 5 deletion request (NIP-09).",
			"parameters":[{
				"name":"pIdLines",
				"type":"",
				"refparam":"false",
				"description":"The ids of the events to delete, one 64-hex id per line."
			},{
				"name":"pReason",
				"type":"",
				"refparam":"false",
				"description":"The reason, or empty."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxDeleteBuild(tOldEvent[\"id\"], \"posted by mistake\", empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"Each id becomes an \"e\" tag and the reason becomes the content. At least\none id is required, and a line that is not a 64-hex id refuses. Relays\nmay honour a deletion request; they are not obliged to.",
			"references":{
				"handler":["nxEventSign","nxrPublish"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-52",
			"name":"nxnpubencode",
			"display name":"nxNpubEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNpubEncode(<pPubkeyHex>)"
			],
			"display syntax":[
				"nxNpubEncode(<i>pPubkeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Encodes a public key as an npub.",
			"parameters":[{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The public key as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNpubEncode(nxKeyPublic(tSeckey)) into field \"npubField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The npub1 string, or empty."
			}],
			"description":"The form to show users and share. The key must be 64 hex characters.",
			"references":{
				"handler":["nxNpubDecode","nxKeyPublic"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-53",
			"name":"nxnpubdecode",
			"display name":"nxNpubDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNpubDecode(<pText>)"
			],
			"display syntax":[
				"nxNpubDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes an npub to a hex public key.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The npub1 string."
			}],
			"examples":[{
				"script":"put nxNpubDecode(field \"npubField\") into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The public key as 64 hex characters, or empty."
			}],
			"description":"A string with another prefix, the bech32m spec or a payload that is not\n32 bytes refuses. Use <nxEntityDecode> when the input could be any\nentity.",
			"references":{
				"handler":["nxNpubEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-54",
			"name":"nxwsurlparse",
			"display name":"nxWsUrlParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxWsUrlParse(<pUrl>)"
			],
			"display syntax":[
				"nxWsUrlParse(<i>pUrl</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Splits a ws:// or wss:// URL into its parts.",
			"parameters":[{
				"name":"pUrl",
				"type":"",
				"refparam":"false",
				"description":"The websocket URL."
			}],
			"examples":[{
				"script":"put nxWsUrlParse(\"wss://relay.example.com/\") into tParts\nput tParts[\"host\"] into tHost"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"scheme\", \"secure\", \"host\", \"port\" and \"path\", or empty."
			}],
			"description":"A missing port defaults to 80 for ws and 443 for wss, and a missing path\nto /. Whitespace, another scheme, a missing host, a port outside 1 to\n65535 and IPv6 bracket addresses refuse.",
			"references":{
				"handler":["nxWsHandshakeRequest","nxrConnect"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-55",
			"name":"nxhexencode",
			"display name":"nxHexEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxHexEncode(<pData>)"
			],
			"display syntax":[
				"nxHexEncode(<i>pData</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Converts binary data to lowercase hex.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to convert."
			}],
			"examples":[{
				"script":"put nxHexEncode(textEncode(\"abc\", \"UTF-8\")) into tHex"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Two lowercase hex characters per byte."
			}],
			"description":"Hex is the currency of the NostrXT API: ids, keys and signatures cross\nit as lowercase hex strings, and binary stays inside the library.",
			"references":{
				"handler":["nxHexDecode","nxIsHex"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-56",
			"name":"nxclientclose",
			"display name":"nxClientClose",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxClientClose(<pSubId>)"
			],
			"display syntax":[
				"nxClientClose(<i>pSubId</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-01 CLOSE message.",
			"parameters":[{
				"name":"pSubId",
				"type":"",
				"refparam":"false",
				"description":"The subscription id, 1 to 64 characters."
			}],
			"examples":[{
				"script":"put nxClientClose(\"my-feed\") into tWire"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The CLOSE message text, or empty."
			}],
			"description":"<nxrUnsubscribe> builds and sends the same message itself.",
			"references":{
				"handler":["nxClientReq","nxrUnsubscribe"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-57",
			"name":"nxishex",
			"display name":"nxIsHex",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxIsHex(<pText>,<pLen>)"
			],
			"display syntax":[
				"nxIsHex(<i>pText</i>,<i>pLen</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether text is all hex digits, optionally of an exact length.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to test."
			},{
				"name":"pLen",
				"type":"",
				"refparam":"false",
				"description":"The required number of characters, or empty for any length."
			}],
			"examples":[{
				"script":"if not nxIsHex(tPubkey, 64) then answer \"a pubkey is 64 hex characters\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Use <nxIsHex> to validate an id or pubkey (64 characters) or a signature\n(128 characters). Either case is accepted. Empty text is never hex.",
			"references":{
				"handler":["nxHexDecode","nxCtEqualHex"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-58",
			"name":"nxtagstotext",
			"display name":"nxTagsToText",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagsToText(<pTags>)"
			],
			"display syntax":[
				"nxTagsToText(<i>pTags</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Converts a nested tag array to text, one tag per line.",
			"parameters":[{
				"name":"pTags",
				"type":"",
				"refparam":"false",
				"description":"The nested tag array."
			}],
			"examples":[{
				"script":"put nxTagsToText(tEvent[\"tags\"]) into field \"tagsField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"One tag per line, items separated by tabs, or empty."
			}],
			"description":"The inverse of <nxTagsFromText>. A tag item that contains a tab or a line\nbreak, or a tag that ends with an empty item, cannot survive the text\nform, so it refuses rather than corrupt the tag. Use the array form for\nsuch tags.",
			"references":{
				"handler":["nxTagsFromText","nxTagItem"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-59",
			"name":"nxentitydecode",
			"display name":"nxEntityDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEntityDecode(<pText>)"
			],
			"display syntax":[
				"nxEntityDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes any NIP-19 entity, with or without a nostr: prefix.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The entity, such as an npub, note, nprofile, nevent, naddr or nsec, optionally starting with nostr:."
			}],
			"examples":[{
				"script":"put nxEntityDecode(field \"pasteField\") into tFields\nif tFields[\"type\"] is \"npub\" then put tFields[\"pubkey\"] into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array keyed by \"type\" plus that entity's fields, or empty."
			}],
			"description":"Use it for a paste box that accepts anything. The fields by type: npub\ngives \"pubkey\", nsec \"seckey\", note \"id\"; nprofile gives \"pubkey\" and\n\"relays\"; nevent \"id\", \"relays\", \"pubkey\" and \"kind\"; naddr\n\"identifier\", \"pubkey\", \"kind\" and \"relays\".\n\nUnknown TLV entries are ignored, as NIP-19 requires. A bech32m string, a\ntruncated TLV or a missing required field refuses. An nsec decodes here,\nso handle a pasted secret key deliberately.",
			"references":{
				"handler":["nxUriDecode","nxBech32Decode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-60",
			"name":"nxtagcount",
			"display name":"nxTagCount",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagCount(<pEvent>)"
			],
			"display syntax":[
				"nxTagCount(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns how many tags an event carries.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			}],
			"examples":[{
				"script":"put nxTagCount(tEvent) into tCount\nput nxTagItem(tEvent, tCount) into tLastTag"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of tags."
			}],
			"description":"Counts the 1-based tags of the event's \"tags\" array.",
			"references":{
				"handler":["nxTagItem","nxTagValues"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-61",
			"name":"nxtagfirst",
			"display name":"nxTagFirst",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagFirst(<pEvent>,<pTagName>)"
			],
			"display syntax":[
				"nxTagFirst(<i>pEvent</i>,<i>pTagName</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the value of the first tag with a given name.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			},{
				"name":"pTagName",
				"type":"",
				"refparam":"false",
				"description":"The tag name, for example \"e\" or \"p\"."
			}],
			"examples":[{
				"script":"put nxTagFirst(tEvent, \"d\") into tIdentifier"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The tag's second item, or empty."
			}],
			"description":"Tag names compare byte for byte: \"p\" and \"P\" are different tags. Returns\nempty when no tag has the name or the first one has no value.",
			"references":{
				"handler":["nxTagValues","nxTagItem"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-62",
			"name":"nxjsonget",
			"display name":"nxJsonGet",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxJsonGet(<pJson>,<pPath>)"
			],
			"display syntax":[
				"nxJsonGet(<i>pJson</i>,<i>pPath</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the value at a path in a JSON document.",
			"parameters":[{
				"name":"pJson",
				"type":"",
				"refparam":"false",
				"description":"The JSON text."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"A path of object keys and 1-based array indexes separated by /, or empty for the root."
			}],
			"examples":[{
				"script":"put nxJsonGet(tJson, \"tags/1/2\") into tValue\nput nxJsonGet(tInfoJson, \"name\") into tName"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value, or empty when the path does not resolve."
			}],
			"description":"Strings come back decoded, numbers as their source text, booleans as\n\"true\" or \"false\", and null as empty. An object or array at the path\ncomes back as its exact source text, so you can pass a sub-document on.\n\nBecause empty can mean null, an empty string or a miss, use <nxJsonType>\nwhen the difference matters. The parser is strict (exact bare words, no\ntrailing bytes, a nesting limit, duplicate keys refused). A key that\ncontains / cannot be reached through a path.",
			"references":{
				"handler":["nxJsonType","nxJsonCount"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-63",
			"name":"nxuridecode",
			"display name":"nxUriDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxUriDecode(<pUri>)"
			],
			"display syntax":[
				"nxUriDecode(<i>pUri</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes a NIP-21 nostr: URI.",
			"parameters":[{
				"name":"pUri",
				"type":"",
				"refparam":"false",
				"description":"The URI, starting with nostr:."
			}],
			"examples":[{
				"script":"put nxUriDecode(\"nostr:\" & tNpub) into tFields"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The entity fields, as from nxEntityDecode, or empty."
			}],
			"description":"Text without the nostr: prefix refuses, and so does a URI carrying an\nnsec.",
			"references":{
				"handler":["nxUriEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-64",
			"name":"nxwsframeencode",
			"display name":"nxWsFrameEncode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxWsFrameEncode(<pOpcode>,<pPayload>,<pMaskHex>)"
			],
			"display syntax":[
				"nxWsFrameEncode(<i>pOpcode</i>,<i>pPayload</i>,<i>pMaskHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds one masked client websocket frame.",
			"parameters":[{
				"name":"pOpcode",
				"type":"",
				"refparam":"false",
				"description":"The frame opcode, 0 to 15 (1 for text, 8 close, 9 ping, 10 pong)."
			},{
				"name":"pPayload",
				"type":"",
				"refparam":"false",
				"description":"The payload bytes."
			},{
				"name":"pMaskHex",
				"type":"",
				"refparam":"false",
				"description":"The 4-byte mask as 8 hex characters."
			}],
			"examples":[{
				"script":"put nxWsFrameEncode(1, textEncode(tText, \"UTF-8\"), \"1a2b3c4d\") into tFrame"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The frame bytes, or empty."
			}],
			"description":"FIN is set, the payload is masked as RFC 6455 requires of a client, and\nnothing is fragmented. A control frame (opcode 8 and up) carries at most\n125 bytes, and any payload is capped at 8 MB. Draw a fresh random mask\nfor every frame; a fixed mask is for test vectors.",
			"references":{
				"handler":["nxWsFrameDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-65",
			"name":"nxtagsfromtext",
			"display name":"nxTagsFromText",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagsFromText(<pText>)"
			],
			"display syntax":[
				"nxTagsFromText(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a nested tag array from text, one tag per line.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"One tag per line, items separated by tabs."
			}],
			"examples":[{
				"script":"put \"t\" & tab & \"openxtalk\" & return & \"p\" & tab & tPubkey into tText\nput nxTagsFromText(tText) into tTags\nput nxEventBuild(1, \"Hello\", tTags, empty) into tEvent"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The nested tag array, or empty."
			}],
			"description":"Empty lines are skipped. A line whose first item is empty refuses,\nbecause a tag must have a name.",
			"references":{
				"handler":["nxTagsToText","nxEventBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-66",
			"name":"nxeventserialize",
			"display name":"nxEventSerialize",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventSerialize(<pEvent>)"
			],
			"display syntax":[
				"nxEventSerialize(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns the canonical NIP-01 serialization of an event.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array, with its pubkey filled in."
			}],
			"examples":[{
				"script":"put nxEventSerialize(tSigned) into tPreimage"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The canonical JSON array text, or empty."
			}],
			"description":"This is the exact text NIP-01 hashes to make the event id:\n[0,pubkey,created_at,kind,tags,content], with no whitespace and the\nNIP-01 escapes. It refuses an event whose pubkey is not 64 lowercase hex\ncharacters, because a half-built event would serialize to a well-formed\nbut wrong preimage.\n\nMost apps never call this directly: <nxEventId> and <nxEventSign> use it.",
			"references":{
				"handler":["nxEventId","nxEventToJson"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-67",
			"name":"nxnprofiledecode",
			"display name":"nxNprofileDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNprofileDecode(<pText>)"
			],
			"display syntax":[
				"nxNprofileDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes an nprofile.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The nprofile1 string."
			}],
			"examples":[{
				"script":"put nxNprofileDecode(tText) into tFields\nput tFields[\"pubkey\"] into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"type\", \"pubkey\" and \"relays\", or empty."
			}],
			"description":"\"relays\" holds the relay hints, one per line. Another entity type\nrefuses. Unknown TLV entries are ignored, as NIP-19 requires; a\ntruncated one refuses.",
			"references":{
				"handler":["nxNprofileEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-68",
			"name":"nxneventdecode",
			"display name":"nxNeventDecode",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNeventDecode(<pText>)"
			],
			"display syntax":[
				"nxNeventDecode(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Decodes an nevent.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The nevent1 string."
			}],
			"examples":[{
				"script":"put nxNeventDecode(tText) into tFields\nput tFields[\"id\"] into tId"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with keys \"type\", \"id\", \"relays\", \"pubkey\" and \"kind\", or empty."
			}],
			"description":"Optional fields that the entity does not carry are empty. Another\nentity type refuses.",
			"references":{
				"handler":["nxNeventEncode","nxEntityDecode"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-69",
			"name":"nxfilterbuild",
			"display name":"nxFilterBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxFilterBuild(<pFilter>)"
			],
			"display syntax":[
				"nxFilterBuild(<i>pFilter</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds a NIP-01 filter object from an array.",
			"parameters":[{
				"name":"pFilter",
				"type":"",
				"refparam":"false",
				"description":"An array of filter fields (see the description)."
			}],
			"examples":[{
				"script":"put tAuthorPubkey into tFilter[\"authors\"]\nput \"1,7\" into tFilter[\"kinds\"]\nput 50 into tFilter[\"limit\"]\nput nxFilterBuild(tFilter) into tFilterJson\nnxrSubscribe tRelay, \"my-feed\", tFilterJson"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The filter as one line of JSON, or empty."
			}],
			"description":"The keys: \"ids\" and \"authors\" (64-hex values, one per line), \"kinds\"\n(a comma list of kind numbers), \"since\", \"until\" and \"limit\" (non-negative\nintegers), \"search\" (text), and any single-letter tag filter keyed \"#e\",\n\"#p\" and so on (values one per line). Absent or empty keys are left out.\n\nFields come out in a fixed order, so the same array always gives the\nsame text. An invalid value refuses with the reason recorded.",
			"references":{
				"handler":["nxClientReq","nxrSubscribe","nxFilterMatches"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-70",
			"name":"nxreactionbuild",
			"display name":"nxReactionBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxReactionBuild(<pTargetEvent>,<pContent>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxReactionBuild(<i>pTargetEvent</i>,<i>pContent</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 7 reaction (NIP-25).",
			"parameters":[{
				"name":"pTargetEvent",
				"type":"",
				"refparam":"false",
				"description":"The event being reacted to, with its id and pubkey."
			},{
				"name":"pContent",
				"type":"",
				"refparam":"false",
				"description":"The reaction, or empty for \"+\"."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxReactionBuild(tTarget, empty, empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"The reaction carries \"e\" and \"p\" tags for the target and its author, and\na \"k\" tag with the target's kind.",
			"references":{
				"handler":["nxReplyBuild","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-71",
			"name":"nxnip05verify",
			"display name":"nxNip05Verify",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip05Verify(<pJsonBody>,<pUserName>,<pPubkeyHex>)"
			],
			"display syntax":[
				"nxNip05Verify(<i>pJsonBody</i>,<i>pUserName</i>,<i>pPubkeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether a fetched nostr.json maps a name to a public key.",
			"parameters":[{
				"name":"pJsonBody",
				"type":"",
				"refparam":"false",
				"description":"The nostr.json document the app fetched."
			},{
				"name":"pUserName",
				"type":"",
				"refparam":"false",
				"description":"The name part of the identifier."
			},{
				"name":"pPubkeyHex",
				"type":"",
				"refparam":"false",
				"description":"The expected public key as 64 hex characters."
			}],
			"examples":[{
				"script":"put nxNip05Verify(tBody, \"alice\", tPubkey) into tVerified"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"The hex comparison ignores case. A name containing / cannot be looked up\nand refuses, as does a pubkey that is not 64 hex characters.",
			"references":{
				"handler":["nxNip05Url"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-72",
			"name":"nxjsonescape",
			"display name":"nxJsonEscape",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxJsonEscape(<pText>)"
			],
			"display syntax":[
				"nxJsonEscape(<i>pText</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Escapes text for a JSON string the way NIP-01 requires.",
			"parameters":[{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to escape."
			}],
			"examples":[{
				"script":"put quote & nxJsonEscape(tContent) & quote into tJsonString"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The escaped text, without surrounding quotes."
			}],
			"description":"NIP-01 uses exactly seven escapes: quote, backslash, line feed, carriage\nreturn, tab, backspace and form feed. Every other byte, other control\nbytes included, passes through unchanged. A general JSON encoder escapes\nmore than that, which is why it produces wrong event ids.\n\nThe text is handled as UTF-8, so multi-byte characters pass through\nuntouched.",
			"references":{
				"handler":["nxEventSerialize","nxJsonGet"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-73",
			"name":"nxkeyisvalid",
			"display name":"nxKeyIsValid",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxKeyIsValid(<pSeckeyHex>)"
			],
			"display syntax":[
				"nxKeyIsValid(<i>pSeckeyHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether hex text is a valid secp256k1 secret key.",
			"parameters":[{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"The secret key as 64 hex characters."
			}],
			"examples":[{
				"script":"if not nxKeyIsValid(tSeckey) then answer \"that is not a usable secret key\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Needs CoinXT (cxSeckeyIsValid). Text that is not 64 hex characters\nreturns false. Without CoinXT it returns false and records why.",
			"references":{
				"handler":["nxKeyGenerate","nxKeyPublic"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-74",
			"name":"nxeventfromjson",
			"display name":"nxEventFromJson",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventFromJson(<pJson>)"
			],
			"display syntax":[
				"nxEventFromJson(<i>pJson</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Parses a wire-format event object into an event array.",
			"parameters":[{
				"name":"pJson",
				"type":"",
				"refparam":"false",
				"description":"The event JSON object text."
			}],
			"examples":[{
				"script":"put nxEventFromJson(tJson) into tEvent\nif tEvent is empty then answer \"unparseable:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The event array, or empty."
			}],
			"description":"<nxEventFromJson> checks structure only. Call <nxEventVerify> before\ntrusting the result.\n\nIt is strict: hex fields must be lowercase and the right length,\ncreated_at and kind must be plain digit runs, every tag must be a\nnon-empty array of strings, and duplicate keys are refused.",
			"references":{
				"handler":["nxEventVerify","nxEventToJson","nxRelayParse"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-75",
			"name":"nxmetadataparse",
			"display name":"nxMetadataParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxMetadataParse(<pEvent>)"
			],
			"display syntax":[
				"nxMetadataParse(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Reads the common profile fields from a kind 0 event.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"A kind 0 event array."
			}],
			"examples":[{
				"script":"put nxMetadataParse(tEvent) into tProfile\nput tProfile[\"name\"] into field \"nameField\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of the profile fields, or empty for another kind."
			}],
			"description":"The keys are \"name\", \"about\", \"picture\", \"display_name\", \"nip05\",\n\"website\", \"banner\" and \"lud16\". A field that is absent, or is not a\nstring, is empty.",
			"references":{
				"handler":["nxMetadataBuild"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-76",
			"name":"nxwshandshakerequest",
			"display name":"nxWsHandshakeRequest",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxWsHandshakeRequest(<pHost>,<pPort>,<pPath>,<pKeyB64>,<pSecure>)"
			],
			"display syntax":[
				"nxWsHandshakeRequest(<i>pHost</i>,<i>pPort</i>,<i>pPath</i>,<i>pKeyB64</i>,<i>pSecure</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds the HTTP upgrade request that opens a websocket.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"The host name."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"The port number."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The request path, such as /."
			},{
				"name":"pKeyB64",
				"type":"",
				"refparam":"false",
				"description":"The Sec-WebSocket-Key, base64."
			},{
				"name":"pSecure",
				"type":"",
				"refparam":"false",
				"description":"true for wss, false for ws."
			}],
			"examples":[{
				"script":"put nxWsHandshakeRequest(\"relay.example.com\", 443, \"/\", tKeyB64, true) into tRequest"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The request text with CRLF line endings, or empty."
			}],
			"description":"The Host header leaves out the port only when it is the default for the\nscheme (80 for ws, 443 for wss), which is why the secure flag is an\nargument. Host, path and key are required. Only needed for a transport\nof your own; the relay client calls it for you.",
			"references":{
				"handler":["nxWsAcceptFor","nxWsUrlParse"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-77",
			"name":"nxauthbuild",
			"display name":"nxAuthBuild",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxAuthBuild(<pRelayUrl>,<pChallenge>,<pCreatedAt>)"
			],
			"display syntax":[
				"nxAuthBuild(<i>pRelayUrl</i>,<i>pChallenge</i>,<i>pCreatedAt</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Builds an unsigned kind 22242 NIP-42 authentication event.",
			"parameters":[{
				"name":"pRelayUrl",
				"type":"",
				"refparam":"false",
				"description":"The URL of the relay that sent the challenge."
			},{
				"name":"pChallenge",
				"type":"",
				"refparam":"false",
				"description":"The challenge text the relay sent."
			},{
				"name":"pCreatedAt",
				"type":"",
				"refparam":"false",
				"description":"The unix time in seconds, or empty for now."
			}],
			"examples":[{
				"script":"put nxAuthBuild(nxrUrl(tRelay), nxrChallenge(tRelay), empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned\nnxrAuth tRelay, tSigned"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The unsigned event array, or empty."
			}],
			"description":"The event carries \"relay\" and \"challenge\" tags. Both arguments are\nrequired. Sign it with <nxEventSign>, then send it with <nxrAuth> or\nwrap it yourself with <nxClientAuth>.",
			"references":{
				"handler":["nxrAuth","nxClientAuth","nxrChallenge"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-78",
			"name":"nxeventid",
			"display name":"nxEventId",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventId(<pEvent>)"
			],
			"display syntax":[
				"nxEventId(<i>pEvent</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Computes the NIP-01 id of an event.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array, with its pubkey filled in."
			}],
			"examples":[{
				"script":"put nxEventId(tEvent) into tId"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 64-hex SHA-256 of the canonical serialization, or empty."
			}],
			"description":"Needs CoinXT (cxSha256). The id is the hash of the UTF-8 bytes of\n<nxEventSerialize>, so it never depends on the wire form <nxEventToJson>\nemits.",
			"references":{
				"handler":["nxEventSerialize","nxEventSign"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-79",
			"name":"nxrelayparse",
			"display name":"nxRelayParse",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxRelayParse(<pWire>)"
			],
			"display syntax":[
				"nxRelayParse(<i>pWire</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Parses one relay-to-client message.",
			"parameters":[{
				"name":"pWire",
				"type":"",
				"refparam":"false",
				"description":"The message text, a JSON array."
			}],
			"examples":[{
				"script":"put nxRelayParse(tWire) into tMsg\nif tMsg[\"type\"] is \"EVENT\" then put nxEventFromJson(tMsg[\"eventJson\"]) into tEvent"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array keyed by \"type\" plus that message's fields, or empty."
			}],
			"description":"Types and fields: EVENT (\"subId\", \"eventJson\", the event object's exact\ntext), OK (\"eventId\", \"accepted\", \"reason\"), EOSE (\"subId\"), CLOSED\n(\"subId\", \"reason\"), NOTICE (\"notice\") and AUTH (\"challenge\"). Any other\ntype gives \"unknown\" with the text in \"raw\".\n\nMessage types compare byte for byte, so \"event\" is not \"EVENT\". An\nEVENT is not verified here: parse it with <nxEventFromJson> and check it\nwith <nxEventVerify>.",
			"references":{
				"handler":["nxEventFromJson","nxEventVerify"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-80",
			"name":"nxnip44hascipher",
			"display name":"nxNip44HasCipher",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxNip44HasCipher()"
			],
			"display syntax":[
				"nxNip44HasCipher()"
			],
			"associations":["nostrxt"],
			"summary":"Tells whether the NIP-44 cipher is available right now.",
			"examples":[{
				"script":"if not nxNip44HasCipher() then answer \"Encrypted messages need SodiumXT ABI 10 or later\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"A live probe of SodiumXT's sxChaCha20IetfXor, which shipped in SodiumXT\nABI 10. Unlike the cached \"canNip44Cipher\" of <nxProbeCapabilities>, it\nnotices an upgrade without a restart.",
			"references":{
				"handler":["nxProbeCapabilities","nxNip44Encrypt"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-81",
			"name":"nxtagitem",
			"display name":"nxTagItem",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxTagItem(<pEvent>,<pIndex>)"
			],
			"display syntax":[
				"nxTagItem(<i>pEvent</i>,<i>pIndex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Returns one tag of an event as tab-separated text.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The event array."
			},{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based tag number."
			}],
			"examples":[{
				"script":"put nxTagItem(tEvent, 1) into tFirstTag"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The tag's items joined by tabs, or empty when there is no such tag."
			}],
			"description":"An index out of range returns empty and records the reason.",
			"references":{
				"handler":["nxTagCount","nxTagFirst"]
			},
			"tags":["networking","nostr"]
		},{
			"id":"nostrxt-82",
			"name":"nxeventsign",
			"display name":"nxEventSign",
			"library":"nostrxt",
			"type":"function",
			"syntax":[
				"nxEventSign(<pEvent>,<pSeckeyHex>,<pAuxHex>)"
			],
			"display syntax":[
				"nxEventSign(<i>pEvent</i>,<i>pSeckeyHex</i>,<i>pAuxHex</i>)"
			],
			"associations":["nostrxt"],
			"summary":"Signs an event, filling in its pubkey, id and signature.",
			"parameters":[{
				"name":"pEvent",
				"type":"",
				"refparam":"false",
				"description":"The unsigned event array."
			},{
				"name":"pSeckeyHex",
				"type":"",
				"refparam":"false",
				"description":"The secret key as 64 hex characters."
			},{
				"name":"pAuxHex",
				"type":"",
				"refparam":"false",
				"description":"Empty for fresh signing randomness, or 64 hex characters for a deterministic signature."
			}],
			"examples":[{
				"script":"put nxEventBuild(1, \"Hello\", empty, empty) into tEvent\nput nxEventSign(tEvent, tSeckey, empty) into tSigned\nif tSigned is empty then answer \"signing failed:\" && nxLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The completed event array, or empty."
			}],
			"description":"Needs CoinXT. <nxEventSign> derives the pubkey, computes the id and makes\na BIP-340 Schnorr signature over it. Pass empty for pAuxHex in an app; a\nfixed value makes the signature repeatable, which is for test vectors.",
			"references":{
				"handler":["nxEventBuild","nxEventVerify","nxrPublish"]
			},
			"tags":["networking","nostr"]
		}