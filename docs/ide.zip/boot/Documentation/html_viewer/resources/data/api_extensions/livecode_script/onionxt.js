{
			"id":"onionxt-1",
			"name":"onionxt",
			"display name":"OnionXT",
			"library":"onionxt",
			"type":"library",
			"display syntax":[
				"OnionXT"
			],
			"associations":["onionxt"],
			"description":"A Tor transport and rendezvous layer for OpenXTalk. OnionXT dials any TCP\nendpoint through Tor's SOCKS5 proxy and creates and reaches v3 onion\nservices, whose address is an ed25519 public key. It talks to a tor daemon\nthat is already running on this machine (SOCKS 127.0.0.1:9050, control\n127.0.0.1:9051 by default); it does not embed or ship Tor.\n\nEverything is asynchronous. Commands that open something (<oxDial>,\n<oxCreateService>) report a handle in the result at once, and the outcome\narrives later through the callbacks you register: a status callback, a\nper-stream callback and a peer callback. Commands report empty or a\nhandle on success and an \"OnionXT: ...\" string on failure; every wire\nerror fails closed and tears the resource down.\n\nOnionXT adds no cryptography. The payload is yours to seal (with SodiumXT),\nand the deterministic-address, SAFECOOKIE and offline-checksum features\ncompose SodiumXT handlers (ABI 6 or later; ABI 7 for the checksum). Free\nwhat you open with <oxShutdown>, for example on closeStack."
		},{
			"id":"onionxt-2",
			"name":"oxbootstrapprogress",
			"display name":"oxBootstrapProgress",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxBootstrapProgress()"
			],
			"display syntax":[
				"oxBootstrapProgress()"
			],
			"associations":["onionxt"],
			"summary":"Return tor's bootstrap progress.",
			"examples":[{
				"script":"put oxBootstrapProgress() & \"%\" into field \"Progress\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A number from 0 to 100; 0 until tor has reported any progress."
			}],
			"description":"The value comes from tor's bootstrap status over the control connection, so\nit stays 0 until <oxConnectControl> has authenticated. A cold tor can take\ntens of seconds to reach 100.",
			"references":{
				"handler":["oxIsReady","oxSetStatusCallback"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-3",
			"name":"oxdisconnectcontrol",
			"display name":"oxDisconnectControl",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxDisconnectControl"
			],
			"display syntax":[
				"oxDisconnectControl"
			],
			"associations":["onionxt"],
			"summary":"Close the control connection.",
			"examples":[{
				"script":"oxDisconnectControl"
			}],
			"description":"Closes the control socket and resets the control state. It is safe to call\nwhen nothing is open. Services created with Flags=Detach stay published;\nremove them with <oxRemoveService> first if they should go.",
			"references":{
				"handler":["oxConnectControl","oxShutdown"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-4",
			"name":"oxsocketerror",
			"display name":"oxSocketError",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxSocketError(<pSocketID>,<pError>)"
			],
			"display syntax":[
				"oxSocketError(<i>pSocketID</i>,<i>pError</i>)"
			],
			"associations":["onionxt"],
			"summary":"Handle a socketError message if the socket belongs to OnionXT.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"the socket id from the engine's socketError message."
			},{
				"name":"pError",
				"type":"",
				"refparam":"false",
				"description":"the error text from that message."
			}],
			"examples":[{
				"script":"if oxSocketError(pSocketID, pError) then exit socketError"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" if the socket was OnionXT's and the error was handled, \"false\" otherwise."
			}],
			"description":"For apps that embed OnionXT's script into their own: call it from your own\nsocketError handler where you would otherwise pass the message. For an\nOnionXT stream it fails the stream with an \"error\" event; for the control\nsocket it reports the error and disconnects.\n\nWhen OnionXT is loaded as a library instead, it handles the message itself,\nand your own socketError handler must pass any socket that is not yours,\nor OnionXT never sees it and the app hangs.",
			"references":{
				"handler":["oxSocketClosed","oxSocketTimeout"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-5",
			"name":"oxremoveservice",
			"display name":"oxRemoveService",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxRemoveService <pService>"
			],
			"display syntax":[
				"oxRemoveService <i>pService</i>"
			],
			"associations":["onionxt"],
			"summary":"Unpublish an onion service and stop its listener.",
			"parameters":[{
				"name":"pService",
				"type":"",
				"refparam":"false",
				"description":"a service handle."
			}],
			"examples":[{
				"script":"oxRemoveService tService"
			}],
			"description":"Asks tor to remove the service (when the control connection is\nauthenticated) and closes the local listener if OnionXT owns it. Safe to\ncall more than once; a stale handle is a no-op.",
			"references":{
				"handler":["oxCreateService","oxPublishService","oxShutdown"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-6",
			"name":"oxtransportinfo",
			"display name":"oxTransportInfo",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxTransportInfo()"
			],
			"display syntax":[
				"oxTransportInfo()"
			],
			"associations":["onionxt"],
			"summary":"Describe the OnionXT transport and which optional features are available.",
			"examples":[{
				"script":"put oxTransportInfo() into tInfo\nif not tInfo[\"deterministicOnion\"] then answer \"Stable addresses need SodiumXT.\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the keys transport (\"ox\"), version, safeCookieAuth, deterministicOnion and offlineAddress."
			}],
			"description":"The three flags are true when the SodiumXT handlers that feature needs are\nloaded, so a protocol layer can choose a transport and fall back visibly.",
			"references":{
				"handler":["oxTransportDial","oxTransportListen"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-7",
			"name":"oxsockettimeout",
			"display name":"oxSocketTimeout",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxSocketTimeout(<pSocketID>)"
			],
			"display syntax":[
				"oxSocketTimeout(<i>pSocketID</i>)"
			],
			"associations":["onionxt"],
			"summary":"Handle a socketTimeout message if the socket belongs to OnionXT.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"the socket id from the engine's socketTimeout message."
			}],
			"examples":[{
				"script":"if oxSocketTimeout(pSocketID) then exit socketTimeout"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" if the socket was OnionXT's, \"false\" otherwise."
			}],
			"description":"For apps that embed OnionXT's script into their own: call it from your own\nsocketTimeout handler where you would otherwise pass the message. The\nengine repeats socketTimeout while a read is pending, so OnionXT treats it\nas fatal only during a handshake; an idle connected stream ignores it but\nstill answers \"true\".",
			"references":{
				"handler":["oxSocketError","oxSocketClosed"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-8",
			"name":"oxisvalidaddress",
			"display name":"oxIsValidAddress",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxIsValidAddress(<pOnionAddress>)"
			],
			"display syntax":[
				"oxIsValidAddress(<i>pOnionAddress</i>)"
			],
			"associations":["onionxt"],
			"summary":"Check that text is a well-formed v3 .onion address.",
			"parameters":[{
				"name":"pOnionAddress",
				"type":"",
				"refparam":"false",
				"description":"the address to check, with or without \".onion\"."
			}],
			"examples":[{
				"script":"if not oxIsValidAddress(field \"Address\") then answer \"That is not a v3 onion address.\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Always checks the length, alphabet and version. It also verifies the\nchecksum when SodiumXT's SHA3-256 is available; without it a structurally\nvalid address passes. Tor still authenticates the service when you connect.",
			"references":{
				"handler":["oxPublicKeyFromAddress","oxAddressFromPublicKey"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-9",
			"name":"oxstoptor",
			"display name":"oxStopTor",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxStopTor"
			],
			"display syntax":[
				"oxStopTor"
			],
			"associations":["onionxt"],
			"summary":"Ask tor to shut down, then disconnect the control connection.",
			"examples":[{
				"script":"oxStopTor"
			}],
			"description":"Sends tor a shutdown signal when the control connection is authenticated,\nthen disconnects. Without an authenticated connection it only disconnects.\nSafe to call more than once. Not yet run on an engine.",
			"references":{
				"handler":["oxLaunchTor","oxDisconnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-10",
			"name":"oxtransportlisten",
			"display name":"oxTransportListen",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxTransportListen <pSeed>,<pVirtualPort>,<pLocalPort>"
			],
			"display syntax":[
				"oxTransportListen <i>pSeed</i>,<i>pVirtualPort</i>,<i>pLocalPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Listen at a seed-derived address through the transport seam.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"32 bytes of secret binary data that fix the address."
			},{
				"name":"pVirtualPort",
				"type":"",
				"refparam":"false",
				"description":"the port visitors connect to on the .onion address."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"the loopback port OnionXT listens on."
			}],
			"examples":[{
				"script":"oxTransportListen tSeed, 80, 8080"
			}],
			"description":"A wrapper for <oxCreateServiceFromSeed>; the result is the same.",
			"references":{
				"handler":["oxCreateServiceFromSeed","oxTransportDial"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-11",
			"name":"oxtransportdial",
			"display name":"oxTransportDial",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxTransportDial <pAddress>,<pPort>"
			],
			"display syntax":[
				"oxTransportDial <i>pAddress</i>,<i>pPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Dial a rendezvous address through the transport seam.",
			"parameters":[{
				"name":"pAddress",
				"type":"",
				"refparam":"false",
				"description":"a .onion address, a 32-byte ed25519 public key, or that key as 64 hex characters."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"the port to connect to; empty means 80."
			}],
			"examples":[{
				"script":"oxTransportDial tPeerKey, 80\nput the result into tStream"
			}],
			"description":"A key is turned into its .onion address first (which needs SodiumXT's\nSHA3-256), then this works exactly like <oxDial> and reports the same way.",
			"references":{
				"handler":["oxDial","oxTransportSend","oxTransportRecv"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-12",
			"name":"oxsetstatuscallback",
			"display name":"oxSetStatusCallback",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetStatusCallback <pHandlerName>"
			],
			"display syntax":[
				"oxSetStatusCallback <i>pHandlerName</i>"
			],
			"associations":["onionxt"],
			"summary":"Register the handler that receives OnionXT status updates.",
			"parameters":[{
				"name":"pHandlerName",
				"type":"",
				"refparam":"false",
				"description":"the name of a handler in the callback owner's script, called with a kind and an info value."
			}],
			"examples":[{
				"script":"oxSetStatusCallback \"onTorStatus\""
			}],
			"description":"The handler receives two parameters, a kind and an info value. The kinds\nare \"control\" (connected, authenticated, disconnected, or an \"authfailed:\"\nor \"error:\" reason), \"bootstrap\" (0 to 100), \"ready\", \"service\" (a new\naddress), \"serviceReady\" (its descriptor is uploaded), \"notice\" and\n\"event\" (a raw 650 line). Bootstrap updates are coalesced to about four\nper second.",
			"references":{
				"handler":["oxSetCallbackOwner","oxConnectControl","oxBootstrapProgress"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-13",
			"name":"oxshutdown",
			"display name":"oxShutdown",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxShutdown"
			],
			"display syntax":[
				"oxShutdown"
			],
			"associations":["onionxt"],
			"summary":"Close every stream, remove every service and disconnect control.",
			"examples":[{
				"script":"oxShutdown"
			}],
			"description":"Call it when your app closes, for example in closeStack: OpenXTalk has no\nunload hook, so OnionXT cannot free its sockets and services on its own.\nSafe to call more than once.",
			"references":{
				"handler":["oxCloseStream","oxRemoveService","oxDisconnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-14",
			"name":"oxwrite",
			"display name":"oxWrite",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxWrite <pStream>,<pData>"
			],
			"display syntax":[
				"oxWrite <i>pStream</i>,<i>pData</i>"
			],
			"associations":["onionxt"],
			"summary":"Write bytes to an open stream.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle whose state is connected."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"the binary data to send, already encrypted by your app if it needs to be."
			}],
			"examples":[{
				"script":"oxWrite tStream, textEncode(\"hello\", \"UTF-8\")\nif the result is not empty then answer the result"
			}],
			"description":"OnionXT does not encrypt or frame what you send. The result is empty on\nsuccess, or an \"OnionXT: ...\" error when the stream is not open or the\nengine reports that the write failed.",
			"references":{
				"handler":["oxDial","oxStreamState","oxTransportSend"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-15",
			"name":"oxaddressfrompublickey",
			"display name":"oxAddressFromPublicKey",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxAddressFromPublicKey(<pEd25519Pub>)"
			],
			"display syntax":[
				"oxAddressFromPublicKey(<i>pEd25519Pub</i>)"
			],
			"associations":["onionxt"],
			"summary":"Return the v3 .onion address for an ed25519 public key.",
			"parameters":[{
				"name":"pEd25519Pub",
				"type":"",
				"refparam":"false",
				"description":"a 32-byte ed25519 public key."
			}],
			"examples":[{
				"script":"put oxAddressFromPublicKey(tPubKey) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The address ending in .onion, or an \"OnionXT: ...\" error string."
			}],
			"description":"The checksum uses SodiumXT's SHA3-256 (ABI 7 or later). Without it, or for\na key that is not 32 bytes, the result is an \"OnionXT: ...\" error rather\nthan a wrong address.",
			"references":{
				"handler":["oxPublicKeyFromAddress","oxIsValidAddress"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-16",
			"name":"oxcreateservice",
			"display name":"oxCreateService",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxCreateService <pVirtualPort>,<pLocalPort>"
			],
			"display syntax":[
				"oxCreateService <i>pVirtualPort</i>,<i>pLocalPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Publish a new onion service with a key that tor generates.",
			"parameters":[{
				"name":"pVirtualPort",
				"type":"",
				"refparam":"false",
				"description":"the port visitors connect to on the .onion address, 1 to 65535."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"the loopback port OnionXT listens on and tor forwards to, 1 to 65535."
			}],
			"examples":[{
				"script":"oxCreateService 80, 8080\nput the result into tService"
			}],
			"description":"Needs an authenticated control connection. OnionXT starts listening on\n127.0.0.1 at pLocalPort first, then asks tor to publish the service. The\nresult is a service handle at once, or an \"OnionXT: ...\" error (control not\nauthenticated, a bad port, or a local port that cannot be bound or is\nalready used by another service).\n\nThe address arrives later as a \"service\" status and from\n<oxServiceAddress>; \"serviceReady\" follows when its descriptor is uploaded.\nEach visitor arrives through the peer callback. The address is new each\ntime; use <oxCreateServiceFromSeed> for a stable one.",
			"references":{
				"handler":["oxRemoveService","oxServiceAddress","oxSetPeerCallback","oxCreateServiceFromSeed"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-17",
			"name":"oxiscontrolauthenticated",
			"display name":"oxIsControlAuthenticated",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxIsControlAuthenticated()"
			],
			"display syntax":[
				"oxIsControlAuthenticated()"
			],
			"associations":["onionxt"],
			"summary":"Tell whether the control connection has authenticated.",
			"examples":[{
				"script":"if oxIsControlAuthenticated() then oxCreateService 80, 8080"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true once the control connection is authenticated, otherwise false."
			}],
			"description":"Service creation needs an authenticated control connection.",
			"references":{
				"handler":["oxConnectControl","oxIsReady"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-18",
			"name":"oxcreateservicefromseed",
			"display name":"oxCreateServiceFromSeed",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxCreateServiceFromSeed <pSeed>,<pVirtualPort>,<pLocalPort>"
			],
			"display syntax":[
				"oxCreateServiceFromSeed <i>pSeed</i>,<i>pVirtualPort</i>,<i>pLocalPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Publish an onion service whose address is derived from a seed.",
			"parameters":[{
				"name":"pSeed",
				"type":"",
				"refparam":"false",
				"description":"32 bytes of secret binary data; the same seed always gives the same address."
			},{
				"name":"pVirtualPort",
				"type":"",
				"refparam":"false",
				"description":"the port visitors connect to on the .onion address, 1 to 65535."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"the loopback port OnionXT listens on and tor forwards to, 1 to 65535."
			}],
			"examples":[{
				"script":"oxCreateServiceFromSeed tSeed, 80, 8080\nput the result into tService"
			}],
			"description":"Works like <oxCreateService>, but the service key is the ed25519 key from\npSeed, so the address survives restarts and can serve as a published\nidentity. It needs SodiumXT (ABI 6 or later) for the key expansion and\nreports an \"OnionXT: ...\" error if it is missing or the seed is not 32\nbytes. Keep the seed secret: anyone holding it can run your address.",
			"references":{
				"handler":["oxCreateService","oxAddressFromPublicKey","oxTransportListen"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-19",
			"name":"oxlaunchtor",
			"display name":"oxLaunchTor",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxLaunchTor <pTorPath>,<pDataDir>,<pSocksPort>,<pControlPort>"
			],
			"display syntax":[
				"oxLaunchTor <i>pTorPath</i>,<i>pDataDir</i>,<i>pSocksPort</i>,<i>pControlPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Write a torrc and start a tor process for this app (optional Mode B).",
			"parameters":[{
				"name":"pTorPath",
				"type":"",
				"refparam":"false",
				"description":"the full path to the tor executable."
			},{
				"name":"pDataDir",
				"type":"",
				"refparam":"false",
				"description":"an existing folder for tor's data, its torrc and its log."
			},{
				"name":"pSocksPort",
				"type":"",
				"refparam":"false",
				"description":"the SOCKS port to configure; empty means 9050."
			},{
				"name":"pControlPort",
				"type":"",
				"refparam":"false",
				"description":"the control port to configure; empty means 9051."
			}],
			"examples":[{
				"script":"oxLaunchTor tTorPath, tDataDir, 9250, 9251\nif the result is not empty then answer the result"
			}],
			"description":"The recommended setup is a tor daemon that is already running; this is an\noptional convenience that has not yet been run on an engine. It writes\nonionxt-torrc into pDataDir (cookie authentication, tor's log to\nonionxt-tor.log there, tied to this process) and starts tor with it. Only\nafter the launch is accepted are the SOCKS and control ports pointed at it.\n\nThe result is empty or an \"OnionXT: ...\" reason. Empty does not mean tor\nis up: it does not wait for bootstrap, so connect with <oxConnectControl>\nand watch <oxBootstrapProgress>.",
			"references":{
				"handler":["oxStopTor","oxConnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-20",
			"name":"oxclosestream",
			"display name":"oxCloseStream",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxCloseStream <pStream>"
			],
			"display syntax":[
				"oxCloseStream <i>pStream</i>"
			],
			"associations":["onionxt"],
			"summary":"Close a stream and forget its handle.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle."
			}],
			"examples":[{
				"script":"oxCloseStream tStream"
			}],
			"description":"Safe to call more than once; an unknown or stale handle is a no-op. No\n\"closed\" event is delivered for a stream you close yourself.",
			"references":{
				"handler":["oxDial","oxShutdown"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-21",
			"name":"oxsetcontrolport",
			"display name":"oxSetControlPort",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetControlPort <pPort>"
			],
			"display syntax":[
				"oxSetControlPort <i>pPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Set the local port of tor's control connection.",
			"parameters":[{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"the control port on 127.0.0.1 (default 9051; Tor Browser uses 9151)."
			}],
			"examples":[{
				"script":"oxSetControlPort 9151"
			}],
			"description":"Use <oxSetControlPort> before <oxConnectControl> when tor's control port is\nnot 9051. Only the port can be set; the host is always 127.0.0.1.",
			"references":{
				"handler":["oxSetSocksPort","oxConnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-22",
			"name":"oxtransportrecv",
			"display name":"oxTransportRecv",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxTransportRecv <pStream>,<pHandlerName>"
			],
			"display syntax":[
				"oxTransportRecv <i>pStream</i>,<i>pHandlerName</i>"
			],
			"associations":["onionxt"],
			"summary":"Register where a transport stream's inbound bytes are delivered.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle."
			},{
				"name":"pHandlerName",
				"type":"",
				"refparam":"false",
				"description":"the name of the stream callback handler."
			}],
			"examples":[{
				"script":"oxTransportRecv tStream, \"onStream\""
			}],
			"description":"A wrapper for <oxSetStreamCallback>; the result is the same.",
			"references":{
				"handler":["oxSetStreamCallback","oxTransportSend"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-23",
			"name":"oxversion",
			"display name":"oxVersion",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxVersion()"
			],
			"display syntax":[
				"oxVersion()"
			],
			"associations":["onionxt"],
			"summary":"Return the OnionXT version, and tor's version once it is known.",
			"examples":[{
				"script":"put oxVersion() into field \"Version\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The library version, followed by the tor version in parentheses once the control connection has read it."
			}],
			"description":"Before the control connection has answered, only the OnionXT version comes\nback.",
			"references":{
				"handler":["oxConnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-24",
			"name":"oxpublishservice",
			"display name":"oxPublishService",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxPublishService <pVirtualPort>,<pLocalPort>"
			],
			"display syntax":[
				"oxPublishService <i>pVirtualPort</i>,<i>pLocalPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Publish an onion service that forwards to a local server you run yourself.",
			"parameters":[{
				"name":"pVirtualPort",
				"type":"",
				"refparam":"false",
				"description":"the port visitors connect to on the .onion address, 1 to 65535."
			},{
				"name":"pLocalPort",
				"type":"",
				"refparam":"false",
				"description":"the loopback port your own server already accepts connections on, 1 to 65535."
			}],
			"examples":[{
				"script":"oxPublishService 80, 8090\nput the result into tService"
			}],
			"description":"Unlike <oxCreateService>, OnionXT starts no listener and no peer\ncallback fires: the external server owns the port. The result is a\nservice handle, and the address arrives as for <oxCreateService>.\n<oxRemoveService> unpublishes it and leaves your server's socket alone.\n\nYour server must refuse any peer that is not 127.0.0.1 itself, because a\nlistening port may be reachable from the local network, bypassing Tor.",
			"references":{
				"handler":["oxCreateService","oxRemoveService","oxServiceAddress"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-25",
			"name":"oxsetcallbackowner",
			"display name":"oxSetCallbackOwner",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetCallbackOwner <pObjectLongId>"
			],
			"display syntax":[
				"oxSetCallbackOwner <i>pObjectLongId</i>"
			],
			"associations":["onionxt"],
			"summary":"Name the object whose script holds your OnionXT callbacks.",
			"parameters":[{
				"name":"pObjectLongId",
				"type":"",
				"refparam":"false",
				"description":"the long id of the object that holds the callback handlers."
			}],
			"examples":[{
				"script":"oxSetCallbackOwner the long id of me"
			}],
			"description":"Status, stream and peer callbacks are sent with dispatch to this object.\nIf you never set it they go to the topStack, which is usually but not\nalways your app's stack, so set it explicitly. A callback handler the\nobject does not define is a clean no-op, and an error thrown inside one is\ncaught so the transport keeps running.",
			"references":{
				"handler":["oxSetStatusCallback","oxSetPeerCallback","oxSetStreamCallback"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-26",
			"name":"oxserviceisready",
			"display name":"oxServiceIsReady",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxServiceIsReady(<pService>)"
			],
			"display syntax":[
				"oxServiceIsReady(<i>pService</i>)"
			],
			"associations":["onionxt"],
			"summary":"Tell whether a service's descriptor has been uploaded.",
			"parameters":[{
				"name":"pService",
				"type":"",
				"refparam":"false",
				"description":"a service handle."
			}],
			"examples":[{
				"script":"if oxServiceIsReady(tService) then answer \"Reachable at\" && oxServiceAddress(tService)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true once the \"serviceReady\" status has fired for this service, otherwise false."
			}],
			"description":"Until the descriptor is uploaded, visitors cannot find the service.",
			"references":{
				"handler":["oxServiceAddress","oxIsReady"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-27",
			"name":"oxdial",
			"display name":"oxDial",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxDial <pHost>,<pPort>"
			],
			"display syntax":[
				"oxDial <i>pHost</i>,<i>pPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Open a stream to a host and port through Tor.",
			"parameters":[{
				"name":"pHost",
				"type":"",
				"refparam":"false",
				"description":"a .onion address or a host name; Tor resolves it, never the local machine."
			},{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"the port to connect to, 1 to 65535."
			}],
			"examples":[{
				"script":"oxDial \"example.onion\", 80\nput the result into tStream\nif tStream is an integer then oxSetStreamCallback tStream, \"onStream\""
			}],
			"description":"Use <oxDial> to reach any TCP endpoint anonymously. The result is a stream\nhandle at once, or an \"OnionXT: ...\" error for an empty host or a bad\nport. The SOCKS5 handshake then runs asynchronously: the stream callback\nreceives \"open\" when the tunnel is live or \"error\" with a reason (a SOCKS\nfailure, a refused connection, or a handshake that took longer than 20\nseconds), after which the stream is already closed.\n\nRegister the stream callback straight after dialing. The tor daemon must be\nrunning; the control connection is not needed for dialing.",
			"references":{
				"handler":["oxSetStreamCallback","oxWrite","oxCloseStream","oxTransportDial"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-28",
			"name":"oxpublickeyfromaddress",
			"display name":"oxPublicKeyFromAddress",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxPublicKeyFromAddress(<pOnionAddress>)"
			],
			"display syntax":[
				"oxPublicKeyFromAddress(<i>pOnionAddress</i>)"
			],
			"associations":["onionxt"],
			"summary":"Return the ed25519 public key inside a v3 .onion address.",
			"parameters":[{
				"name":"pOnionAddress",
				"type":"",
				"refparam":"false",
				"description":"a 56-character v3 address, with or without \".onion\"."
			}],
			"examples":[{
				"script":"put oxPublicKeyFromAddress(tAddress) into tPubKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte public key, or empty if the address is not a well-formed v3 address."
			}],
			"description":"Pure decoding, with no network and no SodiumXT. It does not verify the\nchecksum; use <oxIsValidAddress> for that.",
			"references":{
				"handler":["oxAddressFromPublicKey","oxIsValidAddress"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-29",
			"name":"oxstreamstate",
			"display name":"oxStreamState",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxStreamState(<pStream>)"
			],
			"display syntax":[
				"oxStreamState(<i>pStream</i>)"
			],
			"associations":["onionxt"],
			"summary":"Return the current state of a stream.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle."
			}],
			"examples":[{
				"script":"if oxStreamState(tStream) is \"connected\" then oxWrite tStream, tData"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stream's state, such as \"connecting\" or \"connected\", or \"unknown\" for a stale or never-opened handle."
			}],
			"description":"Use it to check a stream before writing; <oxWrite> refuses any stream that\nis not \"connected\".",
			"references":{
				"handler":["oxDial","oxWrite"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-30",
			"name":"oxsetsocksport",
			"display name":"oxSetSocksPort",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetSocksPort <pPort>"
			],
			"display syntax":[
				"oxSetSocksPort <i>pPort</i>"
			],
			"associations":["onionxt"],
			"summary":"Set the local port of Tor's SOCKS proxy.",
			"parameters":[{
				"name":"pPort",
				"type":"",
				"refparam":"false",
				"description":"the SOCKS port on 127.0.0.1 (default 9050; Tor Browser uses 9150)."
			}],
			"examples":[{
				"script":"oxSetSocksPort 9150"
			}],
			"description":"Use <oxSetSocksPort> when tor listens somewhere other than 9050. Only the\nport can be set; the host is always 127.0.0.1. It takes effect on the next\n<oxDial>.",
			"references":{
				"handler":["oxSetControlPort","oxDial"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-31",
			"name":"oxsetcontrolpassword",
			"display name":"oxSetControlPassword",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetControlPassword <pPassword>"
			],
			"display syntax":[
				"oxSetControlPassword <i>pPassword</i>"
			],
			"associations":["onionxt"],
			"summary":"Store the password for tor's HASHEDPASSWORD control authentication.",
			"parameters":[{
				"name":"pPassword",
				"type":"",
				"refparam":"false",
				"description":"the control password configured for the tor daemon."
			}],
			"examples":[{
				"script":"oxSetControlPassword \"my control password\"\noxConnectControl"
			}],
			"description":"Only needed when the daemon offers HASHEDPASSWORD authentication. Cookie\nand SAFECOOKIE authentication need no password. Set it before\n<oxConnectControl>.",
			"references":{
				"handler":["oxConnectControl"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-32",
			"name":"oxserviceaddress",
			"display name":"oxServiceAddress",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxServiceAddress(<pService>)"
			],
			"display syntax":[
				"oxServiceAddress(<i>pService</i>)"
			],
			"associations":["onionxt"],
			"summary":"Return the .onion address of a service.",
			"parameters":[{
				"name":"pService",
				"type":"",
				"refparam":"false",
				"description":"a service handle."
			}],
			"examples":[{
				"script":"put oxServiceAddress(tService) into field \"Address\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The full address ending in .onion, or empty until tor has assigned it."
			}],
			"description":"The address is known shortly after the service is created, when the\n\"service\" status arrives.",
			"references":{
				"handler":["oxCreateService","oxServiceIsReady"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-33",
			"name":"oxtransportsend",
			"display name":"oxTransportSend",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxTransportSend <pStream>,<pData>"
			],
			"display syntax":[
				"oxTransportSend <i>pStream</i>,<i>pData</i>"
			],
			"associations":["onionxt"],
			"summary":"Send bytes on a transport stream.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"the binary data to send."
			}],
			"examples":[{
				"script":"oxTransportSend tStream, tSealed"
			}],
			"description":"A wrapper for <oxWrite>; the result is the same.",
			"references":{
				"handler":["oxWrite","oxTransportRecv"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-34",
			"name":"oxsetstreamcallback",
			"display name":"oxSetStreamCallback",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetStreamCallback <pStream>,<pHandlerName>"
			],
			"display syntax":[
				"oxSetStreamCallback <i>pStream</i>,<i>pHandlerName</i>"
			],
			"associations":["onionxt"],
			"summary":"Register the handler that receives a stream's events and data.",
			"parameters":[{
				"name":"pStream",
				"type":"",
				"refparam":"false",
				"description":"a stream handle from oxDial or from the peer callback."
			},{
				"name":"pHandlerName",
				"type":"",
				"refparam":"false",
				"description":"the name of a handler in the callback owner's script, called with a stream, an event and data."
			}],
			"examples":[{
				"script":"oxSetStreamCallback tStream, \"onStream\""
			}],
			"description":"The handler receives the stream handle, an event and data. The events are\n\"open\" (the tunnel or inbound peer is live), \"data\" (the third parameter\nis an inbound chunk of binary data), \"closed\" (the far side closed) and\n\"error\" (the third parameter is the reason; the stream is already torn\ndown). Chunks arrive as the network delivers them; your app reassembles its\nown messages.\n\nThe result is an error for an unknown stream handle, otherwise empty.",
			"references":{
				"handler":["oxDial","oxSetPeerCallback","oxWrite"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-35",
			"name":"oxsocketclosed",
			"display name":"oxSocketClosed",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxSocketClosed(<pSocketID>)"
			],
			"display syntax":[
				"oxSocketClosed(<i>pSocketID</i>)"
			],
			"associations":["onionxt"],
			"summary":"Handle a socketClosed message if the socket belongs to OnionXT.",
			"parameters":[{
				"name":"pSocketID",
				"type":"",
				"refparam":"false",
				"description":"the socket id from the engine's socketClosed message."
			}],
			"examples":[{
				"script":"if oxSocketClosed(pSocketID) then exit socketClosed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"true\" if the socket was OnionXT's and the close was handled, \"false\" otherwise."
			}],
			"description":"For apps that embed OnionXT's script into their own: call it from your own\nsocketClosed handler where you would otherwise pass the message. For an\nOnionXT stream it delivers \"closed\" to the stream callback and forgets the\nstream; for the control socket it reports \"disconnected\".",
			"references":{
				"handler":["oxSocketError","oxSocketTimeout"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-36",
			"name":"oxisready",
			"display name":"oxIsReady",
			"library":"onionxt",
			"type":"function",
			"syntax":[
				"oxIsReady()"
			],
			"display syntax":[
				"oxIsReady()"
			],
			"associations":["onionxt"],
			"summary":"Tell whether tor is fully bootstrapped and the control connection is authenticated.",
			"examples":[{
				"script":"if oxIsReady() then enable button \"Publish\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when bootstrap is at 100 and the control connection is authenticated, otherwise false."
			}],
			"description":"This is daemon readiness only. Whether a particular published service can\nbe reached yet is <oxServiceIsReady>.",
			"references":{
				"handler":["oxBootstrapProgress","oxIsControlAuthenticated","oxServiceIsReady"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-37",
			"name":"oxconnectcontrol",
			"display name":"oxConnectControl",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxConnectControl"
			],
			"display syntax":[
				"oxConnectControl"
			],
			"associations":["onionxt"],
			"summary":"Open and authenticate the control connection to the tor daemon.",
			"examples":[{
				"script":"oxSetStatusCallback \"onTorStatus\"\noxConnectControl\nif the result is not empty then answer the result"
			}],
			"description":"Use <oxConnectControl> before creating onion services or reading bootstrap\nprogress. It works asynchronously: it asks tor which authentication methods\nit offers and uses the best one it can (SAFECOOKIE, cookie, none, then a\npassword). The\noutcome arrives as a \"control\" status: \"authenticated\", or an \"authfailed:\"\nor \"error:\" reason. A handshake that does not finish within 20 seconds is\ntorn down.\n\nThe result is an error at once only when a control connection is already\nopen; call <oxDisconnectControl> first to reconnect.",
			"references":{
				"handler":["oxDisconnectControl","oxIsControlAuthenticated","oxSetStatusCallback","oxIsReady"]
			},
			"tags":["networking","tor"]
		},{
			"id":"onionxt-38",
			"name":"oxsetpeercallback",
			"display name":"oxSetPeerCallback",
			"library":"onionxt",
			"type":"command",
			"syntax":[
				"oxSetPeerCallback <pHandlerName>"
			],
			"display syntax":[
				"oxSetPeerCallback <i>pHandlerName</i>"
			],
			"associations":["onionxt"],
			"summary":"Register the handler called when a peer connects to one of your onion services.",
			"parameters":[{
				"name":"pHandlerName",
				"type":"",
				"refparam":"false",
				"description":"the name of a handler in the callback owner's script, called with a stream, a service and a peer address."
			}],
			"examples":[{
				"script":"oxSetPeerCallback \"onPeer\""
			}],
			"description":"The handler receives the new inbound stream handle, the service handle (or\nempty when more than one service is live and OnionXT cannot tell which was\nreached) and the loopback address Tor forwarded from. Register a stream\ncallback on the new stream inside this handler: reading starts only after\nit returns.",
			"references":{
				"handler":["oxCreateService","oxSetStreamCallback"]
			},
			"tags":["networking","tor"]
		}