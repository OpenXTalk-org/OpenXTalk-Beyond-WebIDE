{
			"id":"com.livecode.library.extension-utils-1",
			"name":"com.livecode.library.extension-utils",
			"display name":"Extension Package Handling Utilities",
			"library":"com.livecode.library.extension-utils",
			"type":"library",
			"display syntax":[
				"Extension Package Handling Utilities"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"This library provides handlers for managing livecode extension packages",
			"description":"This library provides handlers for managing livecode extension packages"
		},{
			"id":"com.livecode.library.extension-utils-2",
			"name":"extensionfetchsourcefromfolder",
			"display name":"extensionFetchSourceFromFolder",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionFetchSourceFromFolder <pFolder>,<rSource>,<rSupportFiles>,<rType>"
			],
			"display syntax":[
				"extensionFetchSourceFromFolder <i>pFolder</i>,<i>rSource</i>,<i>rSupportFiles</i>,<i>rType</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Fetch basic information about extension source from a folder",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder to search"
			},{
				"name":"rSource",
				"type":"",
				"refparam":"false",
				"description":"The main source file found"
			},{
				"name":"rSupportFiles",
				"type":"",
				"refparam":"false",
				"description":"A list of supporting source files found"
			},{
				"name":"rType",
				"type":"",
				"refparam":"false",
				"description":"The type of extension.\n- \"lcb\": A LiveCode Builder extension\n- \"lcs\": A LiveCode Script extension"
			}],
			"description":"Fetch basic information about extension source from a folder"
		},{
			"id":"com.livecode.library.extension-utils-3",
			"name":"extensionpackagescriptextension",
			"display name":"extensionPackageScriptExtension",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionPackageScriptExtension <pSourceFolder>,<pTargetFolder>,<pRemoveSource>"
			],
			"display syntax":[
				"extensionPackageScriptExtension <i>pSourceFolder</i>,<i>pTargetFolder</i>,<i>pRemoveSource</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Package a LiveCode Script extension",
			"parameters":[{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder containing the extension"
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder to output the extension package"
			},{
				"name":"pRemoveSource",
				"type":"",
				"refparam":"false",
				"description":"Whether to remove the source files or not"
			}],
			"description":"Package a LiveCode Script extension"
		},{
			"id":"com.livecode.library.extension-utils-4",
			"name":"extensionpackage",
			"display name":"extensionPackage",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionPackage <pSourceFolder>,<pTargetFolder>,<pRemoveSource>"
			],
			"display syntax":[
				"extensionPackage <i>pSourceFolder</i>,<i>pTargetFolder</i>,<i>pRemoveSource</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Package an extension",
			"parameters":[{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder containing the extension"
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The output location of the package"
			},{
				"name":"pRemoveSource",
				"type":"",
				"refparam":"false",
				"description":"Whether to remove the source code from the package or not"
			}],
			"value":[{
				"name":"it",
				"type":"",
				"description":"The location of the build package, or empty if there was an error."
			},{
				"name":"the result",
				"type":"",
				"description":"Any error that occurred when packaging"
			}],
			"description":"Package an extension"
		},{
			"id":"com.livecode.library.extension-utils-5",
			"name":"extensionfindinfolder",
			"display name":"extensionFindInFolder",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionFindInFolder <pFolder>,<pIsUserFolder>,<pRecursive>,<xDataA>"
			],
			"display syntax":[
				"extensionFindInFolder <i>pFolder</i>,<i>pIsUserFolder</i>,<i>pRecursive</i>,<i>xDataA</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Find any extensions in the given folder",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder to search"
			},{
				"name":"pIsUserFolder",
				"type":"",
				"refparam":"false",
				"description":"Whether this is a user folder or not"
			},{
				"name":"pRecursive",
				"type":"",
				"refparam":"false",
				"description":"Whether to search subfolders"
			},{
				"name":"xDataA",
				"type":"",
				"refparam":"false",
				"description":"An array. Details of any extensions found will be placed in the \narray under xDataA[<type_id>][<folder>]"
			}],
			"description":"Find any extensions in the given folder"
		},{
			"id":"com.livecode.library.extension-utils-6",
			"name":"extensiondepsorder",
			"display name":"extensionDepsOrder",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionDepsOrder <pLCCompile>,<pExtensionList>"
			],
			"display syntax":[
				"extensionDepsOrder <i>pLCCompile</i>,<i>pExtensionList</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Use lc-compile to order LiveCode Builder extensions by dependency.",
			"parameters":[{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pExtensionList",
				"type":"",
				"refparam":"false",
				"description":"A list of LiveCode Builder extensions to put in dependency order"
			}],
			"value":[{
				"name":"it",
				"type":"",
				"description":"The dependency-ordered list."
			},{
				"name":"the result",
				"type":"",
				"description":"Any error that occurred."
			}],
			"description":"Use lc-compile to order LiveCode Builder extensions by dependency."
		},{
			"id":"com.livecode.library.extension-utils-7",
			"name":"extensionvalidatelcepackage",
			"display name":"extensionValidateLCEPackage",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionValidateLCEPackage <pPackage>,<rManifestDataA>"
			],
			"display syntax":[
				"extensionValidateLCEPackage <i>pPackage</i>,<i>rManifestDataA</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Validate an extension package",
			"parameters":[{
				"name":"pPackage",
				"type":"",
				"refparam":"false",
				"description":"The .lce package to validate"
			},{
				"name":"rManifestDataA",
				"type":"",
				"refparam":"false",
				"description":"The basic manifest data extracted from the package"
			}],
			"value":[{
				"name":"the result",
				"type":"",
				"description":"If the package was deemed invalid, the result contains the reason why \nthe package failed validation."
			}],
			"description":"Use the <extensionValidateLCEPackage> command to naively validate the \ncontents of an .lce package. <extensionValidateLCEPackage> checks if \nthere is a file that looks like the main extension (either a compiled \nLiveCode Builder module file or a LiveCode stack), that it contains a\nmanifest XML file and that the manifest contains the minimum required\ninformation, namely the name, version, author, type, and title.\n\nThe manifest information is returned in the <rManifestDataA> out \nparameter."
		},{
			"id":"com.livecode.library.extension-utils-8",
			"name":"extensioncheckmoduleversion",
			"display name":"extensionCheckModuleVersion",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionCheckModuleVersion(<pLCCompile>,<pModule>)"
			],
			"display syntax":[
				"extensionCheckModuleVersion(<i>pLCCompile</i>,<i>pModule</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Check the module bytecode is the same version as a particular lc-compile",
			"parameters":[{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pModule",
				"type":"",
				"refparam":"false",
				"description":"The path to the compiled module bytecode file (.lcm)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the version of lc-compile matches that of the bytecode file,\nfalse otherwise."
			}],
			"description":"Check the module bytecode is the same version as a particular lc-compile"
		},{
			"id":"com.livecode.library.extension-utils-9",
			"name":"extensionpackagebuilderextension",
			"display name":"extensionPackageBuilderExtension",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionPackageBuilderExtension <pSourceFolder>,<pTargetFolder>,<pRemoveSource>,<pLCCompile>,<pLCIPath>,<pExtraLCIPaths>"
			],
			"display syntax":[
				"extensionPackageBuilderExtension <i>pSourceFolder</i>,<i>pTargetFolder</i>,<i>pRemoveSource</i>,<i>pLCCompile</i>,<i>pLCIPath</i>,<i>pExtraLCIPaths</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Package a LiveCode Builder extension",
			"parameters":[{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder containing the extension"
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder to output the extension package"
			},{
				"name":"pRemoveSource",
				"type":"",
				"refparam":"false",
				"description":"Whether to remove the source files or not"
			},{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pLCIPath",
				"type":"",
				"refparam":"false",
				"description":"The location of the standard library module interface files. If empty, \nthis will be computed."
			},{
				"name":"pExtraLCIPaths",
				"type":"",
				"refparam":"false",
				"description":"A list of paths to look for extra module interface files."
			}],
			"description":"Package a LiveCode Builder extension"
		},{
			"id":"com.livecode.library.extension-utils-10",
			"name":"extensionbuildpackageandextractlcb",
			"display name":"extensionBuildPackageAndExtractLCB",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionBuildPackageAndExtractLCB <pDocsParser>,<pTargetFolder>,<pCommercialExtension>,<pLCCompile>,<pLCIPath>,<pExtraLCIPaths>"
			],
			"display syntax":[
				"extensionBuildPackageAndExtractLCB <i>pDocsParser</i>,<i>pTargetFolder</i>,<i>pCommercialExtension</i>,<i>pLCCompile</i>,<i>pLCIPath</i>,<i>pExtraLCIPaths</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Build, package and extract LiveCode Builder extensions",
			"parameters":[{
				"name":"pDocsParser",
				"type":"",
				"refparam":"false",
				"description":"The path to the docs parser script."
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The target folder to extract the extension to"
			},{
				"name":"pCommercialExtension",
				"type":"",
				"refparam":"false",
				"description":"Whether the extension source should be removed"
			},{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pLCIPath",
				"type":"",
				"refparam":"false",
				"description":"The location of the standard library module interface files. If empty, \nthis will be computed."
			},{
				"name":"pExtraLCIPaths",
				"type":"",
				"refparam":"false",
				"description":"A list of paths to look for extra module interface files."
			}],
			"description":"Any parameters after <pExtraLCIPaths> are the extension sources to\nbuild, package and extract."
		},{
			"id":"com.livecode.library.extension-utils-11",
			"name":"extensionbuildpackageandextract",
			"display name":"extensionBuildPackageAndExtract",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionBuildPackageAndExtract <pProtectifyScript>,<pProtectifyOutput>,<pGitHash>,<pDocsParser>,<pSourceFolder>,<pSourceFileName>,<pTargetFolder>,<pCommercialExtension>,<pLCCompile>,<pLCIPath>,<pExtraLCIPaths>"
			],
			"display syntax":[
				"extensionBuildPackageAndExtract <i>pProtectifyScript</i>,<i>pProtectifyOutput</i>,<i>pGitHash</i>,<i>pDocsParser</i>,<i>pSourceFolder</i>,<i>pSourceFileName</i>,<i>pTargetFolder</i>,<i>pCommercialExtension</i>,<i>pLCCompile</i>,<i>pLCIPath</i>,<i>pExtraLCIPaths</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Build, package and extract extension",
			"parameters":[{
				"name":"pProtectifyScript",
				"type":"",
				"refparam":"false",
				"description":"The path to the script that protects a livecode stack."
			},{
				"name":"pProtectifyOutput",
				"type":"",
				"refparam":"false",
				"description":"The target filename for the protected livecode stack"
			},{
				"name":"pGitHash",
				"type":"",
				"refparam":"false",
				"description":"The hash to use when protecting the stack"
			},{
				"name":"pDocsParser",
				"type":"",
				"refparam":"false",
				"description":"The path to the docs parser script."
			},{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder containing the extension"
			},{
				"name":"pSourceFileName",
				"type":"",
				"refparam":"false",
				"description":"The extension file name"
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The target folder to extract the extension to"
			},{
				"name":"pCommercialExtension",
				"type":"",
				"refparam":"false",
				"description":"Whether the extension source should be removed"
			},{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pLCIPath",
				"type":"",
				"refparam":"false",
				"description":"The location of the standard library module interface files. If empty, \nthis will be computed."
			},{
				"name":"pExtraLCIPaths",
				"type":"",
				"refparam":"false",
				"description":"A list of paths to look for extra module interface files."
			}],
			"description":"Build, package and extract extension"
		},{
			"id":"com.livecode.library.extension-utils-12",
			"name":"extensionorderbydependency",
			"display name":"extensionOrderByDependency",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionOrderByDependency(<pExtensions>,<pRequiresA>,<pIncludeBuiltin>)"
			],
			"display syntax":[
				"extensionOrderByDependency(<i>pExtensions</i>,<i>pRequiresA</i>,<i>pIncludeBuiltin</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Order extensions by dependency using requires info",
			"parameters":[{
				"name":"pExtensions",
				"type":"",
				"refparam":"false",
				"description":"A list of extensions to order, one per line"
			},{
				"name":"pRequiresA",
				"type":"",
				"refparam":"false",
				"description":"An array of dependencies. For each key `tExtension`, \n`pRequiresA[tExtension]` should be a list of extensions on which \n`tExtension` depends"
			},{
				"name":"pIncludeBuiltin",
				"type":"",
				"refparam":"false",
				"description":"Include built-in modules in dependency analysis. Defaults to false. \nFor most purposes, it is not necessary to include built-in modules."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The list of extensions ordered by dependency according to the \ndependency information in <pRequiresA>"
			}],
			"description":"Order extensions by dependency using requires info"
		},{
			"id":"com.livecode.library.extension-utils-13",
			"name":"extensionlccompileversion",
			"display name":"extensionLCCompileVersion",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionLCCompileVersion(<pLCCompile>)"
			],
			"display syntax":[
				"extensionLCCompileVersion(<i>pLCCompile</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Return the bytecode version of a particular lc-compile",
			"parameters":[{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An integer, the version of the bytecode output by <pLCCompile>"
			}],
			"description":"Return the bytecode version of a particular lc-compile"
		},{
			"id":"com.livecode.library.extension-utils-14",
			"name":"extensioncompile",
			"display name":"extensionCompile",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionCompile <pLCCompile>,<pFile>,<pSupportFiles>,<pLCIPath>,<pExtraLCIPaths>,<pTargetFolder>,<pOutputFilename>"
			],
			"display syntax":[
				"extensionCompile <i>pLCCompile</i>,<i>pFile</i>,<i>pSupportFiles</i>,<i>pLCIPath</i>,<i>pExtraLCIPaths</i>,<i>pTargetFolder</i>,<i>pOutputFilename</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Compile a LiveCode Builder extension file",
			"parameters":[{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pFile",
				"type":"",
				"refparam":"false",
				"description":"The main source file of the LCB extension"
			},{
				"name":"pSupportFiles",
				"type":"",
				"refparam":"false",
				"description":"A list of support files required by the main source file. These must all be named `<main_source_name>-<suffix>.lcb`"
			},{
				"name":"pLCIPath",
				"type":"",
				"refparam":"false",
				"description":"The location of the standard library module interface files. If empty, \nthis will be computed."
			},{
				"name":"pExtraLCIPaths",
				"type":"",
				"refparam":"false",
				"description":"A list of paths to look for extra module interface files."
			},{
				"name":"pTargetFolder",
				"type":"",
				"refparam":"false",
				"description":"The target output folder"
			},{
				"name":"pOutputFilename",
				"type":"",
				"refparam":"false",
				"description":"The target bytecode output filename"
			}],
			"value":[{
				"name":"it",
				"type":"",
				"description":"The dependency-ordered list."
			},{
				"name":"the result",
				"type":"",
				"description":"Any error that occurred."
			}],
			"description":"Compile a LiveCode Builder extension file"
		},{
			"id":"com.livecode.library.extension-utils-15",
			"name":"extensionbytecodefilename",
			"display name":"extensionBytecodeFilename",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionBytecodeFilename(<pLCCompile>,<pUseVersion>)"
			],
			"display syntax":[
				"extensionBytecodeFilename(<i>pLCCompile</i>,<i>pUseVersion</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Return the default bytecode output filename",
			"parameters":[{
				"name":"pLCCompile",
				"type":"",
				"refparam":"false",
				"description":"The path to the lc-compile program. If empty, this will be computed."
			},{
				"name":"pUseVersion",
				"type":"",
				"refparam":"false",
				"description":"Whether to use the bytecode version as part of the filename or not.\nDefaults to true."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Either \"module.lcm\" or \"module.<lc-compile_version>.lcm\" depending on \nthe value of the <pUseVersion> parameter."
			}],
			"description":"Return the default bytecode output filename"
		},{
			"id":"com.livecode.library.extension-utils-16",
			"name":"extensionfetchfolderdetails",
			"display name":"extensionFetchFolderDetails",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionFetchFolderDetails(<pFolder>,<pParseManifest>)"
			],
			"display syntax":[
				"extensionFetchFolderDetails(<i>pFolder</i>,<i>pParseManifest</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Fetch all the information about an extension in the given folder",
			"parameters":[{
				"name":"pFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder to search for an extension"
			},{
				"name":"pParseManifest",
				"type":"",
				"refparam":"false",
				"description":"Whether to parse any existing manifest file for information about the\nextension."
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array of details about any extension found, and its assets, or empty\nif none was found."
			}],
			"description":"Fetch all the information about an extension in the given folder"
		},{
			"id":"com.livecode.library.extension-utils-17",
			"name":"extensiongeneratemanifestforlcsextension",
			"display name":"extensionGenerateManifestForLCSExtension",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionGenerateManifestForLCSExtension <pDocsParser>,<pSourceFolder>"
			],
			"display syntax":[
				"extensionGenerateManifestForLCSExtension <i>pDocsParser</i>,<i>pSourceFolder</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Generate manifest for LiveCode Script extension",
			"parameters":[{
				"name":"pDocsParser",
				"type":"",
				"refparam":"false",
				"description":"The path to the docs parser script."
			},{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder in which to find the lcs extension"
			}],
			"description":"Generate manifest for LiveCode Script extension"
		},{
			"id":"com.livecode.library.extension-utils-18",
			"name":"extensionfetchmetadata",
			"display name":"extensionFetchMetadata",
			"library":"com.livecode.library.extension-utils",
			"type":"function",
			"syntax":[
				"extensionFetchMetadata(<pManifestPath>)"
			],
			"display syntax":[
				"extensionFetchMetadata(<i>pManifestPath</i>)"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Fetch metadata from an extension manifest",
			"parameters":[{
				"name":"pManifestPath",
				"type":"",
				"refparam":"false",
				"description":"The path to the manifest XML file"
			}],
			"description":"Fetch metadata from an extension manifest"
		},{
			"id":"com.livecode.library.extension-utils-19",
			"name":"extensionextractdocs",
			"display name":"extensionExtractDocs",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionExtractDocs <pDocsParser>,<pOutputDir>"
			],
			"display syntax":[
				"extensionExtractDocs <i>pDocsParser</i>,<i>pOutputDir</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Extract docs from extension files",
			"parameters":[{
				"name":"pDocsParser",
				"type":"",
				"refparam":"false",
				"description":"The path to the docs parser script. If empty, this command will do \nnothing"
			},{
				"name":"pOutputDir",
				"type":"",
				"refparam":"false",
				"description":"The folder to output the extracted docs file"
			}],
			"description":"Use <extensionExtractDocs> to run the docs parser script on all the files which\nare parameters subsequent to <pOutputDir>"
		},{
			"id":"com.livecode.library.extension-utils-20",
			"name":"extensionprotectstack",
			"display name":"extensionProtectStack",
			"library":"com.livecode.library.extension-utils",
			"type":"command",
			"syntax":[
				"extensionProtectStack <pProtectifyScript>,<pSourceFolder>,<pSourceFileName>,<pOutput>,<pGitHash>"
			],
			"display syntax":[
				"extensionProtectStack <i>pProtectifyScript</i>,<i>pSourceFolder</i>,<i>pSourceFileName</i>,<i>pOutput</i>,<i>pGitHash</i>"
			],
			"associations":["com.livecode.library.extension-utils"],
			"summary":"Protect a livecode stack using the provided script",
			"parameters":[{
				"name":"pProtectifyScript",
				"type":"",
				"refparam":"false",
				"description":"The path to the script that protects a livecode stack."
			},{
				"name":"pSourceFolder",
				"type":"",
				"refparam":"false",
				"description":"The folder containing the extension"
			},{
				"name":"pSourceFileName",
				"type":"",
				"refparam":"false",
				"description":"The extension file name"
			},{
				"name":"pOutput",
				"type":"",
				"refparam":"false",
				"description":"The target filename for the protected livecode stack"
			},{
				"name":"pGitHash",
				"type":"",
				"refparam":"false",
				"description":"The hash to use when protecting the stack\n"
			}],
			"description":"Protect a livecode stack using the provided script"
		}