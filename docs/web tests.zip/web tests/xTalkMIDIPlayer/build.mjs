// Inlines js-synthesizer + the FluidSynth WASM glue (+ optional default SF2)
// into widget.template.html  ->  dist/xtalk-midi-widget.html
//
// Usage:  npm install && node build.mjs [--sf2 path/to/font.sf2]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const pkgDir = path.join(here, 'node_modules', 'js-synthesizer');
const die = (m) => { console.error('[build] ' + m); process.exit(1); };

if (!fs.existsSync(pkgDir)) die('node_modules/js-synthesizer not found. Run "npm install" first.');

// --- FluidSynth glue (latest version in externals/) -------------------------
const extDir = path.join(pkgDir, 'externals');
const re = /^libfluidsynth-(\d+)\.(\d+)\.(\d+)-with-libsndfile\.js$/;
const found = fs.readdirSync(extDir)
  .map(f => { const m = f.match(re); return m && { f, v: m.slice(1).map(Number) }; })
  .filter(Boolean)
  .sort((a, b) => b.v[0] - a.v[0] || b.v[1] - a.v[1] || b.v[2] - a.v[2]);
if (!found.length) die('No libfluidsynth-*-with-libsndfile.js in ' + extDir);
const externalsPath = path.join(extDir, found[0].f);
const externals = fs.readFileSync(externalsPath, 'utf8');
if (!/base64/.test(externals.slice(0, 5_000_000)) && fs.existsSync(externalsPath.replace(/\.js$/, '.wasm'))) {
  console.warn('[build] WARNING: glue file does not look like a SINGLE_FILE build and a sibling .wasm exists; WASM may not be inlined.');
}

// --- js-synthesizer UMD bundle ----------------------------------------------
const distDir = path.join(pkgDir, 'dist');
const umdName = ['js-synthesizer.min.js', 'js-synthesizer.js'].find(n => fs.existsSync(path.join(distDir, n)));
if (!umdName) die('No js-synthesizer(.min).js in ' + distDir);
const jssynth = fs.readFileSync(path.join(distDir, umdName), 'utf8');

// --- optional default soundfont ---------------------------------------------
let sf2b64 = '';
const i = process.argv.indexOf('--sf2');
if (i > 0) {
  const p = path.resolve(process.argv[i + 1] || '');
  if (!fs.existsSync(p)) die('SF2 not found: ' + p);
  sf2b64 = fs.readFileSync(p).toString('base64');
  console.log(`[build] default SF2: ${path.basename(p)} (${(sf2b64.length / 1048576).toFixed(1)} MB base64)`);
}

// --- assemble -----------------------------------------------------------------
const safe = (s) => s.replace(/<\/script/gi, '<\\/script');
let html = fs.readFileSync(path.join(here, 'widget.template.html'), 'utf8');
const sub = (token, text) => {
  if (!html.includes(token)) die('Template token missing: ' + token);
  html = html.replace(token, () => text);
};
sub('/*__EXTERNALS__*/', safe(externals));
sub('/*__JSSYNTH__*/', safe(jssynth));
sub('/*__SF2__*/', sf2b64);

fs.mkdirSync(path.join(here, 'dist'), { recursive: true });
const out = path.join(here, 'dist', 'xtalk-midi-widget.html');
fs.writeFileSync(out, html);
console.log(`[build] FluidSynth glue: ${found[0].f}`);
console.log(`[build] wrote ${out} (${(html.length / 1048576).toFixed(2)} MB)`);
