{
			"id":"org.openxtalk.box2dxt-1",
			"name":"org.openxtalk.box2dxt",
			"display name":"Box2D for OpenXTalk",
			"library":"org.openxtalk.box2dxt",
			"type":"library",
			"display syntax":[
				"Box2D for OpenXTalk"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Bindings to Box2D v3.1, a fast 2D rigid-body physics engine.\n\nA world holds bodies; a body carries shapes (its collision geometry and\nmaterial) and can be linked to other bodies by joints. Worlds, bodies,\nshapes, joints and chains are integer handles. 0 means a call failed or\nfound nothing, and a stale handle is a harmless no-op: getters return 0,\nactions do nothing.\n\nEvery distance is in metres and every angle in radians, with y pointing\nup. Keep moving objects roughly 0.1 to 10 metres across and convert to\npixels only when drawing. Create a world with <b2NewWorld>, advance it\nwith <b2Step> at a fixed time step, then read positions and events back.\n\nResults that do not fit in one value (ray hits, query rows, contact and\nsensor events, geometry, mass data, bounding boxes) are taken as a\nsnapshot by an update or query call and read back with small getters;\ntheir indices are 1-based. The b2k Kit (box2dxt-kit.livecodescript) is a\nhigher-level layer over this binding that works in pixels and degrees.",
			"description":"Bindings to Box2D v3.1, a fast 2D rigid-body physics engine.\n\nA world holds bodies; a body carries shapes (its collision geometry and\nmaterial) and can be linked to other bodies by joints. Worlds, bodies,\nshapes, joints and chains are integer handles. 0 means a call failed or\nfound nothing, and a stale handle is a harmless no-op: getters return 0,\nactions do nothing.\n\nEvery distance is in metres and every angle in radians, with y pointing\nup. Keep moving objects roughly 0.1 to 10 metres across and convert to\npixels only when drawing. Create a world with <b2NewWorld>, advance it\nwith <b2Step> at a fixed time step, then read positions and events back.\n\nResults that do not fit in one value (ray hits, query rows, contact and\nsensor events, geometry, mass data, bounding boxes) are taken as a\nsnapshot by an update or query call and read back with small getters;\ntheir indices are 1-based. The b2k Kit (box2dxt-kit.livecodescript) is a\nhigher-level layer over this binding that works in pixels and degrees."
		},{
			"id":"org.openxtalk.box2dxt-2",
			"name":"b2bodyangularvelocity",
			"display name":"b2BodyAngularVelocity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyAngularVelocity(<pBody>)"
			],
			"display syntax":[
				"b2BodyAngularVelocity(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's angular velocity.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyAngularVelocity(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in radians per second."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetAngularVelocity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-3",
			"name":"b2setshapedensity",
			"display name":"b2SetShapeDensity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeDensity(<pShape>,<pDensity>)"
			],
			"display syntax":[
				"b2SetShapeDensity(<i>pShape</i>,<i>pDensity</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a shape's density.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"The density in kg/m^2, 0 or more."
			}],
			"examples":[{
				"script":"b2SetShapeDensity tShape, 0.5"
			}],
			"description":"The body's mass is recomputed. A negative or non-finite value is\nignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeDensity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-4",
			"name":"b2aabblowerx",
			"display name":"b2AABBLowerX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AABBLowerX()"
			],
			"display syntax":[
				"b2AABBLowerX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the lower x (left edge) of the bounding box snapshot.",
			"examples":[{
				"script":"b2BodyAABBUpdate tBody\nput b2AABBLowerX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in world metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyAABBUpdate> or <b2ShapeAABBUpdate>.",
			"references":{
				"handler":["b2BodyAABBUpdate","b2ShapeAABBUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-5",
			"name":"b2bodylocalpointvelocityy",
			"display name":"b2BodyLocalPointVelocityY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalPointVelocityY(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyLocalPointVelocityY(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the world y velocity of a body at a point given in its local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the point, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalPointVelocityY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y velocity in m/s."
			}],
			"description":"Includes the spin's contribution as well as the linear velocity. A stale\nor 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalPointVelocityX","b2BodyWorldPointVelocityY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-6",
			"name":"b2revolutespringdamping",
			"display name":"b2RevoluteSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSpringDamping(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteSpringDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteSpringDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSetSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-7",
			"name":"b2applyangularimpulse",
			"display name":"b2ApplyAngularImpulse",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyAngularImpulse(<pBody>,<pImpulse>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyAngularImpulse(<i>pBody</i>,<i>pImpulse</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply an angular impulse to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pImpulse",
				"type":"",
				"refparam":"false",
				"description":"The angular impulse; positive is counter-clockwise."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyAngularImpulse tBody, 1.5, true"
			}],
			"description":"Changes the spin at once. A non-finite value is ignored. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyTorque","b2SetAngularVelocity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-8",
			"name":"b2shapedeffilter",
			"display name":"b2ShapeDefFilter",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefFilter(<pCategory>,<pMask>,<pGroup>)"
			],
			"display syntax":[
				"b2ShapeDefFilter(<i>pCategory</i>,<i>pMask</i>,<i>pGroup</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the collision filter for the next shape.",
			"parameters":[{
				"name":"pCategory",
				"type":"",
				"refparam":"false",
				"description":"The category bits this shape belongs to (0 to 2^53-1)."
			},{
				"name":"pMask",
				"type":"",
				"refparam":"false",
				"description":"The category bits this shape collides with (0 to 2^53-1)."
			},{
				"name":"pGroup",
				"type":"",
				"refparam":"false",
				"description":"The group index: shapes sharing a positive group always collide,\na shared negative group never do; 0 means no group."
			}],
			"examples":[{
				"script":"b2ShapeDefFilter 2, 1, 0\nput b2AddCircle(tBody, 0, 0, 0.2, 1, 0, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared. It\nalso applies to the next <b2CreateChain>. An out-of-range or non-finite\ncategory or mask makes the call ignored.",
			"references":{
				"handler":["b2SetShapeFilter","b2ShapeFilterCategory"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-9",
			"name":"b2setjointtuning",
			"display name":"b2SetJointTuning",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetJointTuning(<pWorld>,<pHertz>,<pDamping>)"
			],
			"display syntax":[
				"b2SetJointTuning(<i>pWorld</i>,<i>pHertz</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Tune how soft a world's joints are.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The joint stiffness in hertz, 0 or more."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The joint damping ratio, 0 or more."
			}],
			"examples":[{
				"script":"b2SetJointTuning tWorld, 60, 2"
			}],
			"description":"Advanced solver tuning. The call is ignored when a value is negative or\nnot finite. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2SetContactTuning"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-10",
			"name":"b2iswarmstartingenabled",
			"display name":"b2IsWarmStartingEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2IsWarmStartingEnabled(<pWorld>)"
			],
			"display syntax":[
				"b2IsWarmStartingEnabled(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a world uses warm starting.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2IsWarmStartingEnabled(tWorld) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if warm starting is on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2EnableWarmStarting"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-11",
			"name":"b2enablesleeping",
			"display name":"b2EnableSleeping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableSleeping(<pWorld>,<pFlag>)"
			],
			"display syntax":[
				"b2EnableSleeping(<i>pWorld</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn sleeping on or off for a whole world.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to let resting bodies sleep, false to keep every body awake."
			}],
			"examples":[{
				"script":"b2EnableSleeping tWorld, false"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2IsSleepingEnabled","b2EnableSleep"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-12",
			"name":"b2setmaximumlinearspeed",
			"display name":"b2SetMaximumLinearSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetMaximumLinearSpeed(<pWorld>,<pValue>)"
			],
			"display syntax":[
				"b2SetMaximumLinearSpeed(<i>pWorld</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the top speed of any body in a world.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The speed limit in m/s; must be above 0."
			}],
			"examples":[{
				"script":"b2SetMaximumLinearSpeed tWorld, 100"
			}],
			"description":"A value that is not above 0 is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2MaximumLinearSpeed"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-13",
			"name":"b2shapesensorcapacity",
			"display name":"b2ShapeSensorCapacity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSensorCapacity(<pShape>)"
			],
			"display syntax":[
				"b2ShapeSensorCapacity(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many overlaps a sensor shape may report.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeSensorCapacity(tZone) into tMax"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Box2D's capacity for the sensor's overlap list; 0 for a stale\nhandle."
			}],
			"description":"An upper bound on what <b2ShapeSensorOverlapsUpdate> can return.",
			"references":{
				"handler":["b2ShapeSensorOverlapsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-14",
			"name":"b2jointlocalanchorax",
			"display name":"b2JointLocalAnchorAX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointLocalAnchorAX(<pJoint>)"
			],
			"display syntax":[
				"b2JointLocalAnchorAX(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the anchor on body A, in that body's local frame.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointLocalAnchorAX(tJoint) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2JointBodyA","b2BodyWorldPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-15",
			"name":"b2sensorendsensorshape",
			"display name":"b2SensorEndSensorShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorEndSensorShape(<pIndex>)"
			],
			"display syntax":[
				"b2SensorEndSensorShape(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the sensor shape of an overlap that ended.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2SensorEndCount>."
			}],
			"examples":[{
				"script":"put b2SensorEndSensorShape(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2SensorsUpdate>. A shape destroyed before\nthe snapshot reads 0.",
			"references":{
				"handler":["b2SensorEndVisitorShape","b2SensorEndCount","b2SensorsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-16",
			"name":"b2destroyworld",
			"display name":"b2DestroyWorld",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DestroyWorld(<pWorld>)"
			],
			"display syntax":[
				"b2DestroyWorld(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Destroy a world and everything in it.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"b2DestroyWorld tWorld\nput 0 into tWorld"
			}],
			"description":"Every body, shape, joint and chain in the world goes with it, and their\nhandles become stale (harmless no-ops). A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2NewWorld"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-17",
			"name":"b2shapebody",
			"display name":"b2ShapeBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeBody(<pShape>)"
			],
			"display syntax":[
				"b2ShapeBody(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the body a shape belongs to.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeBody(tShape) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle, or 0 for a stale shape."
			}],
			"description":"Useful when a query or sensor event hands you a shape.",
			"references":{
				"handler":["b2BodyShapeCount","b2QueryShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-18",
			"name":"b2shapecontacteventsenabled",
			"display name":"b2ShapeContactEventsEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeContactEventsEnabled(<pShape>)"
			],
			"display syntax":[
				"b2ShapeContactEventsEnabled(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a shape has begin and end contact events enabled.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeContactEventsEnabled(tShape) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if begin and end contact events are on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2ShapeEnableContactEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-19",
			"name":"b2worldshapecount",
			"display name":"b2WorldShapeCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldShapeCount()"
			],
			"display syntax":[
				"b2WorldShapeCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many shapes the counters snapshot holds.",
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldShapeCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count."
			}],
			"description":"Reads the snapshot taken by <b2WorldCountersUpdate>.",
			"references":{
				"handler":["b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-20",
			"name":"b2wheelismotorenabled",
			"display name":"b2WheelIsMotorEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelIsMotorEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2WheelIsMotorEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a wheel joint's drive motor is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelIsMotorEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the motor is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a wheel joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2WheelEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-21",
			"name":"b2motorsetcorrectionfactor",
			"display name":"b2MotorSetCorrectionFactor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorSetCorrectionFactor(<pJoint>,<pFactor>)"
			],
			"display syntax":[
				"b2MotorSetCorrectionFactor(<i>pJoint</i>,<i>pFactor</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set how quickly a motor joint corrects position error.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pFactor",
				"type":"",
				"refparam":"false",
				"description":"The correction factor; Box2D expects 0 to 1."
			}],
			"examples":[{
				"script":"b2MotorSetCorrectionFactor tMotor, 0.3"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2MotorCorrectionFactor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-22",
			"name":"b2revoluteenablespring",
			"display name":"b2RevoluteEnableSpring",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteEnableSpring(<pJoint>,<pFlag>)"
			],
			"display syntax":[
				"b2RevoluteEnableSpring(<i>pJoint</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn a revolute joint's rotational spring on or off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to turn the spring on."
			}],
			"examples":[{
				"script":"b2RevoluteEnableSpring tJoint, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op. The shim checks that the handle\nis a live joint, not that it is a revolute joint; check <b2JointType>\nwhen unsure.",
			"references":{
				"handler":["b2RevoluteSetSpringHertz","b2RevoluteIsSpringEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-23",
			"name":"b2bodymovecount",
			"display name":"b2BodyMoveCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveCount()"
			],
			"display syntax":[
				"b2BodyMoveCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many bodies the move snapshot holds.",
			"examples":[{
				"script":"put b2BodyMoveCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count from the last <b2BodiesUpdate>."
			}],
			"description":"The same number <b2BodiesUpdate> returned.",
			"references":{
				"handler":["b2BodiesUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-24",
			"name":"b2worldprofilesensors",
			"display name":"b2WorldProfileSensors",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileSensors()"
			],
			"display syntax":[
				"b2WorldProfileSensors()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on updating sensors.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileSensors() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-25",
			"name":"b2motorcorrectionfactor",
			"display name":"b2MotorCorrectionFactor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorCorrectionFactor(<pJoint>)"
			],
			"display syntax":[
				"b2MotorCorrectionFactor(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a motor joint's correction factor.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorCorrectionFactor(tMotor) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The correction factor."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetCorrectionFactor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-26",
			"name":"b2revolutesetspringdamping",
			"display name":"b2RevoluteSetSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSetSpringDamping(<pJoint>,<pDamping>)"
			],
			"display syntax":[
				"b2RevoluteSetSpringDamping(<i>pJoint</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a revolute joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio, 0 or more."
			}],
			"examples":[{
				"script":"b2RevoluteSetSpringDamping tJoint, 0.5"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-27",
			"name":"b2worldprofileupdate",
			"display name":"b2WorldProfileUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileUpdate(<pWorld>)"
			],
			"display syntax":[
				"b2WorldProfileUpdate(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot the timings of a world's last step.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileStep() into tMs"
			}],
			"description":"Then read the timings with <b2WorldProfileStep>, <b2WorldProfilePairs>,\n<b2WorldProfileCollide>, <b2WorldProfileSolve>, <b2WorldProfileRefit>\nand <b2WorldProfileSensors>. A stale world zeroes the snapshot.",
			"references":{
				"handler":["b2WorldProfileStep","b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-28",
			"name":"b2bodygravityscale",
			"display name":"b2BodyGravityScale",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyGravityScale(<pBody>)"
			],
			"display syntax":[
				"b2BodyGravityScale(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's gravity scale.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyGravityScale(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value."
			}],
			"description":"1 is normal gravity, 0 none. Set it with <b2SetGravityScale>. A stale or\n0 handle returns 0.",
			"references":{
				"handler":["b2SetGravityScale"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-29",
			"name":"b2wheelspringdamping",
			"display name":"b2WheelSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelSpringDamping(<pJoint>)"
			],
			"display syntax":[
				"b2WheelSpringDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's suspension damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelSpringDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-30",
			"name":"b2jointlocalanchorbx",
			"display name":"b2JointLocalAnchorBX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointLocalAnchorBX(<pJoint>)"
			],
			"display syntax":[
				"b2JointLocalAnchorBX(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the anchor on body B, in that body's local frame.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointLocalAnchorBX(tJoint) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2JointBodyA","b2BodyWorldPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-31",
			"name":"b2wheelmotortorque",
			"display name":"b2WheelMotorTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelMotorTorque(<pJoint>)"
			],
			"display syntax":[
				"b2WheelMotorTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the torque a wheel joint's motor applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelMotorTorque(tJoint) into tTorque"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torque in newton-metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelMaxMotorTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-32",
			"name":"b2queryfraction",
			"display name":"b2QueryFraction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryFraction(<pIndex>)"
			],
			"display syntax":[
				"b2QueryFraction(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how far along the cast a query row's hit was.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryFraction(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A fraction from 0 to 1, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query. Filled only by <b2RayCastAll>\nand <b2ShapeCast>.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-33",
			"name":"b2shapedefmaterialid",
			"display name":"b2ShapeDefMaterialId",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefMaterialId(<pId>)"
			],
			"display syntax":[
				"b2ShapeDefMaterialId(<i>pId</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the user material id for the next shape.",
			"parameters":[{
				"name":"pId",
				"type":"",
				"refparam":"false",
				"description":"An integer of your choosing, for example to pick a sound or effect."
			}],
			"examples":[{
				"script":"b2ShapeDefMaterialId 3\nput b2AddBox(tBody, 1, 0.2, 1, 0.5, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared.",
			"references":{
				"handler":["b2ShapeMaterialId","b2SetShapeMaterialId"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-34",
			"name":"b2jointbodyb",
			"display name":"b2JointBodyB",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointBodyB(<pJoint>)"
			],
			"display syntax":[
				"b2JointBodyB(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a joint's second body.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointBodyB(tJoint) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 for a stale joint."
			}],
			"description":"Return a joint's second body.",
			"references":{
				"handler":["b2JointBodyA"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-35",
			"name":"b2createchain",
			"display name":"b2CreateChain",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2CreateChain(<pBody>,<pLoop>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2CreateChain(<i>pBody</i>,<i>pLoop</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a chain of smooth, one-sided segments on a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle, usually a static body."
			},{
				"name":"pLoop",
				"type":"",
				"refparam":"false",
				"description":"true to close the chain into a loop."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction of every segment."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The restitution of every segment."
			}],
			"examples":[{
				"script":"b2ChainBegin\nrepeat with i = 0 to 20\n   b2ChainAddPoint i, sin(i / 3)\nend repeat\nput b2CreateChain(tGround, false, 0.7, 0) into tTerrain"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A chain handle, or 0 when the body is stale or fewer than 4\npoints were added."
			}],
			"description":"Chains are the primitive for terrain and one-sided platforms: bodies\nslide across the joins without catching. A chain needs at least 4\npoints. In an open chain the first and last points are ghost vertices\nthat only shape the ends, so n points give n-3 collidable segments.\n\nOf the pending shape-def options only the collision filter\n(<b2ShapeDefFilter>) applies; all are cleared. Sensor events are on for\nthe segments, so sensors detect terrain.",
			"references":{
				"handler":["b2ChainBegin","b2DestroyChain","b2ChainSegmentCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-36",
			"name":"b2shapecast",
			"display name":"b2ShapeCast",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCast(<pWorld>,<pRadius>,<pDx>,<pDy>)"
			],
			"display syntax":[
				"b2ShapeCast(<i>pWorld</i>,<i>pRadius</i>,<i>pDx</i>,<i>pDy</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Sweep a shape from the vertex builder through a world and gather the hits.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"A rounding radius added around the points, in metres."
			},{
				"name":"pDx",
				"type":"",
				"refparam":"false",
				"description":"The x of the sweep's translation in metres."
			},{
				"name":"pDy",
				"type":"",
				"refparam":"false",
				"description":"The y of the sweep's translation in metres."
			}],
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint tX, tY\nput b2ShapeCast(tWorld, 0.5, 0, -10) into tCount\nif tCount > 0 then put b2QueryFraction(1) into tFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of hits; 0 when the vertex builder is empty."
			}],
			"description":"Builds a proxy from the points added with <b2PolyBegin> and\n<b2PolyAddPoint> (world coordinates) and moves it by the translation.\nThe rows are sorted near to far and carry the hit point, normal and\nfraction. Each query clears the shared result rows and returns how many\nit found; read them with <b2QueryBody>, <b2QueryShape> and the other\nb2Query handlers (1-based). A stale world returns 0.",
			"references":{
				"handler":["b2PolyBegin","b2OverlapShape","b2QueryFraction"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-37",
			"name":"b2restitutionthreshold",
			"display name":"b2RestitutionThreshold",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RestitutionThreshold(<pWorld>)"
			],
			"display syntax":[
				"b2RestitutionThreshold(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a world's restitution threshold.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2RestitutionThreshold(tWorld) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The threshold in m/s."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetRestitutionThreshold"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-38",
			"name":"b2bodyworldcenterx",
			"display name":"b2BodyWorldCenterX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldCenterX(<pBody>)"
			],
			"display syntax":[
				"b2BodyWorldCenterX(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x position of a body's centre of mass in world coordinates.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyWorldCenterX(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Differs from <b2BodyX> when the shapes sit off the body's origin. A\nstale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldCenterY","b2BodyLocalCenterX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-39",
			"name":"b2shapeenablesensorevents",
			"display name":"b2ShapeEnableSensorEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeEnableSensorEvents(<pShape>,<pFlag>)"
			],
			"display syntax":[
				"b2ShapeEnableSensorEvents(<i>pShape</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn sensor events on or off for a shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable sensor events."
			}],
			"examples":[{
				"script":"b2ShapeEnableSensorEvents tShape, true"
			}],
			"description":"Both a sensor and the shape visiting it need sensor events. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeSensorEventsEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-40",
			"name":"b2prismaticmotorforce",
			"display name":"b2PrismaticMotorForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticMotorForce(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticMotorForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the force a prismatic joint's motor applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticMotorForce(tJoint) into tForce"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticMaxMotorForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-41",
			"name":"b2setshaperestitution",
			"display name":"b2SetShapeRestitution",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeRestitution(<pShape>,<pRestitution>)"
			],
			"display syntax":[
				"b2SetShapeRestitution(<i>pShape</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a shape's restitution (bounciness).",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The restitution, 0 or more (usually 0 to 1)."
			}],
			"examples":[{
				"script":"b2SetShapeRestitution tShape, 0.5"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2ShapeRestitution"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-42",
			"name":"b2shapesegmenty1",
			"display name":"b2ShapeSegmentY1",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSegmentY1()"
			],
			"display syntax":[
				"b2ShapeSegmentY1()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of the segment's first end from the segment snapshot.",
			"examples":[{
				"script":"b2ShapeSegmentUpdate tShape\nput b2ShapeSegmentY1() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeSegmentUpdate>.",
			"references":{
				"handler":["b2ShapeSegmentUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-43",
			"name":"b2destroyshape",
			"display name":"b2DestroyShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DestroyShape(<pShape>)"
			],
			"display syntax":[
				"b2DestroyShape(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Remove a shape from its body.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2DestroyShape tShape\nput 0 into tShape"
			}],
			"description":"The body's mass is updated. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2AddBox","b2DestroyBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-44",
			"name":"b2bodyangle",
			"display name":"b2BodyAngle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyAngle(<pBody>)"
			],
			"display syntax":[
				"b2BodyAngle(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's rotation.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyAngle(tBody) * 180 / pi into tDegrees"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in radians."
			}],
			"description":"Convert to degrees for drawing. The simulation's angle is\ncounter-clockwise with y up. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyX","b2SetTransform"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-45",
			"name":"b2settransform",
			"display name":"b2SetTransform",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetTransform(<pBody>,<pX>,<pY>,<pAngle>)"
			],
			"display syntax":[
				"b2SetTransform(<i>pBody</i>,<i>pX</i>,<i>pY</i>,<i>pAngle</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Move a body to a new position and angle at once.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The new x position in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The new y position in metres."
			},{
				"name":"pAngle",
				"type":"",
				"refparam":"false",
				"description":"The new rotation in radians."
			}],
			"examples":[{
				"script":"b2SetTransform tBody, 0, 10, 0"
			}],
			"description":"A teleport: the body does not travel there, so it can end up overlapping\nothers. To move a kinematic body smoothly use <b2SetTargetTransform>. A\nnon-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2SetTargetTransform","b2BodyX","b2BodyAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-46",
			"name":"b2bodyenablehitevents",
			"display name":"b2BodyEnableHitEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyEnableHitEvents(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2BodyEnableHitEvents(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn hit events on or off for every shape of a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable hit events."
			}],
			"examples":[{
				"script":"b2BodyEnableHitEvents tBall, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeEnableHitEvents","b2ContactHitCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-47",
			"name":"b2shapecircleupdate",
			"display name":"b2ShapeCircleUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCircleUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeCircleUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a circle shape's geometry.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2ShapeCircleUpdate tShape\nput b2ShapeCircleRadius() into tRadius"
			}],
			"description":"Read it with <b2ShapeCircleX>, <b2ShapeCircleY> and\n<b2ShapeCircleRadius>. A shape of another type, or a stale handle, reads\nall zeros.",
			"references":{
				"handler":["b2ShapeCircleRadius","b2ShapeType"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-48",
			"name":"b2shapecapsulex2",
			"display name":"b2ShapeCapsuleX2",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleX2()"
			],
			"display syntax":[
				"b2ShapeCapsuleX2()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of the capsule's second centre from the capsule snapshot.",
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleX2() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCapsuleUpdate>.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-49",
			"name":"b2jointconstrainttorque",
			"display name":"b2JointConstraintTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointConstraintTorque(<pJoint>)"
			],
			"display syntax":[
				"b2JointConstraintTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the torque a joint applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"if abs(b2JointConstraintTorque(tJoint)) > 500 then b2DestroyJoint tJoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in newton-metres."
			}],
			"description":"Compare it against a threshold to make a breakable joint. A stale or 0\nhandle returns 0.",
			"references":{
				"handler":["b2JointConstraintForceX","b2DestroyJoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-50",
			"name":"b2motorlinearoffsety",
			"display name":"b2MotorLinearOffsetY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorLinearOffsetY(<pJoint>)"
			],
			"display syntax":[
				"b2MotorLinearOffsetY(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a motor joint's target offset.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorLinearOffsetY(tMotor) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The offset in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetLinearOffset"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-51",
			"name":"b2setlineardamping",
			"display name":"b2SetLinearDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetLinearDamping(<pBody>,<pDamping>)"
			],
			"display syntax":[
				"b2SetLinearDamping(<i>pBody</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set how quickly a body's linear velocity dies away.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The linear damping, 0 or more; 0 means none."
			}],
			"examples":[{
				"script":"b2SetLinearDamping tBody, 0.5"
			}],
			"description":"Damping slows a body even in empty space, like air drag. A negative or\nnon-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyLinearDamping","b2SetAngularDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-52",
			"name":"b2setshapecapsule",
			"display name":"b2SetShapeCapsule",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeCapsule(<pShape>,<pX1>,<pY1>,<pX2>,<pY2>,<pRadius>)"
			],
			"display syntax":[
				"b2SetShapeCapsule(<i>pShape</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>,<i>pRadius</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Replace a shape's geometry with a capsule.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The local x of the first centre in metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The local y of the first centre."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The local x of the second centre."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The local y of the second centre."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius in metres; must be above 0."
			}],
			"examples":[{
				"script":"b2SetShapeCapsule tShape, 0, -0.5, 0, 0.5, 0.3"
			}],
			"description":"The shape's type follows the write. The call is ignored unless the\nhandle is live, the numbers finite, the radius above 0 and the two\ncentres different.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate","b2AddCapsule"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-53",
			"name":"b2bodyworldpointvelocityx",
			"display name":"b2BodyWorldPointVelocityX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldPointVelocityX(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyWorldPointVelocityX(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x velocity of a body at a world point.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the point, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldPointVelocityX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x velocity in m/s."
			}],
			"description":"Includes the spin's contribution as well as the linear velocity. A stale\nor 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldPointVelocityY","b2BodyLocalPointVelocityX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-54",
			"name":"b2overlapshape",
			"display name":"b2OverlapShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2OverlapShape(<pWorld>,<pRadius>)"
			],
			"display syntax":[
				"b2OverlapShape(<i>pWorld</i>,<i>pRadius</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find every shape that overlaps a shape built from the vertex builder.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"A rounding radius added around the points, in metres (0 for\nsharp corners)."
			}],
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint 0, 0\nb2PolyAddPoint 2, 0\nb2PolyAddPoint 1, 2\nput b2OverlapShape(tWorld, 0) into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of shapes found; 0 when the vertex builder is empty."
			}],
			"description":"Add the points in world coordinates with <b2PolyBegin> and\n<b2PolyAddPoint>; one point with a radius is a circle, two make a\ncapsule. The rows carry no point or normal. Each query clears the shared\nresult rows and returns how many it found; read them with <b2QueryBody>,\n<b2QueryShape> and the other b2Query handlers (1-based). A stale world\nreturns 0.",
			"references":{
				"handler":["b2PolyBegin","b2ShapeCast","b2QueryShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-55",
			"name":"b2bodyisenabled",
			"display name":"b2BodyIsEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyIsEnabled(<pBody>)"
			],
			"display syntax":[
				"b2BodyIsEnabled(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a body takes part in the simulation.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"if not b2BodyIsEnabled(tBody) then b2EnableBody tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if enabled, false if disabled."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2EnableBody","b2DisableBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-56",
			"name":"b2bodymoveangle",
			"display name":"b2BodyMoveAngle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveAngle(<pIndex>)"
			],
			"display syntax":[
				"b2BodyMoveAngle(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the new angle of a moved body.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based move index, from 1 to <b2BodyMoveCount>."
			}],
			"examples":[{
				"script":"put b2BodyMoveAngle(i) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle in radians, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodiesUpdate>.",
			"references":{
				"handler":["b2BodiesUpdate","b2BodyMoveBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-57",
			"name":"b2massdatacentery",
			"display name":"b2MassDataCenterY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MassDataCenterY()"
			],
			"display syntax":[
				"b2MassDataCenterY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the centre of mass from the mass data snapshot.",
			"examples":[{
				"script":"b2BodyMassDataUpdate tBody\nput b2MassDataCenterY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local y in metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyMassDataUpdate> or\n<b2ShapeMassDataUpdate>.",
			"references":{
				"handler":["b2BodyMassDataUpdate","b2ShapeMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-58",
			"name":"b2shapetype",
			"display name":"b2ShapeType",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeType(<pShape>)"
			],
			"display syntax":[
				"b2ShapeType(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's type code.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"if b2ShapeType(tShape) is 3 then get b2ShapePolygonUpdate(tShape)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 circle, 1 capsule, 2 segment, 3 polygon, 4 chain segment."
			}],
			"description":"A stale handle also reads 0, the same as a circle.",
			"references":{
				"handler":["b2ShapeCircleUpdate","b2ShapePolygonUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-59",
			"name":"b2sensorbegincount",
			"display name":"b2SensorBeginCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorBeginCount()"
			],
			"display syntax":[
				"b2SensorBeginCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many overlaps began in the sensor snapshot.",
			"examples":[{
				"script":"put b2SensorBeginCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The begin count from the last <b2SensorsUpdate>."
			}],
			"description":"The same number <b2SensorsUpdate> returned.",
			"references":{
				"handler":["b2SensorsUpdate","b2SensorBeginSensorShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-60",
			"name":"b2shapepolygonupdate",
			"display name":"b2ShapePolygonUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapePolygonUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapePolygonUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a polygon shape's vertices.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ShapePolygonUpdate(tShape)\n   put b2ShapePolygonVertexX(i), b2ShapePolygonVertexY(i) & cr after tPoints\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The vertex count, or 0 for a non-polygon or a stale handle."
			}],
			"description":"Read the vertices with <b2ShapePolygonVertexX> and\n<b2ShapePolygonVertexY>, in the body's local frame. A failed update does\nNOT reset the radius, so read <b2ShapePolygonRadius> only after an\nupdate that returned a count above 0.",
			"references":{
				"handler":["b2ShapePolygonVertexX","b2ShapePolygonCount","b2ShapePolygonRadius"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-61",
			"name":"b2revoluteisspringenabled",
			"display name":"b2RevoluteIsSpringEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteIsSpringEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteIsSpringEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a revolute joint's spring is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteIsSpringEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the spring is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a revolute joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2RevoluteEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-62",
			"name":"b2setfixedrotation",
			"display name":"b2SetFixedRotation",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetFixedRotation(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2SetFixedRotation(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Stop a body rotating, or let it rotate again.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to lock the rotation."
			}],
			"examples":[{
				"script":"b2SetFixedRotation tPlayer, true"
			}],
			"description":"Handy for platformer characters that must stay upright. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2BodyIsFixedRotation"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-63",
			"name":"b2shapematerialid",
			"display name":"b2ShapeMaterialId",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeMaterialId(<pShape>)"
			],
			"display syntax":[
				"b2ShapeMaterialId(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's user material id.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeMaterialId(tShape) into tMaterial"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The material id."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeMaterialId","b2ShapeDefMaterialId"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-64",
			"name":"b2shapesensoreventsenabled",
			"display name":"b2ShapeSensorEventsEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSensorEventsEnabled(<pShape>)"
			],
			"display syntax":[
				"b2ShapeSensorEventsEnabled(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a shape has sensor events enabled.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeSensorEventsEnabled(tShape) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if sensor events are on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2ShapeEnableSensorEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-65",
			"name":"b2raynormalx",
			"display name":"b2RayNormalX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayNormalX()"
			],
			"display syntax":[
				"b2RayNormalX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the surface normal at the last ray hit.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayNormalX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's x component, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-66",
			"name":"b2mousesetspringhertz",
			"display name":"b2MouseSetSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSetSpringHertz(<pJoint>,<pHertz>)"
			],
			"display syntax":[
				"b2MouseSetSpringHertz(<i>pJoint</i>,<i>pHertz</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set how stiffly a mouse joint's body follows the target.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The stiffness in hertz, 0 or more."
			}],
			"examples":[{
				"script":"b2MouseSetSpringHertz tDrag, 5"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseSpringHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-67",
			"name":"b2shapeenablecontactevents",
			"display name":"b2ShapeEnableContactEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeEnableContactEvents(<pShape>,<pFlag>)"
			],
			"display syntax":[
				"b2ShapeEnableContactEvents(<i>pShape</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn begin and end contact events on or off for a shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable begin and end contact events."
			}],
			"examples":[{
				"script":"b2ShapeEnableContactEvents tShape, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeContactEventsEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-68",
			"name":"b2enablecontinuous",
			"display name":"b2EnableContinuous",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableContinuous(<pWorld>,<pFlag>)"
			],
			"display syntax":[
				"b2EnableContinuous(<i>pWorld</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn continuous collision on or off for a whole world.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to stop fast bodies tunnelling through static geometry."
			}],
			"examples":[{
				"script":"b2EnableContinuous tWorld, true"
			}],
			"description":"For a single fast dynamic body against other dynamic bodies, see\n<b2SetBullet>. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2IsContinuousEnabled","b2SetBullet"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-69",
			"name":"b2bodyjointcount",
			"display name":"b2BodyJointCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyJointCount(<pBody>)"
			],
			"display syntax":[
				"b2BodyJointCount(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a body's joints and return how many there are.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2BodyJointCount(tBody)\n   put b2BodyJointAt(i) & cr after tJoints\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of joints; 0 for a stale body."
			}],
			"description":"Read each one with <b2BodyJointAt>.",
			"references":{
				"handler":["b2BodyJointAt","b2JointBodyA"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-70",
			"name":"b2setshapefilter",
			"display name":"b2SetShapeFilter",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeFilter(<pShape>,<pCategory>,<pMask>,<pGroup>)"
			],
			"display syntax":[
				"b2SetShapeFilter(<i>pShape</i>,<i>pCategory</i>,<i>pMask</i>,<i>pGroup</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a shape's collision filter.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pCategory",
				"type":"",
				"refparam":"false",
				"description":"The category bits this shape belongs to (0 to 2^53-1)."
			},{
				"name":"pMask",
				"type":"",
				"refparam":"false",
				"description":"The category bits it collides with (0 to 2^53-1)."
			},{
				"name":"pGroup",
				"type":"",
				"refparam":"false",
				"description":"The group index: a shared positive group always collides, a\nshared negative group never does; 0 means none."
			}],
			"examples":[{
				"script":"b2SetShapeFilter tShape, 4, 1, 0"
			}],
			"description":"The whole call is ignored when the category or mask is out of range or\nnot finite. A default mask reads back as 2^64-1, so clamp it before\nwriting it back; xTalk's bitAnd and bitOr are 32-bit anyway. A stale or\n0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeFilterCategory","b2ShapeFilterMask","b2ShapeDefFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-71",
			"name":"b2distancelength",
			"display name":"b2DistanceLength",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceLength(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceLength(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's rest length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceLength(tRope) into tLength"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The rest length in metres."
			}],
			"description":"This is the length <b2DistanceSetLength> sets; <b2DistanceCurrentLength>\nis the live separation. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2DistanceSetLength","b2DistanceCurrentLength"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-72",
			"name":"b2revoluteangle",
			"display name":"b2RevoluteAngle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteAngle(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteAngle(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's current angle.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteAngle(tHinge) into tAngle"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle of body B relative to body A, in radians."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2RevoluteJoint","b2RevoluteEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-73",
			"name":"b2setshapesegment",
			"display name":"b2SetShapeSegment",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeSegment(<pShape>,<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2SetShapeSegment(<i>pShape</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Replace a shape's geometry with a segment.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The local x of the first end in metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The local y of the first end."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The local x of the second end."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The local y of the second end."
			}],
			"examples":[{
				"script":"b2SetShapeSegment tShape, -5, 0, 5, 1"
			}],
			"description":"The shape's type follows the write. The call is ignored unless the\nhandle is live, the numbers finite and the two ends different.",
			"references":{
				"handler":["b2ShapeSegmentUpdate","b2AddSegment"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-74",
			"name":"b2destroychain",
			"display name":"b2DestroyChain",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DestroyChain(<pChain>)"
			],
			"display syntax":[
				"b2DestroyChain(<i>pChain</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Destroy a chain and its segments.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			}],
			"examples":[{
				"script":"b2DestroyChain tTerrain\nput 0 into tTerrain"
			}],
			"description":"The segment shape handles become stale too. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2CreateChain","b2ChainIsValid"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-75",
			"name":"b2setshapecircle",
			"display name":"b2SetShapeCircle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeCircle(<pShape>,<pCx>,<pCy>,<pRadius>)"
			],
			"display syntax":[
				"b2SetShapeCircle(<i>pShape</i>,<i>pCx</i>,<i>pCy</i>,<i>pRadius</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Replace a shape's geometry with a circle.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pCx",
				"type":"",
				"refparam":"false",
				"description":"The local x of the centre in metres."
			},{
				"name":"pCy",
				"type":"",
				"refparam":"false",
				"description":"The local y of the centre in metres."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius in metres; must be above 0."
			}],
			"examples":[{
				"script":"b2SetShapeCircle tShape, 0, 0, 0.75"
			}],
			"description":"The shape's type follows the write. The call is ignored unless the\nhandle is live, the numbers finite and the radius above 0.",
			"references":{
				"handler":["b2ShapeCircleUpdate","b2AddCircle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-76",
			"name":"b2bodylineardamping",
			"display name":"b2BodyLinearDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLinearDamping(<pBody>)"
			],
			"display syntax":[
				"b2BodyLinearDamping(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's linear damping.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyLinearDamping(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value."
			}],
			"description":"Set it with <b2SetLinearDamping>. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetLinearDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-77",
			"name":"b2rayy",
			"display name":"b2RayY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayY()"
			],
			"display syntax":[
				"b2RayY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the last closest ray's hit point.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-78",
			"name":"b2contacthitnormaly",
			"display name":"b2ContactHitNormalY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitNormalY(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitNormalY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a hit event's normal.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitNormalY(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's y component, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-79",
			"name":"b2worldcountersupdate",
			"display name":"b2WorldCountersUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldCountersUpdate(<pWorld>)"
			],
			"display syntax":[
				"b2WorldCountersUpdate(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a world's object counts.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldBodyCount() into tBodies"
			}],
			"description":"Then read them with <b2WorldBodyCount>, <b2WorldShapeCount>,\n<b2WorldContactCount>, <b2WorldJointCount> and <b2WorldIslandCount>. A\nstale world zeroes the snapshot.",
			"references":{
				"handler":["b2WorldBodyCount","b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-80",
			"name":"b2bodyy",
			"display name":"b2BodyY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyY(<pBody>)"
			],
			"display syntax":[
				"b2BodyY(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y position of a body's origin.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put -b2BodyY(tBody) * 40 into tPixelY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Read it after <b2Step>. The simulation's y points up while the screen's\npoints down, so flip it when drawing. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyX","b2BodyAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-81",
			"name":"b2bodylocalvectorx",
			"display name":"b2BodyLocalVectorX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalVectorX(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyLocalVectorX(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Rotate a world vector into a body's frame and return its x.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the vector, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the vector, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalVectorX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local x component."
			}],
			"description":"Only the rotation applies, not the position. A stale or 0 handle returns\n0.",
			"references":{
				"handler":["b2BodyLocalVectorY","b2BodyWorldVectorX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-82",
			"name":"b2contacthitx",
			"display name":"b2ContactHitX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitX(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a hit event's impact point.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitX(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-83",
			"name":"b2shapecapsuleradius",
			"display name":"b2ShapeCapsuleRadius",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleRadius()"
			],
			"display syntax":[
				"b2ShapeCapsuleRadius()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the capsule's radius from the capsule snapshot.",
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleRadius() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCapsuleUpdate>.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-84",
			"name":"b2shapefiltergroup",
			"display name":"b2ShapeFilterGroup",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeFilterGroup(<pShape>)"
			],
			"display syntax":[
				"b2ShapeFilterGroup(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's filter group index.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeFilterGroup(tShape) into tGroup"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The group index."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-85",
			"name":"b2motorsetmaxtorque",
			"display name":"b2MotorSetMaxTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorSetMaxTorque(<pJoint>,<pTorque>)"
			],
			"display syntax":[
				"b2MotorSetMaxTorque(<i>pJoint</i>,<i>pTorque</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the most torque a motor joint may apply.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pTorque",
				"type":"",
				"refparam":"false",
				"description":"The torque in newton-metres, 0 or more."
			}],
			"examples":[{
				"script":"b2MotorSetMaxTorque tMotor, 200"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2MotorMaxTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-86",
			"name":"b2prismaticspringdamping",
			"display name":"b2PrismaticSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSpringDamping(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticSpringDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticSpringDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticSetSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-87",
			"name":"b2shapedefenablepresolveevents",
			"display name":"b2ShapeDefEnablePreSolveEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefEnablePreSolveEvents(<pFlag>)"
			],
			"display syntax":[
				"b2ShapeDefEnablePreSolveEvents(<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn pre-solve events on or off for the next shape.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable pre-solve events."
			}],
			"examples":[{
				"script":"b2ShapeDefEnablePreSolveEvents true\nput b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared. The\nbinding exposes no pre-solve callback, so this flag only matters to\nBox2D itself.",
			"references":{
				"handler":["b2ShapeEnablePreSolveEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-88",
			"name":"b2sensorbeginsensorshape",
			"display name":"b2SensorBeginSensorShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorBeginSensorShape(<pIndex>)"
			],
			"display syntax":[
				"b2SensorBeginSensorShape(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the sensor shape of an overlap that began.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2SensorBeginCount>."
			}],
			"examples":[{
				"script":"put b2SensorBeginSensorShape(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2SensorsUpdate>.",
			"references":{
				"handler":["b2SensorBeginVisitorShape","b2SensorBeginCount","b2SensorsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-89",
			"name":"b2revoluteislimitenabled",
			"display name":"b2RevoluteIsLimitEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteIsLimitEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteIsLimitEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a revolute joint's angle limit is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteIsLimitEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the limit is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a revolute joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2RevoluteEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-90",
			"name":"b2overlapcircle",
			"display name":"b2OverlapCircle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2OverlapCircle(<pWorld>,<pCx>,<pCy>,<pRadius>)"
			],
			"display syntax":[
				"b2OverlapCircle(<i>pWorld</i>,<i>pCx</i>,<i>pCy</i>,<i>pRadius</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find every shape that overlaps a circle.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pCx",
				"type":"",
				"refparam":"false",
				"description":"The x of the centre in world metres."
			},{
				"name":"pCy",
				"type":"",
				"refparam":"false",
				"description":"The y of the centre in world metres."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius in metres."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2OverlapCircle(tWorld, tX, tY, 3)\n   b2ApplyImpulse b2QueryBody(i), 0, 2, true\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of shapes found."
			}],
			"description":"The rows carry no point or normal. Each query clears the shared result\nrows and returns how many it found; read them with <b2QueryBody>,\n<b2QueryShape> and the other b2Query handlers (1-based). A stale world\nreturns 0.",
			"references":{
				"handler":["b2OverlapShape","b2QueryBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-91",
			"name":"b2shapepolygonvertexx",
			"display name":"b2ShapePolygonVertexX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapePolygonVertexX(<pIndex>)"
			],
			"display syntax":[
				"b2ShapePolygonVertexX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of one polygon vertex from the snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based vertex index, from 1 to <b2ShapePolygonCount>."
			}],
			"examples":[{
				"script":"put b2ShapePolygonVertexX(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in metres, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ShapePolygonUpdate>.",
			"references":{
				"handler":["b2ShapePolygonUpdate","b2ShapePolygonCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-92",
			"name":"b2addcircle",
			"display name":"b2AddCircle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AddCircle(<pBody>,<pCx>,<pCy>,<pRadius>,<pDensity>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2AddCircle(<i>pBody</i>,<i>pCx</i>,<i>pCy</i>,<i>pRadius</i>,<i>pDensity</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a circle shape to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pCx",
				"type":"",
				"refparam":"false",
				"description":"The x of the centre in the body's local frame, in metres."
			},{
				"name":"pCy",
				"type":"",
				"refparam":"false",
				"description":"The y of the centre in the body's local frame, in metres."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius in metres; must be above 0."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"The density in kg/m^2; 0 makes the shape massless. A negative\nvalue counts as 0."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, usually 0 to 1. A negative value\ncounts as 0."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The bounciness, 0 (none) to 1 (full). A negative value\ncounts as 0."
			}],
			"examples":[{
				"script":"put b2AddCircle(tBall, 0, 0, 0.25, 1, 0.2, 0.6) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the body is stale or the radius is\nnot above 0."
			}],
			"description":"Any pending options from the shape-def builder (<b2ShapeDefSensor>,\n<b2ShapeDefFilter> and the rest) apply to this shape and are then\ncleared. Contact events are on by default, so <b2ContactsUpdate> sees\nthe shape.",
			"references":{
				"handler":["b2AddBox","b2AddCapsule","b2SetShapeCircle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-93",
			"name":"b2bodyvy",
			"display name":"b2BodyVY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyVY(<pBody>)"
			],
			"display syntax":[
				"b2BodyVY(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y component of a body's linear velocity.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyVY(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in m/s."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyVX","b2SetVelocity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-94",
			"name":"b2polyaddpoint",
			"display name":"b2PolyAddPoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PolyAddPoint(<pX>,<pY>)"
			],
			"display syntax":[
				"b2PolyAddPoint(<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Add one point to the vertex builder.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point in metres (the body's local frame for a polygon,\nworld coordinates for a query)."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point in metres."
			}],
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint 0, 0\nb2PolyAddPoint 1, 0\nb2PolyAddPoint 0, 1"
			}],
			"description":"The builder holds at most 8 points; extra points and non-finite values\nare ignored.",
			"references":{
				"handler":["b2PolyBegin","b2AddPolygon"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-95",
			"name":"b2worldprofilestep",
			"display name":"b2WorldProfileStep",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileStep()"
			],
			"display syntax":[
				"b2WorldProfileStep()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on the whole step.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileStep() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-96",
			"name":"b2wheelenablelimit",
			"display name":"b2WheelEnableLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelEnableLimit(<pJoint>,<pFlag>)"
			],
			"display syntax":[
				"b2WheelEnableLimit(<i>pJoint</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn a wheel joint's suspension travel limit on or off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to turn the limit on."
			}],
			"examples":[{
				"script":"b2WheelSetLimits tJoint, -0.2, 0.2\nb2WheelEnableLimit tJoint, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op. The shim checks that the handle\nis a live joint, not that it is a wheel joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2WheelSetLimits","b2WheelIsLimitEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-97",
			"name":"b2step",
			"display name":"b2Step",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2Step(<pWorld>,<pDt>,<pSubSteps>)"
			],
			"display syntax":[
				"b2Step(<i>pWorld</i>,<i>pDt</i>,<i>pSubSteps</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Advance the simulation by one time step.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pDt",
				"type":"",
				"refparam":"false",
				"description":"The time step in seconds, for example 1/60."
			},{
				"name":"pSubSteps",
				"type":"",
				"refparam":"false",
				"description":"The solver sub-step count; 4 is a good default (clamped to 1\nto 64)."
			}],
			"examples":[{
				"script":"b2Step tWorld, 1/60, 4"
			}],
			"description":"Drive it from a fixed time step: accumulate real elapsed time and step\nin equal chunks. Variable steps make the solver jittery and\nnon-deterministic. A step of 0 or less is ignored.\n\nAfter each step, read events with <b2ContactsUpdate>, <b2SensorsUpdate>\nand <b2BodiesUpdate>.",
			"references":{
				"handler":["b2ContactsUpdate","b2BodiesUpdate","b2NewWorld"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-98",
			"name":"b2overlapaabb",
			"display name":"b2OverlapAABB",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2OverlapAABB(<pWorld>,<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2OverlapAABB(<i>pWorld</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find every shape whose bounding box overlaps a rectangle.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of one corner in world metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of that corner."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the opposite corner."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the opposite corner."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2OverlapAABB(tWorld, 0, 0, 10, 5)\n   put b2QueryBody(i) & cr after tFound\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of shapes found."
			}],
			"description":"The corners may be given in any order. The test is against each shape's\nbounding box, so it can include shapes that only come close. The rows\ncarry no point or normal. Each query clears the shared result rows and\nreturns how many it found; read them with <b2QueryBody>, <b2QueryShape>\nand the other b2Query handlers (1-based). A stale world returns 0.",
			"references":{
				"handler":["b2QueryCount","b2QueryBody","b2OverlapCircle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-99",
			"name":"b2setchainrestitution",
			"display name":"b2SetChainRestitution",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetChainRestitution(<pChain>,<pRestitution>)"
			],
			"display syntax":[
				"b2SetChainRestitution(<i>pChain</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the restitution of every segment of a chain.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The restitution (bounciness)."
			}],
			"examples":[{
				"script":"b2SetChainRestitution tTerrain, 0.3"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ChainRestitution"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-100",
			"name":"b2setvelocity",
			"display name":"b2SetVelocity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetVelocity(<pBody>,<pVx>,<pVy>)"
			],
			"display syntax":[
				"b2SetVelocity(<i>pBody</i>,<i>pVx</i>,<i>pVy</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a body's linear velocity.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pVx",
				"type":"",
				"refparam":"false",
				"description":"The x velocity in m/s."
			},{
				"name":"pVy",
				"type":"",
				"refparam":"false",
				"description":"The y velocity in m/s."
			}],
			"examples":[{
				"script":"b2SetVelocity tBody, 0, 8"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyVX","b2ApplyImpulse"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-101",
			"name":"b2shapepolygoncount",
			"display name":"b2ShapePolygonCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapePolygonCount()"
			],
			"display syntax":[
				"b2ShapePolygonCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the vertex count of the polygon snapshot.",
			"examples":[{
				"script":"put b2ShapePolygonCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count from the last <b2ShapePolygonUpdate>."
			}],
			"description":"The same number <b2ShapePolygonUpdate> returned.",
			"references":{
				"handler":["b2ShapePolygonUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-102",
			"name":"b2shapeenablepresolveevents",
			"display name":"b2ShapeEnablePreSolveEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeEnablePreSolveEvents(<pShape>,<pFlag>)"
			],
			"display syntax":[
				"b2ShapeEnablePreSolveEvents(<i>pShape</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn pre-solve events on or off for a shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable pre-solve events."
			}],
			"examples":[{
				"script":"b2ShapeEnablePreSolveEvents tShape, false"
			}],
			"description":"There is no getter, and the binding exposes no pre-solve callback (no\nsafe way to call into script mid-step). A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2ShapeDefEnablePreSolveEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-103",
			"name":"b2enablespeculative",
			"display name":"b2EnableSpeculative",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableSpeculative(<pWorld>,<pFlag>)"
			],
			"display syntax":[
				"b2EnableSpeculative(<i>pWorld</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn speculative collision on or off.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to let the solver anticipate contacts before they touch."
			}],
			"examples":[{
				"script":"b2EnableSpeculative tWorld, true"
			}],
			"description":"There is no getter for this flag. A stale or 0 handle is a harmless\nno-op.",
			"references":{
				"handler":["b2EnableContinuous"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-104",
			"name":"b2motormaxforce",
			"display name":"b2MotorMaxForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorMaxForce(<pJoint>)"
			],
			"display syntax":[
				"b2MotorMaxForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a motor joint's force cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorMaxForce(tMotor) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetMaxForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-105",
			"name":"b2jointconstraintforcex",
			"display name":"b2JointConstraintForceX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointConstraintForceX(<pJoint>)"
			],
			"display syntax":[
				"b2JointConstraintForceX(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the force a joint applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"if abs(b2JointConstraintForceX(tJoint)) > 500 then b2DestroyJoint tJoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in newtons."
			}],
			"description":"Compare it against a threshold to make a breakable joint. A stale or 0\nhandle returns 0.",
			"references":{
				"handler":["b2JointConstraintForceY","b2JointConstraintTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-106",
			"name":"b2iscontinuousenabled",
			"display name":"b2IsContinuousEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2IsContinuousEnabled(<pWorld>)"
			],
			"display syntax":[
				"b2IsContinuousEnabled(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a world uses continuous collision.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2IsContinuousEnabled(tWorld) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if continuous collision is on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2EnableContinuous"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-107",
			"name":"b2revolutesetspringhertz",
			"display name":"b2RevoluteSetSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSetSpringHertz(<pJoint>,<pHertz>)"
			],
			"display syntax":[
				"b2RevoluteSetSpringHertz(<i>pJoint</i>,<i>pHertz</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a revolute joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The stiffness as a frequency in hertz, 0 or more."
			}],
			"examples":[{
				"script":"b2RevoluteSetSpringHertz tJoint, 2"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSpringHertz","b2RevoluteEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-108",
			"name":"b2disablebody",
			"display name":"b2DisableBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DisableBody(<pBody>)"
			],
			"display syntax":[
				"b2DisableBody(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Take a body out of the simulation without destroying it.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2DisableBody tBody"
			}],
			"description":"A disabled body does not move or collide, and keeps its shapes and\njoints until <b2EnableBody> returns it. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2EnableBody","b2BodyIsEnabled","b2DestroyBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-109",
			"name":"b2motorangularoffset",
			"display name":"b2MotorAngularOffset",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorAngularOffset(<pJoint>)"
			],
			"display syntax":[
				"b2MotorAngularOffset(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a motor joint's target angle.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorAngularOffset(tMotor) into tAngle"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle in radians."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetAngularOffset"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-110",
			"name":"b2prismaticenablespring",
			"display name":"b2PrismaticEnableSpring",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticEnableSpring(<pJoint>,<pFlag>)"
			],
			"display syntax":[
				"b2PrismaticEnableSpring(<i>pJoint</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn a prismatic joint's spring along its axis on or off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to turn the spring on."
			}],
			"examples":[{
				"script":"b2PrismaticEnableSpring tJoint, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op. The shim checks that the handle\nis a live joint, not that it is a prismatic joint; check <b2JointType>\nwhen unsure.",
			"references":{
				"handler":["b2PrismaticSetSpringHertz","b2PrismaticIsSpringEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-111",
			"name":"b2loadnativeliberror",
			"display name":"b2LoadNativeLibError",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2LoadNativeLibError()"
			],
			"display syntax":[
				"b2LoadNativeLibError()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the loader's last error message (Linux only).",
			"examples":[{
				"script":"put b2LoadNativeLibError() into tWhy"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The dlerror text, or empty if there is none."
			}],
			"description":"Tells you why <b2LoadNativeLib> returned 0: a wrong path, or a file that\ncould not be loaded. Linux only, like it.",
			"references":{
				"handler":["b2LoadNativeLib"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-112",
			"name":"b2jointtype",
			"display name":"b2JointType",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointType(<pJoint>)"
			],
			"display syntax":[
				"b2JointType(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a joint's type code.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"if b2JointType(tJoint) is 5 then put b2RevoluteAngle(tJoint) into tAngle"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 distance, 1 filter, 2 motor, 3 mouse, 4 prismatic, 5\nrevolute, 6 weld, 7 wheel."
			}],
			"description":"A stale handle ALSO reads 0, so this cannot tell a distance joint from a\ndead one. The per-type handlers check only that the handle is live, so\ncheck the type when you do not know it.",
			"references":{
				"handler":["b2JointBodyA","b2BodyJointAt"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-113",
			"name":"b2worldthreadcount",
			"display name":"b2WorldThreadCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldThreadCount(<pWorld>)"
			],
			"display syntax":[
				"b2WorldThreadCount(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many native workers a world steps with.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2WorldThreadCount(tWorld) into tThreads"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The active worker count; 1 means serial (or an unsupported\nplatform)."
			}],
			"description":"Use it after <b2NewThreadedWorld> to see whether a pool was built. A\nstale handle returns 1.",
			"references":{
				"handler":["b2NewThreadedWorld"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-114",
			"name":"b2settargettransform",
			"display name":"b2SetTargetTransform",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetTargetTransform(<pBody>,<pX>,<pY>,<pAngle>,<pTimeStep>)"
			],
			"display syntax":[
				"b2SetTargetTransform(<i>pBody</i>,<i>pX</i>,<i>pY</i>,<i>pAngle</i>,<i>pTimeStep</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Drive a kinematic body to reach a pose after a time step.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The target x in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The target y in metres."
			},{
				"name":"pAngle",
				"type":"",
				"refparam":"false",
				"description":"The target angle in radians."
			},{
				"name":"pTimeStep",
				"type":"",
				"refparam":"false",
				"description":"The time in seconds to get there, usually the next step's\nlength; must be above 0."
			}],
			"examples":[{
				"script":"b2SetTargetTransform tPlatform, tNextX, tNextY, 0, 1/60"
			}],
			"description":"Box2D sets the body's velocities so it arrives at the pose, so it pushes\nother bodies properly on the way, unlike the teleport of\n<b2SetTransform>. Use it on kinematic bodies. The call is ignored when\nthe time step is not above 0 or a value is not finite. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2SetTransform","b2NewKinematicBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-115",
			"name":"b2wheelmaxmotortorque",
			"display name":"b2WheelMaxMotorTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelMaxMotorTorque(<pJoint>)"
			],
			"display syntax":[
				"b2WheelMaxMotorTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's motor torque cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelMaxMotorTorque(tJoint) into tTorque"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torque in newton-metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelEnableMotor","b2WheelMotorTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-116",
			"name":"b2setangularvelocity",
			"display name":"b2SetAngularVelocity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetAngularVelocity(<pBody>,<pOmega>)"
			],
			"display syntax":[
				"b2SetAngularVelocity(<i>pBody</i>,<i>pOmega</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a body's angular velocity.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pOmega",
				"type":"",
				"refparam":"false",
				"description":"The angular velocity in radians per second; positive is\ncounter-clockwise."
			}],
			"examples":[{
				"script":"b2SetAngularVelocity tBody, 2 * pi"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyAngularVelocity","b2ApplyTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-117",
			"name":"b2enablesleep",
			"display name":"b2EnableSleep",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableSleep(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2EnableSleep(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Allow or forbid one body to sleep.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to let the body sleep, false to keep it always awake."
			}],
			"examples":[{
				"script":"b2EnableSleep tPlayer, false"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyIsSleepEnabled","b2EnableSleeping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-118",
			"name":"b2worldprofilecollide",
			"display name":"b2WorldProfileCollide",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileCollide()"
			],
			"display syntax":[
				"b2WorldProfileCollide()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on the collide phase.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileCollide() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-119",
			"name":"b2setawake",
			"display name":"b2SetAwake",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetAwake(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2SetAwake(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Wake a body, or put it to sleep.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body, false to put it to sleep."
			}],
			"examples":[{
				"script":"b2SetAwake tBody, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyIsAwake","b2EnableSleep"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-120",
			"name":"b2setbullet",
			"display name":"b2SetBullet",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetBullet(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2SetBullet(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Mark a body as a bullet, or clear the mark.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true for continuous collision against dynamic bodies as well as\nstatic ones."
			}],
			"examples":[{
				"script":"b2SetBullet tBall, true"
			}],
			"description":"Use it for small, very fast dynamic bodies that would otherwise pass\nthrough others. It costs time, so use it sparingly. A stale or 0 handle\nis a harmless no-op.",
			"references":{
				"handler":["b2BodyIsBullet","b2EnableContinuous"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-121",
			"name":"b2newthreadedworld",
			"display name":"b2NewThreadedWorld",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewThreadedWorld(<pGravityX>,<pGravityY>,<pAllowSleep>,<pContinuous>,<pWorkers>)"
			],
			"display syntax":[
				"b2NewThreadedWorld(<i>pGravityX</i>,<i>pGravityY</i>,<i>pAllowSleep</i>,<i>pContinuous</i>,<i>pWorkers</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a world whose step can use a pool of native worker threads.",
			"parameters":[{
				"name":"pGravityX",
				"type":"",
				"refparam":"false",
				"description":"The x component of gravity in m/s^2."
			},{
				"name":"pGravityY",
				"type":"",
				"refparam":"false",
				"description":"The y component of gravity in m/s^2; y points up."
			},{
				"name":"pAllowSleep",
				"type":"",
				"refparam":"false",
				"description":"true to let resting bodies sleep."
			},{
				"name":"pContinuous",
				"type":"",
				"refparam":"false",
				"description":"true to turn on continuous collision."
			},{
				"name":"pWorkers",
				"type":"",
				"refparam":"false",
				"description":"The number of Box2D worker threads to ask for."
			}],
			"examples":[{
				"script":"put b2NewThreadedWorld(0, -10, true, true, 4) into tWorld\nput b2WorldThreadCount(tWorld) into tThreads"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A world handle, or 0 on failure."
			}],
			"description":"Like <b2NewWorld>, but <b2Step> may spread its work over native threads.\nScript stays single-threaded: the shim waits for the workers before\n<b2Step> returns, and no callback ever reaches script. Where the\nplatform has no pool (Windows builds), the world runs serially;\n<b2WorldThreadCount> says what you got. It makes the same ABI check as\n<b2NewWorld>.",
			"references":{
				"handler":["b2NewWorld","b2WorldThreadCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-122",
			"name":"b2maximumlinearspeed",
			"display name":"b2MaximumLinearSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MaximumLinearSpeed(<pWorld>)"
			],
			"display syntax":[
				"b2MaximumLinearSpeed(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a world's body speed limit.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2MaximumLinearSpeed(tWorld) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The limit in m/s."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetMaximumLinearSpeed"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-123",
			"name":"b2bodyissleepenabled",
			"display name":"b2BodyIsSleepEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyIsSleepEnabled(<pBody>)"
			],
			"display syntax":[
				"b2BodyIsSleepEnabled(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a body may sleep.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyIsSleepEnabled(tBody) into tCanSleep"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the body may sleep."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2EnableSleep"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-124",
			"name":"b2addcapsule",
			"display name":"b2AddCapsule",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AddCapsule(<pBody>,<pX1>,<pY1>,<pX2>,<pY2>,<pRadius>,<pDensity>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2AddCapsule(<i>pBody</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>,<i>pRadius</i>,<i>pDensity</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a capsule shape (a rounded line) to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of the first centre in the body's local frame, in metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of the first centre, in metres."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the second centre, in metres."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the second centre, in metres."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius in metres; must be above 0."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"The density in kg/m^2; 0 makes the shape massless. A negative\nvalue counts as 0."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, usually 0 to 1. A negative value\ncounts as 0."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The bounciness, 0 (none) to 1 (full). A negative value\ncounts as 0."
			}],
			"examples":[{
				"script":"put b2AddCapsule(tPlayer, 0, -0.4, 0, 0.4, 0.3, 1, 0.1, 0) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 on failure (stale body, radius not above\n0, or the two centres the same)."
			}],
			"description":"Any pending options from the shape-def builder (<b2ShapeDefSensor>,\n<b2ShapeDefFilter> and the rest) apply to this shape and are then\ncleared. Contact events are on by default, so <b2ContactsUpdate> sees\nthe shape. When both centres coincide use <b2AddCircle> instead.",
			"references":{
				"handler":["b2AddCircle","b2SetShapeCapsule"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-125",
			"name":"b2shapesegmentx2",
			"display name":"b2ShapeSegmentX2",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSegmentX2()"
			],
			"display syntax":[
				"b2ShapeSegmentX2()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of the segment's second end from the segment snapshot.",
			"examples":[{
				"script":"b2ShapeSegmentUpdate tShape\nput b2ShapeSegmentX2() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeSegmentUpdate>.",
			"references":{
				"handler":["b2ShapeSegmentUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-126",
			"name":"b2prismaticisspringenabled",
			"display name":"b2PrismaticIsSpringEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticIsSpringEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticIsSpringEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a prismatic joint's spring is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticIsSpringEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the spring is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-127",
			"name":"b2bodyisbullet",
			"display name":"b2BodyIsBullet",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyIsBullet(<pBody>)"
			],
			"display syntax":[
				"b2BodyIsBullet(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a body is a bullet.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyIsBullet(tBody) into tIsBullet"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the body uses bullet (continuous) collision against\ndynamic bodies."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2SetBullet"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-128",
			"name":"b2massdatainertia",
			"display name":"b2MassDataInertia",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MassDataInertia()"
			],
			"display syntax":[
				"b2MassDataInertia()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the rotational inertia from the mass data snapshot.",
			"examples":[{
				"script":"b2BodyMassDataUpdate tBody\nput b2MassDataInertia() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The inertia in kg m^2."
			}],
			"description":"Reads the snapshot taken by <b2BodyMassDataUpdate> or\n<b2ShapeMassDataUpdate>.",
			"references":{
				"handler":["b2BodyMassDataUpdate","b2ShapeMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-129",
			"name":"b2chainfriction",
			"display name":"b2ChainFriction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainFriction(<pChain>)"
			],
			"display syntax":[
				"b2ChainFriction(<i>pChain</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a chain's friction.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			}],
			"examples":[{
				"script":"put b2ChainFriction(tTerrain) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The friction coefficient."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetChainFriction"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-130",
			"name":"b2shapepolygonradius",
			"display name":"b2ShapePolygonRadius",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapePolygonRadius()"
			],
			"display syntax":[
				"b2ShapePolygonRadius()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the rounding radius of the polygon snapshot.",
			"examples":[{
				"script":"if b2ShapePolygonUpdate(tShape) > 0 then put b2ShapePolygonRadius() into tRadius"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The radius in metres (0 for the sharp polygons this binding\ncreates)."
			}],
			"description":"Only meaningful after a <b2ShapePolygonUpdate> that returned a count\nabove 0: a failed update leaves the previous radius.",
			"references":{
				"handler":["b2ShapePolygonUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-131",
			"name":"b2distancemotorforce",
			"display name":"b2DistanceMotorForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceMotorForce(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceMotorForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the force a distance joint's motor applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceMotorForce(tJoint) into tForce"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceMaxMotorForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-132",
			"name":"b2newkinematicbody",
			"display name":"b2NewKinematicBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewKinematicBody(<pWorld>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2NewKinematicBody(<i>pWorld</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a kinematic body at a position.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x position in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y position in metres."
			}],
			"examples":[{
				"script":"put b2NewKinematicBody(tWorld, 0, 5) into tBody\nget b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 on failure."
			}],
			"description":"Shorthand for <b2NewBody> with type 1, angle 0 and no bullet or\nfixed-rotation flag. A kinematic body moves only by the velocity you\ngive it and is not pushed by collisions.",
			"references":{
				"handler":["b2NewBody","b2AddBox"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-133",
			"name":"b2distancesetlength",
			"display name":"b2DistanceSetLength",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSetLength(<pJoint>,<pLength>)"
			],
			"display syntax":[
				"b2DistanceSetLength(<i>pJoint</i>,<i>pLength</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a distance joint's rest length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pLength",
				"type":"",
				"refparam":"false",
				"description":"The new rest length in metres."
			}],
			"examples":[{
				"script":"b2DistanceSetLength tRope, 2"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2DistanceLength","b2DistanceCurrentLength"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-134",
			"name":"b2wheelenablemotor",
			"display name":"b2WheelEnableMotor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelEnableMotor(<pJoint>,<pEnable>,<pSpeed>,<pMaxTorque>)"
			],
			"display syntax":[
				"b2WheelEnableMotor(<i>pJoint</i>,<i>pEnable</i>,<i>pSpeed</i>,<i>pMaxTorque</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a wheel joint's drive motor and set it.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the motor on."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target spin in radians per second."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the motor may apply, in newton-metres."
			}],
			"examples":[{
				"script":"b2WheelEnableMotor tAxle, true, -10, 50"
			}],
			"description":"The call is ignored when a value is not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2WheelIsMotorEnabled","b2WheelMotorSpeed","b2WheelMaxMotorTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-135",
			"name":"b2setcontacttuning",
			"display name":"b2SetContactTuning",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetContactTuning(<pWorld>,<pHertz>,<pDamping>,<pPushSpeed>)"
			],
			"display syntax":[
				"b2SetContactTuning(<i>pWorld</i>,<i>pHertz</i>,<i>pDamping</i>,<i>pPushSpeed</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Tune how soft a world's contacts are.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The contact stiffness in hertz, 0 or more."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The contact damping ratio, 0 or more."
			},{
				"name":"pPushSpeed",
				"type":"",
				"refparam":"false",
				"description":"The most speed used to push overlapping bodies apart, in\nm/s, 0 or more."
			}],
			"examples":[{
				"script":"b2SetContactTuning tWorld, 30, 10, 3"
			}],
			"description":"Advanced solver tuning; the defaults suit most games. The call is\nignored when a value is negative or not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2SetJointTuning"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-136",
			"name":"b2weldsetstiffness",
			"display name":"b2WeldSetStiffness",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldSetStiffness(<pJoint>,<pLinearHertz>,<pLinearDamping>,<pAngularHertz>,<pAngularDamping>)"
			],
			"display syntax":[
				"b2WeldSetStiffness(<i>pJoint</i>,<i>pLinearHertz</i>,<i>pLinearDamping</i>,<i>pAngularHertz</i>,<i>pAngularDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Make a weld joint springy, or rigid again.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			},{
				"name":"pLinearHertz",
				"type":"",
				"refparam":"false",
				"description":"The linear stiffness in hertz; 0 is rigid."
			},{
				"name":"pLinearDamping",
				"type":"",
				"refparam":"false",
				"description":"The linear damping ratio."
			},{
				"name":"pAngularHertz",
				"type":"",
				"refparam":"false",
				"description":"The angular stiffness in hertz; 0 is rigid."
			},{
				"name":"pAngularDamping",
				"type":"",
				"refparam":"false",
				"description":"The angular damping ratio."
			}],
			"examples":[{
				"script":"b2WeldSetStiffness tWeld, 5, 0.7, 5, 0.7"
			}],
			"description":"The call is ignored when a value is not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2WeldLinearHertz","b2WeldAngularHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-137",
			"name":"b2setjointcollideconnected",
			"display name":"b2SetJointCollideConnected",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetJointCollideConnected(<pJoint>,<pFlag>)"
			],
			"display syntax":[
				"b2SetJointCollideConnected(<i>pJoint</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Let a joint's two bodies collide with each other, or not.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to let them collide."
			}],
			"examples":[{
				"script":"b2SetJointCollideConnected tJoint, false"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2JointCollideConnected"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-138",
			"name":"b2revolutesetmaxmotortorque",
			"display name":"b2RevoluteSetMaxMotorTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSetMaxMotorTorque(<pJoint>,<pTorque>)"
			],
			"display syntax":[
				"b2RevoluteSetMaxMotorTorque(<i>pJoint</i>,<i>pTorque</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the most torque a revolute joint's motor may apply.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pTorque",
				"type":"",
				"refparam":"false",
				"description":"The torque in newton-metres, 0 or more."
			}],
			"examples":[{
				"script":"b2RevoluteSetMaxMotorTorque tJoint, 50"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteMaxMotorTorque","b2RevoluteEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-139",
			"name":"b2querycount",
			"display name":"b2QueryCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryCount()"
			],
			"display syntax":[
				"b2QueryCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many rows the last world query found.",
			"examples":[{
				"script":"put b2QueryCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The row count."
			}],
			"description":"The same number the query returned.",
			"references":{
				"handler":["b2OverlapAABB","b2RayCastAll","b2QueryBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-140",
			"name":"b2motorjoint",
			"display name":"b2MotorJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorJoint(<pWorld>,<pBodyA>,<pBodyB>,<pOffsetX>,<pOffsetY>,<pAngularOffset>,<pMaxForce>,<pMaxTorque>,<pCorrectionFactor>,<pCollide>)"
			],
			"display syntax":[
				"b2MotorJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pOffsetX</i>,<i>pOffsetY</i>,<i>pAngularOffset</i>,<i>pMaxForce</i>,<i>pMaxTorque</i>,<i>pCorrectionFactor</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Drive body B toward a pose offset from body A.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The reference body."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The driven body."
			},{
				"name":"pOffsetX",
				"type":"",
				"refparam":"false",
				"description":"The target x offset in body A's frame, in metres."
			},{
				"name":"pOffsetY",
				"type":"",
				"refparam":"false",
				"description":"The target y offset in body A's frame, in metres."
			},{
				"name":"pAngularOffset",
				"type":"",
				"refparam":"false",
				"description":"The target angle relative to body A, in radians."
			},{
				"name":"pMaxForce",
				"type":"",
				"refparam":"false",
				"description":"The most force the joint may apply, in newtons."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the joint may apply, in newton-metres."
			},{
				"name":"pCorrectionFactor",
				"type":"",
				"refparam":"false",
				"description":"How quickly position error is corrected, 0 to 1."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two bodies collide."
			}],
			"examples":[{
				"script":"put b2MotorJoint(tWorld, tGround, tPlatform, 0, 2, 0, 1000, 1000, 0.3, false) into tMotor"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale or a number is not\nfinite."
			}],
			"description":"Useful for moving platforms and top-down characters: change the target\nwith <b2MotorSetLinearOffset> and <b2MotorSetAngularOffset>.",
			"references":{
				"handler":["b2MotorSetLinearOffset","b2MotorSetAngularOffset","b2MotorSetMaxForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-141",
			"name":"b2worldbodycount",
			"display name":"b2WorldBodyCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldBodyCount()"
			],
			"display syntax":[
				"b2WorldBodyCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many bodies the counters snapshot holds.",
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldBodyCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count."
			}],
			"description":"Reads the snapshot taken by <b2WorldCountersUpdate>.",
			"references":{
				"handler":["b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-142",
			"name":"b2awakebodycount",
			"display name":"b2AwakeBodyCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AwakeBodyCount(<pWorld>)"
			],
			"display syntax":[
				"b2AwakeBodyCount(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many bodies in a world are awake.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"if b2AwakeBodyCount(tWorld) is 0 then put \"settled\" into tState"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The awake body count."
			}],
			"description":"When it reaches 0 the scene has come to rest. A stale or 0 handle\nreturns 0.",
			"references":{
				"handler":["b2BodyIsAwake"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-143",
			"name":"b2rayshape",
			"display name":"b2RayShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayShape()"
			],
			"display syntax":[
				"b2RayShape()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the shape the last closest ray hit.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayShape() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-144",
			"name":"b2bodyjointat",
			"display name":"b2BodyJointAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyJointAt(<pIndex>)"
			],
			"display syntax":[
				"b2BodyJointAt(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return one joint from the body joint snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index, from 1 to the count <b2BodyJointCount>\nreturned."
			}],
			"examples":[{
				"script":"put b2BodyJointAt(1) into tJoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodyJointCount>.",
			"references":{
				"handler":["b2BodyJointCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-145",
			"name":"b2bodylocalpointy",
			"display name":"b2BodyLocalPointY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalPointY(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyLocalPointY(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of a world point in a body's frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the point, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalPointY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local y in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalPointX","b2BodyWorldPointY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-146",
			"name":"b2setshapematerialid",
			"display name":"b2SetShapeMaterialId",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeMaterialId(<pShape>,<pId>)"
			],
			"display syntax":[
				"b2SetShapeMaterialId(<i>pShape</i>,<i>pId</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a shape's user material id.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pId",
				"type":"",
				"refparam":"false",
				"description":"An integer of your choosing."
			}],
			"examples":[{
				"script":"b2SetShapeMaterialId tShape, 2"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeMaterialId"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-147",
			"name":"b2polybegin",
			"display name":"b2PolyBegin",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PolyBegin()"
			],
			"display syntax":[
				"b2PolyBegin()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Start a new vertex list for a polygon or a query proxy.",
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint -0.5, 0\nb2PolyAddPoint 0.5, 0\nb2PolyAddPoint 0, 0.8\nput b2AddPolygon(tBody, 1, 0.3, 0) into tShape"
			}],
			"description":"The vertex builder avoids passing arrays across the binding. Clear it\nhere, add up to 8 points with <b2PolyAddPoint>, then use them in\n<b2AddPolygon>, <b2SetShapePolygon>, <b2OverlapShape> or <b2ShapeCast>.\nThe points stay until the next <b2PolyBegin>.",
			"references":{
				"handler":["b2PolyAddPoint","b2AddPolygon"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-148",
			"name":"b2bodymovebody",
			"display name":"b2BodyMoveBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveBody(<pIndex>)"
			],
			"display syntax":[
				"b2BodyMoveBody(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the body of a move event.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based move index, from 1 to <b2BodyMoveCount>."
			}],
			"examples":[{
				"script":"put b2BodyMoveBody(i) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodiesUpdate>.",
			"references":{
				"handler":["b2BodiesUpdate","b2BodyMoveBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-149",
			"name":"b2massdatamass",
			"display name":"b2MassDataMass",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MassDataMass()"
			],
			"display syntax":[
				"b2MassDataMass()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the mass from the mass data snapshot.",
			"examples":[{
				"script":"b2BodyMassDataUpdate tBody\nput b2MassDataMass() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The mass in kilograms."
			}],
			"description":"Reads the snapshot taken by <b2BodyMassDataUpdate> or\n<b2ShapeMassDataUpdate>.",
			"references":{
				"handler":["b2BodyMassDataUpdate","b2ShapeMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-150",
			"name":"b2setshapepolygon",
			"display name":"b2SetShapePolygon",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapePolygon(<pShape>)"
			],
			"display syntax":[
				"b2SetShapePolygon(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Replace a shape's geometry with a polygon from the vertex builder.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint -1, 0\nb2PolyAddPoint 1, 0\nb2PolyAddPoint 0, 1\nb2SetShapePolygon tShape"
			}],
			"description":"Uses the points added with <b2PolyBegin> and <b2PolyAddPoint>, taken as\na convex hull. The call is ignored for a stale handle, under three\npoints or when the hull degenerates.",
			"references":{
				"handler":["b2PolyBegin","b2ShapePolygonUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-151",
			"name":"b2shapecircley",
			"display name":"b2ShapeCircleY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCircleY()"
			],
			"display syntax":[
				"b2ShapeCircleY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of the circle's centre from the circle snapshot.",
			"examples":[{
				"script":"b2ShapeCircleUpdate tShape\nput b2ShapeCircleY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCircleUpdate>.",
			"references":{
				"handler":["b2ShapeCircleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-152",
			"name":"b2revolutemotortorque",
			"display name":"b2RevoluteMotorTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteMotorTorque(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteMotorTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the torque a revolute joint's motor applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteMotorTorque(tJoint) into tTorque"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torque in newton-metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteMaxMotorTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-153",
			"name":"b2shapeclosestpointx",
			"display name":"b2ShapeClosestPointX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeClosestPointX(<pShape>,<pTargetX>,<pTargetY>)"
			],
			"display syntax":[
				"b2ShapeClosestPointX(<i>pShape</i>,<i>pTargetX</i>,<i>pTargetY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the point on a shape nearest a world target.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pTargetX",
				"type":"",
				"refparam":"false",
				"description":"The x of the target in world metres."
			},{
				"name":"pTargetY",
				"type":"",
				"refparam":"false",
				"description":"The y of the target in world metres."
			}],
			"examples":[{
				"script":"put b2ShapeClosestPointX(tShape, tX, tY) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2ShapeClosestPointY","b2ShapeTestPoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-154",
			"name":"b2shapefriction",
			"display name":"b2ShapeFriction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeFriction(<pShape>)"
			],
			"display syntax":[
				"b2ShapeFriction(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's friction coefficient.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeFriction(tShape) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The friction coefficient."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeFriction"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-155",
			"name":"b2distancemotorspeed",
			"display name":"b2DistanceMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceMotorSpeed(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceMotorSpeed(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceMotorSpeed(tJoint) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The target speed in m/s."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceSetMotorSpeed"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-156",
			"name":"b2bodyisfixedrotation",
			"display name":"b2BodyIsFixedRotation",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyIsFixedRotation(<pBody>)"
			],
			"display syntax":[
				"b2BodyIsFixedRotation(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a body's rotation is locked.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyIsFixedRotation(tBody) into tLocked"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the rotation is locked."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2SetFixedRotation"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-157",
			"name":"b2jointlocalanchorby",
			"display name":"b2JointLocalAnchorBY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointLocalAnchorBY(<pJoint>)"
			],
			"display syntax":[
				"b2JointLocalAnchorBY(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the anchor on body B, in that body's local frame.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointLocalAnchorBY(tJoint) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2JointBodyA","b2BodyWorldPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-158",
			"name":"b2worldgravityx",
			"display name":"b2WorldGravityX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldGravityX(<pWorld>)"
			],
			"display syntax":[
				"b2WorldGravityX(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x component of a world's gravity.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2WorldGravityX(tWorld) into tGx"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x component in m/s^2."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2WorldGravityY","b2SetGravity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-159",
			"name":"b2shaperaycast",
			"display name":"b2ShapeRayCast",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayCast(<pShape>,<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2ShapeRayCast(<i>pShape</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Cast a ray against one shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of the start point in world metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of the start point."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the end point."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the end point."
			}],
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, 0, 5, 0, -5) then put b2ShapeRayY() into tTopY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the ray hit the shape."
			}],
			"description":"On a hit, read <b2ShapeRayX>, <b2ShapeRayY>, <b2ShapeRayNormalX>,\n<b2ShapeRayNormalY> and <b2ShapeRayFraction>; a miss leaves them all 0.\nTo cast against a whole world use <b2CastRayClosest>.",
			"references":{
				"handler":["b2ShapeRayX","b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-160",
			"name":"b2bodyatpoint",
			"display name":"b2BodyAtPoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyAtPoint(<pWorld>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2BodyAtPoint(<i>pWorld</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find a body whose shape covers a world point.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point in world metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point in world metres."
			}],
			"examples":[{
				"script":"put b2BodyAtPoint(tWorld, tMouseX, tMouseY) into tPicked"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 if no shape covers the point."
			}],
			"description":"Handy for click-picking. When several bodies overlap the point you get\nthe first one found; <b2OverlapPoint> lists them all.",
			"references":{
				"handler":["b2OverlapPoint","b2MouseJoint","b2ShapeTestPoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-161",
			"name":"b2bodymovey",
			"display name":"b2BodyMoveY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveY(<pIndex>)"
			],
			"display syntax":[
				"b2BodyMoveY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the new y of a moved body.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based move index, from 1 to <b2BodyMoveCount>."
			}],
			"examples":[{
				"script":"put b2BodyMoveY(i) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in metres, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodiesUpdate>.",
			"references":{
				"handler":["b2BodiesUpdate","b2BodyMoveBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-162",
			"name":"b2shapeissensor",
			"display name":"b2ShapeIsSensor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeIsSensor(<pShape>)"
			],
			"display syntax":[
				"b2ShapeIsSensor(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a shape is a sensor.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeIsSensor(tShape) into tIsSensor"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true for a sensor."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2ShapeDefSensor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-163",
			"name":"b2wheelenablespring",
			"display name":"b2WheelEnableSpring",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelEnableSpring(<pJoint>,<pEnable>,<pHertz>,<pDamping>)"
			],
			"display syntax":[
				"b2WheelEnableSpring(<i>pJoint</i>,<i>pEnable</i>,<i>pHertz</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a wheel joint's suspension spring and set it.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the spring on."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The spring stiffness in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio."
			}],
			"examples":[{
				"script":"b2WheelEnableSpring tAxle, true, 4, 0.7"
			}],
			"description":"The call is ignored when a value is not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2WheelIsSpringEnabled","b2WheelSpringHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-164",
			"name":"b2shapefiltercategory",
			"display name":"b2ShapeFilterCategory",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeFilterCategory(<pShape>)"
			],
			"display syntax":[
				"b2ShapeFilterCategory(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's filter category bits.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeFilterCategory(tShape) into tCategory"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The category bits, as a number."
			}],
			"description":"The bits come back as a Number, not an Integer, because Box2D keeps them\nin 64 bits. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-165",
			"name":"b2bodyshapecount",
			"display name":"b2BodyShapeCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyShapeCount(<pBody>)"
			],
			"display syntax":[
				"b2BodyShapeCount(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a body's shapes and return how many there are.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2BodyShapeCount(tBody)\n   b2SetShapeFriction b2BodyShapeAt(i), 0.9\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of shapes; 0 for a stale body."
			}],
			"description":"Read each one with <b2BodyShapeAt>.",
			"references":{
				"handler":["b2BodyShapeAt","b2ShapeBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-166",
			"name":"b2chainrestitution",
			"display name":"b2ChainRestitution",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainRestitution(<pChain>)"
			],
			"display syntax":[
				"b2ChainRestitution(<i>pChain</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a chain's restitution.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			}],
			"examples":[{
				"script":"put b2ChainRestitution(tTerrain) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The restitution."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetChainRestitution"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-167",
			"name":"b2mousesettarget",
			"display name":"b2MouseSetTarget",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSetTarget(<pJoint>,<pTargetX>,<pTargetY>)"
			],
			"display syntax":[
				"b2MouseSetTarget(<i>pJoint</i>,<i>pTargetX</i>,<i>pTargetY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Move a mouse joint's target.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			},{
				"name":"pTargetX",
				"type":"",
				"refparam":"false",
				"description":"The x of the new target in world metres."
			},{
				"name":"pTargetY",
				"type":"",
				"refparam":"false",
				"description":"The y of the new target in world metres."
			}],
			"examples":[{
				"script":"b2MouseSetTarget tDrag, tX, tY"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2MouseJoint","b2MouseTargetX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-168",
			"name":"b2shapeenablehitevents",
			"display name":"b2ShapeEnableHitEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeEnableHitEvents(<pShape>,<pFlag>)"
			],
			"display syntax":[
				"b2ShapeEnableHitEvents(<i>pShape</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn hit events on or off for a shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable hit events."
			}],
			"examples":[{
				"script":"b2ShapeEnableHitEvents tShape, true"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeHitEventsEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-169",
			"name":"b2revolutelowerlimit",
			"display name":"b2RevoluteLowerLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteLowerLimit(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteLowerLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's lower angle limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteLowerLimit(tJoint) into tLower"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The lower limit in radians."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteUpperLimit","b2RevoluteEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-170",
			"name":"b2mousespringdamping",
			"display name":"b2MouseSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSpringDamping(<pJoint>)"
			],
			"display syntax":[
				"b2MouseSpringDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a mouse joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			}],
			"examples":[{
				"script":"put b2MouseSpringDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseSetSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-171",
			"name":"b2motorlinearoffsetx",
			"display name":"b2MotorLinearOffsetX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorLinearOffsetX(<pJoint>)"
			],
			"display syntax":[
				"b2MotorLinearOffsetX(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a motor joint's target offset.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorLinearOffsetX(tMotor) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The offset in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetLinearOffset"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-172",
			"name":"b2revolutemaxmotortorque",
			"display name":"b2RevoluteMaxMotorTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteMaxMotorTorque(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteMaxMotorTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's motor torque cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteMaxMotorTorque(tJoint) into tTorque"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torque in newton-metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSetMaxMotorTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-173",
			"name":"b2weldangularhertz",
			"display name":"b2WeldAngularHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldAngularHertz(<pJoint>)"
			],
			"display syntax":[
				"b2WeldAngularHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a weld joint's angular stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			}],
			"examples":[{
				"script":"put b2WeldAngularHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz; 0 means rigid."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a weld joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldSetStiffness"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-174",
			"name":"b2contactbegincount",
			"display name":"b2ContactBeginCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactBeginCount()"
			],
			"display syntax":[
				"b2ContactBeginCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many pairs began touching in the snapshot.",
			"examples":[{
				"script":"put b2ContactBeginCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The begin-touch count from the last <b2ContactsUpdate>."
			}],
			"description":"The same number <b2ContactsUpdate> returned.",
			"references":{
				"handler":["b2ContactsUpdate","b2ContactBeginBodyA"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-175",
			"name":"b2sethiteventthreshold",
			"display name":"b2SetHitEventThreshold",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetHitEventThreshold(<pWorld>,<pValue>)"
			],
			"display syntax":[
				"b2SetHitEventThreshold(<i>pWorld</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the approach speed above which a contact reports a hit event.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The threshold in m/s, 0 or more."
			}],
			"examples":[{
				"script":"b2SetHitEventThreshold tWorld, 2"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2HitEventThreshold","b2ContactHitCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-176",
			"name":"b2prismaticmotorspeed",
			"display name":"b2PrismaticMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticMotorSpeed(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticMotorSpeed(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticMotorSpeed(tJoint) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The target speed in m/s."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticSetMotorSpeed"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-177",
			"name":"b2bodylocalpointvelocityx",
			"display name":"b2BodyLocalPointVelocityX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalPointVelocityX(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyLocalPointVelocityX(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the world x velocity of a body at a point given in its local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the point, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalPointVelocityX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x velocity in m/s."
			}],
			"description":"Includes the spin's contribution as well as the linear velocity. A stale\nor 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalPointVelocityY","b2BodyWorldPointVelocityX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-178",
			"name":"b2massdatacenterx",
			"display name":"b2MassDataCenterX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MassDataCenterX()"
			],
			"display syntax":[
				"b2MassDataCenterX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the centre of mass from the mass data snapshot.",
			"examples":[{
				"script":"b2BodyMassDataUpdate tBody\nput b2MassDataCenterX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local x in metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyMassDataUpdate> or\n<b2ShapeMassDataUpdate>.",
			"references":{
				"handler":["b2BodyMassDataUpdate","b2ShapeMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-179",
			"name":"b2distancemaxlength",
			"display name":"b2DistanceMaxLength",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceMaxLength(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceMaxLength(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's longest allowed length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceMaxLength(tJoint) into tMax"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The maximum length in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceMinLength","b2DistanceSetLengthRange"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-180",
			"name":"b2mousesetmaxforce",
			"display name":"b2MouseSetMaxForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSetMaxForce(<pJoint>,<pForce>)"
			],
			"display syntax":[
				"b2MouseSetMaxForce(<i>pJoint</i>,<i>pForce</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the most force a mouse joint may pull with.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			},{
				"name":"pForce",
				"type":"",
				"refparam":"false",
				"description":"The force in newtons, 0 or more."
			}],
			"examples":[{
				"script":"b2MouseSetMaxForce tDrag, 1000"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseMaxForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-181",
			"name":"b2queryx",
			"display name":"b2QueryX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryX(<pIndex>)"
			],
			"display syntax":[
				"b2QueryX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a query row's point.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryX(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query. Filled by the ray and shape\ncasts and by <b2OverlapPoint>; the other overlaps leave it 0.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-182",
			"name":"b2querynormaly",
			"display name":"b2QueryNormalY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryNormalY(<pIndex>)"
			],
			"display syntax":[
				"b2QueryNormalY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a query row's surface normal.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryNormalY(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's y component, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query. Filled only by <b2RayCastAll>\nand <b2ShapeCast>.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-183",
			"name":"b2worldislandcount",
			"display name":"b2WorldIslandCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldIslandCount()"
			],
			"display syntax":[
				"b2WorldIslandCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many simulation islands the counters snapshot holds.",
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldIslandCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count."
			}],
			"description":"Reads the snapshot taken by <b2WorldCountersUpdate>.",
			"references":{
				"handler":["b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-184",
			"name":"b2contacthitbodya",
			"display name":"b2ContactHitBodyA",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitBodyA(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitBodyA(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the first body of a hit event.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitBodyA(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-185",
			"name":"b2worldprofilesolve",
			"display name":"b2WorldProfileSolve",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileSolve()"
			],
			"display syntax":[
				"b2WorldProfileSolve()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on the solve phase.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileSolve() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-186",
			"name":"b2shapesegmentx1",
			"display name":"b2ShapeSegmentX1",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSegmentX1()"
			],
			"display syntax":[
				"b2ShapeSegmentX1()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of the segment's first end from the segment snapshot.",
			"examples":[{
				"script":"b2ShapeSegmentUpdate tShape\nput b2ShapeSegmentX1() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeSegmentUpdate>.",
			"references":{
				"handler":["b2ShapeSegmentUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-187",
			"name":"b2bodyisawake",
			"display name":"b2BodyIsAwake",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyIsAwake(<pBody>)"
			],
			"display syntax":[
				"b2BodyIsAwake(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a body is awake.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"if not b2BodyIsAwake(tBody) then put \"resting\" into tState"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the body is awake, false if it sleeps."
			}],
			"description":"A sleeping body costs nothing to simulate and wakes when touched. A\nstale or 0 handle returns false.",
			"references":{
				"handler":["b2SetAwake","b2AwakeBodyCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-188",
			"name":"b2bodyangulardamping",
			"display name":"b2BodyAngularDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyAngularDamping(<pBody>)"
			],
			"display syntax":[
				"b2BodyAngularDamping(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's angular damping.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyAngularDamping(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value."
			}],
			"description":"Set it with <b2SetAngularDamping>. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetAngularDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-189",
			"name":"b2setangulardamping",
			"display name":"b2SetAngularDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetAngularDamping(<pBody>,<pDamping>)"
			],
			"display syntax":[
				"b2SetAngularDamping(<i>pBody</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set how quickly a body's spin dies away.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The angular damping, 0 or more; 0 means none."
			}],
			"examples":[{
				"script":"b2SetAngularDamping tBody, 1"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2BodyAngularDamping","b2SetLinearDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-190",
			"name":"b2sensorbeginvisitorshape",
			"display name":"b2SensorBeginVisitorShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorBeginVisitorShape(<pIndex>)"
			],
			"display syntax":[
				"b2SensorBeginVisitorShape(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the visiting shape of an overlap that began.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2SensorBeginCount>."
			}],
			"examples":[{
				"script":"put b2SensorBeginVisitorShape(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2SensorsUpdate>.",
			"references":{
				"handler":["b2SensorBeginSensorShape","b2SensorBeginCount","b2SensorsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-191",
			"name":"b2shapesensoroverlapsupdate",
			"display name":"b2ShapeSensorOverlapsUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSensorOverlapsUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeSensorOverlapsUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot the shapes overlapping a sensor now.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ShapeSensorOverlapsUpdate(tZone)\n   put b2ShapeBody(b2ShapeSensorOverlapAt(i)) & cr after tInside\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of overlapping shapes."
			}],
			"description":"A poll, unlike the begin and end events of <b2SensorsUpdate>. Read each\nshape with <b2ShapeSensorOverlapAt>. A stale handle returns 0.",
			"references":{
				"handler":["b2ShapeSensorOverlapAt","b2SensorsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-192",
			"name":"b2raycastall",
			"display name":"b2RayCastAll",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayCastAll(<pWorld>,<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2RayCastAll(<i>pWorld</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find every shape along a ray, nearest first.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of the start point in world metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of the start point."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the end point."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the end point."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2RayCastAll(tWorld, 0, 0, 20, 0)\n   put b2QueryX(i), b2QueryY(i) & cr after tHits\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of hits."
			}],
			"description":"The rows are sorted by fraction, near to far, and each carries the hit\npoint, normal and fraction. For just the closest hit use\n<b2CastRayClosest>. Each query clears the shared result rows and returns\nhow many it found; read them with <b2QueryBody>, <b2QueryShape> and the\nother b2Query handlers (1-based). A stale world returns 0.",
			"references":{
				"handler":["b2CastRayClosest","b2QueryFraction","b2QueryX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-193",
			"name":"b2worldjointcount",
			"display name":"b2WorldJointCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldJointCount()"
			],
			"display syntax":[
				"b2WorldJointCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many joints the counters snapshot holds.",
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldJointCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count."
			}],
			"description":"Reads the snapshot taken by <b2WorldCountersUpdate>.",
			"references":{
				"handler":["b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-194",
			"name":"b2prismaticsetspringdamping",
			"display name":"b2PrismaticSetSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSetSpringDamping(<pJoint>,<pDamping>)"
			],
			"display syntax":[
				"b2PrismaticSetSpringDamping(<i>pJoint</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a prismatic joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio, 0 or more."
			}],
			"examples":[{
				"script":"b2PrismaticSetSpringDamping tJoint, 0.7"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a prismatic joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2PrismaticSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-195",
			"name":"b2contactbeginbodyb",
			"display name":"b2ContactBeginBodyB",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactBeginBodyB(<pIndex>)"
			],
			"display syntax":[
				"b2ContactBeginBodyB(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the second body of a pair that began touching.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2ContactBeginCount>."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ContactBeginCount()\n   put b2ContactBeginBodyA(i) && b2ContactBeginBodyB(i) & cr after tLog\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactBeginBodyA","b2ContactBeginCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-196",
			"name":"b2bodylocalvectory",
			"display name":"b2BodyLocalVectorY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalVectorY(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyLocalVectorY(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Rotate a world vector into a body's frame and return its y.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the vector, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the vector, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalVectorY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local y component."
			}],
			"description":"Only the rotation applies, not the position. A stale or 0 handle returns\n0.",
			"references":{
				"handler":["b2BodyLocalVectorX","b2BodyWorldVectorY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-197",
			"name":"b2newstaticbody",
			"display name":"b2NewStaticBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewStaticBody(<pWorld>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2NewStaticBody(<i>pWorld</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a static body at a position.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x position in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y position in metres."
			}],
			"examples":[{
				"script":"put b2NewStaticBody(tWorld, 0, 5) into tBody\nget b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 on failure."
			}],
			"description":"Shorthand for <b2NewBody> with type 0, angle 0 and no bullet or\nfixed-rotation flag. A static body never moves; use it for ground and\nwalls.",
			"references":{
				"handler":["b2NewBody","b2AddBox"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-198",
			"name":"b2revolutesetmotorspeed",
			"display name":"b2RevoluteSetMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSetMotorSpeed(<pJoint>,<pSpeed>)"
			],
			"display syntax":[
				"b2RevoluteSetMotorSpeed(<i>pJoint</i>,<i>pSpeed</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a revolute joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target speed in radians per second."
			}],
			"examples":[{
				"script":"b2RevoluteSetMotorSpeed tJoint, -pi"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.\nThe shim checks that the handle is a live joint, not that it is a\nrevolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteMotorSpeed","b2RevoluteEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-199",
			"name":"b2shapedefenablecontactevents",
			"display name":"b2ShapeDefEnableContactEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefEnableContactEvents(<pFlag>)"
			],
			"display syntax":[
				"b2ShapeDefEnableContactEvents(<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn begin and end contact events on or off for the next shape.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable begin and end contact events."
			}],
			"examples":[{
				"script":"b2ShapeDefEnableContactEvents true\nput b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared.\nContact events are on by default for every shape this binding creates.",
			"references":{
				"handler":["b2ShapeEnableContactEvents","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-200",
			"name":"b2enablebody",
			"display name":"b2EnableBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableBody(<pBody>)"
			],
			"display syntax":[
				"b2EnableBody(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a disabled body to the simulation.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2EnableBody tBody"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2DisableBody","b2BodyIsEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-201",
			"name":"b2bodylocalcenterx",
			"display name":"b2BodyLocalCenterX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalCenterX(<pBody>)"
			],
			"display syntax":[
				"b2BodyLocalCenterX(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a body's centre of mass in its local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyLocalCenterX(tBody) into tCx"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local x in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalCenterY","b2BodyWorldCenterX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-202",
			"name":"b2raybody",
			"display name":"b2RayBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayBody()"
			],
			"display syntax":[
				"b2RayBody()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the body the last closest ray hit.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayBody() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-203",
			"name":"b2addsegment",
			"display name":"b2AddSegment",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AddSegment(<pBody>,<pX1>,<pY1>,<pX2>,<pY2>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2AddSegment(<i>pBody</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a line segment shape to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of the first end in the body's local frame, in metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of the first end, in metres."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the second end, in metres."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the second end, in metres."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, usually 0 to 1. A negative value\ncounts as 0."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The bounciness, 0 (none) to 1 (full). A negative value\ncounts as 0."
			}],
			"examples":[{
				"script":"put b2NewStaticBody(tWorld, 0, 0) into tGround\nget b2AddSegment(tGround, -20, 0, 20, 0, 0.6, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 on failure (stale body or the two ends the\nsame)."
			}],
			"description":"Segments are massless, so they suit static bodies (ground, walls). A\nsegment is two-sided: bodies collide with it from either side. For\none-sided platforms and smooth terrain use a chain (<b2ChainBegin>). Any\npending options from the shape-def builder (<b2ShapeDefSensor>,\n<b2ShapeDefFilter> and the rest) apply to this shape and are then\ncleared. Contact events are on by default, so <b2ContactsUpdate> sees\nthe shape.",
			"references":{
				"handler":["b2ChainBegin","b2SetShapeSegment"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-204",
			"name":"b2setsleepthreshold",
			"display name":"b2SetSleepThreshold",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetSleepThreshold(<pBody>,<pThreshold>)"
			],
			"display syntax":[
				"b2SetSleepThreshold(<i>pBody</i>,<i>pThreshold</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the speed below which a body may fall asleep.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pThreshold",
				"type":"",
				"refparam":"false",
				"description":"The sleep speed threshold in m/s, 0 or more."
			}],
			"examples":[{
				"script":"b2SetSleepThreshold tBody, 0.05"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2EnableSleep","b2BodyIsAwake"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-205",
			"name":"b2bodyaabbupdate",
			"display name":"b2BodyAABBUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyAABBUpdate(<pBody>)"
			],
			"display syntax":[
				"b2BodyAABBUpdate(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a body's bounding box.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2BodyAABBUpdate tBody\nput b2AABBUpperX() - b2AABBLowerX() into tWidth"
			}],
			"description":"The box covers all the body's shapes, in world coordinates. Read it with\n<b2AABBLowerX>, <b2AABBLowerY>, <b2AABBUpperX> and <b2AABBUpperY>.\n<b2ShapeAABBUpdate> fills the same readers for one shape. A stale handle\nzeroes the snapshot.",
			"references":{
				"handler":["b2AABBLowerX","b2ShapeAABBUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-206",
			"name":"b2enablewarmstarting",
			"display name":"b2EnableWarmStarting",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2EnableWarmStarting(<pWorld>,<pFlag>)"
			],
			"display syntax":[
				"b2EnableWarmStarting(<i>pWorld</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn the solver's warm starting on or off.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to reuse the last step's impulses as a starting guess (the\ndefault)."
			}],
			"examples":[{
				"script":"b2EnableWarmStarting tWorld, true"
			}],
			"description":"Turning it off is mainly for testing; stacks become less stable. A stale\nor 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2IsWarmStartingEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-207",
			"name":"b2filterjoint",
			"display name":"b2FilterJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2FilterJoint(<pWorld>,<pBodyA>,<pBodyB>)"
			],
			"display syntax":[
				"b2FilterJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Stop exactly two bodies colliding with each other.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			}],
			"examples":[{
				"script":"put b2FilterJoint(tWorld, tPlayer, tOwnShield) into tNoHit"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale."
			}],
			"description":"A filter joint holds nothing; it only switches off collision between the\npair. Destroy it with <b2DestroyJoint> to restore collision.",
			"references":{
				"handler":["b2DestroyJoint","b2SetShapeFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-208",
			"name":"b2weldsetreferenceangle",
			"display name":"b2WeldSetReferenceAngle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldSetReferenceAngle(<pJoint>,<pAngle>)"
			],
			"display syntax":[
				"b2WeldSetReferenceAngle(<i>pJoint</i>,<i>pAngle</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change the relative angle a weld joint holds.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			},{
				"name":"pAngle",
				"type":"",
				"refparam":"false",
				"description":"The angle of body B relative to body A, in radians."
			}],
			"examples":[{
				"script":"b2WeldSetReferenceAngle tJoint, pi / 6"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.\nThe shim checks that the handle is a live joint, not that it is a weld\njoint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldReferenceAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-209",
			"name":"b2shapecapsuley2",
			"display name":"b2ShapeCapsuleY2",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleY2()"
			],
			"display syntax":[
				"b2ShapeCapsuleY2()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of the capsule's second centre from the capsule snapshot.",
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleY2() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCapsuleUpdate>.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-210",
			"name":"b2contactsupdate",
			"display name":"b2ContactsUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactsUpdate(<pWorld>)"
			],
			"display syntax":[
				"b2ContactsUpdate(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot the contact events of the last step.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"b2Step tWorld, 1/60, 4\nrepeat with i = 1 to b2ContactsUpdate(tWorld)\n   put b2ContactBeginBodyA(i), b2ContactBeginBodyB(i) & cr after tLog\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of begin-touch events."
			}],
			"description":"Call it once after each <b2Step>. It stores the begin-touch, end-touch\nand hit events together; read them with <b2ContactBeginBodyA>,\n<b2ContactEndBodyA>, <b2ContactHitBodyA> and their siblings. Indices are\n1-based. A stale world clears the snapshot and returns 0.",
			"references":{
				"handler":["b2ContactBeginCount","b2ContactEndCount","b2ContactHitCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-211",
			"name":"b2rayfraction",
			"display name":"b2RayFraction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayFraction()"
			],
			"display syntax":[
				"b2RayFraction()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how far along the last closest ray the hit was.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayFraction() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A fraction from 0 (start) to 1 (end), or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-212",
			"name":"b2chainaddpoint",
			"display name":"b2ChainAddPoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainAddPoint(<pX>,<pY>)"
			],
			"display syntax":[
				"b2ChainAddPoint(<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Add one point to the chain builder.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point in the body's local frame, in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point in the body's local frame, in metres."
			}],
			"examples":[{
				"script":"b2ChainAddPoint 3, 0.5"
			}],
			"description":"The builder holds up to 4096 points; extra points are ignored.",
			"references":{
				"handler":["b2ChainBegin","b2CreateChain"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-213",
			"name":"b2jointwakebodies",
			"display name":"b2JointWakeBodies",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointWakeBodies(<pJoint>)"
			],
			"display syntax":[
				"b2JointWakeBodies(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Wake both bodies of a joint.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"b2JointWakeBodies tJoint"
			}],
			"description":"Useful after changing a motor or target on a sleeping mechanism. A stale\nor 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2SetAwake"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-214",
			"name":"b2mousetargetx",
			"display name":"b2MouseTargetX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseTargetX(<pJoint>)"
			],
			"display syntax":[
				"b2MouseTargetX(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a mouse joint's target.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			}],
			"examples":[{
				"script":"put b2MouseTargetX(tJoint) into tX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseTargetY","b2MouseSetTarget"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-215",
			"name":"b2setrestitutionthreshold",
			"display name":"b2SetRestitutionThreshold",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetRestitutionThreshold(<pWorld>,<pValue>)"
			],
			"display syntax":[
				"b2SetRestitutionThreshold(<i>pWorld</i>,<i>pValue</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the speed below which collisions stop bouncing.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The threshold in m/s, 0 or more."
			}],
			"examples":[{
				"script":"b2SetRestitutionThreshold tWorld, 0.5"
			}],
			"description":"Slow impacts below this speed do not bounce, which stops resting bodies\njittering. A negative or non-finite value is ignored. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2RestitutionThreshold"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-216",
			"name":"b2bodyenablecontactevents",
			"display name":"b2BodyEnableContactEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyEnableContactEvents(<pBody>,<pFlag>)"
			],
			"display syntax":[
				"b2BodyEnableContactEvents(<i>pBody</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn contact events on or off for every shape of a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable begin and end contact events."
			}],
			"examples":[{
				"script":"b2BodyEnableContactEvents tDebris, false"
			}],
			"description":"Turning them off for bodies you never ask about saves work. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2ShapeEnableContactEvents","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-217",
			"name":"b2shaperayy",
			"display name":"b2ShapeRayY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayY()"
			],
			"display syntax":[
				"b2ShapeRayY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the last shape ray hit.",
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, tX1, tY1, tX2, tY2) then put b2ShapeRayY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2ShapeRayCast>.",
			"references":{
				"handler":["b2ShapeRayCast"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-218",
			"name":"b2motorsetlinearoffset",
			"display name":"b2MotorSetLinearOffset",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorSetLinearOffset(<pJoint>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2MotorSetLinearOffset(<i>pJoint</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a motor joint's target offset.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x offset in body A's frame, in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y offset in body A's frame, in metres."
			}],
			"examples":[{
				"script":"b2MotorSetLinearOffset tMotor, 3, 2"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2MotorLinearOffsetX","b2MotorLinearOffsetY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-219",
			"name":"b2bodyworldvectory",
			"display name":"b2BodyWorldVectorY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldVectorY(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyWorldVectorY(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Rotate a body-local vector into the world frame and return its y.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the vector, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the vector, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldVectorY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world y component."
			}],
			"description":"Only the rotation applies, not the position. A stale or 0 handle returns\n0.",
			"references":{
				"handler":["b2BodyWorldVectorX","b2BodyLocalVectorY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-220",
			"name":"b2applyimpulseat",
			"display name":"b2ApplyImpulseAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyImpulseAt(<pBody>,<pIx>,<pIy>,<pPointX>,<pPointY>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyImpulseAt(<i>pBody</i>,<i>pIx</i>,<i>pIy</i>,<i>pPointX</i>,<i>pPointY</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply a linear impulse at a world point on a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pIx",
				"type":"",
				"refparam":"false",
				"description":"The x component of the impulse in newton-seconds."
			},{
				"name":"pIy",
				"type":"",
				"refparam":"false",
				"description":"The y component of the impulse in newton-seconds."
			},{
				"name":"pPointX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point of application in world metres."
			},{
				"name":"pPointY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point of application in world metres."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyImpulseAt tBody, 3, 0, tHitX, tHitY, true"
			}],
			"description":"Off the centre of mass the impulse also sets the body spinning. A\nnon-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyImpulse","b2ApplyForceAt"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-221",
			"name":"b2jointconstraintforcey",
			"display name":"b2JointConstraintForceY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointConstraintForceY(<pJoint>)"
			],
			"display syntax":[
				"b2JointConstraintForceY(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the force a joint applied on the last step.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"if abs(b2JointConstraintForceY(tJoint)) > 500 then b2DestroyJoint tJoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in newtons."
			}],
			"description":"Compare it against a threshold to make a breakable joint. A stale or 0\nhandle returns 0.",
			"references":{
				"handler":["b2JointConstraintForceX","b2JointConstraintTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-222",
			"name":"b2shapedensity",
			"display name":"b2ShapeDensity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDensity(<pShape>)"
			],
			"display syntax":[
				"b2ShapeDensity(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's density.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeDensity(tShape) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The density in kg/m^2."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeDensity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-223",
			"name":"b2setchainfriction",
			"display name":"b2SetChainFriction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetChainFriction(<pChain>,<pFriction>)"
			],
			"display syntax":[
				"b2SetChainFriction(<i>pChain</i>,<i>pFriction</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the friction of every segment of a chain.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient."
			}],
			"examples":[{
				"script":"b2SetChainFriction tTerrain, 0.2"
			}],
			"description":"A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ChainFriction"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-224",
			"name":"b2overlappoint",
			"display name":"b2OverlapPoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2OverlapPoint(<pWorld>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2OverlapPoint(<i>pWorld</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Find every shape that contains a world point.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point in world metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point in world metres."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2OverlapPoint(tWorld, tX, tY)\n   put b2QueryShape(i) & cr after tUnder\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of shapes found."
			}],
			"description":"Each row's point is the query point; it has no normal or fraction.\n<b2BodyAtPoint> is the single-result form. Each query clears the shared\nresult rows and returns how many it found; read them with <b2QueryBody>,\n<b2QueryShape> and the other b2Query handlers (1-based). A stale world\nreturns 0.",
			"references":{
				"handler":["b2BodyAtPoint","b2QueryShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-225",
			"name":"b2shapemassdataupdate",
			"display name":"b2ShapeMassDataUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeMassDataUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeMassDataUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot one shape's mass data.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2ShapeMassDataUpdate tShape\nput b2MassDataMass() into tMass"
			}],
			"description":"Read it with <b2MassDataMass>, <b2MassDataCenterX>, <b2MassDataCenterY>\nand <b2MassDataInertia>. A stale handle zeroes the snapshot.",
			"references":{
				"handler":["b2MassDataMass","b2BodyMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-226",
			"name":"b2bodymassdataupdate",
			"display name":"b2BodyMassDataUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMassDataUpdate(<pBody>)"
			],
			"display syntax":[
				"b2BodyMassDataUpdate(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a body's mass data.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2BodyMassDataUpdate tBody\nput b2MassDataMass() into tMass"
			}],
			"description":"Then read it with <b2MassDataMass>, <b2MassDataCenterX>,\n<b2MassDataCenterY> and <b2MassDataInertia>. <b2ShapeMassDataUpdate>\nfills the same readers for one shape. A stale handle zeroes the\nsnapshot.",
			"references":{
				"handler":["b2MassDataMass","b2ShapeMassDataUpdate","b2SetMassData"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-227",
			"name":"b2distancespringhertz",
			"display name":"b2DistanceSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSpringHertz(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceSpringHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceSpringHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-228",
			"name":"b2mousejoint",
			"display name":"b2MouseJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseJoint(<pWorld>,<pBodyA>,<pBodyB>,<pTargetX>,<pTargetY>,<pHertz>,<pDamping>,<pMaxForce>)"
			],
			"display syntax":[
				"b2MouseJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pTargetX</i>,<i>pTargetY</i>,<i>pHertz</i>,<i>pDamping</i>,<i>pMaxForce</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Drag a body toward a target point.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"A reference body, usually a static one; it is not moved."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The body to drag."
			},{
				"name":"pTargetX",
				"type":"",
				"refparam":"false",
				"description":"The x of the target in world metres."
			},{
				"name":"pTargetY",
				"type":"",
				"refparam":"false",
				"description":"The y of the target in world metres."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"How stiffly the body follows, in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio."
			},{
				"name":"pMaxForce",
				"type":"",
				"refparam":"false",
				"description":"The most force the joint may pull with, in newtons."
			}],
			"examples":[{
				"script":"put b2MouseJoint(tWorld, tGround, tPicked, tX, tY, 5, 0.7, 1000 * b2BodyMass(tPicked)) into tDrag"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale or a number is not\nfinite."
			}],
			"description":"Use it for mouse or touch dragging: move the target each frame with\n<b2MouseSetTarget> and destroy the joint on release.",
			"references":{
				"handler":["b2MouseSetTarget","b2BodyAtPoint","b2DestroyJoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-229",
			"name":"b2worldprofilepairs",
			"display name":"b2WorldProfilePairs",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfilePairs()"
			],
			"display syntax":[
				"b2WorldProfilePairs()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on finding new contact pairs.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfilePairs() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-230",
			"name":"b2prismaticislimitenabled",
			"display name":"b2PrismaticIsLimitEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticIsLimitEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticIsLimitEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a prismatic joint's travel limit is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticIsLimitEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the limit is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-231",
			"name":"b2prismaticsetmotorspeed",
			"display name":"b2PrismaticSetMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSetMotorSpeed(<pJoint>,<pSpeed>)"
			],
			"display syntax":[
				"b2PrismaticSetMotorSpeed(<i>pJoint</i>,<i>pSpeed</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a prismatic joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target speed in m/s."
			}],
			"examples":[{
				"script":"b2PrismaticSetMotorSpeed tJoint, -0.5"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.\nThe shim checks that the handle is a live joint, not that it is a\nprismatic joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2PrismaticMotorSpeed","b2PrismaticEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-232",
			"name":"b2addbox",
			"display name":"b2AddBox",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AddBox(<pBody>,<pHalfW>,<pHalfH>,<pDensity>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2AddBox(<i>pBody</i>,<i>pHalfW</i>,<i>pHalfH</i>,<i>pDensity</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a box shape to a body, centred on its origin.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pHalfW",
				"type":"",
				"refparam":"false",
				"description":"Half the box's width in metres; must be above 0."
			},{
				"name":"pHalfH",
				"type":"",
				"refparam":"false",
				"description":"Half the box's height in metres; must be above 0."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"The density in kg/m^2; 0 makes the shape massless. A negative\nvalue counts as 0."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, usually 0 to 1. A negative value\ncounts as 0."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The bounciness, 0 (none) to 1 (full). A negative value\ncounts as 0."
			}],
			"examples":[{
				"script":"put b2NewDynamicBody(tWorld, 0, 5) into tBody\nput b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0.1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the body is stale or a half size is\nnot above 0."
			}],
			"description":"Any pending options from the shape-def builder (<b2ShapeDefSensor>,\n<b2ShapeDefFilter> and the rest) apply to this shape and are then\ncleared. Contact events are on by default, so <b2ContactsUpdate> sees\nthe shape. For an offset or rotated box, build a polygon with\n<b2PolyBegin>.",
			"references":{
				"handler":["b2AddCircle","b2AddPolygon","b2DestroyShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-233",
			"name":"b2sensorendcount",
			"display name":"b2SensorEndCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorEndCount()"
			],
			"display syntax":[
				"b2SensorEndCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many overlaps ended in the sensor snapshot.",
			"examples":[{
				"script":"repeat with i = 1 to b2SensorEndCount()\n   put b2SensorEndVisitorShape(i) into tLeaver\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The end count from the last <b2SensorsUpdate>."
			}],
			"description":"Read each pair with <b2SensorEndSensorShape> and\n<b2SensorEndVisitorShape>.",
			"references":{
				"handler":["b2SensorsUpdate","b2SensorEndSensorShape"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-234",
			"name":"b2shapedefenablehitevents",
			"display name":"b2ShapeDefEnableHitEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefEnableHitEvents(<pFlag>)"
			],
			"display syntax":[
				"b2ShapeDefEnableHitEvents(<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn hit events on or off for the next shape.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable hit events."
			}],
			"examples":[{
				"script":"b2ShapeDefEnableHitEvents true\nput b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared. Hit\nevents report impacts faster than <b2HitEventThreshold>.",
			"references":{
				"handler":["b2ShapeEnableHitEvents","b2ContactHitCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-235",
			"name":"b2chainsegmentcount",
			"display name":"b2ChainSegmentCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainSegmentCount(<pChain>)"
			],
			"display syntax":[
				"b2ChainSegmentCount(<i>pChain</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a chain's segment shapes and return how many there are.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ChainSegmentCount(tTerrain)\n   put b2ChainSegmentAt(i) & cr after tSegments\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of segments; 0 for a stale chain."
			}],
			"description":"Read each one with <b2ChainSegmentAt>.",
			"references":{
				"handler":["b2ChainSegmentAt"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-236",
			"name":"b2shaperaynormalx",
			"display name":"b2ShapeRayNormalX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayNormalX()"
			],
			"display syntax":[
				"b2ShapeRayNormalX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the surface normal at the last shape ray hit.",
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, tX1, tY1, tX2, tY2) then put b2ShapeRayNormalX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's x component, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2ShapeRayCast>.",
			"references":{
				"handler":["b2ShapeRayCast"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-237",
			"name":"b2weldangulardamping",
			"display name":"b2WeldAngularDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldAngularDamping(<pJoint>)"
			],
			"display syntax":[
				"b2WeldAngularDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a weld joint's angular damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			}],
			"examples":[{
				"script":"put b2WeldAngularDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a weld joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldSetStiffness"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-238",
			"name":"b2motorsetangularoffset",
			"display name":"b2MotorSetAngularOffset",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorSetAngularOffset(<pJoint>,<pAngle>)"
			],
			"display syntax":[
				"b2MotorSetAngularOffset(<i>pJoint</i>,<i>pAngle</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a motor joint's target angle.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pAngle",
				"type":"",
				"refparam":"false",
				"description":"The angle relative to body A, in radians."
			}],
			"examples":[{
				"script":"b2MotorSetAngularOffset tMotor, pi / 2"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2MotorAngularOffset"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-239",
			"name":"b2sensorsupdate",
			"display name":"b2SensorsUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorsUpdate(<pWorld>)"
			],
			"display syntax":[
				"b2SensorsUpdate(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot the sensor events of the last step.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2SensorsUpdate(tWorld)\n   if b2SensorBeginSensorShape(i) is tGoal then put b2SensorBeginVisitorShape(i) into tScorer\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of begin-overlap events."
			}],
			"description":"Call it once after each <b2Step>. Sensor events name SHAPES, not bodies:\nuse <b2ShapeBody> to find the body. Both the sensor and its visitor need\nsensor events enabled. A stale world clears the snapshot and returns 0.",
			"references":{
				"handler":["b2SensorBeginSensorShape","b2SensorEndCount","b2ShapeDefSensor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-240",
			"name":"b2chainsegmentat",
			"display name":"b2ChainSegmentAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainSegmentAt(<pIndex>)"
			],
			"display syntax":[
				"b2ChainSegmentAt(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return one segment shape from the chain snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index, from 1 to the count <b2ChainSegmentCount>\nreturned."
			}],
			"examples":[{
				"script":"put b2ChainSegmentAt(1) into tSegment"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ChainSegmentCount>.",
			"references":{
				"handler":["b2ChainSegmentCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-241",
			"name":"b2setgravityscale",
			"display name":"b2SetGravityScale",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetGravityScale(<pBody>,<pScale>)"
			],
			"display syntax":[
				"b2SetGravityScale(<i>pBody</i>,<i>pScale</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Scale how strongly gravity acts on one body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pScale",
				"type":"",
				"refparam":"false",
				"description":"The gravity multiplier: 1 normal, 0 none, negative to fall\nupward."
			}],
			"examples":[{
				"script":"b2SetGravityScale tBalloon, -0.2"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2BodyGravityScale","b2SetGravity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-242",
			"name":"b2revolutespringhertz",
			"display name":"b2RevoluteSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteSpringHertz(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteSpringHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteSpringHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSetSpringHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-243",
			"name":"b2destroybody",
			"display name":"b2DestroyBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DestroyBody(<pBody>)"
			],
			"display syntax":[
				"b2DestroyBody(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Destroy a body, with its shapes and joints.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2DestroyBody tBody\nput 0 into tBody"
			}],
			"description":"The body's shapes and joints go too, and their handles become stale. A\nstale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2NewBody","b2DestroyShape","b2DestroyJoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-244",
			"name":"b2contactbeginbodya",
			"display name":"b2ContactBeginBodyA",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactBeginBodyA(<pIndex>)"
			],
			"display syntax":[
				"b2ContactBeginBodyA(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the first body of a pair that began touching.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2ContactBeginCount>."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ContactBeginCount()\n   put b2ContactBeginBodyA(i) && b2ContactBeginBodyB(i) & cr after tLog\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactBeginBodyB","b2ContactBeginCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-245",
			"name":"b2wheelsetlimits",
			"display name":"b2WheelSetLimits",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelSetLimits(<pJoint>,<pLower>,<pUpper>)"
			],
			"display syntax":[
				"b2WheelSetLimits(<i>pJoint</i>,<i>pLower</i>,<i>pUpper</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a wheel joint's suspension travel range.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			},{
				"name":"pLower",
				"type":"",
				"refparam":"false",
				"description":"The lower travel along the axis, in metres."
			},{
				"name":"pUpper",
				"type":"",
				"refparam":"false",
				"description":"The upper travel along the axis, in metres."
			}],
			"examples":[{
				"script":"b2WheelSetLimits tJoint, -0.2, 0.2"
			}],
			"description":"It does not switch the limit on; use <b2WheelEnableLimit>. The call is\nignored when the lower value is above the upper or a value is not\nfinite. A stale or 0 handle is a harmless no-op. The shim checks that\nthe handle is a live joint, not that it is a wheel joint; check\n<b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelEnableLimit","b2WheelLowerLimit","b2WheelUpperLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-246",
			"name":"b2weldreferenceangle",
			"display name":"b2WeldReferenceAngle",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldReferenceAngle(<pJoint>)"
			],
			"display syntax":[
				"b2WeldReferenceAngle(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the relative angle a weld joint holds.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			}],
			"examples":[{
				"script":"put b2WeldReferenceAngle(tJoint) into tAngle"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle of body B relative to body A, in radians."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a weld joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldSetReferenceAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-247",
			"name":"b2castrayclosest",
			"display name":"b2CastRayClosest",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2CastRayClosest(<pWorld>,<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2CastRayClosest(<i>pWorld</i>,<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Cast a ray through a world and find the closest hit.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The x of the start point in world metres."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The y of the start point."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The x of the end point."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The y of the end point."
			}],
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, 0, 10, 0, -10) then\n   put b2RayBody() into tHitBody\n   put b2RayY() into tGroundY\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the ray hit a shape."
			}],
			"description":"On a hit, read the result with <b2RayBody>, <b2RayShape>, <b2RayX>,\n<b2RayY>, <b2RayNormalX>, <b2RayNormalY> and <b2RayFraction>. Each cast\nclears the previous result, so a miss or a stale world leaves them all\n0. For every hit along the ray use <b2RayCastAll>.",
			"references":{
				"handler":["b2RayBody","b2RayX","b2RayCastAll"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-248",
			"name":"b2bodyworldpointx",
			"display name":"b2BodyWorldPointX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldPointX(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyWorldPointX(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the world x of a point given in a body's local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the point, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldPointX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world x in metres."
			}],
			"description":"Use it to find where a point fixed on the body is now. A stale or 0\nhandle returns 0.",
			"references":{
				"handler":["b2BodyWorldPointY","b2BodyLocalPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-249",
			"name":"b2distanceenablespring",
			"display name":"b2DistanceEnableSpring",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceEnableSpring(<pJoint>,<pEnable>,<pHertz>,<pDamping>)"
			],
			"display syntax":[
				"b2DistanceEnableSpring(<i>pJoint</i>,<i>pEnable</i>,<i>pHertz</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Make a distance joint springy, or rigid again.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the spring on."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The spring stiffness as a frequency in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio; 0 is bouncy, 1 settles without overshoot."
			}],
			"examples":[{
				"script":"b2DistanceEnableSpring tRope, true, 4, 0.5"
			}],
			"description":"The call is ignored when a value is not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2DistanceIsSpringEnabled","b2DistanceSpringHertz","b2DistanceEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-250",
			"name":"b2issleepingenabled",
			"display name":"b2IsSleepingEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2IsSleepingEnabled(<pWorld>)"
			],
			"display syntax":[
				"b2IsSleepingEnabled(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a world lets bodies sleep.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2IsSleepingEnabled(tWorld) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if sleeping is on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2EnableSleeping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-251",
			"name":"b2hiteventthreshold",
			"display name":"b2HitEventThreshold",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2HitEventThreshold(<pWorld>)"
			],
			"display syntax":[
				"b2HitEventThreshold(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a world's hit event threshold.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2HitEventThreshold(tWorld) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The threshold in m/s."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetHitEventThreshold"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-252",
			"name":"b2sensorendvisitorshape",
			"display name":"b2SensorEndVisitorShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SensorEndVisitorShape(<pIndex>)"
			],
			"display syntax":[
				"b2SensorEndVisitorShape(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the visiting shape of an overlap that ended.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2SensorEndCount>."
			}],
			"examples":[{
				"script":"put b2SensorEndVisitorShape(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2SensorsUpdate>. A shape destroyed before\nthe snapshot reads 0.",
			"references":{
				"handler":["b2SensorEndSensorShape","b2SensorEndCount","b2SensorsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-253",
			"name":"b2distancesetmotorspeed",
			"display name":"b2DistanceSetMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSetMotorSpeed(<pJoint>,<pSpeed>)"
			],
			"display syntax":[
				"b2DistanceSetMotorSpeed(<i>pJoint</i>,<i>pSpeed</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a distance joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target speed along the link in m/s."
			}],
			"examples":[{
				"script":"b2DistanceSetMotorSpeed tJoint, 0.5"
			}],
			"description":"A non-finite value is ignored. A stale or 0 handle is a harmless no-op.\nThe shim checks that the handle is a live joint, not that it is a\ndistance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceMotorSpeed","b2DistanceEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-254",
			"name":"b2mousemaxforce",
			"display name":"b2MouseMaxForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseMaxForce(<pJoint>)"
			],
			"display syntax":[
				"b2MouseMaxForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a mouse joint's force cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			}],
			"examples":[{
				"script":"put b2MouseMaxForce(tJoint) into tForce"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseSetMaxForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-255",
			"name":"b2wheelupperlimit",
			"display name":"b2WheelUpperLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelUpperLimit(<pJoint>)"
			],
			"display syntax":[
				"b2WheelUpperLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's upper travel limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelUpperLimit(tJoint) into tUpper"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The upper limit in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelSetLimits"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-256",
			"name":"b2mousespringhertz",
			"display name":"b2MouseSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSpringHertz(<pJoint>)"
			],
			"display syntax":[
				"b2MouseSpringHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a mouse joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			}],
			"examples":[{
				"script":"put b2MouseSpringHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseSetSpringHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-257",
			"name":"b2revoluteenablemotor",
			"display name":"b2RevoluteEnableMotor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteEnableMotor(<pJoint>,<pEnable>,<pSpeed>,<pMaxTorque>)"
			],
			"display syntax":[
				"b2RevoluteEnableMotor(<i>pJoint</i>,<i>pEnable</i>,<i>pSpeed</i>,<i>pMaxTorque</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a revolute joint's motor and set its speed and torque.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the motor on, false to turn it off."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target speed in radians per second."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the motor may apply, in newton-metres."
			}],
			"examples":[{
				"script":"b2RevoluteEnableMotor tHinge, true, 2 * pi, 100"
			}],
			"description":"The call is ignored when a value is not finite. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2RevoluteSetMotorSpeed","b2RevoluteSetMaxMotorTorque","b2RevoluteIsMotorEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-258",
			"name":"b2shapecapsuley1",
			"display name":"b2ShapeCapsuleY1",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleY1()"
			],
			"display syntax":[
				"b2ShapeCapsuleY1()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of the capsule's first centre from the capsule snapshot.",
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleY1() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCapsuleUpdate>.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-259",
			"name":"b2wheellowerlimit",
			"display name":"b2WheelLowerLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelLowerLimit(<pJoint>)"
			],
			"display syntax":[
				"b2WheelLowerLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's lower travel limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelLowerLimit(tJoint) into tLower"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The lower limit in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelSetLimits"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-260",
			"name":"b2shapehiteventsenabled",
			"display name":"b2ShapeHitEventsEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeHitEventsEnabled(<pShape>)"
			],
			"display syntax":[
				"b2ShapeHitEventsEnabled(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a shape has hit events enabled.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeHitEventsEnabled(tShape) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if hit events are on."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2ShapeEnableHitEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-261",
			"name":"b2newbody",
			"display name":"b2NewBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewBody(<pWorld>,<pType>,<pX>,<pY>,<pAngle>,<pBullet>,<pFixedRotation>)"
			],
			"display syntax":[
				"b2NewBody(<i>pWorld</i>,<i>pType</i>,<i>pX</i>,<i>pY</i>,<i>pAngle</i>,<i>pBullet</i>,<i>pFixedRotation</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a body with every option.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"The body type: 0 static, 1 kinematic, 2 dynamic."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x position in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y position in metres."
			},{
				"name":"pAngle",
				"type":"",
				"refparam":"false",
				"description":"The rotation in radians."
			},{
				"name":"pBullet",
				"type":"",
				"refparam":"false",
				"description":"true to treat it as a fast bullet (continuous collision against\ndynamic bodies too)."
			},{
				"name":"pFixedRotation",
				"type":"",
				"refparam":"false",
				"description":"true to stop the body rotating."
			}],
			"examples":[{
				"script":"put b2NewBody(tWorld, 2, 0, 5, 0, false, false) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the world is stale, the type is not 0\nto 2 or a number is not finite."
			}],
			"description":"A body has no shape until you add one (<b2AddBox>, <b2AddCircle> and so\non); its mass comes from its shapes. Free it with <b2DestroyBody>.",
			"references":{
				"handler":["b2NewDynamicBody","b2AddBox","b2DestroyBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-262",
			"name":"b2bodylocalpointx",
			"display name":"b2BodyLocalPointX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalPointX(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyLocalPointX(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of a world point in a body's frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the point, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyLocalPointX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local x in metres."
			}],
			"description":"Use it to find where a world point (a click, a contact) sits on the\nbody. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalPointY","b2BodyWorldPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-263",
			"name":"b2revoluteupperlimit",
			"display name":"b2RevoluteUpperLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteUpperLimit(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteUpperLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's upper angle limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteUpperLimit(tJoint) into tUpper"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The upper limit in radians."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteLowerLimit","b2RevoluteEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-264",
			"name":"b2shapepolygonvertexy",
			"display name":"b2ShapePolygonVertexY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapePolygonVertexY(<pIndex>)"
			],
			"display syntax":[
				"b2ShapePolygonVertexY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of one polygon vertex from the snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based vertex index, from 1 to <b2ShapePolygonCount>."
			}],
			"examples":[{
				"script":"put b2ShapePolygonVertexY(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in metres, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ShapePolygonUpdate>.",
			"references":{
				"handler":["b2ShapePolygonUpdate","b2ShapePolygonCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-265",
			"name":"b2shapecirclex",
			"display name":"b2ShapeCircleX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCircleX()"
			],
			"display syntax":[
				"b2ShapeCircleX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of the circle's centre from the circle snapshot.",
			"examples":[{
				"script":"b2ShapeCircleUpdate tShape\nput b2ShapeCircleX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCircleUpdate>.",
			"references":{
				"handler":["b2ShapeCircleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-266",
			"name":"b2chainbegin",
			"display name":"b2ChainBegin",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainBegin()"
			],
			"display syntax":[
				"b2ChainBegin()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Start a new point list for a chain.",
			"examples":[{
				"script":"b2ChainBegin\nrepeat with i = 0 to 20\n   b2ChainAddPoint i, sin(i / 3)\nend repeat\nput b2CreateChain(tGround, false, 0.7, 0) into tTerrain"
			}],
			"description":"Clear the chain builder, add the points with <b2ChainAddPoint>, then\ncreate the chain with <b2CreateChain>. The points stay until the next\n<b2ChainBegin>.",
			"references":{
				"handler":["b2ChainAddPoint","b2CreateChain"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-267",
			"name":"b2shapesensoroverlapat",
			"display name":"b2ShapeSensorOverlapAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSensorOverlapAt(<pIndex>)"
			],
			"display syntax":[
				"b2ShapeSensorOverlapAt(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return one shape from the sensor overlap snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index, from 1 to <b2ShapeSensorOverlapCount>."
			}],
			"examples":[{
				"script":"put b2ShapeSensorOverlapAt(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ShapeSensorOverlapsUpdate>.",
			"references":{
				"handler":["b2ShapeSensorOverlapsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-268",
			"name":"b2weldjoint",
			"display name":"b2WeldJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldJoint(<pWorld>,<pBodyA>,<pBodyB>,<pAx>,<pAy>,<pBx>,<pBy>,<pRefAngle>,<pCollide>)"
			],
			"display syntax":[
				"b2WeldJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pAx</i>,<i>pAy</i>,<i>pBx</i>,<i>pBy</i>,<i>pRefAngle</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Glue two bodies together rigidly.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			},{
				"name":"pAx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pAy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pBx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pBy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pRefAngle",
				"type":"",
				"refparam":"false",
				"description":"The angle of body B relative to body A to hold, in radians."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two joined bodies still collide with each\nother."
			}],
			"examples":[{
				"script":"put b2WeldJoint(tWorld, tA, tB, 0.5, 0, -0.5, 0, 0, false) into tWeld"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale or a number is not\nfinite."
			}],
			"description":"Rigid by default; make it springy with <b2WeldSetStiffness>.",
			"references":{
				"handler":["b2WeldSetStiffness","b2WeldReferenceAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-269",
			"name":"b2distancecurrentlength",
			"display name":"b2DistanceCurrentLength",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceCurrentLength(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceCurrentLength(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the separation of a distance joint's anchors right now.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceCurrentLength(tJoint) into tLength"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The current length in metres."
			}],
			"description":"<b2DistanceLength> is the rest length. A stale or 0 handle returns 0.\nThe shim checks that the handle is a live joint, not that it is a\ndistance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceLength"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-270",
			"name":"b2distancesetmaxmotorforce",
			"display name":"b2DistanceSetMaxMotorForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSetMaxMotorForce(<pJoint>,<pForce>)"
			],
			"display syntax":[
				"b2DistanceSetMaxMotorForce(<i>pJoint</i>,<i>pForce</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the most force a distance joint's motor may apply.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pForce",
				"type":"",
				"refparam":"false",
				"description":"The force in newtons, 0 or more."
			}],
			"examples":[{
				"script":"b2DistanceSetMaxMotorForce tJoint, 200"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceMaxMotorForce","b2DistanceEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-271",
			"name":"b2applymassfromshapes",
			"display name":"b2ApplyMassFromShapes",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyMassFromShapes(<pBody>)"
			],
			"display syntax":[
				"b2ApplyMassFromShapes(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Recompute a body's mass from its shapes.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"b2ApplyMassFromShapes tBody"
			}],
			"description":"Undoes a <b2SetMassData> override. A stale or 0 handle is a harmless\nno-op.",
			"references":{
				"handler":["b2SetMassData"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-272",
			"name":"b2bodyrotationalinertia",
			"display name":"b2BodyRotationalInertia",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyRotationalInertia(<pBody>)"
			],
			"display syntax":[
				"b2BodyRotationalInertia(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's rotational inertia.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyRotationalInertia(tBody) into tInertia"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The inertia in kg m^2, about the centre of mass."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyMass","b2BodyMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-273",
			"name":"b2worldgravityy",
			"display name":"b2WorldGravityY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldGravityY(<pWorld>)"
			],
			"display syntax":[
				"b2WorldGravityY(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y component of a world's gravity.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"put b2WorldGravityY(tWorld) into tGy"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y component in m/s^2 (negative pulls down)."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2WorldGravityX","b2SetGravity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-274",
			"name":"b2prismaticenablemotor",
			"display name":"b2PrismaticEnableMotor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticEnableMotor(<pJoint>,<pEnable>,<pSpeed>,<pMaxForce>)"
			],
			"display syntax":[
				"b2PrismaticEnableMotor(<i>pJoint</i>,<i>pEnable</i>,<i>pSpeed</i>,<i>pMaxForce</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a prismatic joint's motor and set its speed and force.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the motor on."
			},{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The target speed in m/s."
			},{
				"name":"pMaxForce",
				"type":"",
				"refparam":"false",
				"description":"The most force the motor may apply, in newtons."
			}],
			"examples":[{
				"script":"b2PrismaticEnableMotor tSlider, true, 1, 500"
			}],
			"description":"This is the only setter for the maximum force. The call is ignored when\na value is not finite. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2PrismaticSetMotorSpeed","b2PrismaticMaxMotorForce","b2PrismaticIsMotorEnabled"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-275",
			"name":"b2bodymovex",
			"display name":"b2BodyMoveX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveX(<pIndex>)"
			],
			"display syntax":[
				"b2BodyMoveX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the new x of a moved body.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based move index, from 1 to <b2BodyMoveCount>."
			}],
			"examples":[{
				"script":"put b2BodyMoveX(i) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in metres, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodiesUpdate>.",
			"references":{
				"handler":["b2BodiesUpdate","b2BodyMoveBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-276",
			"name":"b2distanceisspringenabled",
			"display name":"b2DistanceIsSpringEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceIsSpringEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceIsSpringEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a distance joint's spring is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceIsSpringEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the spring is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a distance joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2DistanceEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-277",
			"name":"b2querybody",
			"display name":"b2QueryBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryBody(<pIndex>)"
			],
			"display syntax":[
				"b2QueryBody(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the body of a query row.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryBody(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-278",
			"name":"b2prismaticspeed",
			"display name":"b2PrismaticSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSpeed(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticSpeed(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how fast a prismatic joint is sliding.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticSpeed(tJoint) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sliding speed in m/s."
			}],
			"description":"<b2PrismaticTranslation> is the position. A stale or 0 handle returns 0.\nThe shim checks that the handle is a live joint, not that it is a\nprismatic joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2PrismaticTranslation"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-279",
			"name":"b2aabbupperx",
			"display name":"b2AABBUpperX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AABBUpperX()"
			],
			"display syntax":[
				"b2AABBUpperX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the upper x (right edge) of the bounding box snapshot.",
			"examples":[{
				"script":"b2BodyAABBUpdate tBody\nput b2AABBUpperX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in world metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyAABBUpdate> or <b2ShapeAABBUpdate>.",
			"references":{
				"handler":["b2BodyAABBUpdate","b2ShapeAABBUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-280",
			"name":"b2revolutejoint",
			"display name":"b2RevoluteJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteJoint(<pWorld>,<pBodyA>,<pBodyB>,<pAx>,<pAy>,<pBx>,<pBy>,<pCollide>)"
			],
			"display syntax":[
				"b2RevoluteJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pAx</i>,<i>pAy</i>,<i>pBx</i>,<i>pBy</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Pin two bodies together at a point they can rotate about.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			},{
				"name":"pAx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pAy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pBx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pBy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two joined bodies still collide with each\nother."
			}],
			"examples":[{
				"script":"put b2RevoluteJoint(tWorld, tCar, tWheel, 1, -0.5, 0, 0, false) into tHinge"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale or a number is not\nfinite."
			}],
			"description":"A hinge or axle. Add a limit with <b2RevoluteEnableLimit> and a motor\nwith <b2RevoluteEnableMotor>. Free it with <b2DestroyJoint>.",
			"references":{
				"handler":["b2RevoluteEnableLimit","b2RevoluteEnableMotor","b2RevoluteAngle"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-281",
			"name":"b2newdynamicbody",
			"display name":"b2NewDynamicBody",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewDynamicBody(<pWorld>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2NewDynamicBody(<i>pWorld</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a dynamic body at a position.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x position in metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y position in metres."
			}],
			"examples":[{
				"script":"put b2NewDynamicBody(tWorld, 0, 5) into tBody\nget b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 on failure."
			}],
			"description":"Shorthand for <b2NewBody> with type 2, angle 0 and no bullet or\nfixed-rotation flag. A dynamic body is moved by gravity, forces and\ncollisions.",
			"references":{
				"handler":["b2NewBody","b2AddBox"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-282",
			"name":"b2aabblowery",
			"display name":"b2AABBLowerY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AABBLowerY()"
			],
			"display syntax":[
				"b2AABBLowerY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the lower y (bottom edge) of the bounding box snapshot.",
			"examples":[{
				"script":"b2BodyAABBUpdate tBody\nput b2AABBLowerY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in world metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyAABBUpdate> or <b2ShapeAABBUpdate>.",
			"references":{
				"handler":["b2BodyAABBUpdate","b2ShapeAABBUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-283",
			"name":"b2wheelmotorspeed",
			"display name":"b2WheelMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelMotorSpeed(<pJoint>)"
			],
			"display syntax":[
				"b2WheelMotorSpeed(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's target spin.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelMotorSpeed(tJoint) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The target speed in radians per second."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-284",
			"name":"b2prismaticspringhertz",
			"display name":"b2PrismaticSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSpringHertz(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticSpringHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticSpringHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticSetSpringHertz"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-285",
			"name":"b2addpolygon",
			"display name":"b2AddPolygon",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AddPolygon(<pBody>,<pDensity>,<pFriction>,<pRestitution>)"
			],
			"display syntax":[
				"b2AddPolygon(<i>pBody</i>,<i>pDensity</i>,<i>pFriction</i>,<i>pRestitution</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a convex polygon, built from the vertex builder, to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"The density in kg/m^2; 0 makes the shape massless. A negative\nvalue counts as 0."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, usually 0 to 1. A negative value\ncounts as 0."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"The bounciness, 0 (none) to 1 (full). A negative value\ncounts as 0."
			}],
			"examples":[{
				"script":"b2PolyBegin\nb2PolyAddPoint -0.5, 0\nb2PolyAddPoint 0.5, 0\nb2PolyAddPoint 0, 0.8\nput b2AddPolygon(tBody, 1, 0.3, 0) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the body is stale, fewer than 3\npoints were added or the hull degenerates."
			}],
			"description":"The points from <b2PolyAddPoint> are taken as a convex hull, so their\norder does not matter and inner points are dropped. Any pending options\nfrom the shape-def builder (<b2ShapeDefSensor>, <b2ShapeDefFilter> and\nthe rest) apply to this shape and are then cleared. Contact events are\non by default, so <b2ContactsUpdate> sees the shape.",
			"references":{
				"handler":["b2PolyBegin","b2PolyAddPoint","b2SetShapePolygon"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-286",
			"name":"b2distanceislimitenabled",
			"display name":"b2DistanceIsLimitEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceIsLimitEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceIsLimitEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a distance joint's length range is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceIsLimitEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the limit is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a distance joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2DistanceSetLengthRange"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-287",
			"name":"b2shapedefsensor",
			"display name":"b2ShapeDefSensor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefSensor(<pFlag>)"
			],
			"display syntax":[
				"b2ShapeDefSensor(<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Make the next shape a sensor.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true for a sensor: it reports overlaps but does not collide."
			}],
			"examples":[{
				"script":"b2ShapeDefSensor true\nb2ShapeDefEnableSensorEvents true\nput b2AddCircle(tBody, 0, 0, 2, 0, 0, 0) into tZone"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared.\nRead sensor events with <b2SensorsUpdate> or poll with\n<b2ShapeSensorOverlapsUpdate>.",
			"references":{
				"handler":["b2ShapeDefEnableSensorEvents","b2SensorsUpdate","b2ShapeIsSensor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-288",
			"name":"b2chainisvalid",
			"display name":"b2ChainIsValid",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ChainIsValid(<pChain>)"
			],
			"display syntax":[
				"b2ChainIsValid(<i>pChain</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a chain handle is live.",
			"parameters":[{
				"name":"pChain",
				"type":"",
				"refparam":"false",
				"description":"The chain handle."
			}],
			"examples":[{
				"script":"if b2ChainIsValid(tTerrain) then b2DestroyChain tTerrain"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the chain exists."
			}],
			"description":"false for a destroyed, stale or 0 handle.",
			"references":{
				"handler":["b2DestroyChain"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-289",
			"name":"b2jointcollideconnected",
			"display name":"b2JointCollideConnected",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointCollideConnected(<pJoint>)"
			],
			"display syntax":[
				"b2JointCollideConnected(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a joint's two bodies collide with each other.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointCollideConnected(tJoint) into tCollide"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if they collide."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2SetJointCollideConnected"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-290",
			"name":"b2prismaticismotorenabled",
			"display name":"b2PrismaticIsMotorEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticIsMotorEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticIsMotorEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a prismatic joint's motor is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticIsMotorEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the motor is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-291",
			"name":"b2contactendcount",
			"display name":"b2ContactEndCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactEndCount()"
			],
			"display syntax":[
				"b2ContactEndCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many pairs stopped touching in the snapshot.",
			"examples":[{
				"script":"repeat with i = 1 to b2ContactEndCount()\n   put b2ContactEndBodyA(i) into tBody\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The end-touch count from the last <b2ContactsUpdate>."
			}],
			"description":"Read each pair with <b2ContactEndBodyA> and <b2ContactEndBodyB>.",
			"references":{
				"handler":["b2ContactsUpdate","b2ContactEndBodyA"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-292",
			"name":"b2queryy",
			"display name":"b2QueryY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryY(<pIndex>)"
			],
			"display syntax":[
				"b2QueryY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a query row's point.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryY(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query. Filled by the ray and shape\ncasts and by <b2OverlapPoint>; the other overlaps leave it 0.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-293",
			"name":"b2contacthitcount",
			"display name":"b2ContactHitCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitCount()"
			],
			"display syntax":[
				"b2ContactHitCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many hit events the last snapshot holds.",
			"examples":[{
				"script":"get b2ContactsUpdate(tWorld)\nrepeat with i = 1 to b2ContactHitCount()\n   if b2ContactHitSpeed(i) > 5 then put b2ContactHitBodyA(i) into tHard\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The hit event count from the last <b2ContactsUpdate>."
			}],
			"description":"A hit event is an impact faster than <b2HitEventThreshold> between\nshapes with hit events enabled (<b2ShapeDefEnableHitEvents> or\n<b2ShapeEnableHitEvents>). Use it for impact sounds and damage.",
			"references":{
				"handler":["b2ContactsUpdate","b2ContactHitSpeed","b2SetHitEventThreshold"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-294",
			"name":"b2jointlocalanchoray",
			"display name":"b2JointLocalAnchorAY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointLocalAnchorAY(<pJoint>)"
			],
			"display syntax":[
				"b2JointLocalAnchorAY(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the anchor on body A, in that body's local frame.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointLocalAnchorAY(tJoint) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2JointBodyA","b2BodyWorldPointX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-295",
			"name":"b2setmassdata",
			"display name":"b2SetMassData",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetMassData(<pBody>,<pMass>,<pCenterX>,<pCenterY>,<pInertia>)"
			],
			"display syntax":[
				"b2SetMassData(<i>pBody</i>,<i>pMass</i>,<i>pCenterX</i>,<i>pCenterY</i>,<i>pInertia</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Override a body's mass, centre of mass and inertia.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pMass",
				"type":"",
				"refparam":"false",
				"description":"The mass in kilograms, 0 or more."
			},{
				"name":"pCenterX",
				"type":"",
				"refparam":"false",
				"description":"The x of the centre of mass in the body's local frame, in\nmetres."
			},{
				"name":"pCenterY",
				"type":"",
				"refparam":"false",
				"description":"The y of the centre of mass in the body's local frame, in\nmetres."
			},{
				"name":"pInertia",
				"type":"",
				"refparam":"false",
				"description":"The rotational inertia about the centre of mass, in kg m^2, 0\nor more."
			}],
			"examples":[{
				"script":"b2SetMassData tBody, 5, 0, -0.3, 0.8"
			}],
			"description":"Adding or changing shapes later can recompute the mass from the shapes\nagain; <b2ApplyMassFromShapes> does that on purpose. The call is ignored\nwhen the mass or inertia is negative or a value is not finite. A stale\nor 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyMassFromShapes","b2BodyMassDataUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-296",
			"name":"b2querynormalx",
			"display name":"b2QueryNormalX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryNormalX(<pIndex>)"
			],
			"display syntax":[
				"b2QueryNormalX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a query row's surface normal.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryNormalX(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's x component, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query. Filled only by <b2RayCastAll>\nand <b2ShapeCast>.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-297",
			"name":"b2distanceismotorenabled",
			"display name":"b2DistanceIsMotorEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceIsMotorEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceIsMotorEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a distance joint's motor is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceIsMotorEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the motor is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a distance joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2DistanceEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-298",
			"name":"b2shaperestitution",
			"display name":"b2ShapeRestitution",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRestitution(<pShape>)"
			],
			"display syntax":[
				"b2ShapeRestitution(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's restitution (bounciness).",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeRestitution(tShape) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The restitution."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2SetShapeRestitution"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-299",
			"name":"b2prismatictranslation",
			"display name":"b2PrismaticTranslation",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticTranslation(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticTranslation(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how far a prismatic joint has slid.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticTranslation(tSlider) into tPos"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The translation along the axis, in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2PrismaticSpeed","b2PrismaticEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-300",
			"name":"b2distancespringdamping",
			"display name":"b2DistanceSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSpringDamping(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceSpringDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceSpringDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-301",
			"name":"b2applyimpulse",
			"display name":"b2ApplyImpulse",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyImpulse(<pBody>,<pIx>,<pIy>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyImpulse(<i>pBody</i>,<i>pIx</i>,<i>pIy</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply a linear impulse at a body's centre of mass.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pIx",
				"type":"",
				"refparam":"false",
				"description":"The x component of the impulse in newton-seconds."
			},{
				"name":"pIy",
				"type":"",
				"refparam":"false",
				"description":"The y component of the impulse in newton-seconds."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyImpulse tPlayer, 0, 6, true"
			}],
			"description":"An impulse changes the velocity at once; use it for jumps and kicks. A\nnon-finite value is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyForce","b2ApplyImpulseAt","b2SetVelocity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-302",
			"name":"b2revolutemotorspeed",
			"display name":"b2RevoluteMotorSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteMotorSpeed(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteMotorSpeed(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a revolute joint's motor speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteMotorSpeed(tJoint) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The target speed in radians per second."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a revolute joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2RevoluteSetMotorSpeed"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-303",
			"name":"b2shapesegmentupdate",
			"display name":"b2ShapeSegmentUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSegmentUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeSegmentUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a segment shape's geometry.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2ShapeSegmentUpdate tShape\nput b2ShapeSegmentX2() - b2ShapeSegmentX1() into tDx"
			}],
			"description":"Read it with <b2ShapeSegmentX1>, <b2ShapeSegmentY1>, <b2ShapeSegmentX2>\nand <b2ShapeSegmentY2>. A shape of another type, or a stale handle,\nreads all zeros.",
			"references":{
				"handler":["b2ShapeSegmentX1","b2ShapeType"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-304",
			"name":"b2contactendbodya",
			"display name":"b2ContactEndBodyA",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactEndBodyA(<pIndex>)"
			],
			"display syntax":[
				"b2ContactEndBodyA(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the first body of a pair that stopped touching.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2ContactEndCount>."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ContactEndCount()\n   put b2ContactEndBodyA(i) && b2ContactEndBodyB(i) & cr after tLog\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ContactsUpdate>. A body destroyed before\nthe snapshot reads 0.",
			"references":{
				"handler":["b2ContactEndBodyB","b2ContactEndCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-305",
			"name":"b2wheeljoint",
			"display name":"b2WheelJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelJoint(<pWorld>,<pBodyA>,<pBodyB>,<pAx>,<pAy>,<pBx>,<pBy>,<pAxisX>,<pAxisY>,<pCollide>)"
			],
			"display syntax":[
				"b2WheelJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pAx</i>,<i>pAy</i>,<i>pBx</i>,<i>pBy</i>,<i>pAxisX</i>,<i>pAxisY</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Attach a wheel: a sprung sliding axis plus free spin.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			},{
				"name":"pAx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pAy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pBx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pBy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pAxisX",
				"type":"",
				"refparam":"false",
				"description":"The x of the suspension axis in body A's frame (it is\nnormalised)."
			},{
				"name":"pAxisY",
				"type":"",
				"refparam":"false",
				"description":"The y of the suspension axis in body A's frame."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two joined bodies still collide with each\nother."
			}],
			"examples":[{
				"script":"put b2WheelJoint(tWorld, tCar, tWheel, 1, -0.6, 0, 0, 0, 1, false) into tAxle"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale, a number is not\nfinite or the axis is zero."
			}],
			"description":"Built for vehicle wheels. Set the suspension with <b2WheelEnableSpring>\nand the drive with <b2WheelEnableMotor>.",
			"references":{
				"handler":["b2WheelEnableSpring","b2WheelEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-306",
			"name":"b2bodytype",
			"display name":"b2BodyType",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyType(<pBody>)"
			],
			"display syntax":[
				"b2BodyType(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's type code.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"if b2BodyType(tBody) is 2 then b2ApplyImpulse tBody, 0, 5, true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 static, 1 kinematic, 2 dynamic."
			}],
			"description":"A stale handle also reads 0, the same as a static body.",
			"references":{
				"handler":["b2SetBodyType","b2NewBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-307",
			"name":"b2bodylocalcentery",
			"display name":"b2BodyLocalCenterY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyLocalCenterY(<pBody>)"
			],
			"display syntax":[
				"b2BodyLocalCenterY(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a body's centre of mass in its local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyLocalCenterY(tBody) into tCy"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The local y in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyLocalCenterX","b2BodyWorldCenterY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-308",
			"name":"b2queryshape",
			"display name":"b2QueryShape",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2QueryShape(<pIndex>)"
			],
			"display syntax":[
				"b2QueryShape(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the shape of a query row.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based row index, from 1 to <b2QueryCount>."
			}],
			"examples":[{
				"script":"put b2QueryShape(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the rows of the last world query.",
			"references":{
				"handler":["b2QueryCount","b2RayCastAll","b2OverlapAABB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-309",
			"name":"b2shapesensoroverlapcount",
			"display name":"b2ShapeSensorOverlapCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSensorOverlapCount()"
			],
			"display syntax":[
				"b2ShapeSensorOverlapCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the count of the sensor overlap snapshot.",
			"examples":[{
				"script":"put b2ShapeSensorOverlapCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count from the last <b2ShapeSensorOverlapsUpdate>."
			}],
			"description":"The same number <b2ShapeSensorOverlapsUpdate> returned.",
			"references":{
				"handler":["b2ShapeSensorOverlapsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-310",
			"name":"b2jointbodya",
			"display name":"b2JointBodyA",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2JointBodyA(<pJoint>)"
			],
			"display syntax":[
				"b2JointBodyA(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a joint's first body.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2JointBodyA(tJoint) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 for a stale joint."
			}],
			"description":"Return a joint's first body.",
			"references":{
				"handler":["b2JointBodyB"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-311",
			"name":"b2bodyworldcentery",
			"display name":"b2BodyWorldCenterY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldCenterY(<pBody>)"
			],
			"display syntax":[
				"b2BodyWorldCenterY(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y position of a body's centre of mass in world coordinates.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyWorldCenterY(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Differs from <b2BodyY> when the shapes sit off the body's origin. A\nstale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldCenterX","b2BodyLocalCenterY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-312",
			"name":"b2mousetargety",
			"display name":"b2MouseTargetY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseTargetY(<pJoint>)"
			],
			"display syntax":[
				"b2MouseTargetY(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a mouse joint's target.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			}],
			"examples":[{
				"script":"put b2MouseTargetY(tJoint) into tY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseTargetX","b2MouseSetTarget"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-313",
			"name":"b2shapesegmenty2",
			"display name":"b2ShapeSegmentY2",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeSegmentY2()"
			],
			"display syntax":[
				"b2ShapeSegmentY2()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local y of the segment's second end from the segment snapshot.",
			"examples":[{
				"script":"b2ShapeSegmentUpdate tShape\nput b2ShapeSegmentY2() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeSegmentUpdate>.",
			"references":{
				"handler":["b2ShapeSegmentUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-314",
			"name":"b2worldexplode",
			"display name":"b2WorldExplode",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldExplode(<pWorld>,<pX>,<pY>,<pRadius>,<pFalloff>,<pImpulsePerLength>)"
			],
			"display syntax":[
				"b2WorldExplode(<i>pWorld</i>,<i>pX</i>,<i>pY</i>,<i>pRadius</i>,<i>pFalloff</i>,<i>pImpulsePerLength</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply an explosion's impulse to every body near a point.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the centre in world metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the centre in world metres."
			},{
				"name":"pRadius",
				"type":"",
				"refparam":"false",
				"description":"The radius of full strength in metres, 0 or more."
			},{
				"name":"pFalloff",
				"type":"",
				"refparam":"false",
				"description":"The extra distance over which the strength fades to 0, in\nmetres, 0 or more."
			},{
				"name":"pImpulsePerLength",
				"type":"",
				"refparam":"false",
				"description":"The impulse per metre of exposed shape perimeter."
			}],
			"examples":[{
				"script":"b2WorldExplode tWorld, tX, tY, 2, 3, 5"
			}],
			"description":"Box2D's native explosion: bodies get a push away from the centre that\nscales with how much of their outline faces it. The call is ignored when\nthe radius or falloff is negative or a value is not finite. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyImpulseAt"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-315",
			"name":"b2shaperayfraction",
			"display name":"b2ShapeRayFraction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayFraction()"
			],
			"display syntax":[
				"b2ShapeRayFraction()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how far along the last shape ray the hit was.",
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, tX1, tY1, tX2, tY2) then put b2ShapeRayFraction() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A fraction from 0 to 1, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2ShapeRayCast>.",
			"references":{
				"handler":["b2ShapeRayCast"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-316",
			"name":"b2weldlinearhertz",
			"display name":"b2WeldLinearHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldLinearHertz(<pJoint>)"
			],
			"display syntax":[
				"b2WeldLinearHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a weld joint's linear stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			}],
			"examples":[{
				"script":"put b2WeldLinearHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz; 0 means rigid."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a weld joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldSetStiffness"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-317",
			"name":"b2shapecapsulex1",
			"display name":"b2ShapeCapsuleX1",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleX1()"
			],
			"display syntax":[
				"b2ShapeCapsuleX1()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the local x of the capsule's first centre from the capsule snapshot.",
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleX1() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCapsuleUpdate>.",
			"references":{
				"handler":["b2ShapeCapsuleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-318",
			"name":"b2shaperayx",
			"display name":"b2ShapeRayX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayX()"
			],
			"display syntax":[
				"b2ShapeRayX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the last shape ray hit.",
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, tX1, tY1, tX2, tY2) then put b2ShapeRayX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2ShapeRayCast>.",
			"references":{
				"handler":["b2ShapeRayCast"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-319",
			"name":"b2shapedefenablesensorevents",
			"display name":"b2ShapeDefEnableSensorEvents",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefEnableSensorEvents(<pFlag>)"
			],
			"display syntax":[
				"b2ShapeDefEnableSensorEvents(<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn sensor events on or off for the next shape.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to enable sensor events."
			}],
			"examples":[{
				"script":"b2ShapeDefEnableSensorEvents true\nput b2AddBox(tBody, 0.5, 0.5, 1, 0.3, 0) into tShape"
			}],
			"description":"It applies to the next shape created (<b2AddBox>, <b2AddCircle>,\n<b2AddCapsule>, <b2AddSegment>, <b2AddPolygon>) and is then cleared.\nBoth the sensor and the shape visiting it need sensor events.",
			"references":{
				"handler":["b2ShapeDefSensor","b2SensorsUpdate","b2ShapeEnableSensorEvents"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-320",
			"name":"b2bodyworldvectorx",
			"display name":"b2BodyWorldVectorX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldVectorX(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyWorldVectorX(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Rotate a body-local vector into the world frame and return its x.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the vector, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the vector, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldVectorX(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world x component."
			}],
			"description":"Only the rotation applies, not the position: use it for directions. A\nstale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldVectorY","b2BodyLocalVectorX"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-321",
			"name":"b2shapedefreset",
			"display name":"b2ShapeDefReset",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeDefReset()"
			],
			"display syntax":[
				"b2ShapeDefReset()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Clear every pending shape-def option.",
			"examples":[{
				"script":"b2ShapeDefReset"
			}],
			"description":"Options set with <b2ShapeDefSensor>, <b2ShapeDefFilter> and the other\nb2ShapeDef handlers are normally used up by the next shape. A creation\ncall that is refused (for example a zero radius) can leave them pending,\nso call this to start clean.",
			"references":{
				"handler":["b2ShapeDefSensor","b2ShapeDefFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-322",
			"name":"b2motorsetmaxforce",
			"display name":"b2MotorSetMaxForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorSetMaxForce(<pJoint>,<pForce>)"
			],
			"display syntax":[
				"b2MotorSetMaxForce(<i>pJoint</i>,<i>pForce</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set the most force a motor joint may apply.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			},{
				"name":"pForce",
				"type":"",
				"refparam":"false",
				"description":"The force in newtons, 0 or more."
			}],
			"examples":[{
				"script":"b2MotorSetMaxForce tMotor, 500"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2MotorMaxForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-323",
			"name":"b2shapetestpoint",
			"display name":"b2ShapeTestPoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeTestPoint(<pShape>,<pX>,<pY>)"
			],
			"display syntax":[
				"b2ShapeTestPoint(<i>pShape</i>,<i>pX</i>,<i>pY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a world point lies inside a shape.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point in world metres."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point in world metres."
			}],
			"examples":[{
				"script":"if b2ShapeTestPoint(tShape, tX, tY) then put \"hit\" into tResult"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the point is inside the shape."
			}],
			"description":"A stale or 0 handle returns false.",
			"references":{
				"handler":["b2BodyAtPoint","b2OverlapPoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-324",
			"name":"b2revoluteenablelimit",
			"display name":"b2RevoluteEnableLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteEnableLimit(<pJoint>,<pEnable>,<pLowerRad>,<pUpperRad>)"
			],
			"display syntax":[
				"b2RevoluteEnableLimit(<i>pJoint</i>,<i>pEnable</i>,<i>pLowerRad</i>,<i>pUpperRad</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a revolute joint's angle limit and set its range.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the limit on, false to turn it off."
			},{
				"name":"pLowerRad",
				"type":"",
				"refparam":"false",
				"description":"The lower angle in radians."
			},{
				"name":"pUpperRad",
				"type":"",
				"refparam":"false",
				"description":"The upper angle in radians."
			}],
			"examples":[{
				"script":"b2RevoluteEnableLimit tHinge, true, -pi / 4, pi / 4"
			}],
			"description":"Both ends are clamped into plus or minus 0.95 pi, as Box2D requires. The\ncall is ignored when the lower angle is above the upper or a value is\nnot finite. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2RevoluteIsLimitEnabled","b2RevoluteLowerLimit","b2RevoluteUpperLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-325",
			"name":"b2bodyworldpointvelocityy",
			"display name":"b2BodyWorldPointVelocityY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldPointVelocityY(<pBody>,<pWorldX>,<pWorldY>)"
			],
			"display syntax":[
				"b2BodyWorldPointVelocityY(<i>pBody</i>,<i>pWorldX</i>,<i>pWorldY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y velocity of a body at a world point.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pWorldX",
				"type":"",
				"refparam":"false",
				"description":"The world x of the point, in metres."
			},{
				"name":"pWorldY",
				"type":"",
				"refparam":"false",
				"description":"The world y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldPointVelocityY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y velocity in m/s."
			}],
			"description":"Includes the spin's contribution as well as the linear velocity. A stale\nor 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldPointVelocityX","b2BodyLocalPointVelocityY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-326",
			"name":"b2distanceenablemotor",
			"display name":"b2DistanceEnableMotor",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceEnableMotor(<pJoint>,<pFlag>)"
			],
			"display syntax":[
				"b2DistanceEnableMotor(<i>pJoint</i>,<i>pFlag</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Turn a distance joint's motor on or off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to turn the motor on."
			}],
			"examples":[{
				"script":"b2DistanceEnableSpring tJoint, true, 2, 0.5\nb2DistanceEnableMotor tJoint, true"
			}],
			"description":"Box2D v3.1 solves the motor only in spring mode, so enable the spring\nfirst. At speed 0 it holds the CURRENT separation, not the rest length.\nA stale or 0 handle is a harmless no-op. The shim checks that the handle\nis a live joint, not that it is a distance joint; check <b2JointType>\nwhen unsure.",
			"references":{
				"handler":["b2DistanceSetMotorSpeed","b2DistanceIsMotorEnabled","b2DistanceEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-327",
			"name":"b2version",
			"display name":"b2Version",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2Version()"
			],
			"display syntax":[
				"b2Version()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the native library's ABI version.",
			"examples":[{
				"script":"if b2Version() is not 4 then answer \"Wrong box2dxt library\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The shim's ABI version, currently 4."
			}],
			"description":"Call it once at startup as a load check: it proves the extension and the\nnative library are both present and in step. <b2NewWorld> and\n<b2NewThreadedWorld> make the same check and throw \"box2dxt:\nincompatible native library (binding needs ABI 4)\" when the loaded\nlibrary disagrees.",
			"references":{
				"handler":["b2NewWorld"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-328",
			"name":"b2wheelislimitenabled",
			"display name":"b2WheelIsLimitEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelIsLimitEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2WheelIsLimitEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a wheel joint's travel limit is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelIsLimitEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the limit is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a wheel joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2WheelEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-329",
			"name":"b2loadnativelib",
			"display name":"b2LoadNativeLib",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2LoadNativeLib(<pPath>)"
			],
			"display syntax":[
				"b2LoadNativeLib(<i>pPath</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Preload the native library by absolute path (Linux only).",
			"parameters":[{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The absolute path of the box2dxt.so file to load."
			}],
			"examples":[{
				"script":"if b2LoadNativeLib(tFolder & \"/box2dxt.so\") is 0 then\n   answer b2LoadNativeLibError()\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"1 on success, 0 on failure (see <b2LoadNativeLibError>)."
			}],
			"description":"Loads the file with dlopen (RTLD_NOW and RTLD_GLOBAL) so the engine's\nlater bare-name load finds the copy already in the process. The match is\nby soname, so it only works for a library built with\n-DBOX2DXT_BARE_SONAME=ON; the committed Linux libraries need the Kit's\nrevLibraryMapping route instead.\n\nIt binds to the POSIX loader: never call it on Windows or macOS. The\npreload route has not been confirmed on an engine.",
			"references":{
				"handler":["b2LoadNativeLibError","b2LoadNativeLibHere"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-330",
			"name":"b2applyforce",
			"display name":"b2ApplyForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyForce(<pBody>,<pFx>,<pFy>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyForce(<i>pBody</i>,<i>pFx</i>,<i>pFy</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply a force at a body's centre of mass.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFx",
				"type":"",
				"refparam":"false",
				"description":"The x component of the force in newtons."
			},{
				"name":"pFy",
				"type":"",
				"refparam":"false",
				"description":"The y component of the force in newtons."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyForce tBody, 0, 50, true"
			}],
			"description":"A force acts over time: apply it every step for as long as it should\npush. For a one-off kick use <b2ApplyImpulse>. A non-finite value is\nignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyImpulse","b2ApplyForceAt","b2ApplyTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-331",
			"name":"b2prismaticsetspringhertz",
			"display name":"b2PrismaticSetSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticSetSpringHertz(<pJoint>,<pHertz>)"
			],
			"display syntax":[
				"b2PrismaticSetSpringHertz(<i>pJoint</i>,<i>pHertz</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a prismatic joint's spring stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The stiffness as a frequency in hertz, 0 or more."
			}],
			"examples":[{
				"script":"b2PrismaticSetSpringHertz tJoint, 3"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a prismatic joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2PrismaticSpringHertz","b2PrismaticEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-332",
			"name":"b2distancesetlengthrange",
			"display name":"b2DistanceSetLengthRange",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceSetLengthRange(<pJoint>,<pMin>,<pMax>)"
			],
			"display syntax":[
				"b2DistanceSetLengthRange(<i>pJoint</i>,<i>pMin</i>,<i>pMax</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Let a distance joint's length vary within a range.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			},{
				"name":"pMin",
				"type":"",
				"refparam":"false",
				"description":"The shortest allowed length in metres."
			},{
				"name":"pMax",
				"type":"",
				"refparam":"false",
				"description":"The longest allowed length in metres."
			}],
			"examples":[{
				"script":"b2DistanceSetLengthRange tRope, 1, 3"
			}],
			"description":"This also switches the joint's limit on. The call is ignored when the\nminimum is above the maximum or a value is not finite. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2DistanceIsLimitEnabled","b2DistanceMinLength","b2DistanceMaxLength"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-333",
			"name":"b2distanceminlength",
			"display name":"b2DistanceMinLength",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceMinLength(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceMinLength(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's shortest allowed length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceMinLength(tJoint) into tMin"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The minimum length in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceMaxLength","b2DistanceSetLengthRange"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-334",
			"name":"b2worldprofilerefit",
			"display name":"b2WorldProfileRefit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldProfileRefit()"
			],
			"display syntax":[
				"b2WorldProfileRefit()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the time the last step spent on refitting the broad-phase tree.",
			"examples":[{
				"script":"b2WorldProfileUpdate tWorld\nput b2WorldProfileRefit() into tMs"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The time in milliseconds."
			}],
			"description":"Reads the snapshot taken by <b2WorldProfileUpdate>.",
			"references":{
				"handler":["b2WorldProfileUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-335",
			"name":"b2revoluteismotorenabled",
			"display name":"b2RevoluteIsMotorEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RevoluteIsMotorEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2RevoluteIsMotorEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a revolute joint's motor is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The revolute joint handle."
			}],
			"examples":[{
				"script":"put b2RevoluteIsMotorEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the motor is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a revolute joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2RevoluteEnableMotor"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-336",
			"name":"b2mousesetspringdamping",
			"display name":"b2MouseSetSpringDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MouseSetSpringDamping(<pJoint>,<pDamping>)"
			],
			"display syntax":[
				"b2MouseSetSpringDamping(<i>pJoint</i>,<i>pDamping</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Set a mouse joint's spring damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The mouse joint handle."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio, 0 or more."
			}],
			"examples":[{
				"script":"b2MouseSetSpringDamping tDrag, 0.7"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op. The shim checks that the handle is a live joint, not\nthat it is a mouse joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2MouseSpringDamping"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-337",
			"name":"b2raynormaly",
			"display name":"b2RayNormalY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayNormalY()"
			],
			"display syntax":[
				"b2RayNormalY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the surface normal at the last ray hit.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayNormalY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's y component, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-338",
			"name":"b2prismaticmaxmotorforce",
			"display name":"b2PrismaticMaxMotorForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticMaxMotorForce(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticMaxMotorForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's motor force cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticMaxMotorForce(tJoint) into tForce"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"Set it with <b2PrismaticEnableMotor>; there is no separate setter. A\nstale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticEnableMotor","b2PrismaticMotorForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-339",
			"name":"b2shaperaynormaly",
			"display name":"b2ShapeRayNormalY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeRayNormalY()"
			],
			"display syntax":[
				"b2ShapeRayNormalY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the surface normal at the last shape ray hit.",
			"examples":[{
				"script":"if b2ShapeRayCast(tShape, tX1, tY1, tX2, tY2) then put b2ShapeRayNormalY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's y component, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2ShapeRayCast>.",
			"references":{
				"handler":["b2ShapeRayCast"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-340",
			"name":"b2contacthitbodyb",
			"display name":"b2ContactHitBodyB",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitBodyB(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitBodyB(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the second body of a hit event.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitBodyB(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-341",
			"name":"b2prismaticlowerlimit",
			"display name":"b2PrismaticLowerLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticLowerLimit(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticLowerLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's lower travel limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticLowerLimit(tJoint) into tLower"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The lower limit in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticUpperLimit","b2PrismaticEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-342",
			"name":"b2prismaticenablelimit",
			"display name":"b2PrismaticEnableLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticEnableLimit(<pJoint>,<pEnable>,<pLower>,<pUpper>)"
			],
			"display syntax":[
				"b2PrismaticEnableLimit(<i>pJoint</i>,<i>pEnable</i>,<i>pLower</i>,<i>pUpper</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Switch a prismatic joint's travel limit and set its range.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			},{
				"name":"pEnable",
				"type":"",
				"refparam":"false",
				"description":"true to turn the limit on."
			},{
				"name":"pLower",
				"type":"",
				"refparam":"false",
				"description":"The lower translation in metres."
			},{
				"name":"pUpper",
				"type":"",
				"refparam":"false",
				"description":"The upper translation in metres."
			}],
			"examples":[{
				"script":"b2PrismaticEnableLimit tSlider, true, 0, 4"
			}],
			"description":"The call is ignored when the lower value is above the upper or a value\nis not finite. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2PrismaticIsLimitEnabled","b2PrismaticLowerLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-343",
			"name":"b2rayx",
			"display name":"b2RayX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2RayX()"
			],
			"display syntax":[
				"b2RayX()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of the last closest ray's hit point.",
			"examples":[{
				"script":"if b2CastRayClosest(tWorld, tX1, tY1, tX2, tY2) then put b2RayX() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The x in world metres, or 0 after a miss."
			}],
			"description":"Reads the result stored by the last <b2CastRayClosest>.",
			"references":{
				"handler":["b2CastRayClosest"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-344",
			"name":"b2prismaticjoint",
			"display name":"b2PrismaticJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticJoint(<pWorld>,<pBodyA>,<pBodyB>,<pAx>,<pAy>,<pBx>,<pBy>,<pAxisX>,<pAxisY>,<pRefAngle>,<pCollide>)"
			],
			"display syntax":[
				"b2PrismaticJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pAx</i>,<i>pAy</i>,<i>pBx</i>,<i>pBy</i>,<i>pAxisX</i>,<i>pAxisY</i>,<i>pRefAngle</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Let body B slide along an axis fixed in body A.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			},{
				"name":"pAx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pAy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pBx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pBy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pAxisX",
				"type":"",
				"refparam":"false",
				"description":"The x of the slide axis in body A's frame (it is normalised)."
			},{
				"name":"pAxisY",
				"type":"",
				"refparam":"false",
				"description":"The y of the slide axis in body A's frame."
			},{
				"name":"pRefAngle",
				"type":"",
				"refparam":"false",
				"description":"The angle of body B relative to body A to hold, in radians."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two joined bodies still collide with each\nother."
			}],
			"examples":[{
				"script":"put b2PrismaticJoint(tWorld, tGround, tLift, 0, 0, 0, 0, 0, 1, 0, false) into tSlider"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale, a number is not\nfinite or the axis is zero."
			}],
			"description":"A piston or elevator. Add a limit with <b2PrismaticEnableLimit> and a\nmotor with <b2PrismaticEnableMotor>.",
			"references":{
				"handler":["b2PrismaticEnableLimit","b2PrismaticEnableMotor","b2PrismaticTranslation"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-345",
			"name":"b2contacthitnormalx",
			"display name":"b2ContactHitNormalX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitNormalX(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitNormalX(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x of a hit event's normal.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitNormalX(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The normal's x component, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-346",
			"name":"b2bodyx",
			"display name":"b2BodyX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyX(<pBody>)"
			],
			"display syntax":[
				"b2BodyX(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x position of a body's origin.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyX(tBody) * 40 into tPixelX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Read it after <b2Step> to draw the body; multiply by your\npixels-per-metre scale (and flip y) at draw time. A stale or 0 handle\nreturns 0.",
			"references":{
				"handler":["b2BodyY","b2BodyAngle","b2BodiesUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-347",
			"name":"b2distancejoint",
			"display name":"b2DistanceJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceJoint(<pWorld>,<pBodyA>,<pBodyB>,<pAx>,<pAy>,<pBx>,<pBy>,<pLength>,<pCollide>)"
			],
			"display syntax":[
				"b2DistanceJoint(<i>pWorld</i>,<i>pBodyA</i>,<i>pBodyB</i>,<i>pAx</i>,<i>pAy</i>,<i>pBx</i>,<i>pBy</i>,<i>pLength</i>,<i>pCollide</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Link two bodies with a rod of fixed length.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pBodyA",
				"type":"",
				"refparam":"false",
				"description":"The first body handle."
			},{
				"name":"pBodyB",
				"type":"",
				"refparam":"false",
				"description":"The second body handle."
			},{
				"name":"pAx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pAy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body A, in A's local frame (metres)."
			},{
				"name":"pBx",
				"type":"",
				"refparam":"false",
				"description":"The x of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pBy",
				"type":"",
				"refparam":"false",
				"description":"The y of the anchor on body B, in B's local frame (metres)."
			},{
				"name":"pLength",
				"type":"",
				"refparam":"false",
				"description":"The rest length in metres (values under 0.005 are raised to\n0.005)."
			},{
				"name":"pCollide",
				"type":"",
				"refparam":"false",
				"description":"true to let the two joined bodies still collide with each\nother."
			}],
			"examples":[{
				"script":"put b2DistanceJoint(tWorld, tAnchor, tBob, 0, 0, 0, 0, 3, false) into tRope"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A joint handle, or 0 when a handle is stale or a number is not\nfinite."
			}],
			"description":"Make it springy with <b2DistanceEnableSpring>, or let the length vary\nwithin a range with <b2DistanceSetLengthRange>.",
			"references":{
				"handler":["b2DistanceSetLength","b2DistanceEnableSpring","b2DistanceSetLengthRange"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-348",
			"name":"b2contacthity",
			"display name":"b2ContactHitY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitY(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitY(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of a hit event's impact point.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitY(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-349",
			"name":"b2bodyworldpointy",
			"display name":"b2BodyWorldPointY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyWorldPointY(<pBody>,<pLocalX>,<pLocalY>)"
			],
			"display syntax":[
				"b2BodyWorldPointY(<i>pBody</i>,<i>pLocalX</i>,<i>pLocalY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the world y of a point given in a body's local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pLocalX",
				"type":"",
				"refparam":"false",
				"description":"The local x of the point, in metres."
			},{
				"name":"pLocalY",
				"type":"",
				"refparam":"false",
				"description":"The local y of the point, in metres."
			}],
			"examples":[{
				"script":"put b2BodyWorldPointY(tBody, 1, 0) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world y in metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyWorldPointX","b2BodyLocalPointY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-350",
			"name":"b2contacthitspeed",
			"display name":"b2ContactHitSpeed",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactHitSpeed(<pIndex>)"
			],
			"display syntax":[
				"b2ContactHitSpeed(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a hit event's approach speed.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based hit index, from 1 to <b2ContactHitCount>."
			}],
			"examples":[{
				"script":"put b2ContactHitSpeed(1) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The speed in m/s, or 0 when the index is out of range."
			}],
			"description":"Reads the hit events snapshotted by <b2ContactsUpdate>.",
			"references":{
				"handler":["b2ContactHitCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-351",
			"name":"b2destroyjoint",
			"display name":"b2DestroyJoint",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DestroyJoint(<pJoint>)"
			],
			"display syntax":[
				"b2DestroyJoint(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Remove a joint.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"b2DestroyJoint tDrag\nput 0 into tDrag"
			}],
			"description":"The two bodies stay. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2RevoluteJoint","b2DestroyBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-352",
			"name":"b2applytorque",
			"display name":"b2ApplyTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyTorque(<pBody>,<pTorque>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyTorque(<i>pBody</i>,<i>pTorque</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply a torque to a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pTorque",
				"type":"",
				"refparam":"false",
				"description":"The torque in newton-metres; positive is counter-clockwise."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyTorque tWheel, 20, true"
			}],
			"description":"Like a force, a torque acts over time; apply it every step. A non-finite\nvalue is ignored. A stale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyAngularImpulse","b2ApplyForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-353",
			"name":"b2shapeaabbupdate",
			"display name":"b2ShapeAABBUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeAABBUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeAABBUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot one shape's bounding box.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2ShapeAABBUpdate tShape\nput b2AABBUpperY() into tTop"
			}],
			"description":"Read it with <b2AABBLowerX>, <b2AABBLowerY>, <b2AABBUpperX> and\n<b2AABBUpperY>, in world metres. A stale handle zeroes the snapshot.",
			"references":{
				"handler":["b2AABBLowerX","b2BodyAABBUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-354",
			"name":"b2wheelisspringenabled",
			"display name":"b2WheelIsSpringEnabled",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelIsSpringEnabled(<pJoint>)"
			],
			"display syntax":[
				"b2WheelIsSpringEnabled(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a wheel joint's suspension spring is on.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelIsSpringEnabled(tJoint) into tOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the spring is on."
			}],
			"description":"A stale or 0 handle returns false. The shim checks that the handle is a\nlive joint, not that it is a wheel joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2WheelEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-355",
			"name":"b2bodyvx",
			"display name":"b2BodyVX",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyVX(<pBody>)"
			],
			"display syntax":[
				"b2BodyVX(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the x component of a body's linear velocity.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyVX(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in m/s."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyVY","b2SetVelocity"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-356",
			"name":"b2worldcontactcount",
			"display name":"b2WorldContactCount",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WorldContactCount()"
			],
			"display syntax":[
				"b2WorldContactCount()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return how many contacts the counters snapshot holds.",
			"examples":[{
				"script":"b2WorldCountersUpdate tWorld\nput b2WorldContactCount() into tCount"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count."
			}],
			"description":"Reads the snapshot taken by <b2WorldCountersUpdate>.",
			"references":{
				"handler":["b2WorldCountersUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-357",
			"name":"b2applyforceat",
			"display name":"b2ApplyForceAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ApplyForceAt(<pBody>,<pFx>,<pFy>,<pPointX>,<pPointY>,<pWake>)"
			],
			"display syntax":[
				"b2ApplyForceAt(<i>pBody</i>,<i>pFx</i>,<i>pFy</i>,<i>pPointX</i>,<i>pPointY</i>,<i>pWake</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Apply a force at a world point on a body.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pFx",
				"type":"",
				"refparam":"false",
				"description":"The x component of the force in newtons."
			},{
				"name":"pFy",
				"type":"",
				"refparam":"false",
				"description":"The y component of the force in newtons."
			},{
				"name":"pPointX",
				"type":"",
				"refparam":"false",
				"description":"The x of the point of application in world metres."
			},{
				"name":"pPointY",
				"type":"",
				"refparam":"false",
				"description":"The y of the point of application in world metres."
			},{
				"name":"pWake",
				"type":"",
				"refparam":"false",
				"description":"true to wake the body if it sleeps."
			}],
			"examples":[{
				"script":"b2ApplyForceAt tBody, 0, 20, b2BodyX(tBody) + 1, b2BodyY(tBody), true"
			}],
			"description":"Off the centre of mass the force also turns the body. Apply it every\nstep for as long as it should push. A non-finite value is ignored. A\nstale or 0 handle is a harmless no-op.",
			"references":{
				"handler":["b2ApplyForce","b2ApplyImpulseAt"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-358",
			"name":"b2bodyshapeat",
			"display name":"b2BodyShapeAt",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyShapeAt(<pIndex>)"
			],
			"display syntax":[
				"b2BodyShapeAt(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return one shape from the body shape snapshot.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index, from 1 to the count <b2BodyShapeCount>\nreturned."
			}],
			"examples":[{
				"script":"put b2BodyShapeAt(1) into tShape"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A shape handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodyShapeCount>.",
			"references":{
				"handler":["b2BodyShapeCount"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-359",
			"name":"b2setbodytype",
			"display name":"b2SetBodyType",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetBodyType(<pBody>,<pType>)"
			],
			"display syntax":[
				"b2SetBodyType(<i>pBody</i>,<i>pType</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a body's type.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			},{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"The new type: 0 static, 1 kinematic, 2 dynamic."
			}],
			"examples":[{
				"script":"b2SetBodyType tCrate, 2"
			}],
			"description":"A type outside 0 to 2 is ignored. A stale or 0 handle is a harmless\nno-op.",
			"references":{
				"handler":["b2BodyType","b2NewBody"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-360",
			"name":"b2shapeclosestpointy",
			"display name":"b2ShapeClosestPointY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeClosestPointY(<pShape>,<pTargetX>,<pTargetY>)"
			],
			"display syntax":[
				"b2ShapeClosestPointY(<i>pShape</i>,<i>pTargetX</i>,<i>pTargetY</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the y of the point on a shape nearest a world target.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pTargetX",
				"type":"",
				"refparam":"false",
				"description":"The x of the target in world metres."
			},{
				"name":"pTargetY",
				"type":"",
				"refparam":"false",
				"description":"The y of the target in world metres."
			}],
			"examples":[{
				"script":"put b2ShapeClosestPointY(tShape, tX, tY) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The y in world metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2ShapeClosestPointX","b2ShapeTestPoint"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-361",
			"name":"b2distancemaxmotorforce",
			"display name":"b2DistanceMaxMotorForce",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2DistanceMaxMotorForce(<pJoint>)"
			],
			"display syntax":[
				"b2DistanceMaxMotorForce(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a distance joint's motor force cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The distance joint handle."
			}],
			"examples":[{
				"script":"put b2DistanceMaxMotorForce(tJoint) into tForce"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The force in newtons."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a distance joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2DistanceSetMaxMotorForce"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-362",
			"name":"b2contactendbodyb",
			"display name":"b2ContactEndBodyB",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ContactEndBodyB(<pIndex>)"
			],
			"display syntax":[
				"b2ContactEndBodyB(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the second body of a pair that stopped touching.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based event index, from 1 to <b2ContactEndCount>."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2ContactEndCount()\n   put b2ContactEndBodyA(i) && b2ContactEndBodyB(i) & cr after tLog\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A body handle, or 0 when the index is out of range."
			}],
			"description":"Reads the snapshot taken by <b2ContactsUpdate>. A body destroyed before\nthe snapshot reads 0.",
			"references":{
				"handler":["b2ContactEndBodyA","b2ContactEndCount","b2ContactsUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-363",
			"name":"b2weldlineardamping",
			"display name":"b2WeldLinearDamping",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WeldLinearDamping(<pJoint>)"
			],
			"display syntax":[
				"b2WeldLinearDamping(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a weld joint's linear damping ratio.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The weld joint handle."
			}],
			"examples":[{
				"script":"put b2WeldLinearDamping(tJoint) into tDamping"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The damping ratio."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a weld joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WeldSetStiffness"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-364",
			"name":"b2prismaticupperlimit",
			"display name":"b2PrismaticUpperLimit",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2PrismaticUpperLimit(<pJoint>)"
			],
			"display syntax":[
				"b2PrismaticUpperLimit(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a prismatic joint's upper travel limit.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The prismatic joint handle."
			}],
			"examples":[{
				"script":"put b2PrismaticUpperLimit(tJoint) into tUpper"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The upper limit in metres."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a prismatic joint; check <b2JointType> when\nunsure.",
			"references":{
				"handler":["b2PrismaticLowerLimit","b2PrismaticEnableLimit"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-365",
			"name":"b2bodymass",
			"display name":"b2BodyMass",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMass(<pBody>)"
			],
			"display syntax":[
				"b2BodyMass(<i>pBody</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a body's mass.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The body handle."
			}],
			"examples":[{
				"script":"put b2BodyMass(tBody) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in kilograms."
			}],
			"description":"The mass comes from the body's shapes and their density, unless set with\n<b2SetMassData>. A static body reads 0. A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2BodyMassDataUpdate","b2SetMassData"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-366",
			"name":"b2setshapefriction",
			"display name":"b2SetShapeFriction",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetShapeFriction(<pShape>,<pFriction>)"
			],
			"display syntax":[
				"b2SetShapeFriction(<i>pShape</i>,<i>pFriction</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a shape's friction.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"The friction coefficient, 0 or more (usually 0 to 1)."
			}],
			"examples":[{
				"script":"b2SetShapeFriction tShape, 0.5"
			}],
			"description":"A negative or non-finite value is ignored. A stale or 0 handle is a\nharmless no-op.",
			"references":{
				"handler":["b2ShapeFriction"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-367",
			"name":"b2loadnativelibhere",
			"display name":"b2LoadNativeLibHere",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2LoadNativeLibHere()"
			],
			"display syntax":[
				"b2LoadNativeLibHere()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Preload box2dxt.so from the running engine's own folder (Linux only).",
			"examples":[{
				"script":"if the platform is \"Linux\" then\n   get b2LoadNativeLibHere()\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"1 if a library was loaded, else 0."
			}],
			"description":"Finds the engine's executable through /proc/self/exe and loads the file\nbox2dxt.so from that folder, so a later bare-name load of the library\nfinds the copy already in the process. Nothing calls it automatically.\n\nIt binds to the POSIX loader, so never call it on Windows or macOS. It\nonly helps for a library built with -DBOX2DXT_BARE_SONAME=ON (soname\nbox2dxt.so); the committed Linux libraries carry libbox2dxt.so and need\nthe Kit's revLibraryMapping route instead. The preload route has not\nbeen confirmed on an engine.",
			"references":{
				"handler":["b2LoadNativeLib","b2LoadNativeLibError"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-368",
			"name":"b2wheelspringhertz",
			"display name":"b2WheelSpringHertz",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2WheelSpringHertz(<pJoint>)"
			],
			"display syntax":[
				"b2WheelSpringHertz(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a wheel joint's suspension stiffness.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The wheel joint handle."
			}],
			"examples":[{
				"script":"put b2WheelSpringHertz(tJoint) into tHertz"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stiffness in hertz."
			}],
			"description":"A stale or 0 handle returns 0. The shim checks that the handle is a live\njoint, not that it is a wheel joint; check <b2JointType> when unsure.",
			"references":{
				"handler":["b2WheelEnableSpring"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-369",
			"name":"b2shapecircleradius",
			"display name":"b2ShapeCircleRadius",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCircleRadius()"
			],
			"display syntax":[
				"b2ShapeCircleRadius()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the circle's radius from the circle snapshot.",
			"examples":[{
				"script":"b2ShapeCircleUpdate tShape\nput b2ShapeCircleRadius() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in metres."
			}],
			"description":"Reads the snapshot taken by <b2ShapeCircleUpdate>.",
			"references":{
				"handler":["b2ShapeCircleUpdate"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-370",
			"name":"b2bodiesupdate",
			"display name":"b2BodiesUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodiesUpdate(<pWorld>)"
			],
			"display syntax":[
				"b2BodiesUpdate(<i>pWorld</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot every body that moved in the last step.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			}],
			"examples":[{
				"script":"repeat with i = 1 to b2BodiesUpdate(tWorld)\n   put b2BodyMoveBody(i), b2BodyMoveX(i), b2BodyMoveY(i) & cr after tMoves\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of bodies that moved."
			}],
			"description":"Call it once after each <b2Step>. One call gathers the new transform of\nevery moved body, which is far cheaper than asking each body with\n<b2BodyX>. Sleeping bodies do not appear. A stale world clears the\nsnapshot and returns 0.",
			"references":{
				"handler":["b2BodyMoveBody","b2BodyMoveX","b2BodyMoveFellAsleep"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-371",
			"name":"b2bodymovefellasleep",
			"display name":"b2BodyMoveFellAsleep",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2BodyMoveFellAsleep(<pIndex>)"
			],
			"display syntax":[
				"b2BodyMoveFellAsleep(<i>pIndex</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Report whether a moved body fell asleep in the last step.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based move index, from 1 to <b2BodyMoveCount>."
			}],
			"examples":[{
				"script":"if b2BodyMoveFellAsleep(i) then put \"resting\" into tState"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the body fell asleep; false otherwise or when the index\nis out of range."
			}],
			"description":"Reads the snapshot taken by <b2BodiesUpdate>. A body that fell asleep\nwill not appear again until it wakes.",
			"references":{
				"handler":["b2BodiesUpdate","b2BodyIsAwake"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-372",
			"name":"b2setgravity",
			"display name":"b2SetGravity",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2SetGravity(<pWorld>,<pGx>,<pGy>)"
			],
			"display syntax":[
				"b2SetGravity(<i>pWorld</i>,<i>pGx</i>,<i>pGy</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Change a world's gravity.",
			"parameters":[{
				"name":"pWorld",
				"type":"",
				"refparam":"false",
				"description":"The world handle."
			},{
				"name":"pGx",
				"type":"",
				"refparam":"false",
				"description":"The x component of gravity in m/s^2."
			},{
				"name":"pGy",
				"type":"",
				"refparam":"false",
				"description":"The y component of gravity in m/s^2."
			}],
			"examples":[{
				"script":"b2SetGravity tWorld, 0, -10"
			}],
			"description":"Sleeping bodies do not wake on their own; wake them with <b2SetAwake> if\nthey should react at once. A non-finite value is ignored. A stale or 0\nhandle is a harmless no-op.",
			"references":{
				"handler":["b2WorldGravityX","b2WorldGravityY"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-373",
			"name":"b2newworld",
			"display name":"b2NewWorld",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2NewWorld(<pGravityX>,<pGravityY>,<pAllowSleep>,<pContinuous>)"
			],
			"display syntax":[
				"b2NewWorld(<i>pGravityX</i>,<i>pGravityY</i>,<i>pAllowSleep</i>,<i>pContinuous</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Create a single-threaded physics world.",
			"parameters":[{
				"name":"pGravityX",
				"type":"",
				"refparam":"false",
				"description":"The x component of gravity in m/s^2."
			},{
				"name":"pGravityY",
				"type":"",
				"refparam":"false",
				"description":"The y component of gravity in m/s^2; y points up, so -10\npulls down."
			},{
				"name":"pAllowSleep",
				"type":"",
				"refparam":"false",
				"description":"true to let resting bodies sleep, which saves time."
			},{
				"name":"pContinuous",
				"type":"",
				"refparam":"false",
				"description":"true to turn on continuous collision, which stops fast\nbodies tunnelling through static ones."
			}],
			"examples":[{
				"script":"local tWorld\nput b2NewWorld(0, -10, true, true) into tWorld"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A world handle, or 0 when gravity is not a finite number."
			}],
			"description":"Everything else lives in a world: create one, add bodies, and advance it\nwith <b2Step>. Free it with <b2DestroyWorld>.\n\nIt first checks the native library's ABI and throws \"box2dxt:\nincompatible native library (binding needs ABI 4)\" on a mismatch, so a\nwrong library fails here with a clear error.",
			"references":{
				"handler":["b2NewThreadedWorld","b2Step","b2DestroyWorld"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-374",
			"name":"b2shapefiltermask",
			"display name":"b2ShapeFilterMask",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeFilterMask(<pShape>)"
			],
			"display syntax":[
				"b2ShapeFilterMask(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a shape's filter mask bits.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"put b2ShapeFilterMask(tShape) into tMask"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The mask bits, as a number."
			}],
			"description":"A default mask reads 2^64-1 (collide with everything). A stale or 0\nhandle returns 0.",
			"references":{
				"handler":["b2SetShapeFilter"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-375",
			"name":"b2motormaxtorque",
			"display name":"b2MotorMaxTorque",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2MotorMaxTorque(<pJoint>)"
			],
			"display syntax":[
				"b2MotorMaxTorque(<i>pJoint</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return a motor joint's torque cap.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle."
			}],
			"examples":[{
				"script":"put b2MotorMaxTorque(tMotor) into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The torque in newton-metres."
			}],
			"description":"A stale or 0 handle returns 0.",
			"references":{
				"handler":["b2MotorSetMaxTorque"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-376",
			"name":"b2shapecapsuleupdate",
			"display name":"b2ShapeCapsuleUpdate",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2ShapeCapsuleUpdate(<pShape>)"
			],
			"display syntax":[
				"b2ShapeCapsuleUpdate(<i>pShape</i>)"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Snapshot a capsule shape's geometry.",
			"parameters":[{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"The shape handle."
			}],
			"examples":[{
				"script":"b2ShapeCapsuleUpdate tShape\nput b2ShapeCapsuleRadius() into tRadius"
			}],
			"description":"Read it with <b2ShapeCapsuleX1>, <b2ShapeCapsuleY1>, <b2ShapeCapsuleX2>,\n<b2ShapeCapsuleY2> and <b2ShapeCapsuleRadius>. A shape of another type,\nor a stale handle, reads all zeros.",
			"references":{
				"handler":["b2ShapeCapsuleRadius","b2ShapeType"]
			},
			"tags":["physics","library"]
		},{
			"id":"org.openxtalk.box2dxt-377",
			"name":"b2aabbuppery",
			"display name":"b2AABBUpperY",
			"library":"org.openxtalk.box2dxt",
			"type":"handler",
			"syntax":[
				"b2AABBUpperY()"
			],
			"display syntax":[
				"b2AABBUpperY()"
			],
			"associations":["org.openxtalk.box2dxt"],
			"summary":"Return the upper y (top edge) of the bounding box snapshot.",
			"examples":[{
				"script":"b2BodyAABBUpdate tBody\nput b2AABBUpperY() into tValue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value in world metres."
			}],
			"description":"Reads the snapshot taken by <b2BodyAABBUpdate> or <b2ShapeAABBUpdate>.",
			"references":{
				"handler":["b2BodyAABBUpdate","b2ShapeAABBUpdate"]
			},
			"tags":["physics","library"]
		}