{
			"id":"org.openxtalk.library.datachannel-1",
			"name":"org.openxtalk.library.datachannel",
			"display name":"DataChannelXT",
			"library":"org.openxtalk.library.datachannel",
			"type":"library",
			"display syntax":[
				"DataChannelXT"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Bindings to libdatachannel: WebRTC data channels for peer-to-peer\nmessaging, including with a web browser.\n\nDataChannelXT wraps libdatachannel. A peer is one WebRTC connection; a\nchannel is one message stream on a peer. Both are integer handles; 0\nmeans the call failed (see <dcLastError>), and a handle that has gone\nstale is a harmless no-op. Action handlers return 0 on success or a\nnegative error: -1 generic, -2 stale handle, -3 bad argument, -4 message\ntoo large, -5 the native engine refused, -6 a native exception was\ncaught.\n\nEverything is asynchronous and signaling is yours. Creating a channel\nstarts a negotiation whose description and candidates arrive as events\nthat your code carries to the other peer over any channel you have; the\nother side's come back through <dcSetRemoteDescription> and\n<dcAddRemoteCandidate>. Events are delivered only when <dcPoll> drains\nthem, so call it on a timer. The dataChannelHelpers library\n(<dcStartPolling>) does that for you and dispatches each event as a\nmessage such as dcLocalDescriptionReady, dcChannelOpen and dcMessage.\n\nCall <dcCleanup> once at quit; there is no automatic unload hook.",
			"description":"Bindings to libdatachannel: WebRTC data channels for peer-to-peer\nmessaging, including with a web browser.\n\nDataChannelXT wraps libdatachannel. A peer is one WebRTC connection; a\nchannel is one message stream on a peer. Both are integer handles; 0\nmeans the call failed (see <dcLastError>), and a handle that has gone\nstale is a harmless no-op. Action handlers return 0 on success or a\nnegative error: -1 generic, -2 stale handle, -3 bad argument, -4 message\ntoo large, -5 the native engine refused, -6 a native exception was\ncaught.\n\nEverything is asynchronous and signaling is yours. Creating a channel\nstarts a negotiation whose description and candidates arrive as events\nthat your code carries to the other peer over any channel you have; the\nother side's come back through <dcSetRemoteDescription> and\n<dcAddRemoteCandidate>. Events are delivered only when <dcPoll> drains\nthem, so call it on a timer. The dataChannelHelpers library\n(<dcStartPolling>) does that for you and dispatches each event as a\nmessage such as dcLocalDescriptionReady, dcChannelOpen and dcMessage.\n\nCall <dcCleanup> once at quit; there is no automatic unload hook."
		},{
			"id":"org.openxtalk.library.datachannel-2",
			"name":"dcchannellabel",
			"display name":"dcChannelLabel",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelLabel(<pChannel>)"
			],
			"display syntax":[
				"dcChannelLabel(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The label of a data channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"on dcChannelIncoming pEvent\n   put dcChannelLabel(pEvent[\"channel\"]) into field \"Channel\"\nend dcChannelIncoming"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The label, or empty for a stale handle."
			}],
			"description":"Use <dcChannelLabel> to tell several channels on one peer apart.",
			"references":{
				"handler":["dcCreateChannel"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-3",
			"name":"dcfreepeer",
			"display name":"dcFreePeer",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcFreePeer(<pPeer>)"
			],
			"display syntax":[
				"dcFreePeer(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Close and destroy a peer connection and all of its channels.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"dcFreePeer sPeer\nput 0 into sPeer"
			}],
			"description":"Use <dcFreePeer> when you are done with a connection. It frees the\npeer, every channel on it and their handles. It is idempotent, and a\nstale handle is a harmless no-op. Events for freed handles are dropped,\nso free only when you no longer need to hear from the peer.",
			"references":{
				"handler":["dcClosePeer","dcCleanup"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-4",
			"name":"dccleanup",
			"display name":"dcCleanup",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcCleanup()"
			],
			"display syntax":[
				"dcCleanup()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Tear down every peer connection, every channel and the native threads.",
			"examples":[{
				"script":"on closeStack\n   dcStopPolling\n   dcCleanup\nend closeStack"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success."
			}],
			"description":"Use <dcCleanup> when your app is done with data channels, typically on\ncloseStack. It is mandatory before quitting: there is no automatic\nunload hook, and skipping it leaks the native worker threads. It is\nidempotent, and <dcCreatePeer> works again after it.\n\nWrite it as a bare command in statement position; dcCleanup() as a\nstatement does not compile. Use the parentheses only in an expression,\nsuch as dcCleanup() is 0. It frees every peer in the process, including\nthose another stack created.",
			"references":{
				"handler":["dcInit","dcFreePeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-5",
			"name":"dccreatepeer",
			"display name":"dcCreatePeer",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcCreatePeer(<pIceServers>)"
			],
			"display syntax":[
				"dcCreatePeer(<i>pIceServers</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Create a WebRTC peer connection.",
			"parameters":[{
				"name":"pIceServers",
				"type":"",
				"refparam":"false",
				"description":"The ICE servers to use, one URI per line, such as \"stun:stun.l.google.com:19302\" or \"turn:user:pass@host:3478?transport=udp\". Empty means none, which works on one machine or a LAN."
			}],
			"examples":[{
				"script":"local tPeer, tChan\nput dcCreatePeer(\"stun:stun.l.google.com:19302\") into tPeer\nput dcCreateChannel(tPeer, \"chat\") into tChan"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A positive peer handle, or 0 on failure."
			}],
			"description":"Use <dcCreatePeer> to start one side of a connection. Negotiation\nis automatic: creating the first channel produces the offer, and\napplying a remote offer with <dcSetRemoteDescription> produces the\nanswer. Both arrive as dcLocalDescriptionReady events for your signaling\ncode to deliver. A STUN server lets peers behind ordinary home NATs find\ntheir public address; a TURN server relays traffic for the rest, and its\ncredentials live in ordinary memory.\n\nIt checks the native library's version and throws an error if it does\nnot match. On failure it returns 0; see <dcLastError>.",
			"references":{
				"handler":["dcCreateChannel","dcSetRemoteDescription","dcFreePeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-6",
			"name":"dcgatheringstate",
			"display name":"dcGatheringState",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcGatheringState(<pPeer>)"
			],
			"display syntax":[
				"dcGatheringState(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The ICE candidate gathering state of a peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"if dcGatheringState(sPeer) is 2 then\n   put dcLocalDescription(sPeer) into field \"myBlob\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 new, 1 in progress, 2 complete, or -1 for a stale handle."
			}],
			"description":"Use <dcGatheringState> to know when the local description holds every\ncandidate, the moment copy/paste signaling can ship it. The\ndcGatheringStateChange event reports each change as it happens.",
			"references":{
				"handler":["dcLocalDescription","dcGatheringName"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-7",
			"name":"dclocaldescriptiontype",
			"display name":"dcLocalDescriptionType",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcLocalDescriptionType(<pPeer>)"
			],
			"display syntax":[
				"dcLocalDescriptionType(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The type of a peer's current local description.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"put dcLocalDescriptionType(sPeer) into tType"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"offer\", \"answer\", or empty when there is none or the handle is stale."
			}],
			"description":"Use <dcLocalDescriptionType> together with <dcLocalDescription> to send\nthe far side both the text and the type that <dcSetRemoteDescription>\nneeds.",
			"references":{
				"handler":["dcLocalDescription"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-8",
			"name":"dcchannelpeer",
			"display name":"dcChannelPeer",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelPeer(<pChannel>)"
			],
			"display syntax":[
				"dcChannelPeer(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The peer connection a data channel belongs to.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"on dcMessage pEvent\n   put dcChannelPeer(pEvent[\"channel\"]) into tPeer\nend dcMessage"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The peer handle, or 0 for a stale handle."
			}],
			"description":"Use <dcChannelPeer> in an event handler when one app drives several\nconnections and needs to know which one a channel is on.",
			"references":{
				"handler":["dcCreateChannel"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-9",
			"name":"dcpeerstate",
			"display name":"dcPeerState",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcPeerState(<pPeer>)"
			],
			"display syntax":[
				"dcPeerState(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The connection state of a peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"if dcPeerState(sPeer) is 2 then put \"connected\" into field \"Status\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 new, 1 connecting, 2 connected, 3 disconnected, 4 failed, 5 closed, or -1 for a stale handle."
			}],
			"description":"Use <dcPeerState> to check a connection on demand; the dcStateChange\nevent reports each change as it happens. 0 is a real state, which is\nwhy a stale handle answers -1. The helpers' <dcStateName> turns the\nnumber into a label.",
			"references":{
				"handler":["dcStateName","dcGatheringState"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-10",
			"name":"dcsetlocaldescription",
			"display name":"dcSetLocalDescription",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSetLocalDescription(<pPeer>,<pType>)"
			],
			"display syntax":[
				"dcSetLocalDescription(<i>pPeer</i>,<i>pType</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Start a manual renegotiation.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"\"offer\", \"answer\", or empty to let the engine choose."
			}],
			"examples":[{
				"script":"get dcSetLocalDescription(sPeer, \"offer\")"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcSetLocalDescription> only for manual renegotiation. Normally you\nnever call it: negotiation is automatic, and the description arrives as a\ndcLocalDescriptionReady event.",
			"references":{
				"handler":["dcLocalDescription","dcSetRemoteDescription"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-11",
			"name":"dcclosepeer",
			"display name":"dcClosePeer",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcClosePeer(<pPeer>)"
			],
			"display syntax":[
				"dcClosePeer(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Politely close a peer connection.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"get dcClosePeer(sPeer)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcClosePeer> to end a connection while still receiving its state\nevents. The handle stays inspectable until <dcFreePeer> destroys it.",
			"references":{
				"handler":["dcFreePeer","dcPeerState"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-12",
			"name":"dcsendtext",
			"display name":"dcSendText",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSendText(<pChannel>,<pText>)"
			],
			"display syntax":[
				"dcSendText(<i>pChannel</i>,<i>pText</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Send one text message on an open channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			},{
				"name":"pText",
				"type":"",
				"refparam":"false",
				"description":"The text to send."
			}],
			"examples":[{
				"script":"on dcChannelOpen pEvent\n   get dcSendText(pEvent[\"channel\"], \"hello!\")\nend dcChannelOpen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error (-4 when over 60000 bytes, -3 when the text contains a NUL character)."
			}],
			"description":"Use <dcSendText> for text messages. A browser peer receives a string; an\nOXT peer receives a dcMessage event with a text key.\n\nText containing a NUL character is refused with -3 before it reaches the\nnative layer, because it would otherwise be cut short at the NUL. That\nrefusal leaves <dcLastError> empty. Send such content as bytes with\n<dcSendData>.",
			"references":{
				"handler":["dcSendData","dcChannelIsOpen"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-13",
			"name":"dclasterror",
			"display name":"dcLastError",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcLastError()"
			],
			"display syntax":[
				"dcLastError()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The last error message from the native layer.",
			"examples":[{
				"script":"local tPeer\nput dcCreatePeer(\"\") into tPeer\nif tPeer is 0 then answer \"Could not create a peer:\" && dcLastError()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The message, or empty when there is no error."
			}],
			"description":"Use <dcLastError> after a call returns 0 or a negative number to find\nout why. The message stays until the next error or <dcClearError>.\n<dcSendText> clears it when it refuses text with an embedded NUL, since\nthat refusal never reaches the native layer.",
			"references":{
				"handler":["dcClearError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-14",
			"name":"dclibraryversion",
			"display name":"dcLibraryVersion",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcLibraryVersion()"
			],
			"display syntax":[
				"dcLibraryVersion()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The version of libdatachannel that DataChannelXT was built with.",
			"examples":[{
				"script":"put dcLibraryVersion() into field \"Version\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A string such as \"libdatachannel v0.24.5\"."
			}],
			"description":"Use <dcLibraryVersion> to report which libdatachannel the installed\nnative library was built from, for example in an about box or a bug\nreport. It is the pinned tag compiled in at build time.",
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-15",
			"name":"dcclearerror",
			"display name":"dcClearError",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcClearError()"
			],
			"display syntax":[
				"dcClearError()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Clear the last error message.",
			"examples":[{
				"script":"dcClearError"
			}],
			"description":"Use <dcClearError> before a call when you want <dcLastError> to report\nonly what that call did.",
			"references":{
				"handler":["dcLastError"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-16",
			"name":"dclocaldescription",
			"display name":"dcLocalDescription",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcLocalDescription(<pPeer>)"
			],
			"display syntax":[
				"dcLocalDescription(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The current local session description of a peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"on dcGatheringStateChange pEvent\n   if pEvent[\"state\"] is 2 then\n      put dcLocalDescription(pEvent[\"peer\"]) into field \"myBlob\"\n   end if\nend dcGatheringStateChange"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The whole SDP text, or empty when there is none yet or the handle is stale."
			}],
			"description":"Use <dcLocalDescription> for copy/paste (non-trickle) signaling. Once\nthe gathering state reaches complete (2), this description contains all\nthe gathered candidates, so you can ship this one text to the other side\nand skip shipping candidates.\n\nThe event that announces a new description is named\ndcLocalDescriptionReady, not dcLocalDescription, because an event of\nthis handler's name would be delivered to this getter instead of to your\nhandler.",
			"references":{
				"handler":["dcGatheringState","dcLocalDescriptionType","dcSetRemoteDescription"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-17",
			"name":"dccreatechannelex",
			"display name":"dcCreateChannelEx",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcCreateChannelEx(<pPeer>,<pLabel>,<pProtocol>,<pUnordered>,<pMaxRetransmits>,<pMaxLifetimeMs>,<pNegotiated>,<pStreamId>)"
			],
			"display syntax":[
				"dcCreateChannelEx(<i>pPeer</i>,<i>pLabel</i>,<i>pProtocol</i>,<i>pUnordered</i>,<i>pMaxRetransmits</i>,<i>pMaxLifetimeMs</i>,<i>pNegotiated</i>,<i>pStreamId</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Create a data channel with explicit reliability and negotiation options.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pLabel",
				"type":"",
				"refparam":"false",
				"description":"A name for the channel."
			},{
				"name":"pProtocol",
				"type":"",
				"refparam":"false",
				"description":"A subprotocol name, or empty for none."
			},{
				"name":"pUnordered",
				"type":"",
				"refparam":"false",
				"description":"true to allow out-of-order delivery."
			},{
				"name":"pMaxRetransmits",
				"type":"",
				"refparam":"false",
				"description":"At most this many retransmissions (0 or more), making the channel unreliable; -1 for unset."
			},{
				"name":"pMaxLifetimeMs",
				"type":"",
				"refparam":"false",
				"description":"Retransmit for at most this many milliseconds (0 or more), making the channel unreliable; -1 for unset."
			},{
				"name":"pNegotiated",
				"type":"",
				"refparam":"false",
				"description":"true for a channel both sides create out of band with the same stream id, with no in-band open handshake."
			},{
				"name":"pStreamId",
				"type":"",
				"refparam":"false",
				"description":"The stream id 0 to 65534 for a negotiated channel, or -1 for automatic."
			}],
			"examples":[{
				"script":"local tChan\nput dcCreateChannelEx(sPeer, \"state\", \"\", true, 0, -1, false, -1) into tChan"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A channel handle, or 0 on failure."
			}],
			"description":"Use <dcCreateChannelEx> for real-time traffic such as game state, where a\nlate message is worse than a lost one. Set at most one of the two\nreliability limits. With both at -1 and ordered delivery it behaves like\n<dcCreateChannel>.",
			"references":{
				"handler":["dcCreateChannel","dcChannelProtocol","dcChannelStreamId"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-18",
			"name":"dcsetremotedescription",
			"display name":"dcSetRemoteDescription",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSetRemoteDescription(<pPeer>,<pSdp>,<pType>)"
			],
			"display syntax":[
				"dcSetRemoteDescription(<i>pPeer</i>,<i>pSdp</i>,<i>pType</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Apply the other peer's description, received over your signaling channel.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pSdp",
				"type":"",
				"refparam":"false",
				"description":"The remote session description (SDP) text."
			},{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"\"offer\" or \"answer\", as the remote dcLocalDescriptionReady event carried it in its sdpType key."
			}],
			"examples":[{
				"script":"on signalArrived pSdpText, pSdpType\n   get dcSetRemoteDescription(sPeer, pSdpText, pSdpType)\nend signalArrived"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcSetRemoteDescription> on each side once the other side's\ndescription arrives. Applying an offer automatically produces this\nside's answer, which arrives as a dcLocalDescriptionReady event to send\nback. With copy/paste signaling, a description taken after gathering\ncompletes already contains its candidates, so this is the only call\nneeded on the far side.",
			"references":{
				"handler":["dcAddRemoteCandidate","dcLocalDescription","dcCreatePeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-19",
			"name":"dcfreechannel",
			"display name":"dcFreeChannel",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcFreeChannel(<pChannel>)"
			],
			"display syntax":[
				"dcFreeChannel(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Close and destroy a data channel, freeing its handle.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"dcFreeChannel sChan\nput 0 into sChan"
			}],
			"description":"Use <dcFreeChannel> when you are done with a channel. It is idempotent,\nand a stale handle is a harmless no-op. <dcFreePeer> frees all of a\npeer's channels at once.",
			"references":{
				"handler":["dcCloseChannel","dcFreePeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-20",
			"name":"dcsenddata",
			"display name":"dcSendData",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSendData(<pChannel>,<pData>)"
			],
			"display syntax":[
				"dcSendData(<i>pChannel</i>,<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Send one binary message on an open channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			},{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to send; empty data sends an empty message."
			}],
			"examples":[{
				"script":"on dcChannelOpen pEvent\n   get dcSendData(pEvent[\"channel\"], textEncode(\"hello\", \"UTF-8\"))\nend dcChannelOpen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error (-4 when the message is over 60000 bytes)."
			}],
			"description":"Use <dcSendData> for binary messages. A browser peer receives an\nArrayBuffer; an OXT peer receives a dcMessage event with the bytes in its\npayload key. Every message must fit both the 60000-byte budget and the\nchannel's negotiated limit (<dcChannelMaxMessage>); nothing is split or\ntruncated silently. Chunk larger payloads, or move bulk with TorrentXT.",
			"references":{
				"handler":["dcSendText","dcChannelMaxMessage","dcBufferedAmount"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-21",
			"name":"dcchannelisopen",
			"display name":"dcChannelIsOpen",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelIsOpen(<pChannel>)"
			],
			"display syntax":[
				"dcChannelIsOpen(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Whether a data channel is open and ready to send.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"if dcChannelIsOpen(sChan) then get dcSendText(sChan, \"ping\")"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true while the channel is open, false otherwise."
			}],
			"description":"Use <dcChannelIsOpen> before sending when you have not tracked the\ndcChannelOpen and dcChannelClosed events yourself. A channel is usable\nonly between those two events.",
			"references":{
				"handler":["dcSendText","dcSendData"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-22",
			"name":"dcchannelmaxmessage",
			"display name":"dcChannelMaxMessage",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelMaxMessage(<pChannel>)"
			],
			"display syntax":[
				"dcChannelMaxMessage(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The negotiated per-message size limit of a data channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"if the number of bytes in tData > dcChannelMaxMessage(sChan) then\n   answer \"Too large for this channel.\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The limit in bytes, or -1 for a stale handle."
			}],
			"description":"Use <dcChannelMaxMessage> to size messages. A send must fit both this\nlimit and DataChannelXT's own 60000-byte budget.",
			"references":{
				"handler":["dcSendData","dcSendText"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-23",
			"name":"dcbufferedamount",
			"display name":"dcBufferedAmount",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcBufferedAmount(<pChannel>)"
			],
			"display syntax":[
				"dcBufferedAmount(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The number of bytes queued to send on a channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"if dcBufferedAmount(sChan) > 1048576 then\n   put true into sPaused\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The queued byte count, or -1 for a stale handle."
			}],
			"description":"Use <dcBufferedAmount> for backpressure: send until it passes your\nhigh-water mark, then stop until the dcBufferedLow event arrives. Do not\nflood a slow channel.",
			"references":{
				"handler":["dcSetBufferedLowThreshold","dcFormatBytes"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-24",
			"name":"dcinit",
			"display name":"dcInit",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcInit()"
			],
			"display syntax":[
				"dcInit()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Initialize the native layer early, before the first connection.",
			"examples":[{
				"script":"on openStack\n   dcInit\nend openStack"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcInit> at startup to move the one-time DTLS certificate cost off\nyour first connection. It is optional: <dcCreatePeer> initializes the\nlibrary itself. It checks that the installed native library matches this\nbinding and throws an error if it does not. Calling it again is harmless.",
			"references":{
				"handler":["dcCleanup","dcCreatePeer"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-25",
			"name":"dcsetbufferedlowthreshold",
			"display name":"dcSetBufferedLowThreshold",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSetBufferedLowThreshold(<pChannel>,<pAmount>)"
			],
			"display syntax":[
				"dcSetBufferedLowThreshold(<i>pChannel</i>,<i>pAmount</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Arm the dcBufferedLow event for a channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			},{
				"name":"pAmount",
				"type":"",
				"refparam":"false",
				"description":"The threshold in bytes."
			}],
			"examples":[{
				"script":"get dcSetBufferedLowThreshold(sChan, 65536)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcSetBufferedLowThreshold> with <dcBufferedAmount> to pace large\nsends. The dcBufferedLow event fires when the channel's send queue\ndrains back under the threshold, the signal to resume sending.",
			"references":{
				"handler":["dcBufferedAmount"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-26",
			"name":"dccreatechannel",
			"display name":"dcCreateChannel",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcCreateChannel(<pPeer>,<pLabel>)"
			],
			"display syntax":[
				"dcCreateChannel(<i>pPeer</i>,<i>pLabel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Create a reliable, ordered data channel on a peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pLabel",
				"type":"",
				"refparam":"false",
				"description":"A name for the channel; the other side sees it in its dcChannelIncoming event."
			}],
			"examples":[{
				"script":"put dcCreatePeer(\"\") into sPeer\nput dcCreateChannel(sPeer, \"chat\") into sChan"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A channel handle, or 0 on failure."
			}],
			"description":"Use <dcCreateChannel> on the side that starts the connection. The first\nchannel on a new peer triggers the offer. The channel is not usable\nuntil its dcChannelOpen event arrives. The other side does not\ncreate it: it arrives there as a dcChannelIncoming event carrying\nits handle.",
			"references":{
				"handler":["dcCreateChannelEx","dcSendText","dcCloseChannel"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-27",
			"name":"dcaddremotecandidate",
			"display name":"dcAddRemoteCandidate",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcAddRemoteCandidate(<pPeer>,<pCandidate>,<pMid>)"
			],
			"display syntax":[
				"dcAddRemoteCandidate(<i>pPeer</i>,<i>pCandidate</i>,<i>pMid</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Apply one ICE candidate from the other peer.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			},{
				"name":"pCandidate",
				"type":"",
				"refparam":"false",
				"description":"The candidate text, as the remote dcLocalCandidate event carried it."
			},{
				"name":"pMid",
				"type":"",
				"refparam":"false",
				"description":"The media id that came with the candidate, or empty to let the engine resolve it."
			}],
			"examples":[{
				"script":"on candidateArrived pCandText, pMidText\n   get dcAddRemoteCandidate(sPeer, pCandText, pMidText)\nend candidateArrived"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcAddRemoteCandidate> for trickle signaling: each side ships every\ndcLocalCandidate event to the other, which applies it here. Trickle\nconnects fastest; copy/paste signaling skips candidates entirely and\nships one complete description instead.",
			"references":{
				"handler":["dcSetRemoteDescription","dcLocalDescription"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-28",
			"name":"dcpoll",
			"display name":"dcPoll",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcPoll()"
			],
			"display syntax":[
				"dcPoll()"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Drain every pending event in one call.",
			"examples":[{
				"script":"local tEvents\nput dcPoll() into tEvents\nrepeat for each element tEvent in tEvents\n   put tEvent[\"name\"] & return after field \"Log\"\nend repeat"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A list of event arrays, oldest first."
			}],
			"description":"Use <dcPoll> on a timer: nothing is delivered until it drains the\nnative queue. Poll every 16 to 33 milliseconds for a real-time feel, or\n100 or more for chat; the interval changes latency, never correctness.\nMost apps let <dcStartPolling> do this and handle the dispatched\nmessages instead.\n\nEach event array has \"code\" (the event number), \"name\" (such as\ndcMessage or dcChannelOpen), \"peer\", \"channel\", and the event's own keys\nsuch as \"sdp\", \"candidate\", \"state\", \"text\" or \"payload\" (binary data).\nIf the app stops polling for a long time, the bounded queue sheds events\nand reports a dcQueueOverflow event with the count.",
			"references":{
				"handler":["dcStartPolling","dcStopPolling"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-29",
			"name":"dcchannelstreamid",
			"display name":"dcChannelStreamId",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelStreamId(<pChannel>)"
			],
			"display syntax":[
				"dcChannelStreamId(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The SCTP stream id of a data channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"put dcChannelStreamId(sChan) into tStream"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The stream id, or -1 when the handle is stale or no id is assigned yet."
			}],
			"description":"Use <dcChannelStreamId> mainly with negotiated channels. Stream 0 is\nvalid, which is why \"no value\" is -1.",
			"references":{
				"handler":["dcCreateChannelEx"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-30",
			"name":"dcclosechannel",
			"display name":"dcCloseChannel",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcCloseChannel(<pChannel>)"
			],
			"display syntax":[
				"dcCloseChannel(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"Politely close a data channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"get dcCloseChannel(sChan)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"0 on success, or a negative error."
			}],
			"description":"Use <dcCloseChannel> to end one channel while keeping the peer. Both\nsides receive a dcChannelClosed event. The handle stays inspectable\nuntil <dcFreeChannel>.",
			"references":{
				"handler":["dcFreeChannel"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-31",
			"name":"dcselectedcandidatepair",
			"display name":"dcSelectedCandidatePair",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcSelectedCandidatePair(<pPeer>)"
			],
			"display syntax":[
				"dcSelectedCandidatePair(<i>pPeer</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The ICE candidate pair a connected peer is using.",
			"parameters":[{
				"name":"pPeer",
				"type":"",
				"refparam":"false",
				"description":"The peer handle."
			}],
			"examples":[{
				"script":"local tPair\nput dcSelectedCandidatePair(sPeer) into tPair\nput tPair[\"remoteCandidate\"] into field \"Route\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"An array with the keys \"localCandidate\" and \"remoteCandidate\", or an empty array until a pair is selected."
			}],
			"description":"Use <dcSelectedCandidatePair> once connected to see the path the\nconnection took. A candidate of type host or srflx means a direct path;\ntype relay means traffic goes through a TURN server.",
			"references":{
				"handler":["dcPeerState"]
			},
			"tags":["networking","library"]
		},{
			"id":"org.openxtalk.library.datachannel-32",
			"name":"dcchannelprotocol",
			"display name":"dcChannelProtocol",
			"library":"org.openxtalk.library.datachannel",
			"type":"handler",
			"syntax":[
				"dcChannelProtocol(<pChannel>)"
			],
			"display syntax":[
				"dcChannelProtocol(<i>pChannel</i>)"
			],
			"associations":["org.openxtalk.library.datachannel"],
			"summary":"The subprotocol of a data channel.",
			"parameters":[{
				"name":"pChannel",
				"type":"",
				"refparam":"false",
				"description":"The channel handle."
			}],
			"examples":[{
				"script":"put dcChannelProtocol(sChan) into tProtocol"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The subprotocol, or empty when there is none or the handle is stale."
			}],
			"description":"Use <dcChannelProtocol> to read the subprotocol set by\n<dcCreateChannelEx> on either side.",
			"references":{
				"handler":["dcCreateChannelEx"]
			},
			"tags":["networking","library"]
		}