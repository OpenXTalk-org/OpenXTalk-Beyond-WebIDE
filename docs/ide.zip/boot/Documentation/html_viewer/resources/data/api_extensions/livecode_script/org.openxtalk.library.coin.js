{
			"id":"org.openxtalk.library.coin-1",
			"name":"org.openxtalk.library.coin",
			"display name":"CoinXT",
			"library":"org.openxtalk.library.coin",
			"type":"library",
			"display syntax":[
				"CoinXT"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Bitcoin and Ethereum cryptography for xTalk: hashes, keys and signatures.\n\nCoinXT wraps two audited native libraries, trezor-crypto and upstream\nlibsecp256k1, and adds no cryptography of its own. This extension is the\nnative half: the digests (Keccak-256, SHA3-256, SHA-256, SHA-512,\nRIPEMD-160), HMAC, PBKDF2, secp256k1 keys, ECDSA signing, verification and\nrecovery, ECDH, the two BIP-32 tweak steps, the BIP-39 wordlist, BIP-340\nSchnorr signatures and the BIP-341 Taproot tweak. Encodings, addresses,\nmnemonics, HD derivation and transaction building live in the separate\nCoinXT Script Library (start with <cxHexEncode>), which must be in the\nmessage path, for example with start using stack \"coinxt\".\n\nEvery handler is synchronous and stateless: Data in, Data out, no handles\nand nothing to close. Hash text through textEncode(tText, \"utf-8\"). A\nfailure throws an error that begins \"CoinXT:\" and names the handler, and\nevery call first checks that the installed native library matches this\nbinding (<cxCheckABI>).\n\nCoinXT is a calculator, not a wallet. It never makes key material (supply\nyour own random bytes, for example from SodiumXT's sxRandomBytes), and\nstoring keys, backing them up and confirming before signing are your\napp's job.",
			"description":"Bitcoin and Ethereum cryptography for xTalk: hashes, keys and signatures.\n\nCoinXT wraps two audited native libraries, trezor-crypto and upstream\nlibsecp256k1, and adds no cryptography of its own. This extension is the\nnative half: the digests (Keccak-256, SHA3-256, SHA-256, SHA-512,\nRIPEMD-160), HMAC, PBKDF2, secp256k1 keys, ECDSA signing, verification and\nrecovery, ECDH, the two BIP-32 tweak steps, the BIP-39 wordlist, BIP-340\nSchnorr signatures and the BIP-341 Taproot tweak. Encodings, addresses,\nmnemonics, HD derivation and transaction building live in the separate\nCoinXT Script Library (start with <cxHexEncode>), which must be in the\nmessage path, for example with start using stack \"coinxt\".\n\nEvery handler is synchronous and stateless: Data in, Data out, no handles\nand nothing to close. Hash text through textEncode(tText, \"utf-8\"). A\nfailure throws an error that begins \"CoinXT:\" and names the handler, and\nevery call first checks that the installed native library matches this\nbinding (<cxCheckABI>).\n\nCoinXT is a calculator, not a wallet. It never makes key material (supply\nyour own random bytes, for example from SodiumXT's sxRandomBytes), and\nstoring keys, backing them up and confirming before signing are your\napp's job."
		},{
			"id":"org.openxtalk.library.coin-2",
			"name":"cxbip39wordlist",
			"display name":"cxBip39Wordlist",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxBip39Wordlist()"
			],
			"display syntax":[
				"cxBip39Wordlist()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The BIP-39 English wordlist as 2048 fixed-width 8-byte slots.",
			"examples":[{
				"script":"put cxBip39Wordlist() into tList\nput word 1 of (byte 1 to 8 of tList) into tFirstWord"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"16384 bytes, as Data: each word left-aligned and space padded, in list order."
			}],
			"description":"Word i, counting from 0, is bytes i*8+1 to i*8+8; trim the trailing\nspaces. The list is sorted, so a word's index can be found by binary\nsearch. The mnemonic handlers already use it; call it yourself only when\nyou build your own mnemonic UI, such as an autocomplete.",
			"references":{
				"handler":["cxBip39WordlistLen","cxMnemonicFromEntropy"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-3",
			"name":"cxpubkeylenuncompressed",
			"display name":"cxPubkeyLenUncompressed",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPubkeyLenUncompressed()"
			],
			"display syntax":[
				"cxPubkeyLenUncompressed()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of an uncompressed public key.",
			"examples":[{
				"script":"put cxPubkeyLenUncompressed() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"65."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxPublicKey","cxPubkeyLenCompressed"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-4",
			"name":"cxtaproottweakpubkey",
			"display name":"cxTaprootTweakPubkey",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxTaprootTweakPubkey(<pInternalKey>,<pMerkleRoot>)"
			],
			"display syntax":[
				"cxTaprootTweakPubkey(<i>pInternalKey</i>,<i>pMerkleRoot</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The BIP-341 Taproot output key for an internal x-only key, with its parity.",
			"parameters":[{
				"name":"pInternalKey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only internal key, as Data."
			},{
				"name":"pMerkleRoot",
				"type":"",
				"refparam":"false",
				"description":"Empty for a key-path-only output, or the 32-byte script-tree root, as Data."
			}],
			"examples":[{
				"script":"put cxTaprootTweakPubkey(tInternal, empty) into tRecord\nput byte 1 to 32 of tRecord into tOutputKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"33 bytes, as Data: the 32-byte x-only output key followed by one parity byte (0 for even Y, 1 for odd)."
			}],
			"description":"Computes BIP-341's Q = P + int(hash_TapTweak(bytes(P) || merkle_root))G.\nThe 32-byte key is the witness program of the P2TR output; the parity\nbyte goes in a script-path spend's control block. <cxTaprootTweak>\nreturns the same thing as a named array.\n\nAn empty pMerkleRoot is NOT 32 zero bytes, and the difference\nis consensus: the two give different output keys and addresses. If you\nhave no script tree, pass empty. Pass the same root to\n<cxTaprootTweakSeckey>.",
			"references":{
				"handler":["cxTaprootTweak","cxTaprootTweakSeckey","cxTaprootOutputLen"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-5",
			"name":"cxsignaturelen",
			"display name":"cxSignatureLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSignatureLen()"
			],
			"display syntax":[
				"cxSignatureLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of an ECDSA signature from cxSign.",
			"examples":[{
				"script":"put cxSignatureLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"64."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSign","cxRecoverableSignatureLen"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-6",
			"name":"cxseckeytweakadd",
			"display name":"cxSeckeyTweakAdd",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSeckeyTweakAdd(<pSeckey>,<pTweak>)"
			],
			"display syntax":[
				"cxSeckeyTweakAdd(<i>pSeckey</i>,<i>pTweak</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Add a 32-byte tweak to a private key modulo the group order (one BIP-32 step).",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data."
			},{
				"name":"pTweak",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte tweak, as Data."
			}],
			"examples":[{
				"script":"put cxSeckeyTweakAdd(tParentKey, byte 1 to 32 of tI) into tChildKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte tweaked private key, as Data."
			}],
			"description":"A low-level primitive; most callers want <cxHdDeriveChild> or\n<cxHdDerivePath>. It throws when the result is not a usable key (a tweak\nat or above the group order, or a zero result), which BIP-32 answers by\nmoving to the next child index. A zero tweak throws too.",
			"references":{
				"handler":["cxPubkeyTweakAdd","cxHdDeriveChild"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-7",
			"name":"cxschnorrsignaturelen",
			"display name":"cxSchnorrSignatureLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSchnorrSignatureLen()"
			],
			"display syntax":[
				"cxSchnorrSignatureLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a BIP-340 Schnorr signature.",
			"examples":[{
				"script":"put cxSchnorrSignatureLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"64."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSchnorrSign"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-8",
			"name":"cxbip39wordlistlen",
			"display name":"cxBip39WordlistLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxBip39WordlistLen()"
			],
			"display syntax":[
				"cxBip39WordlistLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of the BIP-39 wordlist from cxBip39Wordlist.",
			"examples":[{
				"script":"put cxBip39WordlistLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"16384 (2048 words of 8 bytes)."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxBip39Wordlist"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-9",
			"name":"cxtaproottweakseckey",
			"display name":"cxTaprootTweakSeckey",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxTaprootTweakSeckey(<pSeckey>,<pMerkleRoot>)"
			],
			"display syntax":[
				"cxTaprootTweakSeckey(<i>pSeckey</i>,<i>pMerkleRoot</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The private key that spends a BIP-341 Taproot output.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte internal private key, as Data."
			},{
				"name":"pMerkleRoot",
				"type":"",
				"refparam":"false",
				"description":"Empty for a key-path-only output, or the 32-byte script-tree root, as Data."
			}],
			"examples":[{
				"script":"put cxTaprootTweakSeckey(tSeckey, empty) into tSpendKey\nput cxSchnorrSign(tSpendKey, tSighash, empty) into tSignature"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte tweaked private key, as Data."
			}],
			"description":"It takes the internal private key and derives the internal public key\nitself, so a mismatched pair can never produce a key for coins it cannot\nspend. Pass the same pMerkleRoot you used for the address (empty for\nkey-path-only, which is not 32 zero bytes), then sign the BIP-341 sighash\nwith <cxSchnorrSign>.",
			"references":{
				"handler":["cxTaprootTweakPubkey","cxSchnorrSign","cxBtcSighashTaproot"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-10",
			"name":"cxsign",
			"display name":"cxSign",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSign(<pSeckey>,<pDigest>)"
			],
			"display syntax":[
				"cxSign(<i>pSeckey</i>,<i>pDigest</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Sign a 32-byte digest with ECDSA over secp256k1.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data."
			},{
				"name":"pDigest",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte digest to sign, as Data."
			}],
			"examples":[{
				"script":"put cxBtcSighashSegwit(2, tOutpoints, tSequences, 1, tScriptCode, tAmount, tOutputs, 0, 1) into tDigest\nput cxDerEncode(cxSign(tSeckey, tDigest)) & numToByte(1) into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 64-byte signature (r then s), as Data."
			}],
			"description":"Signing is deterministic (RFC 6979): the same key and digest always give\nthe same bytes, and s is always the low value Bitcoin and Ethereum both\nrequire.\n\nSign only what you built. <cxSign> signs any 32 bytes it is handed;\nbuilding the right digest (the transaction builders do that) and showing\nthe user what it means is your app's job. A digest of the wrong length,\nor one that is all zero bytes (forgeable), throws. For Ethereum use\n<cxSignRecoverable>.",
			"references":{
				"handler":["cxVerify","cxSignRecoverable","cxDerEncode","cxBtcSighashSegwit"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-11",
			"name":"cxrecoverablesignaturelen",
			"display name":"cxRecoverableSignatureLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxRecoverableSignatureLen()"
			],
			"display syntax":[
				"cxRecoverableSignatureLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a recoverable signature from cxSignRecoverable.",
			"examples":[{
				"script":"put cxRecoverableSignatureLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"65."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSignRecoverable","cxSignatureLen"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-12",
			"name":"cxxonlypubkey",
			"display name":"cxXOnlyPubkey",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxXOnlyPubkey(<pSeckey>)"
			],
			"display syntax":[
				"cxXOnlyPubkey(<i>pSeckey</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The 32-byte x-only public key for a private key (BIP-340).",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data."
			}],
			"examples":[{
				"script":"put cxXOnlyPubkey(tSeckey) into tInternal\nput cxBtcAddressP2TRFromInternal(tInternal, empty) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 32-byte x-only public key, as Data."
			}],
			"description":"This is the X coordinate of the point whose Y is even: what a BIP-340\nverifier needs, and the internal key a Taproot output is built from. It\nis not a Taproot output key until it has been tweaked; pay to it through\n<cxBtcAddressP2TRFromInternal>, not <cxBtcAddressP2TR>.",
			"references":{
				"handler":["cxTaprootTweakPubkey","cxBtcAddressP2TRFromInternal","cxSchnorrVerify"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-13",
			"name":"cxcheckabi",
			"display name":"cxCheckABI",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxCheckABI()"
			],
			"display syntax":[
				"cxCheckABI()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Check that the installed native library matches this binding.",
			"examples":[{
				"script":"cxCheckABI"
			}],
			"description":"Use <cxCheckABI> at startup to fail loudly on a stale or mismatched\nnative library. It is a command that returns nothing: silence is the\npass, and it throws an error asking you to reinstall CoinXT when the\nlibrary does not report the ABI this binding expects (ABI 7). Call it\nbare, as a command; put cxCheckABI() prints an empty line and proves\nnothing.\n\nEvery other handler runs the same check first, so you rarely need it.\nA \"handler not found\" error means the extension is not installed or did\nnot load.",
			"references":{
				"handler":["cxKeccak256Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-14",
			"name":"cxkeccak256",
			"display name":"cxKeccak256",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxKeccak256(<pData>)"
			],
			"display syntax":[
				"cxKeccak256(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The Keccak-256 digest of some bytes, the hash Ethereum uses.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxKeccak256(textEncode(\"abc\", \"utf-8\")) into tDigest\nput cxHexEncode(tDigest) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 32-byte digest, as Data."
			}],
			"description":"Use <cxKeccak256> for anything Ethereum: addresses, EIP-55 checksums,\ntransaction hashes. It is NOT SHA3-256. The two differ by one padding\nbyte, and a mix-up does not fail: it returns a well-formed digest that is\nsimply wrong. For NIST SHA-3 use <cxSha3_256>.",
			"references":{
				"handler":["cxSha3_256","cxEthAddress","cxKeccak256Len"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-15",
			"name":"cxkeccak256len",
			"display name":"cxKeccak256Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxKeccak256Len()"
			],
			"display syntax":[
				"cxKeccak256Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a Keccak-256 digest.",
			"examples":[{
				"script":"put cxKeccak256Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code. It is also a handy load probe: unlike\n<cxCheckABI>, it returns a value you can print.",
			"references":{
				"handler":["cxKeccak256"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-16",
			"name":"cxsha512len",
			"display name":"cxSha512Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha512Len()"
			],
			"display syntax":[
				"cxSha512Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a SHA-512 digest.",
			"examples":[{
				"script":"put cxSha512Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"64."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSha512"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-17",
			"name":"cxhmacsha256len",
			"display name":"cxHmacSha256Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxHmacSha256Len()"
			],
			"display syntax":[
				"cxHmacSha256Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of an HMAC-SHA256 result.",
			"examples":[{
				"script":"put cxHmacSha256Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxHmacSha256"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-18",
			"name":"cxtaprootoutputlen",
			"display name":"cxTaprootOutputLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxTaprootOutputLen()"
			],
			"display syntax":[
				"cxTaprootOutputLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of the record cxTaprootTweakPubkey returns.",
			"examples":[{
				"script":"put cxTaprootOutputLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"33 (a 32-byte output key and one parity byte)."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxTaprootTweakPubkey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-19",
			"name":"cxseckeyisvalid",
			"display name":"cxSeckeyIsValid",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSeckeyIsValid(<pSeckey>)"
			],
			"display syntax":[
				"cxSeckeyIsValid(<i>pSeckey</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Whether some bytes are a valid secp256k1 private key.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The candidate key, as Data."
			}],
			"examples":[{
				"script":"if not cxSeckeyIsValid(cxHexDecode(field \"Key\")) then\n   answer \"That is not a usable private key.\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Use <cxSeckeyIsValid> for an imported key (a pasted hex string, a decoded\nWIF), where \"no\" is an ordinary answer. Empty, the wrong length, zero and\nvalues at or above the group order all answer false instead of throwing.",
			"references":{
				"handler":["cxNewSeckey","cxWifDecode"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-20",
			"name":"cxsha256",
			"display name":"cxSha256",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha256(<pData>)"
			],
			"display syntax":[
				"cxSha256(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The SHA-256 digest of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxSha256(textEncode(\"abc\", \"utf-8\")) into tDigest\nput cxHexEncode(tDigest) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 32-byte digest, as Data."
			}],
			"description":"Use <cxSha256> for Bitcoin's workhorse hash (FIPS 180-4). For the\ndouble hash Bitcoin uses in checksums and txids, call <cxHash256>; for\nRIPEMD-160 of SHA-256, call <cxHash160>.",
			"references":{
				"handler":["cxHash256","cxHash160","cxSha256Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-21",
			"name":"cxsha512",
			"display name":"cxSha512",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha512(<pData>)"
			],
			"display syntax":[
				"cxSha512(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The SHA-512 digest of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxSha512(textEncode(\"abc\", \"utf-8\")) into tDigest\nput cxHexEncode(tDigest) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 64-byte digest, as Data."
			}],
			"description":"Use <cxSha512> for a plain SHA-512 (FIPS 180-4). BIP-32 and BIP-39\nuse it through <cxHmacSha512> and <cxPbkdf2HmacSha512>.",
			"references":{
				"handler":["cxHmacSha512","cxSha512Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-22",
			"name":"cxseckeylen",
			"display name":"cxSeckeyLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSeckeyLen()"
			],
			"display syntax":[
				"cxSeckeyLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a secp256k1 private key.",
			"examples":[{
				"script":"put cxSeckeyLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxNewSeckey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-23",
			"name":"cxpubkeycombine",
			"display name":"cxPubkeyCombine",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPubkeyCombine(<pKeys>)"
			],
			"display syntax":[
				"cxPubkeyCombine(<i>pKeys</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The sum of one or more compressed public keys.",
			"parameters":[{
				"name":"pKeys",
				"type":"",
				"refparam":"false",
				"description":"The 33-byte compressed keys concatenated, as Data (33 times the number of keys)."
			}],
			"examples":[{
				"script":"put cxPubkeyCombine(tKeyA & tKeyB & tKeyC) into tSum"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 33-byte compressed sum, as Data."
			}],
			"description":"Point addition, for BIP-352 silent-payment receiving, where a receiver\nsums the input public keys of each transaction it scans. The whole set\nis summed at once, so an intermediate sum at infinity is fine as long as\nthe final one is not.\n\nIt throws on a final sum at infinity (a receiver skips such a\ntransaction), a key that does not parse, a length that is not a multiple\nof 33, and an empty set.",
			"references":{
				"handler":["cxPublicKey","cxEcdh"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-24",
			"name":"cxsha3_256",
			"display name":"cxSha3_256",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha3_256(<pData>)"
			],
			"display syntax":[
				"cxSha3_256(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The SHA3-256 digest of some bytes (NIST FIPS 202).",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxSha3_256(textEncode(\"abc\", \"utf-8\")) into tDigest\nput cxHexEncode(tDigest) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 32-byte digest, as Data."
			}],
			"description":"Use <cxSha3_256> when a specification cites FIPS 202 or standard SHA-3.\nIt is NOT Keccak-256, which is what Ethereum uses; for anything Ethereum\nuse <cxKeccak256>.",
			"references":{
				"handler":["cxKeccak256","cxSha3_256Len"]
			},
			"tags":["cryptography","library","cryptography"]
		},{
			"id":"org.openxtalk.library.coin-25",
			"name":"cxecdhlen",
			"display name":"cxEcdhLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxEcdhLen()"
			],
			"display syntax":[
				"cxEcdhLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of the raw ECDH point from cxEcdh.",
			"examples":[{
				"script":"put cxEcdhLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"65."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxEcdh"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-26",
			"name":"cxpubkeydecompress",
			"display name":"cxPubkeyDecompress",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPubkeyDecompress(<pPubkey>)"
			],
			"display syntax":[
				"cxPubkeyDecompress(<i>pPubkey</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Expand a compressed public key to its 65-byte uncompressed form.",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"A 33-byte compressed or 65-byte uncompressed public key, as Data."
			}],
			"examples":[{
				"script":"put cxPubkeyDecompress(tPubkey) into tFullKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 65-byte uncompressed key (0x04, then X and Y), as Data."
			}],
			"description":"An uncompressed key is returned unchanged, so code that normalizes mixed\ninput does not need to branch. A malformed or off-curve key throws.",
			"references":{
				"handler":["cxPublicKey","cxPubkeyLenUncompressed"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-27",
			"name":"cxnewseckey",
			"display name":"cxNewSeckey",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxNewSeckey(<pEntropy>)"
			],
			"display syntax":[
				"cxNewSeckey(<i>pEntropy</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Check 32 bytes of your own entropy as a secp256k1 private key and return them.",
			"parameters":[{
				"name":"pEntropy",
				"type":"",
				"refparam":"false",
				"description":"32 cryptographically random bytes, as Data."
			}],
			"examples":[{
				"script":"put cxNewSeckey(sxRandomBytes(32)) into tSeckey\nput cxPublicKey(tSeckey, true) into tPubkey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The same 32 bytes, unchanged, as Data."
			}],
			"description":"A secp256k1 private key is a 32-byte number from 1 to n-1, so there is\nnothing to transform: <cxNewSeckey> checks the bytes and hands them back,\nand throws if they are not a valid key (about one draw in 2^128 fails).\n\nThe entropy must be cryptographically random. CoinXT has no key-making\nrandom source of its own; use SodiumXT's sxRandomBytes or the operating\nsystem. For an imported key, where \"not valid\" is an ordinary answer,\nuse <cxSeckeyIsValid>.",
			"references":{
				"handler":["cxSeckeyIsValid","cxPublicKey","cxSeckeyLen"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-28",
			"name":"cxschnorrsign",
			"display name":"cxSchnorrSign",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSchnorrSign(<pSeckey>,<pMessage>,<pAuxRand>)"
			],
			"display syntax":[
				"cxSchnorrSign(<i>pSeckey</i>,<i>pMessage</i>,<i>pAuxRand</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Sign a 32-byte message with a BIP-340 Schnorr signature.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data. For a Taproot key-path spend, the key from cxTaprootTweakSeckey."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte message, as Data. For Taproot, the BIP-341 sighash."
			},{
				"name":"pAuxRand",
				"type":"",
				"refparam":"false",
				"description":"Empty, or 32 bytes of auxiliary randomness, as Data."
			}],
			"examples":[{
				"script":"put cxTaprootTweakSeckey(tSeckey, empty) into tSpendKey\nput cxSchnorrSign(tSpendKey, tSighash, empty) into tSignature"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 64-byte BIP-340 signature, as Data."
			}],
			"description":"The message must be exactly 32 bytes: CoinXT signs only a digest you\nbuilt and can explain, the same rule as <cxSign>.\n\nAn empty pAuxRand draws 32 fresh bytes from the operating system, BIP-340's\nrecommended default, so each signature differs (all of them verify). It\nnever means an all-zero aux. Pass 32 bytes when you need a reproducible\nsignature, as the published test vectors do. Any other length throws.",
			"references":{
				"handler":["cxSchnorrVerify","cxTaprootTweakSeckey","cxBtcSighashTaproot"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-29",
			"name":"cxsignrecoverable",
			"display name":"cxSignRecoverable",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSignRecoverable(<pSeckey>,<pDigest>)"
			],
			"display syntax":[
				"cxSignRecoverable(<i>pSeckey</i>,<i>pDigest</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Sign a 32-byte digest with recoverable ECDSA, as Ethereum does.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data."
			},{
				"name":"pDigest",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte digest to sign, as Data."
			}],
			"examples":[{
				"script":"put cxEth1559Sighash(1, 0, \"3b9aca00\", \"04a817c800\", 21000, tTo, \"0de0b6b3a7640000\", \"\") into tDigest\nput cxSignRecoverable(tSeckey, tDigest) into tSig\nput byteToNum(byte 65 of tSig) into tRecid"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"65 bytes, as Data: the 64-byte signature (r then s) followed by a one-byte recovery id."
			}],
			"description":"Deterministic (RFC 6979), with low s, like <cxSign>. Ethereum's v is\nbuilt from the recovery id; <cxEthLegacyEncode> and <cxEth1559Encode>\ntake it with r (bytes 1 to 32) and s (bytes 33 to 64) as hex. The same\nrule as <cxSign> applies: sign only a digest you built and showed the\nuser.",
			"references":{
				"handler":["cxRecover","cxEthLegacyEncode","cxEth1559Encode"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-30",
			"name":"cxhmacsha512len",
			"display name":"cxHmacSha512Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxHmacSha512Len()"
			],
			"display syntax":[
				"cxHmacSha512Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of an HMAC-SHA512 result.",
			"examples":[{
				"script":"put cxHmacSha512Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"64."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxHmacSha512"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-31",
			"name":"cxxonlypubkeylen",
			"display name":"cxXOnlyPubkeyLen",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxXOnlyPubkeyLen()"
			],
			"display syntax":[
				"cxXOnlyPubkeyLen()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of an x-only public key, which is also a Taproot output key.",
			"examples":[{
				"script":"put cxXOnlyPubkeyLen() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxXOnlyPubkey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-32",
			"name":"cxripemd160len",
			"display name":"cxRipemd160Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxRipemd160Len()"
			],
			"display syntax":[
				"cxRipemd160Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a RIPEMD-160 digest.",
			"examples":[{
				"script":"put cxRipemd160Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"20."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxRipemd160"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-33",
			"name":"cxpublickey",
			"display name":"cxPublicKey",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPublicKey(<pSeckey>,<pCompressed>)"
			],
			"display syntax":[
				"cxPublicKey(<i>pSeckey</i>,<i>pCompressed</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The public key for a secp256k1 private key.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte private key, as Data."
			},{
				"name":"pCompressed",
				"type":"",
				"refparam":"false",
				"description":"true for the 33-byte compressed form, false for the 65-byte uncompressed form."
			}],
			"examples":[{
				"script":"put cxPublicKey(tSeckey, true) into tPubkey\nput cxBtcAddressP2WPKH(tPubkey) into tAddress"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The public key, as Data: 33 bytes (0x02 or 0x03, then X) or 65 bytes (0x04, then X and Y)."
			}],
			"description":"Modern Bitcoin uses the compressed form. An Ethereum address is built\nfrom the uncompressed form, but <cxEthAddress> accepts either. Throws if\npSeckey is not a valid private key.",
			"references":{
				"handler":["cxPubkeyDecompress","cxXOnlyPubkey","cxEthAddress"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-34",
			"name":"cxrecover",
			"display name":"cxRecover",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxRecover(<pSignature>,<pDigest>)"
			],
			"display syntax":[
				"cxRecover(<i>pSignature</i>,<i>pDigest</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The public key that produced a recoverable signature.",
			"parameters":[{
				"name":"pSignature",
				"type":"",
				"refparam":"false",
				"description":"The 65-byte recoverable signature from cxSignRecoverable, as Data."
			},{
				"name":"pDigest",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte digest that was signed, as Data."
			}],
			"examples":[{
				"script":"put cxRecover(tSig, tDigest) into tKey\nput cxEthAddress(tKey) into tSigner"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 65-byte uncompressed public key, as Data."
			}],
			"description":"A successful recovery proves nothing on its own: a well-formed signature\nrecovers some key. Compare the recovered key (or its address) against the\none you expected, byte for byte; skipping that comparison is the classic\necrecover mistake. Do not compare hex text with a bare is, which can read\ntwo hex strings as numbers. An unusable signature or a recovery id above\n3 throws.",
			"references":{
				"handler":["cxSignRecoverable","cxEthAddress"]
			},
			"tags":["cryptography","library","cryptography","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-35",
			"name":"cxpubkeytweakadd",
			"display name":"cxPubkeyTweakAdd",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPubkeyTweakAdd(<pPubkey>,<pTweak>)"
			],
			"display syntax":[
				"cxPubkeyTweakAdd(<i>pPubkey</i>,<i>pTweak</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Add the point of a 32-byte tweak to a compressed public key (one BIP-32 step).",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"The 33-byte compressed public key, as Data."
			},{
				"name":"pTweak",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte tweak, as Data."
			}],
			"examples":[{
				"script":"put cxPubkeyTweakAdd(tParentPub, byte 1 to 32 of tI) into tChildPub"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 33-byte compressed tweaked public key, as Data."
			}],
			"description":"The public half of BIP-32 derivation, which lets a watch-only wallet\nderive receive addresses with no private key. An uncompressed key throws\nrather than being compressed for you, and so does a zero tweak or an\nunusable result. Most callers want <cxHdDeriveChild>.",
			"references":{
				"handler":["cxSeckeyTweakAdd","cxHdDeriveChild","cxHdNeuter"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-36",
			"name":"cxecdh",
			"display name":"cxEcdh",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxEcdh(<pSeckey>,<pPubkey>)"
			],
			"display syntax":[
				"cxEcdh(<i>pSeckey</i>,<i>pPubkey</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The raw ECDH shared point between your private key and their public key.",
			"parameters":[{
				"name":"pSeckey",
				"type":"",
				"refparam":"false",
				"description":"Your 32-byte private key, as Data."
			},{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"Their public key (33 or 65 bytes), as Data."
			}],
			"examples":[{
				"script":"put cxEcdh(tMySeckey, tTheirPubkey) into tPoint\nput cxSha256(byte 2 to 33 of tPoint) into tSharedKey"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 65-byte shared point (0x04, then X and Y), as Data."
			}],
			"description":"This is a point, not a shared key. Protocols disagree about which key\nderivation to run over it and whether it covers X alone, so CoinXT\nreturns the point and you apply the derivation your protocol specifies.\nSHA-256 of the 32 X bytes is a common one; match the other end rather\nthan guessing.",
			"references":{
				"handler":["cxEcdhLen","cxSha256"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-37",
			"name":"cxpubkeylencompressed",
			"display name":"cxPubkeyLenCompressed",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPubkeyLenCompressed()"
			],
			"display syntax":[
				"cxPubkeyLenCompressed()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a compressed public key.",
			"examples":[{
				"script":"put cxPubkeyLenCompressed() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"33."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxPublicKey","cxPubkeyLenUncompressed"]
			},
			"tags":["cryptography","library","cryptography","bitcoin","ethereum"]
		},{
			"id":"org.openxtalk.library.coin-38",
			"name":"cxripemd160",
			"display name":"cxRipemd160",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxRipemd160(<pData>)"
			],
			"display syntax":[
				"cxRipemd160(<i>pData</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The RIPEMD-160 digest of some bytes.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"The bytes to hash, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxRipemd160(textEncode(\"abc\", \"utf-8\")) into tDigest\nput cxHexEncode(tDigest) into field \"Digest\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 20-byte digest, as Data."
			}],
			"description":"RIPEMD-160 is the second half of Bitcoin's HASH160. To hash a public\nkey for an address, call <cxHash160>, which runs SHA-256 first.",
			"references":{
				"handler":["cxHash160","cxRipemd160Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-39",
			"name":"cxpbkdf2hmacsha512",
			"display name":"cxPbkdf2HmacSha512",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxPbkdf2HmacSha512(<pPassword>,<pSalt>,<pIterations>,<pOutLen>)"
			],
			"display syntax":[
				"cxPbkdf2HmacSha512(<i>pPassword</i>,<i>pSalt</i>,<i>pIterations</i>,<i>pOutLen</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Derive key bytes from a password with PBKDF2-HMAC-SHA512.",
			"parameters":[{
				"name":"pPassword",
				"type":"",
				"refparam":"false",
				"description":"The password, as Data."
			},{
				"name":"pSalt",
				"type":"",
				"refparam":"false",
				"description":"The salt, as Data."
			},{
				"name":"pIterations",
				"type":"",
				"refparam":"false",
				"description":"The iteration count, from 1 to 2147483647."
			},{
				"name":"pOutLen",
				"type":"",
				"refparam":"false",
				"description":"How many bytes to return; at least 1."
			}],
			"examples":[{
				"script":"put cxPbkdf2HmacSha512(textEncode(tMnemonic, \"utf-8\"), \\\n      textEncode(\"mnemonic\" & tPassphrase, \"utf-8\"), 2048, 64) into tSeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Exactly pOutLen bytes, as Data."
			}],
			"description":"This is the BIP-39 mnemonic-to-seed function: the salt is \"mnemonic\"\nfollowed by the passphrase, 2048 iterations, 64 bytes out. For that use,\ncall <cxMnemonicToSeed>, which also normalizes the mnemonic's whitespace.\n\nIt fails closed: an output length below 1, an iteration count below 1\n(a count of 0 would quietly derive a one-iteration key) or above\n2147483647 throws. The output is prefix-consistent: asking for 20 bytes\ngives the first 20 of the 64-byte answer.\n\nThe result is often a seed. Clear your variable as soon as you are done\nwith it; script variables are not locked memory.",
			"references":{
				"handler":["cxMnemonicToSeed","cxHmacSha512"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-40",
			"name":"cxhmacsha256",
			"display name":"cxHmacSha256",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxHmacSha256(<pKey>,<pMessage>)"
			],
			"display syntax":[
				"cxHmacSha256(<i>pKey</i>,<i>pMessage</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"HMAC-SHA256 of a message under a key (RFC 2104).",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, as Data. It may be empty and may be any length."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxHmacSha256(tKey, textEncode(\"Hi There\", \"utf-8\")) into tMac"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 32-byte MAC, as Data."
			}],
			"description":"Use <cxHmacSha256> for a keyed MAC. A long key is hashed and a short one\npadded internally, as RFC 2104 defines.\n\nDo not compare a MAC with is or =: that is a timing leak. CoinXT has no\nconstant-time compare; use SodiumXT's sxMemEqual if it is installed.",
			"references":{
				"handler":["cxHmacSha512","cxHmacSha256Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-41",
			"name":"cxverify",
			"display name":"cxVerify",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxVerify(<pPubkey>,<pDigest>,<pSignature>)"
			],
			"display syntax":[
				"cxVerify(<i>pPubkey</i>,<i>pDigest</i>,<i>pSignature</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Check an ECDSA signature over a 32-byte digest.",
			"parameters":[{
				"name":"pPubkey",
				"type":"",
				"refparam":"false",
				"description":"The signer's public key (33 or 65 bytes), as Data."
			},{
				"name":"pDigest",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte digest that was signed, as Data."
			},{
				"name":"pSignature",
				"type":"",
				"refparam":"false",
				"description":"The 64-byte signature (r then s), as Data."
			}],
			"examples":[{
				"script":"if cxVerify(tPubkey, tDigest, tSignature) then\n   put \"Signature is good\" into field \"Status\"\nend if"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the signature verifies, false if it does not."
			}],
			"description":"A signature that does not verify is an ordinary answer: false. A\nmalformed public key or a signature of the wrong length throws instead,\nbecause that is a bug in the calling code.",
			"references":{
				"handler":["cxSign","cxSignatureLen"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-42",
			"name":"cxhmacsha512",
			"display name":"cxHmacSha512",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxHmacSha512(<pKey>,<pMessage>)"
			],
			"display syntax":[
				"cxHmacSha512(<i>pKey</i>,<i>pMessage</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"HMAC-SHA512 of a message under a key (RFC 2104).",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The key, as Data. It may be empty and may be any length."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message, as Data. It may be empty."
			}],
			"examples":[{
				"script":"put cxHmacSha512(tKey, textEncode(\"Hi There\", \"utf-8\")) into tMac"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A 64-byte MAC, as Data."
			}],
			"description":"This is the core of BIP-32 derivation, where the key is a chain code and\nthe 64-byte result splits into a key tweak and a new chain code. The key\ncan be secret material, so clear your own variables when you are done.\nMost callers want <cxHdDeriveChild> instead.\n\nDo not compare a MAC with is or =: that is a timing leak. CoinXT has no\nconstant-time compare; use SodiumXT's sxMemEqual if it is installed.",
			"references":{
				"handler":["cxHmacSha256","cxHdDeriveChild","cxHmacSha512Len"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-43",
			"name":"cxschnorrverify",
			"display name":"cxSchnorrVerify",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSchnorrVerify(<pXOnlyPubkey>,<pMessage>,<pSignature>)"
			],
			"display syntax":[
				"cxSchnorrVerify(<i>pXOnlyPubkey</i>,<i>pMessage</i>,<i>pSignature</i>)"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"Check a BIP-340 Schnorr signature against an x-only public key.",
			"parameters":[{
				"name":"pXOnlyPubkey",
				"type":"",
				"refparam":"false",
				"description":"The 32-byte x-only public key, as Data."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The signed message, as Data, of any length."
			},{
				"name":"pSignature",
				"type":"",
				"refparam":"false",
				"description":"The 64-byte signature, as Data."
			}],
			"examples":[{
				"script":"put cxSchnorrVerify(cxXOnlyPubkey(tSeckey), tMessage, tSignature) into tGood"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true if the signature verifies, false if it does not."
			}],
			"description":"Unlike <cxSchnorrSign>, any message length is accepted, as BIP-340\nallows. A public key that is not a point on the curve answers false, as\nBIP-340's own vectors require. Only a key or signature of the wrong\nlength throws, because that is a bug in the calling code.",
			"references":{
				"handler":["cxSchnorrSign","cxXOnlyPubkey"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		},{
			"id":"org.openxtalk.library.coin-44",
			"name":"cxsha3_256len",
			"display name":"cxSha3_256Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha3_256Len()"
			],
			"display syntax":[
				"cxSha3_256Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a SHA3-256 digest.",
			"examples":[{
				"script":"put cxSha3_256Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSha3_256"]
			},
			"tags":["cryptography","library","cryptography"]
		},{
			"id":"org.openxtalk.library.coin-45",
			"name":"cxsha256len",
			"display name":"cxSha256Len",
			"library":"org.openxtalk.library.coin",
			"type":"handler",
			"syntax":[
				"cxSha256Len()"
			],
			"display syntax":[
				"cxSha256Len()"
			],
			"associations":["org.openxtalk.library.coin"],
			"summary":"The size in bytes of a SHA-256 digest.",
			"examples":[{
				"script":"put cxSha256Len() into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"32."
			}],
			"description":"The size comes from the native library. Ask for it rather than writing the\nnumber into your own code.",
			"references":{
				"handler":["cxSha256"]
			},
			"tags":["cryptography","library","cryptography","bitcoin"]
		}