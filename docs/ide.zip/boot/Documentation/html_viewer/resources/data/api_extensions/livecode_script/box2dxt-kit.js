{
			"id":"box2dxt-kit-1",
			"name":"box2dxt-kit",
			"display name":"Box2Dxt Kit",
			"library":"box2dxt-kit",
			"type":"library",
			"display syntax":[
				"Box2Dxt Kit"
			],
			"associations":["box2dxt-kit"],
			"description":"A pure-script game toolkit over the box2dxt extension (Box2D v3.1 physics).\nYou work in screen pixels, screen coordinates (y down) and degrees; the Kit\nconverts to Box2D's metres, radians and y-up, runs a fixed-step frame loop,\nand moves your controls to follow their bodies.\n\nStart with <b2kQuickStart> (or <b2kSetup> and <b2kStart>), give controls\nbodies with <b2kAddBox> or create them with <b2kSpawnBox>, and set a\n<b2kFrameTarget> for per-frame logic and a <b2kContactTarget> for collision\nmessages. Commands report through the result, so read it on the next line.\nBesides physics it has keyboard input, sprite sheets and animation, a\nplatformer player controller, a scrolling camera and synthesized sound.\n\nIt needs the box2dxt extension loaded: b2kVersion() should return 4."
		},{
			"id":"box2dxt-kit-2",
			"name":"b2ksheetforget",
			"display name":"b2kSheetForget",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetForget <pName>"
			],
			"display syntax":[
				"b2kSheetForget <i>pName</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Forget one sheet.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			}],
			"examples":[{
				"script":"b2kSheetForget \"coins\""
			}],
			"description":"It deletes the sheet's sliced and mirrored frame images, the source\nimage if the Kit loaded it, and the sheet's animations. Sprites that show it\nstay on the card.",
			"references":{
				"handler":["b2kSheetsWipe"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-3",
			"name":"b2kcontactb",
			"display name":"b2kContactB",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kContactB(<pIndex>)"
			],
			"display syntax":[
				"b2kContactB(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The second control of a pair that began touching this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the event within this frame."
			}],
			"examples":[{
				"script":"put b2kContactB(1) into tSecond"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control's long id, or empty for a wall, the ground, an untracked body or an index out of range."
			}],
			"description":"The second control of a pair that began touching this frame.",
			"references":{
				"handler":["b2kContactCount","b2kContactA"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-4",
			"name":"b2kquerytocontrols",
			"display name":"b2kQueryToControls",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kQueryToControls(<pCount>)"
			],
			"display syntax":[
				"b2kQueryToControls(<i>pCount</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn the last raw query's rows into Kit controls.",
			"parameters":[{
				"name":"pCount",
				"type":"",
				"refparam":"false",
				"description":"The row count the raw query returned."
			}],
			"examples":[{
				"script":"put b2kQueryToControls(tCount) into tControls"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The controls' long ids, one per line; rows with no Kit control are skipped."
			}],
			"description":"A helper behind <b2kOverlap>, <b2kOverlapCircle> and <b2kRayHitAll>.",
			"references":{
				"handler":["b2kOverlap"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-5",
			"name":"b2kversion",
			"display name":"b2kVersion",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kVersion()"
			],
			"display syntax":[
				"b2kVersion()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The native library's ABI version.",
			"examples":[{
				"script":"if b2kVersion() is not 4 then answer \"box2dxt is missing or out of date\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The ABI version number of the loaded box2dxt library (4 for this Kit)."
			}],
			"description":"A load and in-sync check from Kit-only code. It calls the extension,\nso it throws if the box2dxt extension is not loaded.",
			"references":{
				"handler":["b2kEnsureNativeLib"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-6",
			"name":"b2kaddcapsule",
			"display name":"b2kAddCapsule",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddCapsule <pControl>,<pDynamic>"
			],
			"display syntax":[
				"b2kAddCapsule <i>pControl</i>,<i>pDynamic</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control a capsule (pill) body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDynamic",
				"type":"",
				"refparam":"false",
				"description":"true (the default) for a dynamic body, false for a static one."
			}],
			"examples":[{
				"script":"b2kAddCapsule the long id of graphic \"Hero\"\nb2kSetFixedRotation the long id of graphic \"Hero\", true"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world or the control has no size."
			}],
			"description":"The longer side of the control's rect is the capsule's axis and the\nshorter side its diameter. A dynamic graphic is redrawn as a rounded outline\nthat rotates; a dynamic image rotates through its angle; other controls follow\nposition upright.",
			"references":{
				"handler":["b2kAddBox","b2kSpawnCapsule","b2kReshape"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-7",
			"name":"b2kplayerclimbstart",
			"display name":"b2kPlayerClimbStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerClimbStart <pBody>"
			],
			"display syntax":[
				"b2kPlayerClimbStart <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Start the climb's gravity hold.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerClimbStart b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: saves the body's gravity scale and sets it to 0. A repeated start is a no-op.",
			"references":{
				"handler":["b2kPlayerClimbEnd"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-8",
			"name":"b2kplayertick",
			"display name":"b2kPlayerTick",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerTick"
			],
			"display syntax":[
				"b2kPlayerTick"
			],
			"associations":["box2dxt-kit"],
			"summary":"Run one frame of the player controller.",
			"examples":[{
				"script":"b2kPlayerTick"
			}],
			"description":"Internal handler: the loop and <b2kStepOnce> call it after the input sample.\nIt probes the ground, applies input, jumping, ladders, water, hurt and the\nopt-in actions, and picks the animation. It exits at once when there is no\nplayer.",
			"references":{
				"handler":["b2kPlayerAttach","b2kStepOnce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-9",
			"name":"b2ksetrestitutionthreshold",
			"display name":"b2kSetRestitutionThreshold",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetRestitutionThreshold <pPxPerSec>"
			],
			"display syntax":[
				"b2kSetRestitutionThreshold <i>pPxPerSec</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the speed below which collisions stop bouncing.",
			"parameters":[{
				"name":"pPxPerSec",
				"type":"",
				"refparam":"false",
				"description":"The approach speed, in pixels per second."
			}],
			"examples":[{
				"script":"b2kSetRestitutionThreshold 30"
			}],
			"description":"A higher value removes small jittery bounces. With no world it does nothing.",
			"references":{
				"handler":["b2kSetBounce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-10",
			"name":"b2ksetdensity",
			"display name":"b2kSetDensity",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetDensity <pControl>,<pDensity>"
			],
			"display syntax":[
				"b2kSetDensity <i>pControl</i>,<i>pDensity</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a control's shape density, which sets its mass.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDensity",
				"type":"",
				"refparam":"false",
				"description":"Density in kilograms per square metre; clamped to 0-10000. The default is 1."
			}],
			"examples":[{
				"script":"b2kSetDensity tCrate, 5"
			}],
			"description":"A control with no Kit shape is ignored.",
			"references":{
				"handler":["b2kMass","b2kSetBounce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-11",
			"name":"b2kplayermake",
			"display name":"b2kPlayerMake",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerMake <pX>,<pY>,<pW>,<pH>,<pSheet>"
			],
			"display syntax":[
				"b2kPlayerMake <i>pX</i>,<i>pY</i>,<i>pW</i>,<i>pH</i>,<i>pSheet</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a platformer player in one call.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The centre x in pixels. Not a number means the world origin's x."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The centre y in pixels. Not a number means the world origin's y."
			},{
				"name":"pW",
				"type":"",
				"refparam":"false",
				"description":"The collision width in pixels. Empty means 32."
			},{
				"name":"pH",
				"type":"",
				"refparam":"false",
				"description":"The collision height in pixels. Empty means 48."
			},{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"Optional sheet name: a sprite of its first frame is created and pinned on top."
			}],
			"examples":[{
				"script":"b2kPlayerMake 200, 100, 32, 48, \"chars\"\nput the result into gHero\nb2kPlayerAnims \"idle\", \"walk\", \"jump\"\nb2kCamFollow gHero"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The player control's long id through the result, or empty when there is no world."
			}],
			"description":"It creates a rectangle graphic as the body host (hidden when a\nsprite of the sheet is made), attaches it with <b2kPlayerAttach>, and turns\ninput on. The collision size is independent of the art size. Give the\nreturned control to <b2kCamFollow> and your hazard checks.",
			"references":{
				"handler":["b2kPlayerAttach","b2kPlayerAnims","b2kPlayerSet","b2kPlayer"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-12",
			"name":"b2ksensorentersensor",
			"display name":"b2kSensorEnterSensor",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorEnterSensor(<pIndex>)"
			],
			"display syntax":[
				"b2kSensorEnterSensor(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The sensor control of an entry this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the entry within this frame."
			}],
			"examples":[{
				"script":"put b2kSensorEnterSensor(1) into tZone"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sensor's long id, or empty for an untracked body or an index out of range."
			}],
			"description":"The sensor control of an entry this frame.",
			"references":{
				"handler":["b2kSensorCount","b2kSensorEnterVisitor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-13",
			"name":"b2ksheetpersist",
			"display name":"b2kSheetPersist",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetPersist <pFlag>"
			],
			"display syntax":[
				"b2kSheetPersist <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Keep loaded sheets alive across teardowns.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true (or empty) to keep sheets, false to wipe them with each teardown (the starting state)."
			}],
			"examples":[{
				"script":"b2kSheetPersist true"
			}],
			"description":"With persistence on, sheets survive <b2kTeardown> like sounds do, so\na multi-level game loads its atlases once and an identical reload is a no-op.\nThe Kit's source and frame images have stable names and are marked with\nwhere they came from, so a saved stack carries them: on reopen a load adopts\nthe images already in the stack, and an atlas needs neither its PNG nor its\nXML. <b2kSheetsWipe> still clears everything.",
			"references":{
				"handler":["b2kSheetPersists","b2kSheetLoadAtlas","b2kSheetsWipe"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-14",
			"name":"b2kcontactcount",
			"display name":"b2kContactCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kContactCount()"
			],
			"display syntax":[
				"b2kContactCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many pairs of bodies began touching this frame.",
			"examples":[{
				"script":"if b2kContactCount() > 0 then put b2kContactA(1) && b2kContactB(1) into tPair"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, 0 when none."
			}],
			"description":"Poll it from b2kFrame instead of, or alongside, the b2kContact message. Events are collected after every fixed step of the frame, so none\nis lost on a two-step frame or repeated on a zero-step one.",
			"references":{
				"handler":["b2kContactA","b2kContactB","b2kEndContactCount","b2kContactTarget"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-15",
			"name":"b2ksetsubsteps",
			"display name":"b2kSetSubsteps",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetSubsteps <pN>"
			],
			"display syntax":[
				"b2kSetSubsteps <i>pN</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the solver sub-steps per physics step.",
			"parameters":[{
				"name":"pN",
				"type":"",
				"refparam":"false",
				"description":"Sub-steps per step, rounded and clamped to 1-64. The default is 4."
			}],
			"examples":[{
				"script":"b2kSetSubsteps 8"
			}],
			"description":"More sub-steps make stacks and joints stiffer and cost more CPU.",
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-16",
			"name":"b2kkeyisdown",
			"display name":"b2kKeyIsDown",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyIsDown(<pKey>)"
			],
			"display syntax":[
				"b2kKeyIsDown(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a key is held this frame.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A key name (left, right, up, down, space, return, escape, tab, shift, control, alt, backspace, delete), a single character, or a raw keycode."
			}],
			"examples":[{
				"script":"if b2kKeyIsDown(\"left\") then b2kPush tShip, -10, 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Needs <b2kInputOn>; read it from b2kFrame.",
			"references":{
				"handler":["b2kKeyPressed","b2kKeyReleased","b2kInputOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-17",
			"name":"b2kcorner",
			"display name":"b2kCorner",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCorner(<pWx>,<pWy>,<pLx>,<pLy>,<c>,<s>)"
			],
			"display syntax":[
				"b2kCorner(<i>pWx</i>,<i>pWy</i>,<i>pLx</i>,<i>pLy</i>,<i>c</i>,<i>s</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"One outline corner in screen pixels.",
			"parameters":[{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The body's x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The body's y, in metres."
			},{
				"name":"pLx",
				"type":"",
				"refparam":"false",
				"description":"The corner's local x, in metres."
			},{
				"name":"pLy",
				"type":"",
				"refparam":"false",
				"description":"The corner's local y, in metres."
			},{
				"name":"c",
				"type":"",
				"refparam":"false",
				"description":"The cosine of the body's angle."
			},{
				"name":"s",
				"type":"",
				"refparam":"false",
				"description":"The sine of the body's angle."
			}],
			"examples":[{
				"script":"put b2kCorner(2, 3, 0.5, 0.5, 1, 0) into tPoint"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"x,y\" in rounded screen pixels."
			}],
			"description":"One outline corner in screen pixels.",
			"references":{
				"handler":["b2kDrawPoly"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-18",
			"name":"b2kaxis",
			"display name":"b2kAxis",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kAxis(<pName>)"
			],
			"display syntax":[
				"b2kAxis(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Read an axis.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The axis's name."
			}],
			"examples":[{
				"script":"b2kSetVelocity tHero, b2kAxis(\"moveX\") * 240, item 2 of b2kVelocity(tHero)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"-1, 0 or 1. Both directions held, or neither, gives 0."
			}],
			"description":"Read an axis.",
			"references":{
				"handler":["b2kBindAxis"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-19",
			"name":"b2kcontacttarget",
			"display name":"b2kContactTarget",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kContactTarget <pObject>"
			],
			"display syntax":[
				"b2kContactTarget <i>pObject</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the object that receives contact and sensor messages.",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"A reference to the object, such as the long id of the card. Empty turns the messages off."
			}],
			"examples":[{
				"script":"b2kContactTarget the long id of me"
			}],
			"description":"After each frame the Kit sends this object b2kContact and\nb2kEndContact (two controls that began or stopped touching), and\nb2kSensorEnter and b2kSensorExit (a sensor control and a visitor control).\nA control parameter is empty for a wall, the ground or any body the Kit does\nnot track. Without a target no message is sent; the polling functions such\nas <b2kContactCount> work either way.",
			"references":{
				"handler":["b2kFrameTarget","b2kContactCount","b2kAddSensor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-20",
			"name":"b2kbindaxis",
			"display name":"b2kBindAxis",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kBindAxis <pName>,<pNegKeys>,<pPosKeys>"
			],
			"display syntax":[
				"b2kBindAxis <i>pName</i>,<i>pNegKeys</i>,<i>pPosKeys</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Define a -1, 0, +1 axis from two key sets.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The axis's name, such as \"moveX\"."
			},{
				"name":"pNegKeys",
				"type":"",
				"refparam":"false",
				"description":"A comma list of keys for the -1 direction."
			},{
				"name":"pPosKeys",
				"type":"",
				"refparam":"false",
				"description":"A comma list of keys for the +1 direction."
			}],
			"examples":[{
				"script":"b2kBindAxis \"steer\", \"left,a\", \"right,d\""
			}],
			"description":"Define a -1, 0, +1 axis from two key sets.",
			"references":{
				"handler":["b2kAxis","b2kBindAction"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-21",
			"name":"b2kinputison",
			"display name":"b2kInputIsOn",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kInputIsOn()"
			],
			"display syntax":[
				"b2kInputIsOn()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the keyboard sample is on.",
			"examples":[{
				"script":"if not b2kInputIsOn() then b2kInputOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether the keyboard sample is on.",
			"references":{
				"handler":["b2kInputOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-22",
			"name":"b2kensurenativelib",
			"display name":"b2kEnsureNativeLib",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEnsureNativeLib"
			],
			"display syntax":[
				"b2kEnsureNativeLib"
			],
			"associations":["box2dxt-kit"],
			"summary":"Point the engine at a box2dxt library saved beside the stack.",
			"examples":[{
				"script":"b2kEnsureNativeLib\nput b2kVersion() into tABI"
			}],
			"description":"When a file named box2dxt.dll, box2dxt.dylib or box2dxt.so (by\nplatform) sits in the folder of the saved stack, <b2kEnsureNativeLib> sets the\nrevLibraryMapping for \"box2dxt\" to it, so the extension's foreign handlers\nresolve with no install. Otherwise it leaves the engine's own search alone.\nAn unsaved stack is a quiet no-op.\n\n<b2kSetup> calls it for you. Scripts that use the raw b2 layer without the\nKit can call it before their first b2 call.",
			"references":{
				"handler":["b2kSetup","b2kVersion"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-23",
			"name":"b2ksheetload",
			"display name":"b2kSheetLoad",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetLoad <pName>,<pPath>,<pFW>,<pFH>,<pCount>,<pMargin>,<pSpacing>"
			],
			"display syntax":[
				"b2kSheetLoad <i>pName</i>,<i>pPath</i>,<i>pFW</i>,<i>pFH</i>,<i>pCount</i>,<i>pMargin</i>,<i>pSpacing</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register an image file as a sheet of numbered grid frames.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The image file's path."
			},{
				"name":"pFW",
				"type":"",
				"refparam":"false",
				"description":"Frame width in pixels; 0 or empty registers no grid."
			},{
				"name":"pFH",
				"type":"",
				"refparam":"false",
				"description":"Frame height in pixels; 0 or empty registers no grid."
			},{
				"name":"pCount",
				"type":"",
				"refparam":"false",
				"description":"Optional number of frames to register; empty means every whole cell."
			},{
				"name":"pMargin",
				"type":"",
				"refparam":"false",
				"description":"Optional outer border in pixels. Empty means 0."
			},{
				"name":"pSpacing",
				"type":"",
				"refparam":"false",
				"description":"Optional gap between cells in pixels. Empty means 0."
			}],
			"examples":[{
				"script":"b2kSheetLoad \"coins\", tFolder & \"/coins.png\", 32, 32\nput the result into tFrames"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sheet's frame count through the result, or 0 when the file cannot be loaded."
			}],
			"description":"Frames are numbered 1 to N left to right, top to bottom. With no\ngrid, name regions yourself with <b2kSheetAddFrame>. The image is loaded into\na hidden image the Kit owns.",
			"references":{
				"handler":["b2kSheetLoadAtlas","b2kSheetFromImage","b2kAnimDef","b2kSpriteNew"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-24",
			"name":"b2kspritesetframe",
			"display name":"b2kSpriteSetFrame",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteSetFrame <pCtrl>,<pFrame>"
			],
			"display syntax":[
				"b2kSpriteSetFrame <i>pCtrl</i>,<i>pFrame</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Show one frame on a sprite, stopping any animation.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pFrame",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"b2kSpriteSetFrame tSpr, \"character_beige_hit\""
			}],
			"description":"Show one frame on a sprite, stopping any animation.",
			"references":{
				"handler":["b2kSpriteFrame","b2kSpriteStop"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-25",
			"name":"b2kcammousey",
			"display name":"b2kCamMouseY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamMouseY()"
			],
			"display syntax":[
				"b2kCamMouseY()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The mouse's y in world pixels.",
			"examples":[{
				"script":"put b2kCamMouseY() into tWorldY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The mouse y adjusted for the camera scroll; the plain mouseV when the camera is off."
			}],
			"description":"The mouse's y in world pixels.",
			"references":{
				"handler":["b2kCamMouseX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-26",
			"name":"b2krayhitall",
			"display name":"b2kRayHitAll",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHitAll(<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2kRayHitAll(<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Every Kit control a ray between two screen points crosses.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"Start x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"Start y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"End x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"End y, in pixels."
			}],
			"examples":[{
				"script":"put b2kRayHitAll(0, 200, 600, 200) into tLine"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The controls' long ids, one per line, nearest first, or empty."
			}],
			"description":"Every Kit control a ray between two screen points crosses.",
			"references":{
				"handler":["b2kRayHit"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-27",
			"name":"b2kgrab",
			"display name":"b2kGrab",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kGrab(<pScreenX>,<pScreenY>)"
			],
			"display syntax":[
				"b2kGrab(<i>pScreenX</i>,<i>pScreenY</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Start dragging the dynamic body under a screen point.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The point's x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The point's y, in pixels."
			}],
			"examples":[{
				"script":"get b2kGrab(b2kCamMouseX(), b2kCamMouseY())"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The grabbed control, or empty when no dynamic body is there."
			}],
			"description":"Call it from mouseDown and <b2kRelease> from mouseUp. While a body\nis held, the loop pulls it toward the mouse each frame with a mouse joint.\nWith the camera on, pass <b2kCamMouseX> and <b2kCamMouseY>.",
			"references":{
				"handler":["b2kRelease","b2kControlAt"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-28",
			"name":"b2kdrawball",
			"display name":"b2kDrawBall",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDrawBall <pRef>,<pWx>,<pWy>"
			],
			"display syntax":[
				"b2kDrawBall <i>pRef</i>,<i>pWx</i>,<i>pWy</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Redraw a ball graphic at a body position.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			},{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The body's x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The body's y, in metres."
			}],
			"examples":[{
				"script":"b2kDrawBall tRef, 2, 3"
			}],
			"description":"Internal handler: sets the graphic's rect from the stored radius.",
			"references":{
				"handler":["b2kDrawBody"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-29",
			"name":"b2kspriteunbind",
			"display name":"b2kSpriteUnbind",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteUnbind <pCtrl>"
			],
			"display syntax":[
				"b2kSpriteUnbind <i>pCtrl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop a sprite following another control.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			}],
			"examples":[{
				"script":"b2kSpriteUnbind tArt"
			}],
			"description":"Stop a sprite following another control.",
			"references":{
				"handler":["b2kSpriteBind"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-30",
			"name":"b2ksheetframesize",
			"display name":"b2kSheetFrameSize",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetFrameSize(<pName>,<pFrame>)"
			],
			"display syntax":[
				"b2kSheetFrameSize(<i>pName</i>,<i>pFrame</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A frame's display size.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pFrame",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"put item 1 of b2kSheetFrameSize(\"tiles\", \"grass\") into tTileW"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"w,h\" in pixels (the region times the sheet scale), or empty for an unknown frame."
			}],
			"description":"A frame's display size.",
			"references":{
				"handler":["b2kSheetScale"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-31",
			"name":"b2koverlapmoving",
			"display name":"b2kOverlapMoving",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kOverlapMoving(<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2kOverlapMoving(<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The non-static Kit controls overlapping a screen rectangle.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"One corner's x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"One corner's y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's y, in pixels."
			}],
			"examples":[{
				"script":"put (b2kOverlapMoving(400, 380, 460, 400) is not empty) into tPlateDown"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The controls' long ids, one per line, or empty."
			}],
			"description":"The presence poll for pressure plates and buttons: static bodies\nare filtered out, dynamic and kinematic bodies count, and sleeping bodies\nstill register.",
			"references":{
				"handler":["b2kOverlap","b2kAddSensor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-32",
			"name":"b2kplayerduckset",
			"display name":"b2kPlayerDuckSet",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerDuckSet <pWantDuck>"
			],
			"display syntax":[
				"b2kPlayerDuckSet <i>pWantDuck</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Shrink the player to a crawl, or stand up when there is room.",
			"parameters":[{
				"name":"pWantDuck",
				"type":"",
				"refparam":"false",
				"description":"true to crawl; anything else stands up if a ray finds headroom."
			}],
			"examples":[{
				"script":"b2kPlayerDuckSet true"
			}],
			"description":"Only active when duckScale is below 1 (the default is 1, a no-op).\nThe capsule is rebuilt shorter with the feet planted, keeping its collision\nfilter, with friction 0.08 and no bounce.",
			"references":{
				"handler":["b2kPlayerStandUp","b2kPlayerHalfH"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-33",
			"name":"b2ksettype",
			"display name":"b2kSetType",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetType <pControl>,<pType>"
			],
			"display syntax":[
				"b2kSetType <i>pControl</i>,<i>pType</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Change a body's type by name.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pType",
				"type":"",
				"refparam":"false",
				"description":"\"static\", \"kinematic\" or \"dynamic\"; any other value means dynamic."
			}],
			"examples":[{
				"script":"b2kSetType tPlatform, \"kinematic\""
			}],
			"description":"A kinematic body moves only by the velocity you give it and is not\npushed by others, which suits moving platforms. A non-static body is woken.\nA control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSetStatic","b2kSetDynamic","b2kSetKinematic","b2kBodyType"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-34",
			"name":"b2khinge",
			"display name":"b2kHinge",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kHinge <pCtrlA>,<pCtrlB>,<pScreenX>,<pScreenY>"
			],
			"display syntax":[
				"b2kHinge <i>pCtrlA</i>,<i>pCtrlB</i>,<i>pScreenX</i>,<i>pScreenY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Pin two controls together, or one to the world, at a screen point.",
			"parameters":[{
				"name":"pCtrlA",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pCtrlB",
				"type":"",
				"refparam":"false",
				"description":"The second control, or empty to pin the first to the world."
			},{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The pivot x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The pivot y, in pixels."
			}],
			"examples":[{
				"script":"b2kHinge tDoor, empty, 300, 120\nput the result into tHinge\nb2kHingeLimit tHinge, -90, 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"A revolute joint: the bodies keep the pivot point in common and\nrotate freely about it. Good for pendulums, doors and wheels on a fixed axle.",
			"references":{
				"handler":["b2kMotor","b2kHingeLimit","b2kHingeAngle","b2kRemoveJoint"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-35",
			"name":"b2ksheetatlasrows",
			"display name":"b2kSheetAtlasRows",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetAtlasRows(<pName>)"
			],
			"display syntax":[
				"b2kSheetAtlasRows(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Every frame region of a sheet, one per line.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			}],
			"examples":[{
				"script":"put b2kSheetAtlasRows(\"chars\") into field \"Regions\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Lines of \"x,y,w,h,name\" in source pixels, in definition order; empty for an unknown sheet."
			}],
			"description":"The name comes last so a name with a comma survives. For a persisting atlas this is also the stamp a saved stack adopts.",
			"references":{
				"handler":["b2kSheetAdoptAtlas","b2kSheetFrameNames"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-36",
			"name":"b2ksetcategory",
			"display name":"b2kSetCategory",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetCategory <pControl>,<pLayerList>"
			],
			"display syntax":[
				"b2kSetCategory <i>pControl</i>,<i>pLayerList</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set which collision layers a control belongs to.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pLayerList",
				"type":"",
				"refparam":"false",
				"description":"A comma or space separated list of layer names or raw numbers."
			}],
			"examples":[{
				"script":"b2kSetCategory tSlime, \"enemies\""
			}],
			"description":"Two shapes collide only when each one's category is in the other's\nmask. The shape keeps its mask and group. A control with no Kit shape is\nignored.",
			"references":{
				"handler":["b2kSetMask","b2kSetCollisionGroup","b2kDefineLayer"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-37",
			"name":"b2ksliderlimitoff",
			"display name":"b2kSliderLimitOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSliderLimitOff <pJoint>"
			],
			"display syntax":[
				"b2kSliderLimitOff <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove a slider joint's travel limits.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kSliderLimitOff tTrack"
			}],
			"description":"Remove a slider joint's travel limits.",
			"references":{
				"handler":["b2kSliderLimit"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-38",
			"name":"b2kdrawbody",
			"display name":"b2kDrawBody",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDrawBody <pRef>,<pWx>,<pWy>,<pWa>"
			],
			"display syntax":[
				"b2kDrawBody <i>pRef</i>,<i>pWx</i>,<i>pWy</i>,<i>pWa</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Place a control at a body pose.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			},{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The body's x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The body's y, in metres."
			},{
				"name":"pWa",
				"type":"",
				"refparam":"false",
				"description":"The body's angle, in radians."
			}],
			"examples":[{
				"script":"b2kDrawBody tRef, 2, 3, 0"
			}],
			"description":"Internal handler: picks the renderer for the control's kind and skips the write when nothing visible changed.",
			"references":{
				"handler":["b2kDrawPoly","b2kDrawBall","b2kDrawImage"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-39",
			"name":"b2kstop",
			"display name":"b2kStop",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kStop"
			],
			"display syntax":[
				"b2kStop"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop the simulation loop.",
			"examples":[{
				"script":"b2kStop"
			}],
			"description":"The world and its bodies stay; nothing steps until <b2kStart>.\nUse <b2kTeardown> to destroy the world as well.",
			"references":{
				"handler":["b2kStart","b2kPause","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-40",
			"name":"b2ksleep",
			"display name":"b2kSleep",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSleep <pControl>"
			],
			"display syntax":[
				"b2kSleep <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Put a body to sleep until something wakes it.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kSleep tCrate"
			}],
			"description":"A sleeping body stops simulating until a contact, a joint or a call such as <b2kWake> wakes it. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kWake","b2kIsAwake"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-41",
			"name":"b2kbodyof",
			"display name":"b2kBodyOf",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kBodyOf(<pControl>)"
			],
			"display syntax":[
				"b2kBodyOf(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The raw Box2D body handle behind a control.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kBodyOf(tCrate) into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle, or empty when the control has no Kit body."
			}],
			"description":"Use it to mix Kit code with calls to the raw b2 layer.",
			"references":{
				"handler":["b2kWorld","b2kRegister"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-42",
			"name":"b2kplayerhurtis",
			"display name":"b2kPlayerHurtIs",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerHurtIs()"
			],
			"display syntax":[
				"b2kPlayerHurtIs()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the player is in knockback or its mercy window.",
			"examples":[{
				"script":"if b2kPlayerHurtIs() then put true into tSkipHazards"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether the player is in knockback or its mercy window.",
			"references":{
				"handler":["b2kPlayerHurt"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-43",
			"name":"b2kropesetlength",
			"display name":"b2kRopeSetLength",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRopeSetLength <pJoint>,<pLengthPx>"
			],
			"display syntax":[
				"b2kRopeSetLength <i>pJoint</i>,<i>pLengthPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a distance joint's rest length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pLengthPx",
				"type":"",
				"refparam":"false",
				"description":"The rest length in pixels."
			}],
			"examples":[{
				"script":"b2kRopeSetLength tRope, 120"
			}],
			"description":"Set a distance joint's rest length.",
			"references":{
				"handler":["b2kRopeLength","b2kRopeRange"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-44",
			"name":"b2kplayertunecache",
			"display name":"b2kPlayerTuneCache",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerTuneCache"
			],
			"display syntax":[
				"b2kPlayerTuneCache"
			],
			"associations":["box2dxt-kit"],
			"summary":"Copy the tuning knobs into the controller's fast variables.",
			"examples":[{
				"script":"b2kPlayerTuneCache"
			}],
			"description":"Internal handler: <b2kPlayerSet> calls it, so a knob takes effect on the next frame.",
			"references":{
				"handler":["b2kPlayerSet"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-45",
			"name":"b2kplayerget",
			"display name":"b2kPlayerGet",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerGet(<pKey>)"
			],
			"display syntax":[
				"b2kPlayerGet(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Read a player tuning knob.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The knob's name (case does not matter)."
			}],
			"examples":[{
				"script":"put b2kPlayerGet(\"jumpSpeed\") into tJump"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The knob's value, or its default when unset. A known knob set to a non-number reads as its default."
			}],
			"description":"Read a player tuning knob.",
			"references":{
				"handler":["b2kPlayerSet","b2kPlayerDefault"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-46",
			"name":"b2kspritesclear",
			"display name":"b2kSpritesClear",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpritesClear"
			],
			"display syntax":[
				"b2kSpritesClear"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove every sprite.",
			"examples":[{
				"script":"b2kSpritesClear"
			}],
			"description":"Internal handler: <b2kClear> and <b2kTeardown> call it. Sheets stay loaded.",
			"references":{
				"handler":["b2kSpriteRemove","b2kClear"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-47",
			"name":"b2kspritenew",
			"display name":"b2kSpriteNew",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteNew <pSheet>,<pFrame>,<pX>,<pY>"
			],
			"display syntax":[
				"b2kSpriteNew <i>pSheet</i>,<i>pFrame</i>,<i>pX</i>,<i>pY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a sprite: a transparent button showing a sheet frame.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pFrame",
				"type":"",
				"refparam":"false",
				"description":"The frame to show. Empty means the sheet's first frame."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The centre x in pixels. Empty means the card's centre."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The centre y in pixels. Empty means the card's centre."
			}],
			"examples":[{
				"script":"b2kSpriteNew \"chars\", \"character_beige_idle\", 200, 100\nput the result into tSpr\nb2kSpritePlay tSpr, \"walk\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sprite's long id through the result, or empty for an unknown sheet or frame."
			}],
			"description":"The button is sized to the frame. It is an ordinary Kit control:\ngive it a body with <b2kAddCapsule> or <b2kAddBox> (sprites follow position\nand do not rotate), or pin it to another control with <b2kSpriteBind>.\n<b2kClear> removes it.",
			"references":{
				"handler":["b2kSpritePlay","b2kSpriteBind","b2kSpriteRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-48",
			"name":"b2kisbullet",
			"display name":"b2kIsBullet",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kIsBullet(<pControl>)"
			],
			"display syntax":[
				"b2kIsBullet(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a body uses continuous (bullet) collision.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kIsBullet(tShot) into tCCD"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; false when the control has no body."
			}],
			"description":"Report whether a body uses continuous (bullet) collision.",
			"references":{
				"handler":["b2kSetBullet"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-49",
			"name":"b2kspriteforget",
			"display name":"b2kSpriteForget",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteForget <pRef>"
			],
			"display syntax":[
				"b2kSpriteForget <i>pRef</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drop a sprite's records once its control is gone.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The sprite's long id."
			}],
			"examples":[{
				"script":"b2kSpriteForget tSpr"
			}],
			"description":"Internal handler: <b2kSpriteRemove> and the sprite tick call it. It deletes no control.",
			"references":{
				"handler":["b2kSpriteRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-50",
			"name":"b2kspritestop",
			"display name":"b2kSpriteStop",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteStop <pCtrl>"
			],
			"display syntax":[
				"b2kSpriteStop <i>pCtrl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop a sprite's animation on its current frame.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			}],
			"examples":[{
				"script":"b2kSpriteStop tSpr"
			}],
			"description":"Stop a sprite's animation on its current frame.",
			"references":{
				"handler":["b2kSpritePlay","b2kSpriteSetFrame"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-51",
			"name":"b2kcontacta",
			"display name":"b2kContactA",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kContactA(<pIndex>)"
			],
			"display syntax":[
				"b2kContactA(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The first control of a pair that began touching this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the event within this frame."
			}],
			"examples":[{
				"script":"put b2kContactA(1) into tFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control's long id, or empty for a wall, the ground, an untracked body or an index out of range."
			}],
			"description":"The first control of a pair that began touching this frame.",
			"references":{
				"handler":["b2kContactCount","b2kContactB"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-52",
			"name":"b2kspritefromgif",
			"display name":"b2kSpriteFromGIF",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteFromGIF <pPath>,<pX>,<pY>"
			],
			"display syntax":[
				"b2kSpriteFromGIF <i>pPath</i>,<i>pX</i>,<i>pY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a sprite from an animated GIF file.",
			"parameters":[{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The GIF file's path."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The centre x in pixels. Empty means the card's centre."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The centre y in pixels. Empty means the card's centre."
			}],
			"examples":[{
				"script":"b2kSpriteFromGIF tFolder & \"/flame.gif\", 300, 200\nput the result into tFlame"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The image's long id through the result, or empty when the file cannot be loaded."
			}],
			"description":"The engine plays the GIF. <b2kSpritePlay> and <b2kSpriteStop> set\nits repeatCount and <b2kSpriteSetFrame> its currentFrame.",
			"references":{
				"handler":["b2kSpriteNew","b2kSpriteRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-53",
			"name":"b2kplayerclimbend",
			"display name":"b2kPlayerClimbEnd",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerClimbEnd <pBody>"
			],
			"display syntax":[
				"b2kPlayerClimbEnd <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"End the climb's gravity hold.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerClimbEnd b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: restores the saved gravity scale. Without a start it is a no-op.",
			"references":{
				"handler":["b2kPlayerClimbStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-54",
			"name":"b2kpause",
			"display name":"b2kPause",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPause"
			],
			"display syntax":[
				"b2kPause"
			],
			"associations":["box2dxt-kit"],
			"summary":"Freeze stepping without stopping the loop.",
			"examples":[{
				"script":"b2kPause"
			}],
			"description":"While paused, the loop keeps running but no physics step, sync or\nframe message happens. <b2kStepOnce> still advances one step.",
			"references":{
				"handler":["b2kResume","b2kStepOnce","b2kIsRunning"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-55",
			"name":"b2ktonebytes",
			"display name":"b2kToneBytes",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kToneBytes(<pFreq>,<pMs>,<pVolPct>,<pShape>)"
			],
			"display syntax":[
				"b2kToneBytes(<i>pFreq</i>,<i>pMs</i>,<i>pVolPct</i>,<i>pShape</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Synthesize one note as raw samples.",
			"parameters":[{
				"name":"pFreq",
				"type":"",
				"refparam":"false",
				"description":"The frequency in hertz; 0 or below is a rest."
			},{
				"name":"pMs",
				"type":"",
				"refparam":"false",
				"description":"The length in milliseconds."
			},{
				"name":"pVolPct",
				"type":"",
				"refparam":"false",
				"description":"Volume 0-100."
			},{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"\"sine\", or anything else for square."
			}],
			"examples":[{
				"script":"put b2kToneBytes(880, 50, 60, \"sine\") into tSamples"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"8-bit unsigned mono samples at 22050 Hz with a linear decay, or empty for a zero length."
			}],
			"description":"Synthesize one note as raw samples.",
			"references":{
				"handler":["b2kWavWrap","b2kToneMake"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-56",
			"name":"b2kstart",
			"display name":"b2kStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kStart"
			],
			"display syntax":[
				"b2kStart"
			],
			"associations":["box2dxt-kit"],
			"summary":"Start the simulation loop.",
			"examples":[{
				"script":"b2kSetup\nb2kAddWalls\nb2kStart"
			}],
			"description":"Use <b2kStart> to begin stepping the world at a fixed 1/60 s step,\nsyncing controls and delivering events once per frame. If no world exists yet\nit calls <b2kSetup> first. Starting again replaces any running loop rather\nthan adding a second one.",
			"references":{
				"handler":["b2kStop","b2kPause","b2kStepOnce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-57",
			"name":"b2kkillfloor",
			"display name":"b2kKillFloor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kKillFloor <pScreenY>"
			],
			"display syntax":[
				"b2kKillFloor <i>pScreenY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove moving Kit bodies whose centre falls below a screen line.",
			"parameters":[{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The screen y in pixels below which moving bodies are removed. Empty turns the kill floor off."
			}],
			"examples":[{
				"script":"b2kKillFloor 900"
			}],
			"description":"Crates pushed into pits and enemies knocked off a level are removed\ninstead of falling forever. The player controller's body is exempt; your game\nowns its respawn.\n\nBefore each removal the Kit sends the message b2kFell, with the control as\nits parameter, to the frame target (<b2kFrameTarget>). Use it to clean up\ncompanions such as bound sprites, but do not delete the control in\nthat handler, because the Kit is removing it.",
			"references":{
				"handler":["b2kFrameTarget","b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-58",
			"name":"b2kchain",
			"display name":"b2kChain",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kChain <pPoints>,<pLoop>"
			],
			"display syntax":[
				"b2kChain <i>pPoints</i>,<i>pLoop</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Build smooth static terrain from a list of screen points.",
			"parameters":[{
				"name":"pPoints",
				"type":"",
				"refparam":"false",
				"description":"Screen points, one \"x,y\" per line. At least 4 points."
			},{
				"name":"pLoop",
				"type":"",
				"refparam":"false",
				"description":"true to close the chain into a loop; anything else leaves it open."
			}],
			"examples":[{
				"script":"b2kChain \"900,400\" & cr & \"600,400\" & cr & \"300,400\" & cr & \"0,400\"\nput the result into tGround"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The chain handle through the result, or 0 when there is no world."
			}],
			"description":"A chain has no inner corners for fast bodies to catch on. It is\ninvisible (draw a graphic to match) and one-sided: the solid side is to the\nright of the direction the points run, so list a floor's top surface right to\nleft. On an open chain the first and last segments are ghost anchors that do\nnot collide, so run the chain one segment past the surface you need at\neach end.\n\nEvery Kit chain carries the reserved \"oneway\" layer, which lets the player\ndrop through it. It is not a tracked body, so <b2kClear> leaves it.",
			"references":{
				"handler":["b2kSmoothGround","b2kAddChain","b2kWall"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-59",
			"name":"b2kcapsuleverts",
			"display name":"b2kCapsuleVerts",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCapsuleVerts(<pL>,<pR>,<pHoriz>)"
			],
			"display syntax":[
				"b2kCapsuleVerts(<i>pL</i>,<i>pR</i>,<i>pHoriz</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The local outline the Kit draws a capsule with.",
			"parameters":[{
				"name":"pL",
				"type":"",
				"refparam":"false",
				"description":"The capsule's half-length, in metres."
			},{
				"name":"pR",
				"type":"",
				"refparam":"false",
				"description":"The radius, in metres."
			},{
				"name":"pHoriz",
				"type":"",
				"refparam":"false",
				"description":"true for a horizontal capsule, false for vertical."
			}],
			"examples":[{
				"script":"put b2kCapsuleVerts(0.5, 0.3, false) into tOutline"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"18 local points in metres, one \"x,y\" per line."
			}],
			"description":"Drawing only: the collision shape is a true capsule.",
			"references":{
				"handler":["b2kAddCapsule"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-60",
			"name":"b2kcamapply",
			"display name":"b2kCamApply",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamApply"
			],
			"display syntax":[
				"b2kCamApply"
			],
			"associations":["box2dxt-kit"],
			"summary":"Write the camera's scroll.",
			"examples":[{
				"script":"b2kCamApply"
			}],
			"description":"Internal handler: clamps the view to the bounds, adds any shake and sets the group's scroll when it changed.",
			"references":{
				"handler":["b2kCamTick","b2kCamBounds"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-61",
			"name":"b2kslidermotoroff",
			"display name":"b2kSliderMotorOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSliderMotorOff <pJoint>"
			],
			"display syntax":[
				"b2kSliderMotorOff <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn a slider joint's motor off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kSliderMotorOff tTrack"
			}],
			"description":"Turn a slider joint's motor off.",
			"references":{
				"handler":["b2kSliderMotor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-62",
			"name":"b2ksetbullet",
			"display name":"b2kSetBullet",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetBullet <pControl>,<pFlag>"
			],
			"display syntax":[
				"b2kSetBullet <i>pControl</i>,<i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn continuous collision on or off for one fast body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to treat the body as a bullet, false for normal stepping."
			}],
			"examples":[{
				"script":"b2kSetBullet tShot, true"
			}],
			"description":"A bullet does not tunnel through other moving bodies. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kIsBullet","b2kEnableContinuous"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-63",
			"name":"b2ksensorexitsensor",
			"display name":"b2kSensorExitSensor",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorExitSensor(<pIndex>)"
			],
			"display syntax":[
				"b2kSensorExitSensor(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The sensor control of an exit this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the exit within this frame."
			}],
			"examples":[{
				"script":"put b2kSensorExitSensor(1) into tZone"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sensor's long id, or empty for an untracked body or an index out of range."
			}],
			"description":"The sensor control of an exit this frame.",
			"references":{
				"handler":["b2kSensorExitCount","b2kSensorExitVisitor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-64",
			"name":"b2krope",
			"display name":"b2kRope",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRope <pCtrlA>,<pCtrlB>,<pLengthPx>"
			],
			"display syntax":[
				"b2kRope <i>pCtrlA</i>,<i>pCtrlB</i>,<i>pLengthPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Link two controls by a distance joint between their centres.",
			"parameters":[{
				"name":"pCtrlA",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pCtrlB",
				"type":"",
				"refparam":"false",
				"description":"The second control, by reference."
			},{
				"name":"pLengthPx",
				"type":"",
				"refparam":"false",
				"description":"The rest length in pixels. Empty means the current distance between the centres."
			}],
			"examples":[{
				"script":"b2kRope tAnchor, tBob\nput the result into tRope\nb2kSpring tRope, 4, 0.3"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"As built, the joint holds the bodies at the rest length. Use\n<b2kRopeRange> for a slack rope with a minimum and maximum, and <b2kSpring>\nto make it springy.",
			"references":{
				"handler":["b2kRopeRange","b2kRopeLength","b2kSpring","b2kRemoveJoint"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-65",
			"name":"b2kspriteonfinish",
			"display name":"b2kSpriteOnFinish",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteOnFinish <pCtrl>,<pMessage>"
			],
			"display syntax":[
				"b2kSpriteOnFinish <i>pCtrl</i>,<i>pMessage</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Name a message to send when a one-shot animation ends.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pMessage",
				"type":"",
				"refparam":"false",
				"description":"The message name; empty turns it off."
			}],
			"examples":[{
				"script":"b2kSpriteOnFinish tSpr, \"heroAttackDone\""
			}],
			"description":"When a non-looping animation on this sprite ends, the Kit sends the\nmessage to the frame target (<b2kFrameTarget>) with two parameters, the\nsprite and the animation name. It fires for every non-looping animation,\nwhoever started it.",
			"references":{
				"handler":["b2kAnimDef","b2kFrameTarget"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-66",
			"name":"b2kreshape",
			"display name":"b2kReshape",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kReshape <pControl>,<pShape>,<pW>,<pH>"
			],
			"display syntax":[
				"b2kReshape <i>pControl</i>,<i>pShape</i>,<i>pW</i>,<i>pH</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Rebuild a body's collision shape from the control's current size.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"\"box\" (the default), \"ball\", \"capsule\" or \"poly\"."
			},{
				"name":"pW",
				"type":"",
				"refparam":"false",
				"description":"Optional width in pixels to use instead of the control's width (box, ball and capsule)."
			},{
				"name":"pH",
				"type":"",
				"refparam":"false",
				"description":"Optional height in pixels to use instead of the control's height (box and capsule)."
			}],
			"examples":[{
				"script":"set the width of tPlank to 200\nb2kReshape tPlank, \"box\"\nb2kSetFriction tPlank, 0.6"
			}],
			"description":"The new shape goes on the same body, so joints stay valid, and the\ncontrol is redrawn at once. The new shape has the default material and\ncollision filter, so re-apply bounce, friction, density and layers after it.\nA sensor stays a sensor. If the new size is zero, or a poly outline has\nfewer than 3 points, the old shape is kept.\n\nPass pW and pH for a polygon graphic: the engine will not resize one by\nsetting its height.",
			"references":{
				"handler":["b2kAddBox","b2kSetSensor","b2kSetCategory"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-67",
			"name":"b2ksyncall",
			"display name":"b2kSyncAll",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSyncAll"
			],
			"display syntax":[
				"b2kSyncAll"
			],
			"associations":["box2dxt-kit"],
			"summary":"Redraw every awake, moving Kit body's control now.",
			"examples":[{
				"script":"b2kSyncAll"
			}],
			"description":"The same as <b2kSync>.",
			"references":{
				"handler":["b2kSync"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-68",
			"name":"b2kinputoff",
			"display name":"b2kInputOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kInputOff"
			],
			"display syntax":[
				"b2kInputOff"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn off the per-frame keyboard sample.",
			"examples":[{
				"script":"b2kInputOff"
			}],
			"description":"Every key reads as up afterwards. Bindings are kept.",
			"references":{
				"handler":["b2kInputOn","b2kInputIsOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-69",
			"name":"b2kcontrolcontains",
			"display name":"b2kControlContains",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kControlContains(<pControl>,<pScreenX>,<pScreenY>)"
			],
			"display syntax":[
				"b2kControlContains(<i>pControl</i>,<i>pScreenX</i>,<i>pScreenY</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a screen point is inside one control's collision shape.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The point's x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The point's y, in pixels."
			}],
			"examples":[{
				"script":"if b2kControlContains(tGear, the mouseH, the mouseV) then b2kSpin tGear, 180"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when the point is inside the shape (rotation and shape aware); false otherwise or when the control has no shape."
			}],
			"description":"Report whether a screen point is inside one control's collision shape.",
			"references":{
				"handler":["b2kControlAt"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-70",
			"name":"b2kspriteremove",
			"display name":"b2kSpriteRemove",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteRemove <pCtrl>"
			],
			"display syntax":[
				"b2kSpriteRemove <i>pCtrl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove a sprite, and its body if it has one.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference."
			}],
			"examples":[{
				"script":"b2kSpriteRemove tSpr"
			}],
			"description":"A control that is already gone is still cleared from the Kit's records.",
			"references":{
				"handler":["b2kSpriteNew","b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-71",
			"name":"b2ksheetgridregions",
			"display name":"b2kSheetGridRegions",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetGridRegions <pName>,<pFW>,<pFH>,<pCount>,<pMargin>,<pSpacing>"
			],
			"display syntax":[
				"b2kSheetGridRegions <i>pName</i>,<i>pFW</i>,<i>pFH</i>,<i>pCount</i>,<i>pMargin</i>,<i>pSpacing</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register numbered grid frames over a sheet's source image.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pFW",
				"type":"",
				"refparam":"false",
				"description":"Frame width in pixels; 0 or empty registers no grid."
			},{
				"name":"pFH",
				"type":"",
				"refparam":"false",
				"description":"Frame height in pixels; 0 or empty registers no grid."
			},{
				"name":"pCount",
				"type":"",
				"refparam":"false",
				"description":"Optional number of frames to register; empty means every whole cell."
			},{
				"name":"pMargin",
				"type":"",
				"refparam":"false",
				"description":"Optional outer border in pixels. Empty means 0."
			},{
				"name":"pSpacing",
				"type":"",
				"refparam":"false",
				"description":"Optional gap between cells in pixels. Empty means 0."
			}],
			"examples":[{
				"script":"b2kSheetGridRegions \"coins\", 32, 32, empty, 0, 0"
			}],
			"description":"Internal handler: the grid loaders call it. A frame size below 1 registers nothing.",
			"references":{
				"handler":["b2kSheetLoad","b2kSheetFromImage"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-72",
			"name":"b2ksheetpersists",
			"display name":"b2kSheetPersists",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetPersists()"
			],
			"display syntax":[
				"b2kSheetPersists()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether sheets survive teardown.",
			"examples":[{
				"script":"put b2kSheetPersists() into tKeep"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether sheets survive teardown.",
			"references":{
				"handler":["b2kSheetPersist"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-73",
			"name":"b2kcamlocsemantics",
			"display name":"b2kCamLocSemantics",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamLocSemantics()"
			],
			"display syntax":[
				"b2kCamLocSemantics()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Which grouped-location model this engine uses.",
			"examples":[{
				"script":"put b2kCamLocSemantics() into tModel"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"visual\" when grouped controls report scroll-adjusted locations, else \"content\"."
			}],
			"description":"A diagnostic from the probe <b2kCamOn> runs; the Kit compensates either way.",
			"references":{
				"handler":["b2kCamShiftX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-74",
			"name":"b2ksetmask",
			"display name":"b2kSetMask",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetMask <pControl>,<pLayerList>"
			],
			"display syntax":[
				"b2kSetMask <i>pControl</i>,<i>pLayerList</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set which collision layers a control collides with.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pLayerList",
				"type":"",
				"refparam":"false",
				"description":"A comma or space separated list of layer names or raw numbers."
			}],
			"examples":[{
				"script":"b2kSetMask tGhost, \"walls\""
			}],
			"description":"The reserved \"oneway\" bit is always added, so a body with a custom\nmask still stands on <b2kChain> terrain. The shape keeps its category and\ngroup. A control with no Kit shape is ignored.",
			"references":{
				"handler":["b2kSetCategory","b2kNoCollide"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-75",
			"name":"b2ksetmaxspeed",
			"display name":"b2kSetMaxSpeed",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetMaxSpeed <pPxPerSec>"
			],
			"display syntax":[
				"b2kSetMaxSpeed <i>pPxPerSec</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Limit how fast any body can move.",
			"parameters":[{
				"name":"pPxPerSec",
				"type":"",
				"refparam":"false",
				"description":"The top speed, in pixels per second."
			}],
			"examples":[{
				"script":"b2kSetMaxSpeed 1800"
			}],
			"description":"With no world it does nothing.",
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-76",
			"name":"b2koverlapcircle",
			"display name":"b2kOverlapCircle",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kOverlapCircle(<pX>,<pY>,<pRadiusPx>)"
			],
			"display syntax":[
				"b2kOverlapCircle(<i>pX</i>,<i>pY</i>,<i>pRadiusPx</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The Kit controls whose bodies overlap a screen circle.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The centre x, in pixels."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The centre y, in pixels."
			},{
				"name":"pRadiusPx",
				"type":"",
				"refparam":"false",
				"description":"The radius, in pixels."
			}],
			"examples":[{
				"script":"put b2kOverlapCircle(the mouseH, the mouseV, 40) into tNear"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The controls' long ids, one per line, or empty."
			}],
			"description":"The Kit controls whose bodies overlap a screen circle.",
			"references":{
				"handler":["b2kOverlap"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-77",
			"name":"b2ksheetslicesig",
			"display name":"b2kSheetSliceSig",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetSliceSig(<pSheet>)"
			],
			"display syntax":[
				"b2kSheetSliceSig(<i>pSheet</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A sheet's provenance stamp.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			}],
			"examples":[{
				"script":"put b2kSheetSliceSig(\"chars\") into tSig"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A string naming the sheet's source, its load arguments and its scale."
			}],
			"description":"A saved slice is reused only when its stamp matches, so new art or a new scale is re-sliced.",
			"references":{
				"handler":["b2kSheetKeyIndex","b2kSheetEnsureIcon"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-78",
			"name":"b2ksetgravity",
			"display name":"b2kSetGravity",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetGravity <pGx>,<pGy>"
			],
			"display syntax":[
				"b2kSetGravity <i>pGx</i>,<i>pGy</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Change the world's gravity.",
			"parameters":[{
				"name":"pGx",
				"type":"",
				"refparam":"false",
				"description":"Horizontal gravity in Box2D units (metres per second squared). Not a number means 0."
			},{
				"name":"pGy",
				"type":"",
				"refparam":"false",
				"description":"Vertical gravity in Box2D units, y up, so negative pulls down. Not a number means -10."
			}],
			"examples":[{
				"script":"b2kSetGravity 0, -20"
			}],
			"description":"The values go to Box2D unchanged, in metres per second squared with\ny pointing up, the same convention as <b2kSetup>. With no world it does\nnothing.",
			"references":{
				"handler":["b2kSetup","b2kSetGravityScale"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-79",
			"name":"b2kaddpolygon",
			"display name":"b2kAddPolygon",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddPolygon <pControl>,<pDynamic>"
			],
			"display syntax":[
				"b2kAddPolygon <i>pControl</i>,<i>pDynamic</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a polygon graphic a body built from its own points.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The polygon graphic, by reference. Its points must form a convex outline."
			},{
				"name":"pDynamic",
				"type":"",
				"refparam":"false",
				"description":"true (the default) for a dynamic body, false for a static one."
			}],
			"examples":[{
				"script":"b2kAddPolygon the long id of graphic \"Wedge\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world or fewer than 3 points."
			}],
			"description":"Only the first 8 points are used, relative to the control's centre.\nThe graphic is redrawn from those points as the body moves and rotates.",
			"references":{
				"handler":["b2kAddBox","b2kReshape"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-80",
			"name":"b2kisawake",
			"display name":"b2kIsAwake",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kIsAwake(<pControl>)"
			],
			"display syntax":[
				"b2kIsAwake(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a body is awake.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"if not b2kIsAwake(tCrate) then b2kWake tCrate"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; false when the control has no body."
			}],
			"description":"Report whether a body is awake.",
			"references":{
				"handler":["b2kWake","b2kSleep"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-81",
			"name":"b2kworldcenter",
			"display name":"b2kWorldCenter",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kWorldCenter(<pControl>)"
			],
			"display syntax":[
				"b2kWorldCenter(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's centre of mass in screen pixels.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kWorldCenter(tLever) into tPivot"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"x,y\" in screen pixels, or \"0,0\" when the control has no body."
			}],
			"description":"It differs from <b2kPosition> for off-centre shapes; it is the true pivot for spin and torque.",
			"references":{
				"handler":["b2kPosition"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-82",
			"name":"b2kcamgoto",
			"display name":"b2kCamGoto",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamGoto <pX>,<pY>"
			],
			"display syntax":[
				"b2kCamGoto <i>pX</i>,<i>pY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Cut the view to a world point.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The new view centre x, in world pixels."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The new view centre y, in world pixels."
			}],
			"examples":[{
				"script":"b2kCamGoto 0, 320"
			}],
			"description":"The point is clamped to the bounds and applied at once.",
			"references":{
				"handler":["b2kCamPos","b2kCamBounds"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-83",
			"name":"b2kcamtick",
			"display name":"b2kCamTick",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamTick"
			],
			"display syntax":[
				"b2kCamTick"
			],
			"associations":["box2dxt-kit"],
			"summary":"Run one frame of the camera.",
			"examples":[{
				"script":"b2kCamTick"
			}],
			"description":"Internal handler: the loop calls it each frame. It chases the followed\ncontrol, then applies the view with <b2kCamApply>, and forces the scroll if\nthe target ever ends up outside the view.",
			"references":{
				"handler":["b2kCamApply","b2kCamFollow"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-84",
			"name":"b2ksheetadoptatlas",
			"display name":"b2kSheetAdoptAtlas",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetAdoptAtlas <pName>,<pPngPath>,<pXmlPath>"
			],
			"display syntax":[
				"b2kSheetAdoptAtlas <i>pName</i>,<i>pPngPath</i>,<i>pXmlPath</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register an atlas from the stamp a saved stack carries.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pPngPath",
				"type":"",
				"refparam":"false",
				"description":"The PNG path the atlas was first loaded from."
			},{
				"name":"pXmlPath",
				"type":"",
				"refparam":"false",
				"description":"The XML path the atlas was first loaded from."
			}],
			"examples":[{
				"script":"b2kSheetAdoptAtlas \"chars\", tPng, tXml\nput the result into tFrames"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The frame count through the result, or 0 when there is nothing to adopt."
			}],
			"description":"Internal handler: <b2kSheetLoadAtlas> calls it when sheets persist. It\nadopts only when the image b2ksheet_ plus the sheet name exists and was\nstamped from the same PNG and XML paths, and a malformed stamp adopts\nnothing. It reads no file.",
			"references":{
				"handler":["b2kSheetLoadAtlas","b2kSheetAtlasRows"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-85",
			"name":"b2kweld",
			"display name":"b2kWeld",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWeld <pCtrlA>,<pCtrlB>"
			],
			"display syntax":[
				"b2kWeld <i>pCtrlA</i>,<i>pCtrlB</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Glue two controls rigidly together.",
			"parameters":[{
				"name":"pCtrlA",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pCtrlB",
				"type":"",
				"refparam":"false",
				"description":"The second control, by reference."
			}],
			"examples":[{
				"script":"b2kWeld tCart, tCrate\nput the result into tGlue"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"The bodies keep their current relative position and angle. <b2kWeldSpring> makes the weld springy.",
			"references":{
				"handler":["b2kWeldSpring","b2kRemoveJoint"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-86",
			"name":"b2kplayerattach",
			"display name":"b2kPlayerAttach",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerAttach <pCtrl>"
			],
			"display syntax":[
				"b2kPlayerAttach <i>pCtrl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make an existing control the player.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kPlayerAttach the long id of graphic \"Hitbox\""
			}],
			"description":"A control without a body gets a capsule body with low friction\n(0.08) and no bounce; a body you made yourself keeps its material. The body\ngets fixed rotation and is never allowed to sleep, and input is turned on.\n\nThere is one player at a time: attaching another replaces the controller's\nstate, and the old body and sprite stay. With no world it does nothing.",
			"references":{
				"handler":["b2kPlayerMake","b2kPlayerRemove","b2kPlayerAnims"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-87",
			"name":"b2kplayerdropstart",
			"display name":"b2kPlayerDropStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerDropStart"
			],
			"display syntax":[
				"b2kPlayerDropStart"
			],
			"associations":["box2dxt-kit"],
			"summary":"Open the drop-through window.",
			"examples":[{
				"script":"b2kPlayerDropStart"
			}],
			"description":"Internal handler: takes the reserved one-way bit (2^31) out of the\nplayer's collision mask, so one-way chains alone stop colliding, for\ndropMs.",
			"references":{
				"handler":["b2kPlayerDropRestore","b2kChain"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-88",
			"name":"b2ksoundmuted",
			"display name":"b2kSoundMuted",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSoundMuted()"
			],
			"display syntax":[
				"b2kSoundMuted()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether sounds are muted.",
			"examples":[{
				"script":"put b2kSoundMuted() into tMuted"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether sounds are muted.",
			"references":{
				"handler":["b2kSoundMute"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-89",
			"name":"b2kbodycount",
			"display name":"b2kBodyCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kBodyCount()"
			],
			"display syntax":[
				"b2kBodyCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many bodies the Kit is tracking.",
			"examples":[{
				"script":"put b2kBodyCount() into field \"Bodies\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The number of controls with a Kit body."
			}],
			"description":"How many bodies the Kit is tracking.",
			"references":{
				"handler":["b2kAwakeCount","b2kAwakeBodyCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-90",
			"name":"b2krelease",
			"display name":"b2kRelease",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRelease"
			],
			"display syntax":[
				"b2kRelease"
			],
			"associations":["box2dxt-kit"],
			"summary":"Let go of a dragged body.",
			"examples":[{
				"script":"b2kRelease"
			}],
			"description":"Safe to call when nothing is held.",
			"references":{
				"handler":["b2kGrab"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-91",
			"name":"b2kplayerset",
			"display name":"b2kPlayerSet",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerSet <pKey>,<pValue>"
			],
			"display syntax":[
				"b2kPlayerSet <i>pKey</i>,<i>pValue</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a player tuning knob.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The knob's name (case does not matter)."
			},{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The new value; empty goes back to the default."
			}],
			"examples":[{
				"script":"b2kPlayerSet \"jumpSpeed\", 520\nb2kPlayerSet \"airJumps\", 1"
			}],
			"description":"The knobs: moveSpeed, accel, airAccel, jumpSpeed, jumpCut, coyoteMs,\nbufferMs, maxFall, maxSlopeDeg, dropMs, climbSpeed, swimSpeed, swimJump,\nswimGravity, swimMaxFall, hurtPopX, hurtPopY, hurtMs, invulnMs, and the\nopt-in airJumps, wallJumpX, wallJumpY, wallSlideMax, dashSpeed, dashMs,\ndashCooldownMs, airDash, duckScale and platformCarry (<b2kPlayerDefault>\ngives each default). Unknown keys are stored for your own use.\n\nSet them before or after the player exists; a change applies from the next\nframe. <b2kClear> keeps them; <b2kTeardown> and <b2kPlayerRemove> reset\nthem.",
			"references":{
				"handler":["b2kPlayerGet","b2kPlayerDefault","b2kPlayerTuneCache"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-92",
			"name":"b2kspriteflipped",
			"display name":"b2kSpriteFlipped",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSpriteFlipped(<pCtrl>)"
			],
			"display syntax":[
				"b2kSpriteFlipped(<i>pCtrl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a sprite is mirrored.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference."
			}],
			"examples":[{
				"script":"put b2kSpriteFlipped(tSpr) into tFacingLeft"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether a sprite is mirrored.",
			"references":{
				"handler":["b2kSpriteFlipH"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-93",
			"name":"b2ktonemake",
			"display name":"b2kToneMake",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kToneMake <pName>,<pFreqs>,<pMsPerNote>,<pVolPct>,<pShape>"
			],
			"display syntax":[
				"b2kToneMake <i>pName</i>,<i>pFreqs</i>,<i>pMsPerNote</i>,<i>pVolPct</i>,<i>pShape</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Synthesize a sound from note frequencies, with no asset file.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			},{
				"name":"pFreqs",
				"type":"",
				"refparam":"false",
				"description":"A comma list of frequencies in hertz; 0 is a rest."
			},{
				"name":"pMsPerNote",
				"type":"",
				"refparam":"false",
				"description":"Each note's length in milliseconds, 5-2000."
			},{
				"name":"pVolPct",
				"type":"",
				"refparam":"false",
				"description":"Volume 0-100. Empty means 60."
			},{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"\"sine\" for a soft tone; anything else is a square wave."
			}],
			"examples":[{
				"script":"b2kToneMake \"coin\", \"1319,1760\", 36\nb2kSound \"coin\""
			}],
			"description":"It builds an 8-bit mono WAV at 22050 Hz in script, with a decay on\neach note, and imports it as an audioClip, replacing a sound of the same\nname. About 22 KB per second: keep effects short.",
			"references":{
				"handler":["b2kSound","b2kToneBytes","b2kSoundLoad"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-94",
			"name":"b2kwheelmotoroff",
			"display name":"b2kWheelMotorOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWheelMotorOff <pJoint>"
			],
			"display syntax":[
				"b2kWheelMotorOff <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn a wheel joint's motor off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kWheelMotorOff tAxle"
			}],
			"description":"Turn a wheel joint's motor off.",
			"references":{
				"handler":["b2kWheelMotor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-95",
			"name":"b2kaddwalls",
			"display name":"b2kAddWalls",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddWalls"
			],
			"display syntax":[
				"b2kAddWalls"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add static, invisible walls along the four card edges.",
			"examples":[{
				"script":"b2kSetup\nb2kAddWalls"
			}],
			"description":"The walls are untracked world bodies, so <b2kClear> leaves them in\nplace. They are placed for the current scale and origin, so set those first.",
			"references":{
				"handler":["b2kWall","b2kAddGround","b2kQuickStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-96",
			"name":"b2kangle",
			"display name":"b2kAngle",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kAngle(<pControl>)"
			],
			"display syntax":[
				"b2kAngle(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's rotation in degrees.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put round(b2kAngle(tPlank)) into field \"Angle\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle in degrees (counter-clockwise positive, not wrapped), or 0 when the control has no body."
			}],
			"description":"A body's rotation in degrees.",
			"references":{
				"handler":["b2kSpinRate","b2kMoveTo"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-97",
			"name":"b2kcambounds",
			"display name":"b2kCamBounds",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamBounds <pX1>,<pY1>,<pX2>,<pY2>"
			],
			"display syntax":[
				"b2kCamBounds <i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Keep the view inside the level's rectangle.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"The level's left, in world pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"The level's top, in world pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The level's right, in world pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The level's bottom, in world pixels."
			}],
			"examples":[{
				"script":"b2kCamBounds 0, 0, 3072, 640"
			}],
			"description":"Set the bounds before <b2kCamGoto>.",
			"references":{
				"handler":["b2kCamOn","b2kCamGoto"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-98",
			"name":"b2kplayerhalfw",
			"display name":"b2kPlayerHalfW",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerHalfW()"
			],
			"display syntax":[
				"b2kPlayerHalfW()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The player capsule's half-width.",
			"examples":[{
				"script":"put b2kPlayerHalfW() into tHalfW"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Pixels, or 0 when there is no player."
			}],
			"description":"The player capsule's half-width.",
			"references":{
				"handler":["b2kPlayerHalfH"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-99",
			"name":"b2ksetdamping",
			"display name":"b2kSetDamping",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetDamping <pControl>,<pLinear>,<pAngular>"
			],
			"display syntax":[
				"b2kSetDamping <i>pControl</i>,<i>pLinear</i>,<i>pAngular</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a body's linear and angular damping (drag).",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pLinear",
				"type":"",
				"refparam":"false",
				"description":"Linear damping, 0 for none. Empty leaves it unchanged."
			},{
				"name":"pAngular",
				"type":"",
				"refparam":"false",
				"description":"Angular damping, 0 for none. Empty leaves it unchanged."
			}],
			"examples":[{
				"script":"b2kSetDamping tFeather, 2, 1"
			}],
			"description":"A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kDamping"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-100",
			"name":"b2kaddbox",
			"display name":"b2kAddBox",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddBox <pControl>,<pDynamic>"
			],
			"display syntax":[
				"b2kAddBox <i>pControl</i>,<i>pDynamic</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control a box-shaped body matching its rect.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDynamic",
				"type":"",
				"refparam":"false",
				"description":"true (the default) for a dynamic body, false for a static one."
			}],
			"examples":[{
				"script":"b2kAddBox the long id of graphic \"Crate\"\nput the result into tBody"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world or the control has no size."
			}],
			"description":"A graphic becomes a polygon outline that rotates with its body; a\ndynamic image rotates through its angle; other controls (buttons, fields)\nfollow position only and have their rotation locked so the simulation matches\nthe upright drawing. The control is drawn at once, even with the loop\nstopped.\n\nThe shape starts with density 1, friction 0.4 and bounce 0.2.",
			"references":{
				"handler":["b2kAddBall","b2kAddStatic","b2kSpawnBox","b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-101",
			"name":"b2kspring",
			"display name":"b2kSpring",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpring <pJoint>,<pHertz>,<pDamping>"
			],
			"display syntax":[
				"b2kSpring <i>pJoint</i>,<i>pHertz</i>,<i>pDamping</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a distance joint springy.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The spring stiffness in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio. Empty means 0.5."
			}],
			"examples":[{
				"script":"b2kSpring tRope, 3, 0.2"
			}],
			"description":"Make a distance joint springy.",
			"references":{
				"handler":["b2kRope","b2kWeldSpring","b2kWheelSpring"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-102",
			"name":"b2ksetup",
			"display name":"b2kSetup",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetup <pGravityX>,<pGravityY>"
			],
			"display syntax":[
				"b2kSetup <i>pGravityX</i>,<i>pGravityY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create the physics world and reset the Kit to a clean state.",
			"parameters":[{
				"name":"pGravityX",
				"type":"",
				"refparam":"false",
				"description":"Horizontal gravity in Box2D units (metres per second squared, y up). Empty means 0."
			},{
				"name":"pGravityY",
				"type":"",
				"refparam":"false",
				"description":"Vertical gravity in Box2D units, y up, so a negative value pulls down. Empty means -10."
			}],
			"examples":[{
				"script":"b2kSetup\nb2kAddStatic the long id of graphic \"Floor\"\nb2kAddBox the long id of graphic \"Crate\"\nb2kStart"
			}],
			"description":"Use <b2kSetup> to start a world without starting the loop. It first\ntears down any previous world (<b2kTeardown>), then sets the scale to 40\npixels per metre, the origin to the card's bottom centre (40 px up from the\nbottom edge) and 4 solver sub-steps.\n\nThe gravity values go to Box2D unchanged, in metres per second squared with\ny pointing up. It also maps a native library saved beside the stack\n(<b2kEnsureNativeLib>).",
			"references":{
				"handler":["b2kQuickStart","b2kStart","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-103",
			"name":"b2kplayeraddladder",
			"display name":"b2kPlayerAddLadder",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerAddLadder <pX1>,<pY1>,<pX2>,<pY2>"
			],
			"display syntax":[
				"b2kPlayerAddLadder <i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register a ladder zone.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"One corner's x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"One corner's y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's y, in pixels."
			}],
			"examples":[{
				"script":"b2kPlayerAddLadder 600, 180, 640, 420"
			}],
			"description":"While the player's centre is inside, UP starts a climb (DOWN too\nwhen airborne): gravity stops, y moves at climbSpeed and x at half speed,\nand JUMP leaves with a normal jump. Zones are plain rectangles with no\nphysics; <b2kClear> removes them. Start the zone a little above the\nplatform at the ladder's top. Corners that are not numbers are ignored.",
			"references":{
				"handler":["b2kPlayerInLadder","b2kPlayerAddWater"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-104",
			"name":"b2kwheelmotor",
			"display name":"b2kWheelMotor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWheelMotor <pJoint>,<pDegPerSec>,<pMaxTorque>"
			],
			"display syntax":[
				"b2kWheelMotor <i>pJoint</i>,<i>pDegPerSec</i>,<i>pMaxTorque</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drive a wheel joint at a set spin speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pDegPerSec",
				"type":"",
				"refparam":"false",
				"description":"The target spin in degrees per second."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the motor may use. Empty means 1000."
			}],
			"examples":[{
				"script":"b2kWheelMotor tAxle, -720"
			}],
			"description":"Drive a wheel joint at a set spin speed.",
			"references":{
				"handler":["b2kWheelMotorOff","b2kWheel"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-105",
			"name":"b2kmoveto",
			"display name":"b2kMoveTo",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kMoveTo <pControl>,<pScreenX>,<pScreenY>,<pAngleDeg>"
			],
			"display syntax":[
				"b2kMoveTo <i>pControl</i>,<i>pScreenX</i>,<i>pScreenY</i>,<i>pAngleDeg</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Teleport a body to a screen point and angle.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The new centre x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The new centre y, in pixels."
			},{
				"name":"pAngleDeg",
				"type":"",
				"refparam":"false",
				"description":"The new angle in degrees. Empty means 0."
			}],
			"examples":[{
				"script":"b2kMoveTo tCrate, 300, 100"
			}],
			"description":"The control is redrawn at once. Velocity is kept; follow it with\n<b2kSetVelocity> to stop the body. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kPosition","b2kSetVelocity","b2kSpriteMoveTo"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-106",
			"name":"b2kslider",
			"display name":"b2kSlider",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSlider <pCtrlA>,<pCtrlB>,<pAxisDeg>"
			],
			"display syntax":[
				"b2kSlider <i>pCtrlA</i>,<i>pCtrlB</i>,<i>pAxisDeg</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Let one control slide along an axis relative to another, or to the world.",
			"parameters":[{
				"name":"pCtrlA",
				"type":"",
				"refparam":"false",
				"description":"The control that slides, by reference."
			},{
				"name":"pCtrlB",
				"type":"",
				"refparam":"false",
				"description":"The control it slides against, or empty for the world."
			},{
				"name":"pAxisDeg",
				"type":"",
				"refparam":"false",
				"description":"The on-screen slide direction in degrees: 0 is horizontal, 90 vertical. Empty means 90."
			}],
			"examples":[{
				"script":"b2kSlider tLift, empty, 90\nput the result into tTrack\nb2kSliderLimit tTrack, -200, 0"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"A prismatic joint. Drive it with <b2kSliderMotor> and bound it with <b2kSliderLimit>.",
			"references":{
				"handler":["b2kSliderMotor","b2kSliderLimit","b2kSliderPos","b2kRemoveJoint"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-107",
			"name":"b2kprofile",
			"display name":"b2kProfile",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kProfile()"
			],
			"display syntax":[
				"b2kProfile()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Timings for the last physics step.",
			"examples":[{
				"script":"put b2kProfile() into field \"Perf\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"totalStep,collide,solve\" in milliseconds, or empty with no world."
			}],
			"description":"Timings for the last physics step.",
			"references":{
				"handler":["b2kAwakeBodyCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-108",
			"name":"b2kspritemoveto",
			"display name":"b2kSpriteMoveTo",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteMoveTo <pCtrl>,<pX>,<pY>"
			],
			"display syntax":[
				"b2kSpriteMoveTo <i>pCtrl</i>,<i>pX</i>,<i>pY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Move a control to a world position, camera-correct.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference. Empty makes this a no-op."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The world x, in pixels."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The world y, in pixels."
			}],
			"examples":[{
				"script":"b2kSpriteMoveTo tBat, tBatX, 200"
			}],
			"description":"Use it instead of setting the loc for things you animate by hand,\nsuch as patrols. Outside a camera it is a plain loc set. It does not move a\nbody; use <b2kMoveTo> for that.",
			"references":{
				"handler":["b2kMoveTo","b2kCamShiftX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-109",
			"name":"b2ksync",
			"display name":"b2kSync",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSync"
			],
			"display syntax":[
				"b2kSync"
			],
			"associations":["box2dxt-kit"],
			"summary":"Redraw every awake, moving Kit body's control now.",
			"examples":[{
				"script":"b2kMoveTo tCrate, 300, 100\nb2kSync"
			}],
			"description":"For a stopped or paused world, such as an editor, where no step\nproduces the move events the loop draws from. It holds one screen lock and\nalways releases it.",
			"references":{
				"handler":["b2kSyncAll","b2kSyncAllBodies"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-110",
			"name":"b2kcampos",
			"display name":"b2kCamPos",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamPos()"
			],
			"display syntax":[
				"b2kCamPos()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The view's centre.",
			"examples":[{
				"script":"put b2kCamPos() into tView"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"x,y\" in world pixels."
			}],
			"description":"The view's centre.",
			"references":{
				"handler":["b2kCamGoto"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-111",
			"name":"b2ksetgravityscale",
			"display name":"b2kSetGravityScale",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetGravityScale <pControl>,<pScale>"
			],
			"display syntax":[
				"b2kSetGravityScale <i>pControl</i>,<i>pScale</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a per-body gravity multiplier.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pScale",
				"type":"",
				"refparam":"false",
				"description":"1 is normal gravity, 0 none, a negative value floats the body up."
			}],
			"examples":[{
				"script":"b2kSetGravityScale tBalloon, -0.4"
			}],
			"description":"A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kGravityScale","b2kSetGravity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-112",
			"name":"b2kinputinjectoff",
			"display name":"b2kInputInjectOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kInputInjectOff"
			],
			"display syntax":[
				"b2kInputInjectOff"
			],
			"associations":["box2dxt-kit"],
			"summary":"Return to reading the real keyboard.",
			"examples":[{
				"script":"b2kInputInjectOff"
			}],
			"description":"Return to reading the real keyboard.",
			"references":{
				"handler":["b2kInputInject"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-113",
			"name":"b2kplayerinladder",
			"display name":"b2kPlayerInLadder",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerInLadder()"
			],
			"display syntax":[
				"b2kPlayerInLadder()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the player is inside a ladder zone this frame.",
			"examples":[{
				"script":"if b2kPlayerInLadder() then show field \"ClimbHint\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether the player is inside a ladder zone this frame.",
			"references":{
				"handler":["b2kPlayerAddLadder","b2kPlayerInWater"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-114",
			"name":"b2kspriteframe",
			"display name":"b2kSpriteFrame",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSpriteFrame(<pCtrl>)"
			],
			"display syntax":[
				"b2kSpriteFrame(<i>pCtrl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The frame a sprite is showing.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference."
			}],
			"examples":[{
				"script":"put b2kSpriteFrame(tSpr) into tShown"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The frame's name or number, or empty."
			}],
			"description":"The frame a sprite is showing.",
			"references":{
				"handler":["b2kSpriteSetFrame"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-115",
			"name":"b2kkeypressed",
			"display name":"b2kKeyPressed",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyPressed(<pKey>)"
			],
			"display syntax":[
				"b2kKeyPressed(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a key went down this frame.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A key name (left, right, up, down, space, return, escape, tab, shift, control, alt, backspace, delete), a single character, or a raw keycode."
			}],
			"examples":[{
				"script":"if b2kKeyPressed(\"space\") then b2kPush tHero, 0, -420"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true only on the frame the key went down."
			}],
			"description":"Report whether a key went down this frame.",
			"references":{
				"handler":["b2kKeyIsDown","b2kKeyReleased"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-116",
			"name":"b2kpush",
			"display name":"b2kPush",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPush <pControl>,<pDvxPx>,<pDvyPx>"
			],
			"display syntax":[
				"b2kPush <i>pControl</i>,<i>pDvxPx</i>,<i>pDvyPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add to a body's velocity in pixels per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDvxPx",
				"type":"",
				"refparam":"false",
				"description":"Change in horizontal velocity, px/s."
			},{
				"name":"pDvyPx",
				"type":"",
				"refparam":"false",
				"description":"Change in vertical velocity, px/s (negative is up)."
			}],
			"examples":[{
				"script":"b2kPush tHero, 0, -420"
			}],
			"description":"A one-shot kick that ignores mass: every body gains the same speed.\nIt wakes the body. Use <b2kImpulse> for a mass-aware kick. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kImpulse","b2kSetVelocity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-117",
			"name":"b2kplayerdroprestore",
			"display name":"b2kPlayerDropRestore",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerDropRestore"
			],
			"display syntax":[
				"b2kPlayerDropRestore"
			],
			"associations":["box2dxt-kit"],
			"summary":"Close the drop-through window.",
			"examples":[{
				"script":"b2kPlayerDropRestore"
			}],
			"description":"Internal handler: puts back the mask <b2kPlayerDropStart> saved.",
			"references":{
				"handler":["b2kPlayerDropStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-118",
			"name":"b2kbindaction",
			"display name":"b2kBindAction",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kBindAction <pName>,<pKeyList>"
			],
			"display syntax":[
				"b2kBindAction <i>pName</i>,<i>pKeyList</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Name a set of keys as one action.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The action's name, such as \"jump\"."
			},{
				"name":"pKeyList",
				"type":"",
				"refparam":"false",
				"description":"A comma list of key names, such as \"space,up,w\"."
			}],
			"examples":[{
				"script":"b2kBindAction \"fire\", \"x,control\""
			}],
			"description":"Any bound key counts, and pressed and released treat the set as one key. Keycodes are resolved once, here.",
			"references":{
				"handler":["b2kActionIsDown","b2kActionPressed","b2kBindAxis"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-119",
			"name":"b2kaddball",
			"display name":"b2kAddBall",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddBall <pControl>,<pDynamic>"
			],
			"display syntax":[
				"b2kAddBall <i>pControl</i>,<i>pDynamic</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control a circular body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDynamic",
				"type":"",
				"refparam":"false",
				"description":"true (the default) for a dynamic body, false for a static one."
			}],
			"examples":[{
				"script":"b2kAddBall the long id of graphic \"Ball\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world or the control has no width."
			}],
			"description":"The radius is half the control's width. A graphic is redrawn as a\ncircle, an image rotates through its angle, and other controls follow\nposition. The shape starts with density 1, friction 0.4 and bounce 0.4.",
			"references":{
				"handler":["b2kAddBox","b2kSpawnBall"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-120",
			"name":"b2kkeyreleased",
			"display name":"b2kKeyReleased",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyReleased(<pKey>)"
			],
			"display syntax":[
				"b2kKeyReleased(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a key came up this frame.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A key name (left, right, up, down, space, return, escape, tab, shift, control, alt, backspace, delete), a single character, or a raw keycode."
			}],
			"examples":[{
				"script":"if b2kKeyReleased(\"space\") then put false into tCharging"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true only on the frame the key came up."
			}],
			"description":"Report whether a key came up this frame.",
			"references":{
				"handler":["b2kKeyIsDown","b2kKeyPressed"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-121",
			"name":"b2klocalanchor",
			"display name":"b2kLocalAnchor",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kLocalAnchor(<pBody>,<pWx>,<pWy>)"
			],
			"display syntax":[
				"b2kLocalAnchor(<i>pBody</i>,<i>pWx</i>,<i>pWy</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Convert a world point to a raw body's local frame.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"A raw body handle (see b2kBodyOf)."
			},{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The world x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The world y, in metres."
			}],
			"examples":[{
				"script":"put b2kLocalAnchor(b2kBodyOf(tDoor), b2kToWorldX(300), b2kToWorldY(120)) into tAnchor"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"lx,ly\" in metres in the body's local frame."
			}],
			"description":"A helper the joint constructors use to place anchors.",
			"references":{
				"handler":["b2kBodyOf","b2kHinge"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-122",
			"name":"b2kinputtick",
			"display name":"b2kInputTick",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kInputTick"
			],
			"display syntax":[
				"b2kInputTick"
			],
			"associations":["box2dxt-kit"],
			"summary":"Take this frame's keyboard sample.",
			"examples":[{
				"script":"b2kInputTick"
			}],
			"description":"Internal handler: the loop and <b2kStepOnce> call it once per frame. The\ncurrent key set becomes the previous one and a new set is read from the\nkeyboard, or from the injected keys. A no-op while input is off.",
			"references":{
				"handler":["b2kInputOn","b2kInputInject"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-123",
			"name":"b2kcamshiftx",
			"display name":"b2kCamShiftX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamShiftX(<pRef>)"
			],
			"display syntax":[
				"b2kCamShiftX(<i>pRef</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The horizontal scroll to subtract when placing a control in the viewport.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			}],
			"examples":[{
				"script":"set the loc of tRef to tX - b2kCamShiftX(tRef), tY - b2kCamShiftY(tRef)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The scroll in pixels on a visual-model engine for a control inside the viewport, else 0."
			}],
			"description":"<b2kSpriteMoveTo> and the renderer apply it for you.",
			"references":{
				"handler":["b2kCamShiftY","b2kCamLocSemantics","b2kSpriteMoveTo"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-124",
			"name":"b2kcamoff",
			"display name":"b2kCamOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamOff"
			],
			"display syntax":[
				"b2kCamOff"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn off the camera.",
			"examples":[{
				"script":"b2kCamOff"
			}],
			"description":"The viewport is dissolved and its controls return to the card with their world locations. <b2kTeardown> calls it.",
			"references":{
				"handler":["b2kCamOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-125",
			"name":"b2kaddchain",
			"display name":"b2kAddChain",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddChain <pControl>,<pPoints>,<pLoop>"
			],
			"display syntax":[
				"b2kAddChain <i>pControl</i>,<i>pPoints</i>,<i>pLoop</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control a static chain body from its outline points.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pPoints",
				"type":"",
				"refparam":"false",
				"description":"Screen points, one \"x,y\" per line."
			},{
				"name":"pLoop",
				"type":"",
				"refparam":"false",
				"description":"true to close the outline into a solid blob; anything else leaves an open line."
			}],
			"examples":[{
				"script":"b2kAddChain the long id of graphic \"Hill\", the points of graphic \"Hill\", false"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world."
			}],
			"description":"Unlike <b2kChain> the body is registered against the control, so\n<b2kControlAt>, <b2kMoveTo> and <b2kRemove> treat it like any static part.\nThe points are taken relative to the control's centre. These chains are solid\nterrain and do not carry the \"oneway\" layer.",
			"references":{
				"handler":["b2kChain","b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-126",
			"name":"b2kplayeronground",
			"display name":"b2kPlayerOnGround",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerOnGround()"
			],
			"display syntax":[
				"b2kPlayerOnGround()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the player is grounded this frame.",
			"examples":[{
				"script":"if b2kPlayerOnGround() then put 0 into tAirTime"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; false on the frame a jump launches."
			}],
			"description":"Report whether the player is grounded this frame.",
			"references":{
				"handler":["b2kPlayerState"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-127",
			"name":"b2kraydist",
			"display name":"b2kRayDist",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayDist()"
			],
			"display syntax":[
				"b2kRayDist()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The distance from the last ray's start to its hit, in pixels.",
			"examples":[{
				"script":"put b2kRayDist() into tGap"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The distance, or empty when the last ray missed."
			}],
			"description":"The distance from the last ray's start to its hit, in pixels.",
			"references":{
				"handler":["b2kRayHit"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-128",
			"name":"b2ktoscreenx",
			"display name":"b2kToScreenX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kToScreenX(<pWx>)"
			],
			"display syntax":[
				"b2kToScreenX(<i>pWx</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Convert a world x in metres to a screen x in pixels.",
			"parameters":[{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The world x, in metres."
			}],
			"examples":[{
				"script":"put b2kToScreenX(2.5) into tX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The screen x, in pixels."
			}],
			"description":"Convert a world x in metres to a screen x in pixels.",
			"references":{
				"handler":["b2kToScreenY","b2kToWorldX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-129",
			"name":"b2ksensorentervisitor",
			"display name":"b2kSensorEnterVisitor",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorEnterVisitor(<pIndex>)"
			],
			"display syntax":[
				"b2kSensorEnterVisitor(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The visiting control of an entry this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the entry within this frame."
			}],
			"examples":[{
				"script":"put b2kSensorEnterVisitor(1) into tWho"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The visitor's long id, or empty for an untracked body or an index out of range."
			}],
			"description":"The visiting control of an entry this frame.",
			"references":{
				"handler":["b2kSensorCount","b2kSensorEnterSensor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-130",
			"name":"b2ksteponce",
			"display name":"b2kStepOnce",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kStepOnce"
			],
			"display syntax":[
				"b2kStepOnce"
			],
			"associations":["box2dxt-kit"],
			"summary":"Advance the world exactly one fixed step.",
			"examples":[{
				"script":"b2kPause\nb2kStepOnce"
			}],
			"description":"It works while paused, for a Step button or tests, and runs one\nfull frame: sync, input, player, sprites, camera, events and b2kFrame. It\ndoes nothing unless the loop has been started.",
			"references":{
				"handler":["b2kPause","b2kStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-131",
			"name":"b2ksetscale",
			"display name":"b2kSetScale",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetScale <pPixelsPerMetre>"
			],
			"display syntax":[
				"b2kSetScale <i>pPixelsPerMetre</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set how many screen pixels make one Box2D metre.",
			"parameters":[{
				"name":"pPixelsPerMetre",
				"type":"",
				"refparam":"false",
				"description":"Pixels per metre, clamped to 1-10000. The default after setup is 40."
			}],
			"examples":[{
				"script":"b2kSetup\nb2kSetScale 50"
			}],
			"description":"Set the scale right after <b2kSetup>, before adding bodies: bodies\nalready in the world keep the size they were built with. Moving objects\nbehave best at roughly 0.1 to 10 metres, so 4 to 400 px at the default scale.",
			"references":{
				"handler":["b2kSetOrigin","b2kToWorldX","b2kToScreenX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-132",
			"name":"b2ktoworldx",
			"display name":"b2kToWorldX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kToWorldX(<pSx>)"
			],
			"display syntax":[
				"b2kToWorldX(<i>pSx</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Convert a screen x in pixels to a world x in metres.",
			"parameters":[{
				"name":"pSx",
				"type":"",
				"refparam":"false",
				"description":"The screen x, in pixels."
			}],
			"examples":[{
				"script":"put b2kToWorldX(the mouseH) into tWx"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world x in metres, or 0 before <b2kSetup>."
			}],
			"description":"Convert a screen x in pixels to a world x in metres.",
			"references":{
				"handler":["b2kToWorldY","b2kToScreenX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-133",
			"name":"b2kplayerstandup",
			"display name":"b2kPlayerStandUp",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerStandUp"
			],
			"display syntax":[
				"b2kPlayerStandUp"
			],
			"associations":["box2dxt-kit"],
			"summary":"Restore the player's standing capsule.",
			"examples":[{
				"script":"b2kPlayerStandUp"
			}],
			"description":"Internal handler: stands the player up with no headroom check whenever it is ducked. <b2kPlayerRespawn> uses it.",
			"references":{
				"handler":["b2kPlayerDuckSet"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-134",
			"name":"b2ksetsleepenabled",
			"display name":"b2kSetSleepEnabled",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetSleepEnabled <pControl>,<pFlag>"
			],
			"display syntax":[
				"b2kSetSleepEnabled <i>pControl</i>,<i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Allow or forbid one body ever falling asleep.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to allow sleep; anything else forbids it and wakes the body."
			}],
			"examples":[{
				"script":"b2kSetSleepEnabled tHero, false"
			}],
			"description":"<b2kEnableSleeping> switches the whole world; this switches one\nbody. The player controller forbids sleep on its body so it always responds\nto input. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kEnableSleeping","b2kSetSleepThreshold"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-135",
			"name":"b2kcamison",
			"display name":"b2kCamIsOn",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamIsOn()"
			],
			"display syntax":[
				"b2kCamIsOn()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the camera is on.",
			"examples":[{
				"script":"if not b2kCamIsOn() then b2kCamOn"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether the camera is on.",
			"references":{
				"handler":["b2kCamOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-136",
			"name":"b2ksmoothground",
			"display name":"b2kSmoothGround",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSmoothGround <pPoints>"
			],
			"display syntax":[
				"b2kSmoothGround <i>pPoints</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Build an open chain of smooth static terrain.",
			"parameters":[{
				"name":"pPoints",
				"type":"",
				"refparam":"false",
				"description":"Screen points, one \"x,y\" per line. At least 4 points."
			}],
			"examples":[{
				"script":"b2kSmoothGround tPoints\nput the result into tGround"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The chain handle through the result, or 0 when there is no world."
			}],
			"description":"The same as <b2kChain> with pLoop false; its ghost rule and winding apply.",
			"references":{
				"handler":["b2kChain"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-137",
			"name":"b2ksetfixedrotation",
			"display name":"b2kSetFixedRotation",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetFixedRotation <pControl>,<pFlag>"
			],
			"display syntax":[
				"b2kSetFixedRotation <i>pControl</i>,<i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop or allow a body's rotation.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to stop the body rotating, false to let it rotate."
			}],
			"examples":[{
				"script":"b2kSetFixedRotation tHero, true"
			}],
			"description":"Characters usually want fixed rotation. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSpin","b2kAngle"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-138",
			"name":"b2kplayerdashend",
			"display name":"b2kPlayerDashEnd",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerDashEnd <pBody>"
			],
			"display syntax":[
				"b2kPlayerDashEnd <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"End a dash.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerDashEnd b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: restores the saved gravity scale. Without a start it is a no-op.",
			"references":{
				"handler":["b2kPlayerDashStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-139",
			"name":"b2kplayerswimstart",
			"display name":"b2kPlayerSwimStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerSwimStart <pBody>"
			],
			"display syntax":[
				"b2kPlayerSwimStart <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Start the swim's buoyancy.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerSwimStart b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: saves the body's gravity scale and sets it to swimGravity. A repeated start is a no-op.",
			"references":{
				"handler":["b2kPlayerSwimEnd"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-140",
			"name":"b2ksheetfromimage",
			"display name":"b2kSheetFromImage",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetFromImage <pName>,<pImgRef>,<pFW>,<pFH>,<pCount>,<pMargin>,<pSpacing>"
			],
			"display syntax":[
				"b2kSheetFromImage <i>pName</i>,<i>pImgRef</i>,<i>pFW</i>,<i>pFH</i>,<i>pCount</i>,<i>pMargin</i>,<i>pSpacing</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register an image already in the stack as a grid sheet.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pImgRef",
				"type":"",
				"refparam":"false",
				"description":"The image, by reference."
			},{
				"name":"pFW",
				"type":"",
				"refparam":"false",
				"description":"Frame width in pixels; 0 or empty registers no grid."
			},{
				"name":"pFH",
				"type":"",
				"refparam":"false",
				"description":"Frame height in pixels; 0 or empty registers no grid."
			},{
				"name":"pCount",
				"type":"",
				"refparam":"false",
				"description":"Optional number of frames to register; empty means every whole cell."
			},{
				"name":"pMargin",
				"type":"",
				"refparam":"false",
				"description":"Optional outer border in pixels. Empty means 0."
			},{
				"name":"pSpacing",
				"type":"",
				"refparam":"false",
				"description":"Optional gap between cells in pixels. Empty means 0."
			}],
			"examples":[{
				"script":"b2kSheetFromImage \"hero\", the long id of image \"HeroArt\", 48, 48\nput the result into tFrames"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sheet's frame count through the result."
			}],
			"description":"The image is used in place and the Kit never deletes it.",
			"references":{
				"handler":["b2kSheetLoad","b2kSheetAddFrame"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-141",
			"name":"b2ksheetframenames",
			"display name":"b2kSheetFrameNames",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetFrameNames(<pName>)"
			],
			"display syntax":[
				"b2kSheetFrameNames(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Every frame key of a sheet.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			}],
			"examples":[{
				"script":"put b2kSheetFrameNames(\"chars\") into field \"Frames\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The frame names or numbers, one per line, in definition order."
			}],
			"description":"Every frame key of a sheet.",
			"references":{
				"handler":["b2kSheetFrames","b2kSheetAtlasRows"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-142",
			"name":"b2kspritesweeporphans",
			"display name":"b2kSpriteSweepOrphans",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteSweepOrphans <pKeepAssets>"
			],
			"display syntax":[
				"b2kSpriteSweepOrphans <i>pKeepAssets</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Delete Kit controls a previous session left on the card.",
			"parameters":[{
				"name":"pKeepAssets",
				"type":"",
				"refparam":"false",
				"description":"true to keep sheet images (sources and frames) and delete only sprites and dead viewports."
			}],
			"examples":[{
				"script":"b2kSpriteSweepOrphans false"
			}],
			"description":"A reopened stack resets script variables but keeps its controls,\nso old sprites would linger frozen. It deletes controls on this card\nnamed with the Kit's prefixes: dead camera viewports (ungrouped first),\nsprites, and unless kept, sheet images. Teardowns call it.",
			"references":{
				"handler":["b2kSheetsWipe","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-143",
			"name":"b2kplayerjump",
			"display name":"b2kPlayerJump",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerJump <pSpeed>"
			],
			"display syntax":[
				"b2kPlayerJump <i>pSpeed</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make the player jump, with no ground check.",
			"parameters":[{
				"name":"pSpeed",
				"type":"",
				"refparam":"false",
				"description":"The launch speed in px/s. Empty means the jumpSpeed knob."
			}],
			"examples":[{
				"script":"b2kPlayerJump 700"
			}],
			"description":"The same launch as a pressed jump, for springs and power-ups; the\ncaller decides when it is allowed. Use it for every upward boost: a raw\nupward velocity on a grounded player is treated as a rebound and snapped\naway.",
			"references":{
				"handler":["b2kPlayerSet","b2kPlayerOnGround"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-144",
			"name":"b2ksetstatic",
			"display name":"b2kSetStatic",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetStatic <pControl>"
			],
			"display syntax":[
				"b2kSetStatic <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a body static (immovable).",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kSetStatic tCrate"
			}],
			"description":"The same as <b2kSetType> with \"static\".",
			"references":{
				"handler":["b2kSetType","b2kSetDynamic"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-145",
			"name":"b2kspawnball",
			"display name":"b2kSpawnBall",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpawnBall <pScreenX>,<pScreenY>,<pDiameter>,<pColor>"
			],
			"display syntax":[
				"b2kSpawnBall <i>pScreenX</i>,<i>pScreenY</i>,<i>pDiameter</i>,<i>pColor</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a filled circle graphic with a dynamic ball body.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"Centre x in pixels. Not a number means the world origin's x."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"Centre y in pixels. Not a number means the world origin's y."
			},{
				"name":"pDiameter",
				"type":"",
				"refparam":"false",
				"description":"Diameter in pixels. Empty means 40."
			},{
				"name":"pColor",
				"type":"",
				"refparam":"false",
				"description":"Optional fill colour. An unknown name is ignored."
			}],
			"examples":[{
				"script":"b2kSpawnBall 200, 80, 50, \"red\"\nput the result into tBall"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The new control's long id through the result, or empty when there is no world."
			}],
			"description":"The Kit owns the control: <b2kRemove> and <b2kClear> delete it.",
			"references":{
				"handler":["b2kSpawnBox","b2kAddBall"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-146",
			"name":"b2kwheelspring",
			"display name":"b2kWheelSpring",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWheelSpring <pJoint>,<pHertz>,<pDamping>"
			],
			"display syntax":[
				"b2kWheelSpring <i>pJoint</i>,<i>pHertz</i>,<i>pDamping</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Tune a wheel joint's suspension.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The spring stiffness in hertz. Empty means 4."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio. Empty means 0.7."
			}],
			"examples":[{
				"script":"b2kWheelSpring tAxle, 6, 0.5"
			}],
			"description":"Tune a wheel joint's suspension.",
			"references":{
				"handler":["b2kWheel"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-147",
			"name":"b2kaddsensor",
			"display name":"b2kAddSensor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddSensor <pControl>,<pShape>"
			],
			"display syntax":[
				"b2kAddSensor <i>pControl</i>,<i>pShape</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control a static sensor body: it reports overlaps but never blocks.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pShape",
				"type":"",
				"refparam":"false",
				"description":"\"box\" (the default), \"ball\" or \"capsule\"."
			}],
			"examples":[{
				"script":"b2kAddSensor the long id of graphic \"Goal\"\nb2kContactTarget the long id of me"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The body handle through the result, or 0 when there is no world or the control has no size."
			}],
			"description":"Each frame, bodies that entered or left the sensor are reported to\nthe contact target (<b2kContactTarget>) as b2kSensorEnter and b2kSensorExit,\nwith the sensor control and the visitor control. The frame target does not\nget them. The Kit enables sensor events on every body it creates, so its\nbodies are detected.\n\nSensor messages suit one-shot triggers such as coins and goals. For presence\n(pressure plates) poll <b2kOverlapMoving> each frame instead.",
			"references":{
				"handler":["b2kSensorCount","b2kSetSensor","b2kOverlapMoving"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-148",
			"name":"b2ksensorexitcount",
			"display name":"b2kSensorExitCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorExitCount()"
			],
			"display syntax":[
				"b2kSensorExitCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many sensor exits happened this frame.",
			"examples":[{
				"script":"put b2kSensorExitCount() into tLeft"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, 0 when none."
			}],
			"description":"How many sensor exits happened this frame.",
			"references":{
				"handler":["b2kSensorExitSensor","b2kSensorExitVisitor","b2kSensorCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-149",
			"name":"b2kenablesleeping",
			"display name":"b2kEnableSleeping",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEnableSleeping <pFlag>"
			],
			"display syntax":[
				"b2kEnableSleeping <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn island sleeping on or off for the whole world.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to let resting bodies sleep, false to keep them all awake."
			}],
			"examples":[{
				"script":"b2kEnableSleeping false"
			}],
			"description":"Sleeping saves CPU when bodies rest, and it is on by default. Use\n<b2kSetSleepEnabled> to change it for one body.",
			"references":{
				"handler":["b2kSetSleepEnabled","b2kSleep"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-150",
			"name":"b2kcamfollow",
			"display name":"b2kCamFollow",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamFollow <pCtrl>,<pLerp>"
			],
			"display syntax":[
				"b2kCamFollow <i>pCtrl</i>,<i>pLerp</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make the camera follow a control.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pLerp",
				"type":"",
				"refparam":"false",
				"description":"Optional smoothing, 0.01 to 1 (1 snaps). The default is 0.15."
			}],
			"examples":[{
				"script":"b2kCamFollow gHero, 0.18"
			}],
			"description":"The camera eases toward the control, and snaps when the control would leave the view.",
			"references":{
				"handler":["b2kCamUnfollow","b2kCamDeadzone"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-151",
			"name":"b2kmotoroff",
			"display name":"b2kMotorOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kMotorOff <pJoint>"
			],
			"display syntax":[
				"b2kMotorOff <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn a hinge joint's motor off.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kMotorOff tHinge"
			}],
			"description":"The hinge swings freely again.",
			"references":{
				"handler":["b2kMotor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-152",
			"name":"b2kisenabled",
			"display name":"b2kIsEnabled",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kIsEnabled(<pControl>)"
			],
			"display syntax":[
				"b2kIsEnabled(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a body is in the simulation.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"if not b2kIsEnabled(tDoor) then b2kEnable tDoor"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; false when the control has no body."
			}],
			"description":"Report whether a body is in the simulation.",
			"references":{
				"handler":["b2kEnable","b2kDisable"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-153",
			"name":"b2kactionisdown",
			"display name":"b2kActionIsDown",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kActionIsDown(<pName>)"
			],
			"display syntax":[
				"b2kActionIsDown(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether any key of an action is held.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The action's name."
			}],
			"examples":[{
				"script":"if b2kActionIsDown(\"fire\") then put true into tCharging"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; false for an action that was never bound."
			}],
			"description":"Report whether any key of an action is held.",
			"references":{
				"handler":["b2kBindAction","b2kActionPressed"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-154",
			"name":"b2krayhit",
			"display name":"b2kRayHit",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHit(<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2kRayHit(<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Cast a ray between two screen points and find the closest hit.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"Start x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"Start y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"End x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"End y, in pixels."
			}],
			"examples":[{
				"script":"get b2kRayHit(100, 300, 600, 300)\nput b2kRayHitX() into tHitX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The Kit control hit, or empty when nothing is hit or the body is not a Kit body."
			}],
			"description":"After a hit, <b2kRayHitX>, <b2kRayHitY>, <b2kRayHitNormalX>,\n<b2kRayHitNormalY> and <b2kRayDist> describe it; after a miss they are empty.\nWalls and chains count as hits even though they return empty, so test\n<b2kRayHitX> to tell a wall from a miss. A ray that starts inside a shape\ndoes not report that shape.",
			"references":{
				"handler":["b2kRayHitX","b2kRayDist","b2kRayHitAll"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-155",
			"name":"b2khingeangle",
			"display name":"b2kHingeAngle",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kHingeAngle(<pJoint>)"
			],
			"display syntax":[
				"b2kHingeAngle(<i>pJoint</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A hinge joint's current angle.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"put round(b2kHingeAngle(tHinge)) into field \"Angle\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angle in degrees, or 0 for an empty or 0 handle."
			}],
			"description":"A hinge joint's current angle.",
			"references":{
				"handler":["b2kHingeLimit","b2kHinge"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-156",
			"name":"b2kregister",
			"display name":"b2kRegister",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRegister <pRef>,<pBody>,<pIsStatic>"
			],
			"display syntax":[
				"b2kRegister <i>pRef</i>,<i>pBody</i>,<i>pIsStatic</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Record a control and body pair in the Kit's tables.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			},{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The raw body handle."
			},{
				"name":"pIsStatic",
				"type":"",
				"refparam":"false",
				"description":"true when the body never moves, so the sync skips it."
			}],
			"examples":[{
				"script":"b2kRegister the long id of graphic \"Rock\", tBody, true"
			}],
			"description":"Internal handler: the attach handlers call it. Registering a body you made\nwith the raw b2 layer lets Kit getters and events find its control, but the\nKit does not draw it until a render kind is set by an attach handler.",
			"references":{
				"handler":["b2kAddBox","b2kBodyOf"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-157",
			"name":"b2kplayerwallprobe",
			"display name":"b2kPlayerWallProbe",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerWallProbe <pBody>,<pAxis>"
			],
			"display syntax":[
				"b2kPlayerWallProbe <i>pBody</i>,<i>pAxis</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Look for a wall beside the player.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			},{
				"name":"pAxis",
				"type":"",
				"refparam":"false",
				"description":"The side to look: -1 left, 1 right, 0 the facing."
			}],
			"examples":[{
				"script":"b2kPlayerWallProbe b2kBodyOf(b2kPlayer()), 1"
			}],
			"description":"Internal handler: one sideways ray for the wall-slide and wall-jump system. Its result has no public reader.",
			"references":{
				"handler":["b2kPlayerTick"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-158",
			"name":"b2ksoundclip",
			"display name":"b2kSoundClip",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSoundClip(<pName>)"
			],
			"display syntax":[
				"b2kSoundClip(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The audioClip that plays a named sound.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			}],
			"examples":[{
				"script":"put b2kSoundClip(\"coin\") into tClip"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The clip's name, or empty."
			}],
			"description":"A clip already in the stack under the Kit's name for the sound (as\nin a reopened saved stack) is adopted instead of being made again.",
			"references":{
				"handler":["b2kSoundIsLoaded","b2kSound"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-159",
			"name":"b2kaddstatic",
			"display name":"b2kAddStatic",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddStatic <pControl>"
			],
			"display syntax":[
				"b2kAddStatic <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give a control an immovable box body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kAddStatic the long id of graphic \"Floor\""
			}],
			"description":"The same as <b2kAddBox> with pDynamic false.",
			"references":{
				"handler":["b2kAddBox","b2kSetStatic"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-160",
			"name":"b2knocollide",
			"display name":"b2kNoCollide",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kNoCollide <pCtrlA>,<pCtrlB>"
			],
			"display syntax":[
				"b2kNoCollide <i>pCtrlA</i>,<i>pCtrlB</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop two controls colliding with each other.",
			"parameters":[{
				"name":"pCtrlA",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pCtrlB",
				"type":"",
				"refparam":"false",
				"description":"The second control, by reference."
			}],
			"examples":[{
				"script":"b2kNoCollide tHero, tPet\nput the result into tPass"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"A filter joint: only this pair stops colliding; each still\ncollides with everything else. Remove it with <b2kRemoveJoint>.",
			"references":{
				"handler":["b2kRemoveJoint","b2kSetCollisionGroup"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-161",
			"name":"b2kplayersprite",
			"display name":"b2kPlayerSprite",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerSprite()"
			],
			"display syntax":[
				"b2kPlayerSprite()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The control the controller animates.",
			"examples":[{
				"script":"put b2kPlayerSprite() into tArt"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The art control, or empty when none is found."
			}],
			"description":"The control the controller animates.",
			"references":{
				"handler":["b2kPlayer","b2kPlayerResolveArt"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-162",
			"name":"b2kspeed",
			"display name":"b2kSpeed",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSpeed(<pControl>)"
			],
			"display syntax":[
				"b2kSpeed(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's speed in pixels per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"if b2kSpeed(tBall) > 600 then b2kSound \"whoosh\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The speed, or 0 when the control has no body."
			}],
			"description":"A body's speed in pixels per second.",
			"references":{
				"handler":["b2kVelocity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-163",
			"name":"b2kresettables",
			"display name":"b2kResetTables",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kResetTables"
			],
			"display syntax":[
				"b2kResetTables"
			],
			"associations":["box2dxt-kit"],
			"summary":"Empty the Kit's control and body tables.",
			"examples":[{
				"script":"b2kResetTables"
			}],
			"description":"Internal handler: <b2kSetup> and <b2kTeardown> call it. It forgets every\ncontrol-to-body pairing, shape, render kind and camera membership, but it\ndestroys no body and deletes no control, so calling it on a live world leaves\nbodies the Kit no longer tracks.",
			"references":{
				"handler":["b2kSetup","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-164",
			"name":"b2kplayerforget",
			"display name":"b2kPlayerForget",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerForget <pFull>"
			],
			"display syntax":[
				"b2kPlayerForget <i>pFull</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drop the controller's state.",
			"parameters":[{
				"name":"pFull",
				"type":"",
				"refparam":"false",
				"description":"true to drop the tuning knobs too."
			}],
			"examples":[{
				"script":"b2kPlayerForget false"
			}],
			"description":"Internal handler: <b2kClear> passes false and <b2kTeardown> and\n<b2kPlayerRemove> pass true. A climb, swim, dash or drop in progress is ended\nfirst so the body gets its gravity and mask back. Ladder and water zones go\neither way.",
			"references":{
				"handler":["b2kPlayerRemove","b2kClear"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-165",
			"name":"b2kwall",
			"display name":"b2kWall",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWall <pX1>,<pY1>,<pX2>,<pY2>"
			],
			"display syntax":[
				"b2kWall <i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add an invisible static segment between two screen points.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"Screen x of the first point, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"Screen y of the first point, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"Screen x of the second point, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"Screen y of the second point, in pixels."
			}],
			"examples":[{
				"script":"b2kWall 100, 400, 300, 340"
			}],
			"description":"Use <b2kWall> for custom walls, ramps and ledges. The segment is\ntwo-sided: bodies collide from either side. It is invisible, so draw a\ngraphic to match, and it is not tracked as a body, so <b2kClear> leaves it.\nFor one-sided surfaces use <b2kChain>.",
			"references":{
				"handler":["b2kChain","b2kAddWalls","b2kEdge"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-166",
			"name":"b2kle16",
			"display name":"b2kLE16",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kLE16(<pN>)"
			],
			"display syntax":[
				"b2kLE16(<i>pN</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Pack a number as two little-endian bytes.",
			"parameters":[{
				"name":"pN",
				"type":"",
				"refparam":"false",
				"description":"A whole number from 0 to 65535."
			}],
			"examples":[{
				"script":"put b2kLE16(1) into tBytes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Two bytes."
			}],
			"description":"Pack a number as two little-endian bytes.",
			"references":{
				"handler":["b2kLE32","b2kWavWrap"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-167",
			"name":"b2ksheetkeyindex",
			"display name":"b2kSheetKeyIndex",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetKeyIndex(<pSheet>,<pKey>)"
			],
			"display syntax":[
				"b2kSheetKeyIndex(<i>pSheet</i>,<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A frame's position in its sheet.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"put b2kSheetKeyIndex(\"chars\", \"character_beige_idle\") into tPos"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The 1-based position in definition order, or 0 when absent."
			}],
			"description":"It names saved slices so a reopened stack can find and reuse them.",
			"references":{
				"handler":["b2kSheetSliceSig"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-168",
			"name":"b2ksheethasframe",
			"display name":"b2kSheetHasFrame",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetHasFrame(<pName>,<pFrame>)"
			],
			"display syntax":[
				"b2kSheetHasFrame(<i>pName</i>,<i>pFrame</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a sheet has a frame.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pFrame",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"if b2kSheetHasFrame(\"chars\", \"character_beige_jump\") then put true into tCanJump"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether a sheet has a frame.",
			"references":{
				"handler":["b2kSheetFrames"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-169",
			"name":"b2kdispatchsensors",
			"display name":"b2kDispatchSensors",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDispatchSensors"
			],
			"display syntax":[
				"b2kDispatchSensors"
			],
			"associations":["box2dxt-kit"],
			"summary":"Send this frame's sensor messages.",
			"examples":[{
				"script":"b2kDispatchSensors"
			}],
			"description":"Internal handler: sends b2kSensorEnter and b2kSensorExit to the contact target, in step order. No target, no messages.",
			"references":{
				"handler":["b2kContactTarget","b2kDispatchContacts"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-170",
			"name":"b2kgravityscale",
			"display name":"b2kGravityScale",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kGravityScale(<pControl>)"
			],
			"display syntax":[
				"b2kGravityScale(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's gravity multiplier.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kGravityScale(tBalloon) into tScale"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The gravity scale, or 0 when the control has no body."
			}],
			"description":"A body's gravity multiplier.",
			"references":{
				"handler":["b2kSetGravityScale"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-171",
			"name":"b2krayhitx",
			"display name":"b2kRayHitX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHitX()"
			],
			"display syntax":[
				"b2kRayHitX()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The x of the last ray hit, in screen pixels.",
			"examples":[{
				"script":"if b2kRayHitX() is not empty then put b2kRayHitX() into tX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The rounded x, or empty when the last ray missed."
			}],
			"description":"The x of the last ray hit, in screen pixels.",
			"references":{
				"handler":["b2kRayHit","b2kRayHitY"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-172",
			"name":"b2kplayerswimend",
			"display name":"b2kPlayerSwimEnd",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerSwimEnd <pBody>"
			],
			"display syntax":[
				"b2kPlayerSwimEnd <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"End the swim's buoyancy.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerSwimEnd b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: restores the saved gravity scale. Without a start it is a no-op.",
			"references":{
				"handler":["b2kPlayerSwimStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-173",
			"name":"b2kspinrate",
			"display name":"b2kSpinRate",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSpinRate(<pControl>)"
			],
			"display syntax":[
				"b2kSpinRate(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's rotation speed in degrees per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kSpinRate(tWheel) into tRate"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The angular velocity, or 0 when the control has no body."
			}],
			"description":"A body's rotation speed in degrees per second.",
			"references":{
				"handler":["b2kSpin","b2kSpinBy"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-174",
			"name":"b2kkeylistcodes",
			"display name":"b2kKeyListCodes",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyListCodes(<pKeyList>)"
			],
			"display syntax":[
				"b2kKeyListCodes(<i>pKeyList</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Every keycode a comma list of key names matches.",
			"parameters":[{
				"name":"pKeyList",
				"type":"",
				"refparam":"false",
				"description":"A comma list of key names or codes."
			}],
			"examples":[{
				"script":"put b2kKeyListCodes(\"left,a\") into tCodes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A comma list of keycodes."
			}],
			"description":"A helper the bind commands use.",
			"references":{
				"handler":["b2kKeyCodes","b2kBindAction"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-175",
			"name":"b2kbodytype",
			"display name":"b2kBodyType",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kBodyType(<pControl>)"
			],
			"display syntax":[
				"b2kBodyType(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's type as a word.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"if b2kBodyType(tCrate) is \"dynamic\" then b2kPush tCrate, 0, -200"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"static\", \"kinematic\" or \"dynamic\"; \"static\" when the control has no body."
			}],
			"description":"A body's type as a word.",
			"references":{
				"handler":["b2kSetType"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-176",
			"name":"b2kplayerresolveart",
			"display name":"b2kPlayerResolveArt",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerResolveArt"
			],
			"display syntax":[
				"b2kPlayerResolveArt"
			],
			"associations":["box2dxt-kit"],
			"summary":"Find the control whose animations the controller drives.",
			"examples":[{
				"script":"b2kPlayerResolveArt\nput b2kPlayerSprite() into tArt"
			}],
			"description":"Internal handler: the player itself if it is a sprite, else the first sprite\npinned to it with <b2kSpriteBind>. Call it after binding new art to an\nexisting player.",
			"references":{
				"handler":["b2kPlayerSprite","b2kSpriteBind"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-177",
			"name":"b2kplayeraddwater",
			"display name":"b2kPlayerAddWater",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerAddWater <pX1>,<pY1>,<pX2>,<pY2>"
			],
			"display syntax":[
				"b2kPlayerAddWater <i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register a water (swim) zone.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"One corner's x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"One corner's y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's y, in pixels."
			}],
			"examples":[{
				"script":"b2kPlayerAddWater 900, 300, 1200, 460"
			}],
			"description":"While the player's centre is inside, it swims: gravity drops to\nswimGravity, sinking is capped at swimMaxFall, UP and DOWN move at swimSpeed,\nand each JUMP press is an upward stroke. Zones have no physics; <b2kClear>\nremoves them. Top the zone a little above the drawn water surface.",
			"references":{
				"handler":["b2kPlayerInWater","b2kPlayerAddLadder"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-178",
			"name":"b2kremove",
			"display name":"b2kRemove",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRemove <pControl>"
			],
			"display syntax":[
				"b2kRemove <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Destroy a control's body and forget it.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kRemove tCoin"
			}],
			"description":"If the Kit created the control (b2kSpawn commands, sprites) the\ncontrol is deleted too; a control you attached is left on the card. The\nbody's joints are destroyed with it.",
			"references":{
				"handler":["b2kClear","b2kSpriteRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-179",
			"name":"b2kdamping",
			"display name":"b2kDamping",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kDamping(<pControl>)"
			],
			"display syntax":[
				"b2kDamping(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's linear and angular damping.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put item 1 of b2kDamping(tFeather) into tDrag"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"linear,angular\", or \"0,0\" when the control has no body."
			}],
			"description":"A body's linear and angular damping.",
			"references":{
				"handler":["b2kSetDamping"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-180",
			"name":"b2ksoundisloaded",
			"display name":"b2kSoundIsLoaded",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSoundIsLoaded(<pName>)"
			],
			"display syntax":[
				"b2kSoundIsLoaded(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a named sound exists.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			}],
			"examples":[{
				"script":"if not b2kSoundIsLoaded(\"coin\") then b2kToneMake \"coin\", \"1319,1760\", 36"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false; true too for a clip a saved stack carried in."
			}],
			"description":"Report whether a named sound exists.",
			"references":{
				"handler":["b2kSoundClip"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-181",
			"name":"b2kplayerhurt",
			"display name":"b2kPlayerHurt",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerHurt <pFromX>"
			],
			"display syntax":[
				"b2kPlayerHurt <i>pFromX</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Knock the player back from a hit.",
			"parameters":[{
				"name":"pFromX",
				"type":"",
				"refparam":"false",
				"description":"The x the hit came from; the player pops away from it. Empty pops backward from the facing."
			}],
			"examples":[{
				"script":"if not b2kPlayerHurtIs() then b2kPlayerHurt item 1 of b2kPosition(tSlime)"
			}],
			"description":"The contact-damage standard: an away pop (hurtPopX, hurtPopY), the\nhurt state, input ignored until hurtMs has passed or the first landing after\nhalf of it, whichever is later, then an invulnMs mercy window in which\nthis command does nothing. Ignored while control is off. Keep your respawn flow\nfor lethal falls.",
			"references":{
				"handler":["b2kPlayerHurtIs","b2kPlayerControl","b2kPlayerRespawn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-182",
			"name":"b2kplayercontrol",
			"display name":"b2kPlayerControl",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerControl <pFlag>"
			],
			"display syntax":[
				"b2kPlayerControl <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Give the controller control of the player, or make it only observe.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"false to observe only; anything else gives control back."
			}],
			"examples":[{
				"script":"b2kPlayerControl false"
			}],
			"description":"While observing, ground, state and facing stay fresh but the\ncontroller writes no velocity and no animation (the maxFall limit still\napplies); use it for cutscenes and scripted poses. Either call cancels a\nknockback in progress with no mercy window. Giving control back re-applies\nthe state's animation.",
			"references":{
				"handler":["b2kPlayerHurt","b2kPlayerRespawn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-183",
			"name":"b2kframems",
			"display name":"b2kFrameMS",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kFrameMS()"
			],
			"display syntax":[
				"b2kFrameMS()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The real time the last frame covered.",
			"examples":[{
				"script":"add b2kFrameMS() to tTimer"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Milliseconds, or 0 before the first frame. A hand step counts as one 1/60 s step."
			}],
			"description":"Drive animations and game timers from this, not the frame count: a\nframe may run zero, one or several fixed physics steps.",
			"references":{
				"handler":["b2kFrameTarget"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-184",
			"name":"b2kplayerinwater",
			"display name":"b2kPlayerInWater",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerInWater()"
			],
			"display syntax":[
				"b2kPlayerInWater()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the player is inside a water zone this frame.",
			"examples":[{
				"script":"if b2kPlayerInWater() then subtract b2kFrameMS() from tBreath"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true or false."
			}],
			"description":"Report whether the player is inside a water zone this frame.",
			"references":{
				"handler":["b2kPlayerAddWater","b2kPlayerInLadder"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-185",
			"name":"b2ksheetsourcefromfile",
			"display name":"b2kSheetSourceFromFile",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetSourceFromFile(<pName>,<pPath>)"
			],
			"display syntax":[
				"b2kSheetSourceFromFile(<i>pName</i>,<i>pPath</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Load an image file into the hidden source image of a sheet.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"The image file's path."
			}],
			"examples":[{
				"script":"put b2kSheetSourceFromFile(\"coins\", tPath) into tImg"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The source image's long id, or empty on failure."
			}],
			"description":"Internal handler: the sheet loaders call it. The file is loaded as image\ncontent. When sheets persist and an image already loaded from the same path\nis in the stack, it is reused without reading the file.",
			"references":{
				"handler":["b2kSheetLoad","b2kSheetLoadAtlas"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-186",
			"name":"b2ksliderpos",
			"display name":"b2kSliderPos",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSliderPos(<pJoint>)"
			],
			"display syntax":[
				"b2kSliderPos(<i>pJoint</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A slider joint's current translation.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"if b2kSliderPos(tTrack) <= -200 then b2kSliderMotor tTrack, 80"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The translation in pixels along the axis, or 0 for an empty or 0 handle."
			}],
			"description":"A slider joint's current translation.",
			"references":{
				"handler":["b2kSliderLimit","b2kSlider"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-187",
			"name":"b2krayhitnormaly",
			"display name":"b2kRayHitNormalY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHitNormalY()"
			],
			"display syntax":[
				"b2kRayHitNormalY()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The y part of the surface normal at the last ray hit.",
			"examples":[{
				"script":"if b2kRayHitNormalY() < -0.7 then put true into tIsFloor"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A unit-vector component, screen oriented (negative points up), or empty when the last ray missed."
			}],
			"description":"The y part of the surface normal at the last ray hit.",
			"references":{
				"handler":["b2kRayHit","b2kRayHitNormalX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-188",
			"name":"b2kharvestevents",
			"display name":"b2kHarvestEvents",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kHarvestEvents"
			],
			"display syntax":[
				"b2kHarvestEvents"
			],
			"associations":["box2dxt-kit"],
			"summary":"Collect the last step's contact and sensor events.",
			"examples":[{
				"script":"b2kHarvestEvents"
			}],
			"description":"Internal handler: runs after every fixed step, because Box2D keeps only the latest step's events.",
			"references":{
				"handler":["b2kEventsReset","b2kContactCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-189",
			"name":"b2ktorque",
			"display name":"b2kTorque",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kTorque <pControl>,<pTorque>"
			],
			"display syntax":[
				"b2kTorque <i>pControl</i>,<i>pTorque</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Apply a continuous turning force to a body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pTorque",
				"type":"",
				"refparam":"false",
				"description":"The torque, in Box2D units; the sign sets the direction."
			}],
			"examples":[{
				"script":"b2kTorque tWheel, 20"
			}],
			"description":"Like <b2kForce>, call it every frame for a sustained twist. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kAngularImpulse","b2kForce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-190",
			"name":"b2ksheetloadatlas",
			"display name":"b2kSheetLoadAtlas",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetLoadAtlas <pName>,<pPngPath>,<pXmlPath>"
			],
			"display syntax":[
				"b2kSheetLoadAtlas <i>pName</i>,<i>pPngPath</i>,<i>pXmlPath</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Register a packed atlas: a PNG and its TextureAtlas XML.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pPngPath",
				"type":"",
				"refparam":"false",
				"description":"The PNG file's path."
			},{
				"name":"pXmlPath",
				"type":"",
				"refparam":"false",
				"description":"The XML file's path. Empty means the PNG path with an xml extension."
			}],
			"examples":[{
				"script":"b2kSheetLoadAtlas \"chars\", tFolder & \"/spritesheet-characters-default.png\"\nput the result into tFrames"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The sheet's frame count through the result, or 0 when a file cannot be read."
			}],
			"description":"The XML names each region in SubTexture tags (the Kenney format),\nand frames are addressed by those names. With <b2kSheetPersist> on, the first\nload stamps the regions on the Kit's source image and a later load, even in a\nreopened saved stack, adopts them with no file access.",
			"references":{
				"handler":["b2kSheetPersist","b2kSheetAdoptAtlas","b2kSheetFrameNames","b2kAnimDef"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-191",
			"name":"b2kangularimpulse",
			"display name":"b2kAngularImpulse",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAngularImpulse <pControl>,<pImpulse>"
			],
			"display syntax":[
				"b2kAngularImpulse <i>pControl</i>,<i>pImpulse</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Apply a one-shot, mass-aware turning impulse.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pImpulse",
				"type":"",
				"refparam":"false",
				"description":"The angular impulse, in Box2D units; the sign sets the direction."
			}],
			"examples":[{
				"script":"b2kAngularImpulse tWheel, 2"
			}],
			"description":"Bodies with more rotational inertia turn less. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kTorque","b2kSpinBy"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-192",
			"name":"b2kdisable",
			"display name":"b2kDisable",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDisable <pControl>"
			],
			"display syntax":[
				"b2kDisable <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Take a body out of the simulation.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kMoveTo tDoor, -500, -500\nb2kDisable tDoor"
			}],
			"description":"A disabled body has no gravity and no collisions and its control\nstays where it is. Move it out of the way first if it should vanish. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kEnable","b2kIsEnabled"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-193",
			"name":"b2ksetsensor",
			"display name":"b2kSetSensor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetSensor <pControl>,<pFlag>"
			],
			"display syntax":[
				"b2kSetSensor <i>pControl</i>,<i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Mark a control's shape as a sensor or as solid, for its next rebuild.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true for a sensor, anything else for solid."
			}],
			"examples":[{
				"script":"b2kSetSensor tZone, true\nb2kReshape tZone, \"box\""
			}],
			"description":"The sensor flag lives on the shape, so this only records the\nchoice. Rebuild the shape with <b2kReshape> to apply it.",
			"references":{
				"handler":["b2kReshape","b2kAddSensor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-194",
			"name":"b2kcammousex",
			"display name":"b2kCamMouseX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamMouseX()"
			],
			"display syntax":[
				"b2kCamMouseX()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The mouse's x in world pixels.",
			"examples":[{
				"script":"get b2kGrab(b2kCamMouseX(), b2kCamMouseY())"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The mouse x adjusted for the camera scroll; the plain mouseH when the camera is off."
			}],
			"description":"The mouse's x in world pixels.",
			"references":{
				"handler":["b2kCamMouseY","b2kGrab"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-195",
			"name":"b2kawakebodycount",
			"display name":"b2kAwakeBodyCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kAwakeBodyCount()"
			],
			"display syntax":[
				"b2kAwakeBodyCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many bodies Box2D has awake.",
			"examples":[{
				"script":"put b2kAwakeBodyCount() into field \"Awake\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The native count, or 0 with no world."
			}],
			"description":"It counts every awake body in the world, including bodies the Kit does not track.",
			"references":{
				"handler":["b2kAwakeCount","b2kProfile"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-196",
			"name":"b2kforce",
			"display name":"b2kForce",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kForce <pControl>,<pFxPx>,<pFyPx>"
			],
			"display syntax":[
				"b2kForce <i>pControl</i>,<i>pFxPx</i>,<i>pFyPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Apply a continuous force to a body's centre.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFxPx",
				"type":"",
				"refparam":"false",
				"description":"Horizontal force, scaled by the Kit's pixels per metre (positive is right)."
			},{
				"name":"pFyPx",
				"type":"",
				"refparam":"false",
				"description":"Vertical force, scaled the same way (positive is down)."
			}],
			"examples":[{
				"script":"b2kForce tRocket, 0, -300"
			}],
			"description":"A force acts for one step, so call it every frame (from b2kFrame)\nfor thrust or wind. It wakes the body. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kImpulse","b2kTorque"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-197",
			"name":"b2ksheetframes",
			"display name":"b2kSheetFrames",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSheetFrames(<pName>)"
			],
			"display syntax":[
				"b2kSheetFrames(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many frames a sheet has.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			}],
			"examples":[{
				"script":"put b2kSheetFrames(\"coins\") into tN"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The frame count, 0 for an unknown sheet."
			}],
			"description":"How many frames a sheet has.",
			"references":{
				"handler":["b2kSheetHasFrame","b2kSheetFrameNames"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-198",
			"name":"b2ksetvelocity",
			"display name":"b2kSetVelocity",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetVelocity <pControl>,<pVxPx>,<pVyPx>"
			],
			"display syntax":[
				"b2kSetVelocity <i>pControl</i>,<i>pVxPx</i>,<i>pVyPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a body's velocity in pixels per second, and wake it.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pVxPx",
				"type":"",
				"refparam":"false",
				"description":"Horizontal velocity in px/s (positive is right)."
			},{
				"name":"pVyPx",
				"type":"",
				"refparam":"false",
				"description":"Vertical velocity in px/s (positive is down)."
			}],
			"examples":[{
				"script":"b2kSetVelocity tHero, b2kAxis(\"moveX\") * 240, item 2 of b2kVelocity(tHero)"
			}],
			"description":"Setting a velocity always wakes the body. Do not write a velocity\nevery frame to a body that is meant to come to rest: it never sleeps. For a\nplayer under the controller use <b2kPlayerJump> for upward boosts. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kVelocity","b2kPush","b2kImpulse"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-199",
			"name":"b2kposition",
			"display name":"b2kPosition",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPosition(<pControl>)"
			],
			"display syntax":[
				"b2kPosition(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's centre in screen pixels.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put item 1 of b2kPosition(tHero) into tHeroX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"x,y\" in screen pixels (sub-pixel), or \"0,0\" when the control has no body."
			}],
			"description":"A body's centre in screen pixels.",
			"references":{
				"handler":["b2kWorldCenter","b2kVelocity","b2kMoveTo"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-200",
			"name":"b2ksheetswipe",
			"display name":"b2kSheetsWipe",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetsWipe"
			],
			"display syntax":[
				"b2kSheetsWipe"
			],
			"associations":["box2dxt-kit"],
			"summary":"Forget every sheet and remove every sprite.",
			"examples":[{
				"script":"b2kSheetsWipe"
			}],
			"description":"It also deletes Kit-made sprite and sheet images a previous session\nleft on the card. <b2kTeardown> calls it unless sheets persist; call it\nyourself to force a clean reload.",
			"references":{
				"handler":["b2kSheetForget","b2kSheetPersist","b2kSpriteSweepOrphans"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-201",
			"name":"b2kcamshifty",
			"display name":"b2kCamShiftY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamShiftY(<pRef>)"
			],
			"display syntax":[
				"b2kCamShiftY(<i>pRef</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The vertical scroll to subtract when placing a control in the viewport.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			}],
			"examples":[{
				"script":"put b2kCamShiftY(tRef) into tShift"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The scroll in pixels on a visual-model engine for a control inside the viewport, else 0."
			}],
			"description":"The vertical scroll to subtract when placing a control in the viewport.",
			"references":{
				"handler":["b2kCamShiftX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-202",
			"name":"b2kwavwrap",
			"display name":"b2kWavWrap",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kWavWrap(<pData>)"
			],
			"display syntax":[
				"b2kWavWrap(<i>pData</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Wrap raw samples in a WAV file header.",
			"parameters":[{
				"name":"pData",
				"type":"",
				"refparam":"false",
				"description":"8-bit mono samples at 22050 Hz."
			}],
			"examples":[{
				"script":"put b2kWavWrap(tSamples) into URL (\"binfile:\" & tPath)"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The bytes of a WAV file."
			}],
			"description":"Wrap raw samples in a WAV file header.",
			"references":{
				"handler":["b2kToneBytes","b2kLE32"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-203",
			"name":"b2kawakecount",
			"display name":"b2kAwakeCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kAwakeCount()"
			],
			"display syntax":[
				"b2kAwakeCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many non-static Kit bodies are awake.",
			"examples":[{
				"script":"put b2kAwakeCount() into field \"Awake\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, walked over the Kit's own bodies."
			}],
			"description":"<b2kAwakeBodyCount> asks Box2D instead and counts bodies the Kit does not track too.",
			"references":{
				"handler":["b2kBodyCount","b2kAwakeBodyCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-204",
			"name":"b2kspriteshowframe",
			"display name":"b2kSpriteShowFrame",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteShowFrame <pRef>,<pKey>"
			],
			"display syntax":[
				"b2kSpriteShowFrame <i>pRef</i>,<i>pKey</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Point a sprite's icon at a frame.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The sprite's long id."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"b2kSpriteShowFrame tSpr, 3"
			}],
			"description":"Internal handler: it honours the sprite's facing and skips the icon set\nwhen the frame is already shown. It does not stop an animation; use\n<b2kSpriteSetFrame> for that.",
			"references":{
				"handler":["b2kSpriteSetFrame"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-205",
			"name":"b2kmotor",
			"display name":"b2kMotor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kMotor <pJoint>,<pDegPerSec>,<pMaxTorque>"
			],
			"display syntax":[
				"b2kMotor <i>pJoint</i>,<i>pDegPerSec</i>,<i>pMaxTorque</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drive a hinge joint at a set speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pDegPerSec",
				"type":"",
				"refparam":"false",
				"description":"The target speed in degrees per second."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the motor may use. Empty means 1000."
			}],
			"examples":[{
				"script":"b2kMotor tHinge, 180"
			}],
			"description":"Drive a hinge joint at a set speed.",
			"references":{
				"handler":["b2kMotorOff","b2kHinge"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-206",
			"name":"b2kspawnbox",
			"display name":"b2kSpawnBox",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpawnBox <pScreenX>,<pScreenY>,<pW>,<pH>,<pColor>"
			],
			"display syntax":[
				"b2kSpawnBox <i>pScreenX</i>,<i>pScreenY</i>,<i>pW</i>,<i>pH</i>,<i>pColor</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a filled rectangle graphic with a dynamic box body.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"Centre x in pixels. Not a number means the world origin's x."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"Centre y in pixels. Not a number means the world origin's y."
			},{
				"name":"pW",
				"type":"",
				"refparam":"false",
				"description":"Width in pixels. Empty means 40."
			},{
				"name":"pH",
				"type":"",
				"refparam":"false",
				"description":"Height in pixels. Empty means the width."
			},{
				"name":"pColor",
				"type":"",
				"refparam":"false",
				"description":"Optional fill colour, such as \"orange\" or \"255,128,0\". An unknown name is ignored."
			}],
			"examples":[{
				"script":"b2kSpawnBox 260, 80, 60, 40, \"orange\"\nput the result into tBox"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The new control's long id through the result, or empty when there is no world."
			}],
			"description":"The Kit owns the control: <b2kRemove> and <b2kClear> delete it.\nWhile the camera is on it is created inside the viewport. Read the result on\nthe very next line, because the next command replaces it.",
			"references":{
				"handler":["b2kSpawnBall","b2kSpawnCapsule","b2kAddBox","b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-207",
			"name":"b2ksetcollisiongroup",
			"display name":"b2kSetCollisionGroup",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetCollisionGroup <pControl>,<pGroup>"
			],
			"display syntax":[
				"b2kSetCollisionGroup <i>pControl</i>,<i>pGroup</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a control's collision group index.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pGroup",
				"type":"",
				"refparam":"false",
				"description":"A negative group never collides with its own group; a positive one always does; 0 uses category and mask."
			}],
			"examples":[{
				"script":"b2kSetCollisionGroup tRagdollArm, -1"
			}],
			"description":"The group overrides category and mask. A control with no Kit shape is ignored.",
			"references":{
				"handler":["b2kSetCategory","b2kNoCollide"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-208",
			"name":"b2ktoscreeny",
			"display name":"b2kToScreenY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kToScreenY(<pWy>)"
			],
			"display syntax":[
				"b2kToScreenY(<i>pWy</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Convert a world y in metres (y up) to a screen y in pixels (y down).",
			"parameters":[{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The world y, in metres."
			}],
			"examples":[{
				"script":"put b2kToScreenY(0) into tGroundY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The screen y, in pixels."
			}],
			"description":"Convert a world y in metres (y up) to a screen y in pixels (y down).",
			"references":{
				"handler":["b2kToScreenX","b2kToWorldY"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-209",
			"name":"b2kplayer",
			"display name":"b2kPlayer",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayer()"
			],
			"display syntax":[
				"b2kPlayer()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The player control.",
			"examples":[{
				"script":"put b2kPlayer() into tHero"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The player's long id, or empty when there is no player."
			}],
			"description":"The player control.",
			"references":{
				"handler":["b2kPlayerSprite","b2kPlayerMake"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-210",
			"name":"b2kcamon",
			"display name":"b2kCamOn",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamOn <pRect>"
			],
			"display syntax":[
				"b2kCamOn <i>pRect</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn on the scrolling camera.",
			"parameters":[{
				"name":"pRect",
				"type":"",
				"refparam":"false",
				"description":"The viewport rect on the card. Empty means the card's rect. World\n0,0 is the viewport's top-left corner, wherever the viewport is on the card."
			}],
			"examples":[{
				"script":"b2kCamOn\nb2kCamBounds 0, 0, 3072, 640\nb2kCamFollow gHero, 0.18"
			}],
			"description":"It creates a clipped viewport group the loop scrolls. While it is on,\ncontrols the Kit creates go inside it and keep world-pixel locations. Turn\nit on before building the level, after any static backdrop. Check\n<b2kCamStatus> afterwards: a failure is reported there, not thrown.",
			"references":{
				"handler":["b2kCamOff","b2kCamFollow","b2kCamBounds","b2kCamStatus"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-211",
			"name":"b2ktoworldy",
			"display name":"b2kToWorldY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kToWorldY(<pSy>)"
			],
			"display syntax":[
				"b2kToWorldY(<i>pSy</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Convert a screen y in pixels (y down) to a world y in metres (y up).",
			"parameters":[{
				"name":"pSy",
				"type":"",
				"refparam":"false",
				"description":"The screen y, in pixels."
			}],
			"examples":[{
				"script":"put b2kToWorldY(the mouseV) into tWy"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world y in metres, or 0 before <b2kSetup>."
			}],
			"description":"Convert a screen y in pixels (y down) to a world y in metres (y up).",
			"references":{
				"handler":["b2kToWorldX","b2kToScreenY"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-212",
			"name":"b2kvelocity",
			"display name":"b2kVelocity",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kVelocity(<pControl>)"
			],
			"display syntax":[
				"b2kVelocity(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's velocity in pixels per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put item 2 of b2kVelocity(tHero) into tFallSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"\"vx,vy\" in px/s with y down, or \"0,0\" when the control has no body."
			}],
			"description":"A body's velocity in pixels per second.",
			"references":{
				"handler":["b2kSetVelocity","b2kSpeed"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-213",
			"name":"b2kspritefps",
			"display name":"b2kSpriteFPS",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteFPS <pCtrl>,<pFPS>"
			],
			"display syntax":[
				"b2kSpriteFPS <i>pCtrl</i>,<i>pFPS</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Override a sprite's animation speed.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pFPS",
				"type":"",
				"refparam":"false",
				"description":"Frames per second; empty goes back to each animation's own speed."
			}],
			"examples":[{
				"script":"b2kSpriteFPS tSpr, 12"
			}],
			"description":"Override a sprite's animation speed.",
			"references":{
				"handler":["b2kSpritePlay","b2kAnimDef"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-214",
			"name":"b2kdefinelayer",
			"display name":"b2kDefineLayer",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDefineLayer <pName>"
			],
			"display syntax":[
				"b2kDefineLayer <i>pName</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Define or look up a named collision layer.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The layer's name."
			}],
			"examples":[{
				"script":"b2kDefineLayer \"enemies\"\nput the result into tBit"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The layer's bit value through the result, or 0 when all 31 nameable layers are taken."
			}],
			"description":"Layers are handed out from bit 1 up to bit 2^30. The top bit, 2^31,\nis the Kit's reserved \"oneway\" layer for chains; it can be named in a list\nbut is never handed out. You rarely need to call this yourself: the layer\nlists of <b2kSetCategory> and <b2kSetMask> define names as they meet them.",
			"references":{
				"handler":["b2kLayerBits","b2kSetCategory","b2kSetMask"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-215",
			"name":"b2kanimdef",
			"display name":"b2kAnimDef",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAnimDef <pSheet>,<pAnim>,<pFrames>,<pFPS>,<pLoop>"
			],
			"display syntax":[
				"b2kAnimDef <i>pSheet</i>,<i>pAnim</i>,<i>pFrames</i>,<i>pFPS</i>,<i>pLoop</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Define a named animation over a sheet's frames.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pAnim",
				"type":"",
				"refparam":"false",
				"description":"The animation's name."
			},{
				"name":"pFrames",
				"type":"",
				"refparam":"false",
				"description":"A comma list of frame names and numbers; a numeric range such as 1-8 expands."
			},{
				"name":"pFPS",
				"type":"",
				"refparam":"false",
				"description":"Frames per second, clamped to 0.1-120."
			},{
				"name":"pLoop",
				"type":"",
				"refparam":"false",
				"description":"false for a one-shot animation; anything else loops."
			}],
			"examples":[{
				"script":"b2kAnimDef \"chars\", \"walk\", \"character_beige_walk_a,character_beige_walk_b\", 6, true"
			}],
			"description":"Define a named animation over a sheet's frames.",
			"references":{
				"handler":["b2kSpritePlay","b2kSpriteOnFinish"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-216",
			"name":"b2kspinby",
			"display name":"b2kSpinBy",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpinBy <pControl>,<pDegPerSec>"
			],
			"display syntax":[
				"b2kSpinBy <i>pControl</i>,<i>pDegPerSec</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add to a body's angular velocity, in degrees per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDegPerSec",
				"type":"",
				"refparam":"false",
				"description":"The change in spin rate, degrees per second."
			}],
			"examples":[{
				"script":"b2kSpinBy tWheel, 90"
			}],
			"description":"It wakes the body. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSpin","b2kAngularImpulse"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-217",
			"name":"b2ksoundswipe",
			"display name":"b2kSoundsWipe",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundsWipe"
			],
			"display syntax":[
				"b2kSoundsWipe"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop playback and delete every Kit sound.",
			"examples":[{
				"script":"b2kSoundsWipe"
			}],
			"description":"It deletes every Kit-made audioClip, including ones a previous\nsession left in the stack, and resets audio after a failure. The mute\nsetting survives.",
			"references":{
				"handler":["b2kSoundLoad","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-218",
			"name":"b2kendcontacta",
			"display name":"b2kEndContactA",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kEndContactA(<pIndex>)"
			],
			"display syntax":[
				"b2kEndContactA(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The first control of a pair that stopped touching this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the event within this frame."
			}],
			"examples":[{
				"script":"put b2kEndContactA(1) into tFirst"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control's long id, or empty for a wall, the ground, an untracked body or an index out of range."
			}],
			"description":"The first control of a pair that stopped touching this frame.",
			"references":{
				"handler":["b2kEndContactCount","b2kEndContactB"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-219",
			"name":"b2ksensorexitvisitor",
			"display name":"b2kSensorExitVisitor",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorExitVisitor(<pIndex>)"
			],
			"display syntax":[
				"b2kSensorExitVisitor(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The visiting control of an exit this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the exit within this frame."
			}],
			"examples":[{
				"script":"put b2kSensorExitVisitor(1) into tWho"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The visitor's long id, or empty for an untracked body or an index out of range."
			}],
			"description":"The visiting control of an exit this frame.",
			"references":{
				"handler":["b2kSensorExitCount","b2kSensorExitSensor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-220",
			"name":"b2kenablewarmstarting",
			"display name":"b2kEnableWarmStarting",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEnableWarmStarting <pFlag>"
			],
			"display syntax":[
				"b2kEnableWarmStarting <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn the solver's warm starting on or off.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to reuse the last step's solution (the default), false to turn it off."
			}],
			"examples":[{
				"script":"b2kEnableWarmStarting true"
			}],
			"description":"Warm starting makes stacks faster and more stable. With no world it does nothing.",
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-221",
			"name":"b2kwheel",
			"display name":"b2kWheel",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWheel <pChassis>,<pWheel>,<pScreenX>,<pScreenY>,<pAxisDeg>"
			],
			"display syntax":[
				"b2kWheel <i>pChassis</i>,<i>pWheel</i>,<i>pScreenX</i>,<i>pScreenY</i>,<i>pAxisDeg</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Attach a wheel to a chassis with a sprung axis and free spin.",
			"parameters":[{
				"name":"pChassis",
				"type":"",
				"refparam":"false",
				"description":"The chassis control, by reference."
			},{
				"name":"pWheel",
				"type":"",
				"refparam":"false",
				"description":"The wheel control, by reference."
			},{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The anchor x in pixels. Empty means the wheel's centre."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The anchor y in pixels, used when an anchor x is given."
			},{
				"name":"pAxisDeg",
				"type":"",
				"refparam":"false",
				"description":"The suspension axis in screen degrees. Empty means straight up."
			}],
			"examples":[{
				"script":"b2kWheel tCar, tFrontWheel\nput the result into tAxle\nb2kWheelMotor tAxle, -720"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"Attach a wheel to a chassis with a sprung axis and free spin.",
			"references":{
				"handler":["b2kWheelMotor","b2kWheelSpring","b2kRemoveJoint"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-222",
			"name":"b2kkeyname",
			"display name":"b2kKeyName",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyName(<pCode>)"
			],
			"display syntax":[
				"b2kKeyName(<i>pCode</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The friendly name of a keycode.",
			"parameters":[{
				"name":"pCode",
				"type":"",
				"refparam":"false",
				"description":"A keycode."
			}],
			"examples":[{
				"script":"put b2kKeyName(65361) into tName"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The key's name, a lower-case letter or digit, or the code itself when it has no name."
			}],
			"description":"The friendly name of a keycode.",
			"references":{
				"handler":["b2kKeyCodes","b2kKeysHeld"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-223",
			"name":"b2ksound",
			"display name":"b2kSound",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSound <pName>"
			],
			"display syntax":[
				"b2kSound <i>pName</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Play a named sound.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			}],
			"examples":[{
				"script":"b2kSound \"coin\""
			}],
			"description":"The engine plays one clip at a time, so this cuts whatever is\nplaying. Unknown names, mute and dead audio are silent no-ops; a failed play\nturns audio off for the session and <b2kSoundStatus> says why.",
			"references":{
				"handler":["b2kSoundLoop","b2kSoundMute","b2kToneMake"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-224",
			"name":"b2kropelength",
			"display name":"b2kRopeLength",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRopeLength(<pJoint>)"
			],
			"display syntax":[
				"b2kRopeLength(<i>pJoint</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A distance joint's current length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"put b2kRopeLength(tRope) into tLen"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The length in pixels, or 0 for an empty or 0 handle."
			}],
			"description":"A distance joint's current length.",
			"references":{
				"handler":["b2kRopeSetLength","b2kRope"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-225",
			"name":"b2kplayerstate",
			"display name":"b2kPlayerState",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerState()"
			],
			"display syntax":[
				"b2kPlayerState()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The player's current state.",
			"examples":[{
				"script":"if b2kPlayerState() is \"land\" then b2kSound \"land\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"idle, run, jump, fall, duck, climb, hurt, swim, wallslide or dash, or land for one frame on touch-down; empty when there is no player."
			}],
			"description":"Read it from b2kFrame. A drop-through reads as fall. The wallslide\nand dash states appear only when their knobs are on.",
			"references":{
				"handler":["b2kPlayerOnGround","b2kPlayerAnims"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-226",
			"name":"b2kclamp",
			"display name":"b2kClamp",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kClamp(<pValue>,<pLo>,<pHi>)"
			],
			"display syntax":[
				"b2kClamp(<i>pValue</i>,<i>pLo</i>,<i>pHi</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Clamp a value into a range.",
			"parameters":[{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The value to clamp. Empty or not a number counts as the low bound."
			},{
				"name":"pLo",
				"type":"",
				"refparam":"false",
				"description":"The lower bound."
			},{
				"name":"pHi",
				"type":"",
				"refparam":"false",
				"description":"The upper bound."
			}],
			"examples":[{
				"script":"put b2kClamp(tVolume, 0, 100) into tVolume"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value limited to the range from the low to the high bound."
			}],
			"description":"Clamp a value into a range.",
			"references":{
				"handler":["b2kNumberOr"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-227",
			"name":"b2ksetjointtuning",
			"display name":"b2kSetJointTuning",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetJointTuning <pHertz>,<pDamping>"
			],
			"display syntax":[
				"b2kSetJointTuning <i>pHertz</i>,<i>pDamping</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Tune joint softness for the world.",
			"parameters":[{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"Joint stiffness, in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The joint damping ratio."
			}],
			"examples":[{
				"script":"b2kSetJointTuning 60, 2"
			}],
			"description":"With no world it does nothing.",
			"references":{
				"handler":["b2kSetContactTuning"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-228",
			"name":"b2kactionreleased",
			"display name":"b2kActionReleased",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kActionReleased(<pName>)"
			],
			"display syntax":[
				"b2kActionReleased(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether an action ended this frame.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The action's name."
			}],
			"examples":[{
				"script":"if b2kActionReleased(\"fire\") then put false into tCharging"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true on the frame the last of its keys came up."
			}],
			"description":"Report whether an action ended this frame.",
			"references":{
				"handler":["b2kBindAction","b2kActionPressed"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-229",
			"name":"b2kcamdeadzone",
			"display name":"b2kCamDeadzone",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamDeadzone <pW>,<pH>"
			],
			"display syntax":[
				"b2kCamDeadzone <i>pW</i>,<i>pH</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a centre box the target may move in before the camera chases.",
			"parameters":[{
				"name":"pW",
				"type":"",
				"refparam":"false",
				"description":"The box's width in pixels; 0 always centres."
			},{
				"name":"pH",
				"type":"",
				"refparam":"false",
				"description":"The box's height in pixels; 0 always centres."
			}],
			"examples":[{
				"script":"b2kCamDeadzone 140, 600"
			}],
			"description":"Set a centre box the target may move in before the camera chases.",
			"references":{
				"handler":["b2kCamFollow"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-230",
			"name":"b2kroperange",
			"display name":"b2kRopeRange",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRopeRange <pJoint>,<pMinPx>,<pMaxPx>"
			],
			"display syntax":[
				"b2kRopeRange <i>pJoint</i>,<i>pMinPx</i>,<i>pMaxPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a distance joint's minimum and maximum length.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pMinPx",
				"type":"",
				"refparam":"false",
				"description":"The shortest length in pixels."
			},{
				"name":"pMaxPx",
				"type":"",
				"refparam":"false",
				"description":"The longest length in pixels."
			}],
			"examples":[{
				"script":"b2kRopeRange tRope, 0, 200"
			}],
			"description":"Set a distance joint's minimum and maximum length.",
			"references":{
				"handler":["b2kRope","b2kRopeSetLength"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-231",
			"name":"b2ksetfriction",
			"display name":"b2kSetFriction",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetFriction <pControl>,<pFriction>"
			],
			"display syntax":[
				"b2kSetFriction <i>pControl</i>,<i>pFriction</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a control's shape friction.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pFriction",
				"type":"",
				"refparam":"false",
				"description":"Friction, usually 0 (ice) to 1 (rubber); clamped to 0-10."
			}],
			"examples":[{
				"script":"b2kSetFriction tCrate, 0.1"
			}],
			"description":"A control with no Kit shape is ignored.",
			"references":{
				"handler":["b2kSetBounce","b2kSetDensity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-232",
			"name":"b2ksyncallbodies",
			"display name":"b2kSyncAllBodies",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSyncAllBodies"
			],
			"display syntax":[
				"b2kSyncAllBodies"
			],
			"associations":["box2dxt-kit"],
			"summary":"Draw every awake, non-static Kit body.",
			"examples":[{
				"script":"b2kSyncAllBodies"
			}],
			"description":"Internal handler: the caller holds the screen lock. <b2kSync> wraps it in one.",
			"references":{
				"handler":["b2kSync","b2kSyncBodies"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-233",
			"name":"b2kdrawpoly",
			"display name":"b2kDrawPoly",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDrawPoly <pRef>,<pWx>,<pWy>,<pWa>"
			],
			"display syntax":[
				"b2kDrawPoly <i>pRef</i>,<i>pWx</i>,<i>pWy</i>,<i>pWa</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Redraw a polygon graphic at a body pose.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			},{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The body's x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The body's y, in metres."
			},{
				"name":"pWa",
				"type":"",
				"refparam":"false",
				"description":"The body's angle, in radians."
			}],
			"examples":[{
				"script":"b2kDrawPoly tRef, 2, 3, 0.5"
			}],
			"description":"Internal handler: re-points the graphic from its stored outline.",
			"references":{
				"handler":["b2kDrawBody","b2kCorner"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-234",
			"name":"b2kendcontactcount",
			"display name":"b2kEndContactCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kEndContactCount()"
			],
			"display syntax":[
				"b2kEndContactCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many pairs of bodies stopped touching this frame.",
			"examples":[{
				"script":"put b2kEndContactCount() into tPartings"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, 0 when none."
			}],
			"description":"Events are collected after every fixed step of the frame, so none\nis lost on a two-step frame or repeated on a zero-step one.",
			"references":{
				"handler":["b2kEndContactA","b2kEndContactB","b2kContactCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-235",
			"name":"b2klayerbits",
			"display name":"b2kLayerBits",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kLayerBits(<pLayerList>)"
			],
			"display syntax":[
				"b2kLayerBits(<i>pLayerList</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn a list of layer names into a bitmask.",
			"parameters":[{
				"name":"pLayerList",
				"type":"",
				"refparam":"false",
				"description":"A comma or space separated list of layer names or raw numbers."
			}],
			"examples":[{
				"script":"put b2kLayerBits(\"player,enemies\") into tMask"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The combined bit value."
			}],
			"description":"Unknown names are defined on the way (<b2kDefineLayer>); \"oneway\" is bit 2^31.",
			"references":{
				"handler":["b2kDefineLayer"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-236",
			"name":"b2kwake",
			"display name":"b2kWake",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWake <pControl>"
			],
			"display syntax":[
				"b2kWake <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Wake a sleeping body.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kWake tCrate"
			}],
			"description":"A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSleep","b2kIsAwake"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-237",
			"name":"b2kspritestick",
			"display name":"b2kSpritesTick",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpritesTick"
			],
			"display syntax":[
				"b2kSpritesTick"
			],
			"associations":["box2dxt-kit"],
			"summary":"Run one frame of sprite service.",
			"examples":[{
				"script":"b2kSpritesTick"
			}],
			"description":"Internal handler: the loop calls it each frame. Bound sprites follow their\ncontrol and playing animations advance on wall-clock time; sprites whose\ncontrol vanished are forgotten. Only bound or playing sprites are visited.",
			"references":{
				"handler":["b2kSpriteBind","b2kSpritePlay"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-238",
			"name":"b2kworld",
			"display name":"b2kWorld",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kWorld()"
			],
			"display syntax":[
				"b2kWorld()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The raw Box2D world handle.",
			"examples":[{
				"script":"put b2kWorld() into tWorld"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The world handle, or empty before setup."
			}],
			"description":"Use it to mix Kit code with calls to the raw b2 layer.",
			"references":{
				"handler":["b2kBodyOf"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-239",
			"name":"b2ksliderlimit",
			"display name":"b2kSliderLimit",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSliderLimit <pJoint>,<pLowerPx>,<pUpperPx>"
			],
			"display syntax":[
				"b2kSliderLimit <i>pJoint</i>,<i>pLowerPx</i>,<i>pUpperPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Limit a slider joint's travel.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pLowerPx",
				"type":"",
				"refparam":"false",
				"description":"The lowest translation in pixels."
			},{
				"name":"pUpperPx",
				"type":"",
				"refparam":"false",
				"description":"The highest translation in pixels."
			}],
			"examples":[{
				"script":"b2kSliderLimit tTrack, -200, 0"
			}],
			"description":"Translation is measured along the joint's axis from where the joint was made.",
			"references":{
				"handler":["b2kSliderLimitOff","b2kSliderPos"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-240",
			"name":"b2kcamstatus",
			"display name":"b2kCamStatus",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamStatus()"
			],
			"display syntax":[
				"b2kCamStatus()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Why the camera is not working, if it is not.",
			"examples":[{
				"script":"if b2kCamStatus() is not empty then answer b2kCamStatus()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Empty when healthy (or off), otherwise the reason."
			}],
			"description":"Why the camera is not working, if it is not.",
			"references":{
				"handler":["b2kCamOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-241",
			"name":"b2khingelimit",
			"display name":"b2kHingeLimit",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kHingeLimit <pJoint>,<pLowerDeg>,<pUpperDeg>"
			],
			"display syntax":[
				"b2kHingeLimit <i>pJoint</i>,<i>pLowerDeg</i>,<i>pUpperDeg</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Limit a hinge joint's angle.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pLowerDeg",
				"type":"",
				"refparam":"false",
				"description":"The lowest angle in degrees."
			},{
				"name":"pUpperDeg",
				"type":"",
				"refparam":"false",
				"description":"The highest angle in degrees."
			}],
			"examples":[{
				"script":"b2kHingeLimit tHinge, -45, 45"
			}],
			"description":"Angles are measured from the pose the bodies had when the hinge was made.",
			"references":{
				"handler":["b2kHingeLimitOff","b2kHingeAngle"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-242",
			"name":"b2kmass",
			"display name":"b2kMass",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kMass(<pControl>)"
			],
			"display syntax":[
				"b2kMass(<i>pControl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"A body's mass.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"put b2kMass(tCrate) into tMass"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The mass in Box2D units (kilograms), or 0 when the control has no body."
			}],
			"description":"A body's mass.",
			"references":{
				"handler":["b2kSetDensity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-243",
			"name":"b2ksheetensureflip",
			"display name":"b2kSheetEnsureFlip",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetEnsureFlip <pSheet>,<pKey>"
			],
			"display syntax":[
				"b2kSheetEnsureFlip <i>pSheet</i>,<i>pKey</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a frame's mirrored image now instead of on first display.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"b2kSheetEnsureFlip \"chars\", \"character_beige_walk_a\""
			}],
			"description":"It slices the frame first if needed. If this engine's flip fails, the unmirrored frame is used.",
			"references":{
				"handler":["b2kSheetEnsureIcon","b2kSpriteFlipH"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-244",
			"name":"b2kactionpressed",
			"display name":"b2kActionPressed",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kActionPressed(<pName>)"
			],
			"display syntax":[
				"b2kActionPressed(<i>pName</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether an action started this frame.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The action's name."
			}],
			"examples":[{
				"script":"if b2kActionPressed(\"jump\") then b2kPush tHero, 0, -420"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true on the frame the first of its keys went down."
			}],
			"description":"Report whether an action started this frame.",
			"references":{
				"handler":["b2kBindAction","b2kActionReleased"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-245",
			"name":"b2kplayershowstate",
			"display name":"b2kPlayerShowState",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerShowState <pNow>,<pVX>"
			],
			"display syntax":[
				"b2kPlayerShowState <i>pNow</i>,<i>pVX</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Play the animation and facing for the player's state.",
			"parameters":[{
				"name":"pNow",
				"type":"",
				"refparam":"false",
				"description":"The controller's clock, in milliseconds."
			},{
				"name":"pVX",
				"type":"",
				"refparam":"false",
				"description":"The player's horizontal velocity, in px/s."
			}],
			"examples":[{
				"script":"b2kPlayerShowState 0, 0"
			}],
			"description":"Internal handler: the tick calls it while the controller has control and art.",
			"references":{
				"handler":["b2kPlayerAnims","b2kPlayerTick"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-246",
			"name":"b2kle32",
			"display name":"b2kLE32",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kLE32(<pN>)"
			],
			"display syntax":[
				"b2kLE32(<i>pN</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Pack a number as four little-endian bytes.",
			"parameters":[{
				"name":"pN",
				"type":"",
				"refparam":"false",
				"description":"A whole number from 0 to 4294967295."
			}],
			"examples":[{
				"script":"put b2kLE32(22050) into tBytes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Four bytes."
			}],
			"description":"Pack a number as four little-endian bytes.",
			"references":{
				"handler":["b2kLE16","b2kWavWrap"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-247",
			"name":"b2kplayerrespawn",
			"display name":"b2kPlayerRespawn",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerRespawn <pX>,<pY>"
			],
			"display syntax":[
				"b2kPlayerRespawn <i>pX</i>,<i>pY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Teleport the player and reset it to a clean standing idle.",
			"parameters":[{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The new centre x in pixels. Not a number keeps the current x."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The new centre y in pixels. Not a number keeps the current y."
			}],
			"examples":[{
				"script":"b2kPlayerRespawn 120, 300"
			}],
			"description":"Velocity is zeroed; jump, hurt, dash, climb, swim, drop and duck\nstates are cleared; the air-jump budget is refilled and control is on.\nTuning and zones are kept.",
			"references":{
				"handler":["b2kPlayerHurt","b2kMoveTo"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-248",
			"name":"b2ksoundload",
			"display name":"b2kSoundLoad",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundLoad <pName>,<pPath>"
			],
			"display syntax":[
				"b2kSoundLoad <i>pName</i>,<i>pPath</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Import a sound file under a name.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			},{
				"name":"pPath",
				"type":"",
				"refparam":"false",
				"description":"A WAV, AIFF or AU file's path."
			}],
			"examples":[{
				"script":"b2kSoundLoad \"boom\", tFolder & \"/boom.wav\""
			}],
			"description":"The file becomes an audioClip in the stack, replacing a sound of the\nsame name. A missing file or failed import is reported by <b2kSoundStatus>,\nnot thrown.",
			"references":{
				"handler":["b2kSound","b2kToneMake","b2kSoundStatus"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-249",
			"name":"b2kkeyinset",
			"display name":"b2kKeyInSet",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyInSet(<pSet>,<pKey>)"
			],
			"display syntax":[
				"b2kKeyInSet(<i>pSet</i>,<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether a key is in a comma-wrapped keycode set.",
			"parameters":[{
				"name":"pSet",
				"type":"",
				"refparam":"false",
				"description":"A set of keycodes wrapped in commas, such as \",65361,32,\"."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A key name (left, right, up, down, space, return, escape, tab, shift, control, alt, backspace, delete), a single character, or a raw keycode."
			}],
			"examples":[{
				"script":"put b2kKeyInSet(\",32,\", \"space\") into tHeld"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when any of the key's codes is in the set; false for an empty set."
			}],
			"description":"A helper behind <b2kKeyIsDown>, <b2kKeyPressed> and <b2kKeyReleased>.",
			"references":{
				"handler":["b2kCodesInSet","b2kKeyIsDown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-250",
			"name":"b2ksetorigin",
			"display name":"b2kSetOrigin",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetOrigin <pScreenX>,<pScreenY>"
			],
			"display syntax":[
				"b2kSetOrigin <i>pScreenX</i>,<i>pScreenY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the screen point that maps to the world origin.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"Screen x in pixels. Empty or not a number keeps the current value."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"Screen y in pixels. Empty or not a number keeps the current value."
			}],
			"examples":[{
				"script":"b2kSetOrigin 0, 0"
			}],
			"description":"<b2kSetup> puts the origin at the card's bottom centre. Change it\nbefore adding bodies, because conversions made earlier are not redone.",
			"references":{
				"handler":["b2kSetScale","b2kToWorldX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-251",
			"name":"b2ksetcontacttuning",
			"display name":"b2kSetContactTuning",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetContactTuning <pHertz>,<pDamping>,<pPushPx>"
			],
			"display syntax":[
				"b2kSetContactTuning <i>pHertz</i>,<i>pDamping</i>,<i>pPushPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Tune contact softness for the world.",
			"parameters":[{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"Contact stiffness, in hertz."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The contact damping ratio."
			},{
				"name":"pPushPx",
				"type":"",
				"refparam":"false",
				"description":"The fastest speed, in pixels per second, at which overlapping shapes are pushed apart."
			}],
			"examples":[{
				"script":"b2kSetContactTuning 30, 10, 5"
			}],
			"description":"With no world it does nothing.",
			"references":{
				"handler":["b2kSetJointTuning"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-252",
			"name":"b2keventsreset",
			"display name":"b2kEventsReset",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEventsReset"
			],
			"display syntax":[
				"b2kEventsReset"
			],
			"associations":["box2dxt-kit"],
			"summary":"Zero this frame's event counts.",
			"examples":[{
				"script":"b2kEventsReset"
			}],
			"description":"Internal handler: the loop calls it before stepping. The event readers check the counts, so old entries are never returned.",
			"references":{
				"handler":["b2kHarvestEvents"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-253",
			"name":"b2knumberor",
			"display name":"b2kNumberOr",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kNumberOr(<pValue>,<pDefault>)"
			],
			"display syntax":[
				"b2kNumberOr(<i>pValue</i>,<i>pDefault</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Return a value when it is a number, else a default.",
			"parameters":[{
				"name":"pValue",
				"type":"",
				"refparam":"false",
				"description":"The value to test."
			},{
				"name":"pDefault",
				"type":"",
				"refparam":"false",
				"description":"What to return when the value is empty or not a number."
			}],
			"examples":[{
				"script":"put b2kNumberOr(field \"Speed\", 200) into tSpeed"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The value, or the default."
			}],
			"description":"A small helper the Kit uses to make optional arguments safe.",
			"references":{
				"handler":["b2kClamp"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-254",
			"name":"b2krayhity",
			"display name":"b2kRayHitY",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHitY()"
			],
			"display syntax":[
				"b2kRayHitY()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The y of the last ray hit, in screen pixels.",
			"examples":[{
				"script":"put b2kRayHitY() into tGroundY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The rounded y, or empty when the last ray missed."
			}],
			"description":"The y of the last ray hit, in screen pixels.",
			"references":{
				"handler":["b2kRayHit","b2kRayHitX"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-255",
			"name":"b2kplayerdashstart",
			"display name":"b2kPlayerDashStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerDashStart <pBody>"
			],
			"display syntax":[
				"b2kPlayerDashStart <i>pBody</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Start a dash.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			}],
			"examples":[{
				"script":"b2kPlayerDashStart b2kBodyOf(b2kPlayer())"
			}],
			"description":"Internal handler: saves the gravity scale and sets it to 0, and starts the\ndash timer and cooldown in the facing direction. A repeated start is a no-op.",
			"references":{
				"handler":["b2kPlayerDashEnd"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-256",
			"name":"b2kendcontactb",
			"display name":"b2kEndContactB",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kEndContactB(<pIndex>)"
			],
			"display syntax":[
				"b2kEndContactB(<i>pIndex</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The second control of a pair that stopped touching this frame.",
			"parameters":[{
				"name":"pIndex",
				"type":"",
				"refparam":"false",
				"description":"The 1-based index of the event within this frame."
			}],
			"examples":[{
				"script":"put b2kEndContactB(1) into tSecond"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control's long id, or empty for a wall, the ground, an untracked body or an index out of range."
			}],
			"description":"The second control of a pair that stopped touching this frame.",
			"references":{
				"handler":["b2kEndContactCount","b2kEndContactA"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-257",
			"name":"b2kinputon",
			"display name":"b2kInputOn",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kInputOn"
			],
			"display syntax":[
				"b2kInputOn"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn on the per-frame keyboard sample.",
			"examples":[{
				"script":"b2kInputOn\nb2kFrameTarget the long id of me"
			}],
			"description":"Each frame the loop reads the keys held down and compares them with\nthe previous frame, so the key, action and axis queries work from b2kFrame.\nNo focus or key messages are needed.\n\nIt also fills empty bindings: action \"jump\" (space), action \"dash\" (shift, x),\naxis \"moveX\" (left, a / right, d) and axis \"moveY\" (up, w / down, s). Your own\nbindings are kept.",
			"references":{
				"handler":["b2kInputOff","b2kKeyIsDown","b2kBindAction","b2kAxis"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-258",
			"name":"b2ksoundstop",
			"display name":"b2kSoundStop",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundStop"
			],
			"display syntax":[
				"b2kSoundStop"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop the current sound.",
			"examples":[{
				"script":"b2kSoundStop"
			}],
			"description":"Stop the current sound.",
			"references":{
				"handler":["b2kSoundLoop"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-259",
			"name":"b2kexplode",
			"display name":"b2kExplode",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kExplode <pScreenX>,<pScreenY>,<pRadiusPx>,<pPowerPx>"
			],
			"display syntax":[
				"b2kExplode <i>pScreenX</i>,<i>pScreenY</i>,<i>pRadiusPx</i>,<i>pPowerPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Push dynamic bodies away from a point with a radial blast.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The blast centre x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The blast centre y, in pixels."
			},{
				"name":"pRadiusPx",
				"type":"",
				"refparam":"false",
				"description":"The reach in pixels. Empty means 180."
			},{
				"name":"pPowerPx",
				"type":"",
				"refparam":"false",
				"description":"The impulse per unit of facing surface, scaled by the Kit's pixels per metre. Empty means 900."
			}],
			"examples":[{
				"script":"b2kExplode the mouseH, the mouseV, 200, 1200"
			}],
			"description":"It uses Box2D's own explosion, which is shape-aware (a wide plank\ncatches more than a small ball) and affects every dynamic body in range, not\nonly Kit bodies. With no world it does nothing.",
			"references":{
				"handler":["b2kExplodeLegacy","b2kImpulse"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-260",
			"name":"b2kaddground",
			"display name":"b2kAddGround",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kAddGround <pScreenY>"
			],
			"display syntax":[
				"b2kAddGround <i>pScreenY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add a wide, invisible static floor across the card.",
			"parameters":[{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The floor's screen y in pixels. Empty means 40 px above the card's bottom edge."
			}],
			"examples":[{
				"script":"b2kAddGround 420"
			}],
			"description":"The floor is a long static segment (1000 m wide), not tracked as a\nbody, so <b2kClear> keeps it. With no world it does nothing.",
			"references":{
				"handler":["b2kAddWalls","b2kWall"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-261",
			"name":"b2ksetdynamic",
			"display name":"b2kSetDynamic",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetDynamic <pControl>"
			],
			"display syntax":[
				"b2kSetDynamic <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a body dynamic (moved by forces and collisions).",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kSetDynamic tCrate"
			}],
			"description":"The same as <b2kSetType> with \"dynamic\".",
			"references":{
				"handler":["b2kSetType","b2kSetStatic"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-262",
			"name":"b2kremovejoint",
			"display name":"b2kRemoveJoint",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kRemoveJoint <pJoint>"
			],
			"display syntax":[
				"b2kRemoveJoint <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Destroy a joint.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kRemoveJoint tRope"
			}],
			"description":"Works for every joint the Kit makes, including <b2kMotorTo> and <b2kNoCollide> joints. A stale handle is harmless.",
			"references":{
				"handler":["b2kHinge","b2kRope","b2kNoCollide"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-263",
			"name":"b2kframetarget",
			"display name":"b2kFrameTarget",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kFrameTarget <pObject>"
			],
			"display syntax":[
				"b2kFrameTarget <i>pObject</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the object that receives a b2kFrame message every frame.",
			"parameters":[{
				"name":"pObject",
				"type":"",
				"refparam":"false",
				"description":"A reference to the object, such as the long id of the card. Empty turns the message off."
			}],
			"examples":[{
				"script":"b2kFrameTarget the long id of me"
			}],
			"description":"The Kit sends b2kFrame once per simulated frame, after bodies,\ninput, the player, sprites and the camera have updated. Put per-frame game\nlogic there. The same object receives b2kFell (<b2kKillFloor>) and sprite\nfinish messages (<b2kSpriteOnFinish>).\n\nAn error inside b2kFrame is caught silently so the screen never stays\nlocked; the rest of that frame's work is skipped.",
			"references":{
				"handler":["b2kContactTarget","b2kFrameMS","b2kKillFloor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-264",
			"name":"b2kspin",
			"display name":"b2kSpin",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpin <pControl>,<pDegPerSec>"
			],
			"display syntax":[
				"b2kSpin <i>pControl</i>,<i>pDegPerSec</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set a body's angular velocity in degrees per second.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pDegPerSec",
				"type":"",
				"refparam":"false",
				"description":"The spin rate in degrees per second."
			}],
			"examples":[{
				"script":"b2kSpin tWheel, 360"
			}],
			"description":"It replaces the current spin. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSpinBy","b2kSpinRate"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-265",
			"name":"b2kcamgroup",
			"display name":"b2kCamGroup",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCamGroup()"
			],
			"display syntax":[
				"b2kCamGroup()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The camera's viewport group.",
			"examples":[{
				"script":"create graphic \"Sign\" in b2kCamGroup()"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The group's long id, or empty when the camera is off."
			}],
			"description":"Create your own level controls inside it so they scroll.",
			"references":{
				"handler":["b2kCamAdopt","b2kCamOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-266",
			"name":"b2kplayerremove",
			"display name":"b2kPlayerRemove",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerRemove"
			],
			"display syntax":[
				"b2kPlayerRemove"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove the player controller.",
			"examples":[{
				"script":"b2kPlayerRemove\nb2kRemove tHero"
			}],
			"description":"The controller's state and tuning go. The body and sprite stay;\nremove them with <b2kRemove> and <b2kSpriteRemove>.",
			"references":{
				"handler":["b2kPlayerAttach","b2kPlayerForget"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-267",
			"name":"b2ksoundloop",
			"display name":"b2kSoundLoop",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundLoop <pName>"
			],
			"display syntax":[
				"b2kSoundLoop <i>pName</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Loop a named sound until stopped.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sound's name."
			}],
			"examples":[{
				"script":"b2kSoundLoop \"wind\""
			}],
			"description":"It plays until <b2kSoundStop> or the next sound.",
			"references":{
				"handler":["b2kSoundStop","b2kSound"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-268",
			"name":"b2kprunedeadrefs",
			"display name":"b2kPruneDeadRefs",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPruneDeadRefs <pDead>"
			],
			"display syntax":[
				"b2kPruneDeadRefs <i>pDead</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Forget controls that no longer exist.",
			"parameters":[{
				"name":"pDead",
				"type":"",
				"refparam":"false",
				"description":"Control references, one per line."
			}],
			"examples":[{
				"script":"b2kPruneDeadRefs tGone"
			}],
			"description":"Internal handler: destroys each one's body and drops every record of it, as <b2kRemove> would.",
			"references":{
				"handler":["b2kRemove"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-269",
			"name":"b2ksheetaddframe",
			"display name":"b2kSheetAddFrame",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetAddFrame <pSheet>,<pFrame>,<pX>,<pY>,<pW>,<pH>"
			],
			"display syntax":[
				"b2kSheetAddFrame <i>pSheet</i>,<i>pFrame</i>,<i>pX</i>,<i>pY</i>,<i>pW</i>,<i>pH</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Name one rectangular region of a loaded sheet as a frame.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pFrame",
				"type":"",
				"refparam":"false",
				"description":"The frame's name."
			},{
				"name":"pX",
				"type":"",
				"refparam":"false",
				"description":"The region's left, in source pixels."
			},{
				"name":"pY",
				"type":"",
				"refparam":"false",
				"description":"The region's top, in source pixels."
			},{
				"name":"pW",
				"type":"",
				"refparam":"false",
				"description":"The region's width in pixels, at least 1."
			},{
				"name":"pH",
				"type":"",
				"refparam":"false",
				"description":"The region's height in pixels, at least 1."
			}],
			"examples":[{
				"script":"b2kSheetAddFrame \"items\", \"key\", 0, 64, 32, 32"
			}],
			"description":"The path for packed sheets that have no XML: load the source with a\nframe size of 0, then add each frame. It also works on top of a grid or an\natlas. Redefining a name drops its old slices. Bad arguments, or a sheet\nthat is not loaded, are ignored.",
			"references":{
				"handler":["b2kSheetLoad","b2kSheetFrameNames"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-270",
			"name":"b2ksoundmute",
			"display name":"b2kSoundMute",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundMute <pFlag>"
			],
			"display syntax":[
				"b2kSoundMute <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Mute or unmute the Kit's sounds.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to mute; anything else unmutes."
			}],
			"examples":[{
				"script":"b2kSoundMute true"
			}],
			"description":"Muting also stops the current sound. The setting survives <b2kTeardown> but not a reopened stack; save it yourself if needed.",
			"references":{
				"handler":["b2kSoundMuted"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-271",
			"name":"b2kresume",
			"display name":"b2kResume",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kResume"
			],
			"display syntax":[
				"b2kResume"
			],
			"associations":["box2dxt-kit"],
			"summary":"Resume stepping after a pause.",
			"examples":[{
				"script":"b2kResume"
			}],
			"description":"The elapsed-time clock restarts from now, so the pause is not\nreplayed as one long catch-up step.",
			"references":{
				"handler":["b2kPause"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-272",
			"name":"b2krayhitnormalx",
			"display name":"b2kRayHitNormalX",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kRayHitNormalX()"
			],
			"display syntax":[
				"b2kRayHitNormalX()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The x part of the surface normal at the last ray hit.",
			"examples":[{
				"script":"put b2kRayHitNormalX() into tNX"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A unit-vector component, screen oriented, or empty when the last ray missed."
			}],
			"description":"The x part of the surface normal at the last ray hit.",
			"references":{
				"handler":["b2kRayHit","b2kRayHitNormalY"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-273",
			"name":"b2ksheetensureicon",
			"display name":"b2kSheetEnsureIcon",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetEnsureIcon <pSheet>,<pKey>"
			],
			"display syntax":[
				"b2kSheetEnsureIcon <i>pSheet</i>,<i>pKey</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Slice a frame's image now instead of on first display.",
			"parameters":[{
				"name":"pSheet",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The frame's name or number."
			}],
			"examples":[{
				"script":"b2kSheetEnsureIcon \"chars\", \"character_beige_hit\""
			}],
			"description":"Frames are sliced lazily, and a slice made mid-game costs a visible\nhitch. Pre-warm frames that first appear during play. The result is cached,\nso a second call is free.",
			"references":{
				"handler":["b2kSheetEnsureFlip","b2kSheetScale"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-274",
			"name":"b2ksetsleepthreshold",
			"display name":"b2kSetSleepThreshold",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetSleepThreshold <pControl>,<pPxPerSec>"
			],
			"display syntax":[
				"b2kSetSleepThreshold <i>pControl</i>,<i>pPxPerSec</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the speed below which a body may fall asleep.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pPxPerSec",
				"type":"",
				"refparam":"false",
				"description":"The speed in pixels per second. Lower keeps the body awake longer."
			}],
			"examples":[{
				"script":"b2kSetSleepThreshold tCrate, 4"
			}],
			"description":"A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kSetSleepEnabled"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-275",
			"name":"b2kplayerdefault",
			"display name":"b2kPlayerDefault",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerDefault(<pKey>)"
			],
			"display syntax":[
				"b2kPlayerDefault(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The shipped default of a player tuning knob.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"The knob's name in lower case, such as \"jumpspeed\"."
			}],
			"examples":[{
				"script":"put b2kPlayerDefault(\"jumpspeed\") into tStock"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The default value, or empty for a knob the controller does not know."
			}],
			"description":"The defaults suit a 32 by 48 px player at scale 40: moveSpeed 220,\njumpSpeed 460, maxFall 900, and so on. The opt-in actions default to off.\n<b2kPlayerGet> lower-cases its key for you; this does not.",
			"references":{
				"handler":["b2kPlayerGet","b2kPlayerSet"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-276",
			"name":"b2kspritefliph",
			"display name":"b2kSpriteFlipH",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteFlipH <pCtrl>,<pFlag>"
			],
			"display syntax":[
				"b2kSpriteFlipH <i>pCtrl</i>,<i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a sprite face left or right.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to mirror the frames (face left), false for the art as drawn."
			}],
			"examples":[{
				"script":"b2kSpriteFlipH tSpr, true"
			}],
			"description":"Mirrored frames are made the first time they are needed and shared by every sprite of the sheet.",
			"references":{
				"handler":["b2kSpriteFlipped","b2kSheetEnsureFlip"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-277",
			"name":"b2kspritebind",
			"display name":"b2kSpriteBind",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpriteBind <pCtrl>,<pBodyCtrl>,<pDX>,<pDY>"
			],
			"display syntax":[
				"b2kSpriteBind <i>pCtrl</i>,<i>pBodyCtrl</i>,<i>pDX</i>,<i>pDY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Pin a sprite to another control's position every frame.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pBodyCtrl",
				"type":"",
				"refparam":"false",
				"description":"The control to follow, by reference. Empty makes this a no-op."
			},{
				"name":"pDX",
				"type":"",
				"refparam":"false",
				"description":"Optional x offset in pixels. Empty means 0."
			},{
				"name":"pDY",
				"type":"",
				"refparam":"false",
				"description":"Optional y offset in pixels. Empty means 0."
			}],
			"examples":[{
				"script":"b2kSpriteBind tArt, tHitbox, 0, -6"
			}],
			"description":"The usual pattern for art bigger than its collision shape: an\ninvisible control owns the body and the sprite follows it.",
			"references":{
				"handler":["b2kSpriteUnbind","b2kSpriteNew"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-278",
			"name":"b2kslidermotor",
			"display name":"b2kSliderMotor",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSliderMotor <pJoint>,<pPxPerSec>,<pMaxForce>"
			],
			"display syntax":[
				"b2kSliderMotor <i>pJoint</i>,<i>pPxPerSec</i>,<i>pMaxForce</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drive a slider joint at a set speed.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pPxPerSec",
				"type":"",
				"refparam":"false",
				"description":"The target speed in pixels per second along the axis."
			},{
				"name":"pMaxForce",
				"type":"",
				"refparam":"false",
				"description":"The most force the motor may use. Empty means 1000."
			}],
			"examples":[{
				"script":"b2kSliderMotor tTrack, 80"
			}],
			"description":"Drive a slider joint at a set speed.",
			"references":{
				"handler":["b2kSliderMotorOff","b2kSlider"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-279",
			"name":"b2kspriteanim",
			"display name":"b2kSpriteAnim",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSpriteAnim(<pCtrl>)"
			],
			"display syntax":[
				"b2kSpriteAnim(<i>pCtrl</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The animation a sprite is playing.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference."
			}],
			"examples":[{
				"script":"if b2kSpriteAnim(tSpr) is empty then b2kSpritePlay tSpr, \"idle\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The animation's name, or empty when stopped or the control is gone."
			}],
			"description":"The animation a sprite is playing.",
			"references":{
				"handler":["b2kSpritePlay"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-280",
			"name":"b2ksensorcount",
			"display name":"b2kSensorCount",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSensorCount()"
			],
			"display syntax":[
				"b2kSensorCount()"
			],
			"associations":["box2dxt-kit"],
			"summary":"How many sensor entries happened this frame.",
			"examples":[{
				"script":"if b2kSensorCount() > 0 then put b2kSensorEnterVisitor(1) into tWho"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The count, 0 when none."
			}],
			"description":"The polling alternative to the b2kSensorEnter message; read it from\nb2kFrame. Events are collected after every fixed step of the frame.",
			"references":{
				"handler":["b2kSensorEnterSensor","b2kSensorEnterVisitor","b2kSensorExitCount"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-281",
			"name":"b2kplayerhalfh",
			"display name":"b2kPlayerHalfH",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerHalfH()"
			],
			"display syntax":[
				"b2kPlayerHalfH()"
			],
			"associations":["box2dxt-kit"],
			"summary":"The player capsule's current half-height.",
			"examples":[{
				"script":"put item 2 of b2kPosition(b2kPlayer()) - b2kPlayerHalfH() into tHeadY"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Pixels, or 0 when there is no player."
			}],
			"description":"It shrinks during a reshaped crawl, so read it live rather than using a constant.",
			"references":{
				"handler":["b2kPlayerHalfW"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-282",
			"name":"b2kweldspring",
			"display name":"b2kWeldSpring",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kWeldSpring <pJoint>,<pHertz>,<pDamping>"
			],
			"display syntax":[
				"b2kWeldSpring <i>pJoint</i>,<i>pHertz</i>,<i>pDamping</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a weld joint springy.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			},{
				"name":"pHertz",
				"type":"",
				"refparam":"false",
				"description":"The stiffness in hertz for both the linear and angular parts; 0 makes the weld rigid again."
			},{
				"name":"pDamping",
				"type":"",
				"refparam":"false",
				"description":"The damping ratio. Empty means 0.5."
			}],
			"examples":[{
				"script":"b2kWeldSpring tGlue, 5"
			}],
			"description":"Make a weld joint springy.",
			"references":{
				"handler":["b2kWeld","b2kSpring"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-283",
			"name":"b2koverlap",
			"display name":"b2kOverlap",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kOverlap(<pX1>,<pY1>,<pX2>,<pY2>)"
			],
			"display syntax":[
				"b2kOverlap(<i>pX1</i>,<i>pY1</i>,<i>pX2</i>,<i>pY2</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The Kit controls whose bodies overlap a screen rectangle.",
			"parameters":[{
				"name":"pX1",
				"type":"",
				"refparam":"false",
				"description":"One corner's x, in pixels."
			},{
				"name":"pY1",
				"type":"",
				"refparam":"false",
				"description":"One corner's y, in pixels."
			},{
				"name":"pX2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's x, in pixels."
			},{
				"name":"pY2",
				"type":"",
				"refparam":"false",
				"description":"The other corner's y, in pixels."
			}],
			"examples":[{
				"script":"put b2kOverlap(100, 100, 200, 200) into tInside"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The controls' long ids, one per line, or empty."
			}],
			"description":"It asks Box2D's broadphase, whose boxes are slightly enlarged\n(about 0.1 m, a few pixels), so a rectangle touching the floor reports the\nfloor. Use <b2kOverlapMoving> for presence checks.",
			"references":{
				"handler":["b2kOverlapMoving","b2kOverlapCircle"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-284",
			"name":"b2kmotorto",
			"display name":"b2kMotorTo",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kMotorTo <pMover>,<pRef>,<pOffsetXPx>,<pOffsetYPx>,<pAngleDeg>,<pMaxForce>,<pMaxTorque>"
			],
			"display syntax":[
				"b2kMotorTo <i>pMover</i>,<i>pRef</i>,<i>pOffsetXPx</i>,<i>pOffsetYPx</i>,<i>pAngleDeg</i>,<i>pMaxForce</i>,<i>pMaxTorque</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Drive a control toward a pose offset from another control or the world.",
			"parameters":[{
				"name":"pMover",
				"type":"",
				"refparam":"false",
				"description":"The control to drive, by reference."
			},{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control the offset is measured from, or empty for the world."
			},{
				"name":"pOffsetXPx",
				"type":"",
				"refparam":"false",
				"description":"The target x offset, in pixels."
			},{
				"name":"pOffsetYPx",
				"type":"",
				"refparam":"false",
				"description":"The target y offset, in pixels (positive is down)."
			},{
				"name":"pAngleDeg",
				"type":"",
				"refparam":"false",
				"description":"The target angle offset in degrees. Empty means 0."
			},{
				"name":"pMaxForce",
				"type":"",
				"refparam":"false",
				"description":"The most force the joint may use. Empty means 1000."
			},{
				"name":"pMaxTorque",
				"type":"",
				"refparam":"false",
				"description":"The most torque the joint may use. Empty means 1000."
			}],
			"examples":[{
				"script":"b2kMotorTo tPet, tHero, -40, 0, 0\nput the result into tLeash"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The joint handle through the result, or 0 when a control has no body or there is no world."
			}],
			"description":"A motor joint, good for followers and lifts. Remove it with <b2kRemoveJoint>.",
			"references":{
				"handler":["b2kRemoveJoint","b2kSlider"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-285",
			"name":"b2ksheetscale",
			"display name":"b2kSheetScale",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSheetScale <pName>,<pScale>"
			],
			"display syntax":[
				"b2kSheetScale <i>pName</i>,<i>pScale</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the display scale of a sheet's frames.",
			"parameters":[{
				"name":"pName",
				"type":"",
				"refparam":"false",
				"description":"The sheet's name."
			},{
				"name":"pScale",
				"type":"",
				"refparam":"false",
				"description":"The scale factor, clamped to 0.05-8. The default is 1."
			}],
			"examples":[{
				"script":"b2kSheetLoad \"tiles\", tPath, 70, 70\nb2kSheetScale \"tiles\", 0.9"
			}],
			"description":"Set it right after loading, before making sprites: frames already\nsliced are dropped and re-sliced at the new scale, but existing sprite\nbuttons keep their size.",
			"references":{
				"handler":["b2kSheetFrameSize","b2kSheetLoad"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-286",
			"name":"b2kcamunfollow",
			"display name":"b2kCamUnfollow",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamUnfollow"
			],
			"display syntax":[
				"b2kCamUnfollow"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop the camera following.",
			"examples":[{
				"script":"b2kCamUnfollow"
			}],
			"description":"Stop the camera following.",
			"references":{
				"handler":["b2kCamFollow","b2kCamGoto"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-287",
			"name":"b2kcontrolat",
			"display name":"b2kControlAt",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kControlAt(<pScreenX>,<pScreenY>)"
			],
			"display syntax":[
				"b2kControlAt(<i>pScreenX</i>,<i>pScreenY</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The Kit control whose body covers a screen point.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The point's x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The point's y, in pixels."
			}],
			"examples":[{
				"script":"put b2kControlAt(the mouseH, the mouseV) into tPicked"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The control's long id, or empty when no Kit body is there."
			}],
			"description":"With the camera on, pass world pixels from <b2kCamMouseX> and <b2kCamMouseY>.",
			"references":{
				"handler":["b2kControlContains","b2kGrab"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-288",
			"name":"b2kspawncapsule",
			"display name":"b2kSpawnCapsule",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpawnCapsule <pScreenX>,<pScreenY>,<pLength>,<pThickness>,<pColor>"
			],
			"display syntax":[
				"b2kSpawnCapsule <i>pScreenX</i>,<i>pScreenY</i>,<i>pLength</i>,<i>pThickness</i>,<i>pColor</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Create a pill-shaped graphic with a dynamic capsule body.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"Centre x in pixels. Not a number means the world origin's x."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"Centre y in pixels. Not a number means the world origin's y."
			},{
				"name":"pLength",
				"type":"",
				"refparam":"false",
				"description":"Length along the pill's axis in pixels. Empty means 80."
			},{
				"name":"pThickness",
				"type":"",
				"refparam":"false",
				"description":"Thickness across the pill in pixels. Empty means 40."
			},{
				"name":"pColor",
				"type":"",
				"refparam":"false",
				"description":"Optional fill colour. An unknown name is ignored."
			}],
			"examples":[{
				"script":"b2kSpawnCapsule 200, 100, 64, 30, \"gold\"\nput the result into tHero"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The new control's long id through the result, or empty when there is no world."
			}],
			"description":"The pill is horizontal when the length is at least the thickness,\nvertical otherwise. The Kit owns the control.",
			"references":{
				"handler":["b2kSpawnBox","b2kAddCapsule"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-289",
			"name":"b2kteardown",
			"display name":"b2kTeardown",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kTeardown"
			],
			"display syntax":[
				"b2kTeardown"
			],
			"associations":["box2dxt-kit"],
			"summary":"Stop the loop and destroy the world and all Kit state.",
			"examples":[{
				"script":"b2kTeardown"
			}],
			"description":"Use <b2kTeardown> when a scene is finished. It stops the loop,\ndestroys the Box2D world, forgets the player controller (tuning included),\nremoves sprites, dissolves the camera viewport and empties the Kit's tables.\n\nSheets are wiped too unless <b2kSheetPersist> is on, in which case only the\nsprite instances go and the sheet cache survives. Sounds always survive; use\n<b2kSoundsWipe> to remove them.",
			"references":{
				"handler":["b2kSetup","b2kClear","b2kStop"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-290",
			"name":"b2kenable",
			"display name":"b2kEnable",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEnable <pControl>"
			],
			"display syntax":[
				"b2kEnable <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Put a disabled body back into the simulation.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kEnable tDoor"
			}],
			"description":"A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kDisable","b2kIsEnabled"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-291",
			"name":"b2ksetbounce",
			"display name":"b2kSetBounce",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetBounce <pControl>,<pRestitution>"
			],
			"display syntax":[
				"b2kSetBounce <i>pControl</i>,<i>pRestitution</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set how bouncy a control's shape is (restitution).",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pRestitution",
				"type":"",
				"refparam":"false",
				"description":"0 for no bounce up to 1 for a full bounce; clamped to 0-2."
			}],
			"examples":[{
				"script":"b2kSetBounce tBall, 0.8"
			}],
			"description":"A control with no Kit shape is ignored.",
			"references":{
				"handler":["b2kSetFriction","b2kSetDensity","b2kSetRestitutionThreshold"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-292",
			"name":"b2kedge",
			"display name":"b2kEdge",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEdge <pWx1>,<pWy1>,<pWx2>,<pWy2>"
			],
			"display syntax":[
				"b2kEdge <i>pWx1</i>,<i>pWy1</i>,<i>pWx2</i>,<i>pWy2</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Add a static segment between two points given in world metres.",
			"parameters":[{
				"name":"pWx1",
				"type":"",
				"refparam":"false",
				"description":"X of the first point, in metres."
			},{
				"name":"pWy1",
				"type":"",
				"refparam":"false",
				"description":"Y of the first point, in metres (y up)."
			},{
				"name":"pWx2",
				"type":"",
				"refparam":"false",
				"description":"X of the second point, in metres."
			},{
				"name":"pWy2",
				"type":"",
				"refparam":"false",
				"description":"Y of the second point, in metres (y up)."
			}],
			"examples":[{
				"script":"b2kEdge b2kToWorldX(0), b2kToWorldY(400), b2kToWorldX(300), b2kToWorldY(400)"
			}],
			"description":"Internal handler: <b2kWall> and <b2kAddWalls> build their segments with it.\nWith no world it is a quiet no-op. Most scripts want <b2kWall>, which takes\nscreen pixels.",
			"references":{
				"handler":["b2kWall"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-293",
			"name":"b2kkeycodes",
			"display name":"b2kKeyCodes",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeyCodes(<pKey>)"
			],
			"display syntax":[
				"b2kKeyCodes(<i>pKey</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"The keycodes a key name matches.",
			"parameters":[{
				"name":"pKey",
				"type":"",
				"refparam":"false",
				"description":"A key name (left, right, up, down, space, return, escape, tab, shift, control, alt, backspace, delete), a single character, or a raw keycode."
			}],
			"examples":[{
				"script":"put b2kKeyCodes(\"w\") into tCodes"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"A comma list of keycodes. A letter gives both cases; a number of 32 or more is returned as is; an unknown name gives 0."
			}],
			"description":"The keycodes a key name matches.",
			"references":{
				"handler":["b2kKeyName","b2kKeyListCodes"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-294",
			"name":"b2kclear",
			"display name":"b2kClear",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kClear"
			],
			"display syntax":[
				"b2kClear"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove every moving body and every sprite, keeping the world.",
			"examples":[{
				"script":"b2kClear\nb2kSpawnBox 200, 80, 60, 40\nput the result into tBox"
			}],
			"description":"Use <b2kClear> to reset a scene without rebuilding the world. Every\nnon-static Kit body is removed with <b2kRemove> (controls the Kit spawned are\ndeleted, attached controls are only detached), sprites are removed, and the\nplayer controller's state and ladder and water zones are dropped. Player\ntuning, input bindings, loaded sheets, sounds, static bodies, walls and chains\nstay.",
			"references":{
				"handler":["b2kRemove","b2kTeardown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-295",
			"name":"b2kisrunning",
			"display name":"b2kIsRunning",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kIsRunning()"
			],
			"display syntax":[
				"b2kIsRunning()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether the loop is running and not paused.",
			"examples":[{
				"script":"if b2kIsRunning() then b2kPause"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true while the loop is stepping; false when stopped or paused."
			}],
			"description":"Report whether the loop is running and not paused.",
			"references":{
				"handler":["b2kStart","b2kPause"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-296",
			"name":"b2ksyncbodies",
			"display name":"b2kSyncBodies",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSyncBodies"
			],
			"display syntax":[
				"b2kSyncBodies"
			],
			"associations":["box2dxt-kit"],
			"summary":"Draw the bodies that moved in the last step.",
			"examples":[{
				"script":"b2kSyncBodies"
			}],
			"description":"Internal handler: the loop calls it under its screen lock. It reads\nBox2D's move events, applies the kill floor, and forgets controls that\nvanished.",
			"references":{
				"handler":["b2kSyncAllBodies","b2kKillFloor"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-297",
			"name":"b2kxmlattr",
			"display name":"b2kXmlAttr",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kXmlAttr(<pLine>,<pAttr>)"
			],
			"display syntax":[
				"b2kXmlAttr(<i>pLine</i>,<i>pAttr</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Read one attribute value from an XML tag line.",
			"parameters":[{
				"name":"pLine",
				"type":"",
				"refparam":"false",
				"description":"A line holding one XML tag."
			},{
				"name":"pAttr",
				"type":"",
				"refparam":"false",
				"description":"The attribute's name."
			}],
			"examples":[{
				"script":"put b2kXmlAttr(tLine, \"width\") into tW"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The attribute's value, or empty when it is absent."
			}],
			"description":"The atlas loader's small parser.",
			"references":{
				"handler":["b2kSheetLoadAtlas"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-298",
			"name":"b2kspriteplay",
			"display name":"b2kSpritePlay",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSpritePlay <pCtrl>,<pAnim>,<pRestart>"
			],
			"display syntax":[
				"b2kSpritePlay <i>pCtrl</i>,<i>pAnim</i>,<i>pRestart</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Play a named animation on a sprite.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The sprite control, by reference. Empty makes this a no-op."
			},{
				"name":"pAnim",
				"type":"",
				"refparam":"false",
				"description":"The animation's name, defined with b2kAnimDef for the sprite's sheet."
			},{
				"name":"pRestart",
				"type":"",
				"refparam":"false",
				"description":"true to restart from the first frame when it is already playing."
			}],
			"examples":[{
				"script":"b2kSpritePlay tSpr, \"walk\""
			}],
			"description":"Playing the animation that is already playing does nothing, so a\nstate machine can call it every frame. An unknown animation is ignored.",
			"references":{
				"handler":["b2kAnimDef","b2kSpriteStop","b2kSpriteAnim","b2kSpriteFPS"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-299",
			"name":"b2kcamadopt",
			"display name":"b2kCamAdopt",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamAdopt <pCtrl>"
			],
			"display syntax":[
				"b2kCamAdopt <i>pCtrl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Move an existing control into the camera's viewport.",
			"parameters":[{
				"name":"pCtrl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kCamAdopt the long id of graphic \"Platform1\""
			}],
			"description":"For levels laid out in the IDE. With the camera off it does nothing.",
			"references":{
				"handler":["b2kCamGroup"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-300",
			"name":"b2ksoundstatus",
			"display name":"b2kSoundStatus",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kSoundStatus()"
			],
			"display syntax":[
				"b2kSoundStatus()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Why audio is degraded, if it is.",
			"examples":[{
				"script":"if b2kSoundStatus() is not empty then put b2kSoundStatus() into field \"Log\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"Empty when healthy, otherwise the latest reason (missing file, failed import or play)."
			}],
			"description":"Why audio is degraded, if it is.",
			"references":{
				"handler":["b2kSound"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-301",
			"name":"b2kkeysheld",
			"display name":"b2kKeysHeld",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kKeysHeld()"
			],
			"display syntax":[
				"b2kKeysHeld()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Every key held this frame, by name.",
			"examples":[{
				"script":"put b2kKeysHeld() into field \"Keys\""
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"The names separated by spaces, or empty."
			}],
			"description":"Handy for a debug display.",
			"references":{
				"handler":["b2kKeyName","b2kKeyIsDown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-302",
			"name":"b2khingelimitoff",
			"display name":"b2kHingeLimitOff",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kHingeLimitOff <pJoint>"
			],
			"display syntax":[
				"b2kHingeLimitOff <i>pJoint</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Remove a hinge joint's angle limits.",
			"parameters":[{
				"name":"pJoint",
				"type":"",
				"refparam":"false",
				"description":"The joint handle a Kit joint constructor reported. Empty or 0 makes this a no-op."
			}],
			"examples":[{
				"script":"b2kHingeLimitOff tHinge"
			}],
			"description":"Remove a hinge joint's angle limits.",
			"references":{
				"handler":["b2kHingeLimit"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-303",
			"name":"b2kplayerfacing",
			"display name":"b2kPlayerFacing",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kPlayerFacing()"
			],
			"display syntax":[
				"b2kPlayerFacing()"
			],
			"associations":["box2dxt-kit"],
			"summary":"Which way the player faces.",
			"examples":[{
				"script":"b2kSpawnBall item 1 of b2kPosition(b2kPlayer()) + 30 * b2kPlayerFacing(), 100, 12"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"1 for right, -1 for left (the last horizontal input)."
			}],
			"description":"Which way the player faces.",
			"references":{
				"handler":["b2kPlayerState"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-304",
			"name":"b2kcamshake",
			"display name":"b2kCamShake",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kCamShake <pAmpPx>,<pMs>"
			],
			"display syntax":[
				"b2kCamShake <i>pAmpPx</i>,<i>pMs</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Shake the view for a moment.",
			"parameters":[{
				"name":"pAmpPx",
				"type":"",
				"refparam":"false",
				"description":"The shake size in pixels, 0-200."
			},{
				"name":"pMs",
				"type":"",
				"refparam":"false",
				"description":"How long it lasts, in milliseconds, 0-5000."
			}],
			"examples":[{
				"script":"b2kCamShake 8, 300"
			}],
			"description":"Shake the view for a moment.",
			"references":{
				"handler":["b2kCamOn"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-305",
			"name":"b2kenablecontinuous",
			"display name":"b2kEnableContinuous",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kEnableContinuous <pFlag>"
			],
			"display syntax":[
				"b2kEnableContinuous <i>pFlag</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Turn continuous collision (CCD) on or off for the world.",
			"parameters":[{
				"name":"pFlag",
				"type":"",
				"refparam":"false",
				"description":"true to stop fast bodies tunnelling through static walls, false to turn it off."
			}],
			"examples":[{
				"script":"b2kEnableContinuous true"
			}],
			"description":"Use <b2kSetBullet> for continuous collision between moving bodies.",
			"references":{
				"handler":["b2kSetBullet"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-306",
			"name":"b2kcodesinset",
			"display name":"b2kCodesInSet",
			"library":"box2dxt-kit",
			"type":"function",
			"syntax":[
				"b2kCodesInSet(<pSet>,<pCodes>)"
			],
			"display syntax":[
				"b2kCodesInSet(<i>pSet</i>,<i>pCodes</i>)"
			],
			"associations":["box2dxt-kit"],
			"summary":"Report whether any of a list of keycodes is in a comma-wrapped set.",
			"parameters":[{
				"name":"pSet",
				"type":"",
				"refparam":"false",
				"description":"A set of keycodes wrapped in commas."
			},{
				"name":"pCodes",
				"type":"",
				"refparam":"false",
				"description":"A comma list of keycodes."
			}],
			"examples":[{
				"script":"put b2kCodesInSet(\",32,\", \"32,65362\") into tAny"
			}],
			"value":[{
				"name":"return",
				"type":"",
				"description":"true when any code is in the set; false for an empty set."
			}],
			"description":"A helper behind the action and axis queries.",
			"references":{
				"handler":["b2kKeyInSet","b2kActionIsDown"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-307",
			"name":"b2kinputinject",
			"display name":"b2kInputInject",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kInputInject <pKeys>"
			],
			"display syntax":[
				"b2kInputInject <i>pKeys</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Replace the keyboard with a scripted set of held keys.",
			"parameters":[{
				"name":"pKeys",
				"type":"",
				"refparam":"false",
				"description":"A comma list of key names or codes to hold; empty holds nothing."
			}],
			"examples":[{
				"script":"b2kInputInject \"right,space\""
			}],
			"description":"Until <b2kInputInjectOff>, each frame's sample reads this set\ninstead of the keyboard, and pressed and released edges come from the normal\nframe comparison. For tests, input replays and scripted characters.",
			"references":{
				"handler":["b2kInputInjectOff","b2kInputTick"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-308",
			"name":"b2kquickstart",
			"display name":"b2kQuickStart",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kQuickStart <pGravityY>"
			],
			"display syntax":[
				"b2kQuickStart <i>pGravityY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a world with gravity, walls around the card, and start the loop.",
			"parameters":[{
				"name":"pGravityY",
				"type":"",
				"refparam":"false",
				"description":"Vertical gravity in Box2D units, y up (negative pulls down). Empty means -10."
			}],
			"examples":[{
				"script":"b2kQuickStart\nb2kSpawnBall 200, 80, 50\nput the result into tBall"
			}],
			"description":"The one-call start: <b2kSetup> with no horizontal gravity,\n<b2kAddWalls> around the card edges, then <b2kStart>.",
			"references":{
				"handler":["b2kSetup","b2kAddWalls","b2kStart"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-309",
			"name":"b2kplayerprobe",
			"display name":"b2kPlayerProbe",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerProbe <pBody>,<pVY>"
			],
			"display syntax":[
				"b2kPlayerProbe <i>pBody</i>,<i>pVY</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Run the controller's ground probe.",
			"parameters":[{
				"name":"pBody",
				"type":"",
				"refparam":"false",
				"description":"The player's raw body handle, b2kBodyOf(b2kPlayer())."
			},{
				"name":"pVY",
				"type":"",
				"refparam":"false",
				"description":"The body's vertical velocity in px/s, screen oriented (negative is rising)."
			}],
			"examples":[{
				"script":"b2kPlayerProbe b2kBodyOf(b2kPlayer()), 0"
			}],
			"description":"Internal handler: three short rays down from the capsule decide whether\nthe player is grounded (a surface whose normal points up within\nmaxSlopeDeg). Skipped while the controller's own jump is still rising.",
			"references":{
				"handler":["b2kPlayerOnGround","b2kPlayerTick"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-310",
			"name":"b2kimpulse",
			"display name":"b2kImpulse",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kImpulse <pControl>,<pIxPx>,<pIyPx>"
			],
			"display syntax":[
				"b2kImpulse <i>pControl</i>,<i>pIxPx</i>,<i>pIyPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Apply a one-shot, mass-aware impulse to a body's centre.",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			},{
				"name":"pIxPx",
				"type":"",
				"refparam":"false",
				"description":"Horizontal impulse, scaled by the Kit's pixels per metre (positive is right)."
			},{
				"name":"pIyPx",
				"type":"",
				"refparam":"false",
				"description":"Vertical impulse, scaled the same way (positive is down)."
			}],
			"examples":[{
				"script":"b2kImpulse tCrate, 0, -50"
			}],
			"description":"Heavier bodies move less. It wakes the body. A control with no Kit body is ignored.",
			"references":{
				"handler":["b2kPush","b2kForce"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-311",
			"name":"b2kdrawimage",
			"display name":"b2kDrawImage",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDrawImage <pRef>,<pWx>,<pWy>,<pWa>"
			],
			"display syntax":[
				"b2kDrawImage <i>pRef</i>,<i>pWx</i>,<i>pWy</i>,<i>pWa</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Move and rotate an image to a body pose.",
			"parameters":[{
				"name":"pRef",
				"type":"",
				"refparam":"false",
				"description":"The control's long id."
			},{
				"name":"pWx",
				"type":"",
				"refparam":"false",
				"description":"The body's x, in metres."
			},{
				"name":"pWy",
				"type":"",
				"refparam":"false",
				"description":"The body's y, in metres."
			},{
				"name":"pWa",
				"type":"",
				"refparam":"false",
				"description":"The body's angle, in radians."
			}],
			"examples":[{
				"script":"b2kDrawImage tRef, 2, 3, 0.5"
			}],
			"description":"Internal handler: sets the image's angle in whole degrees and its location; the image keeps its design size.",
			"references":{
				"handler":["b2kDrawBody"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-312",
			"name":"b2kplayeranims",
			"display name":"b2kPlayerAnims",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kPlayerAnims <pIdle>,<pRun>,<pJump>,<pFall>,<pLand>,<pDuck>,<pClimb>,<pHurt>,<pSwim>,<pWall>,<pDash>"
			],
			"display syntax":[
				"b2kPlayerAnims <i>pIdle</i>,<i>pRun</i>,<i>pJump</i>,<i>pFall</i>,<i>pLand</i>,<i>pDuck</i>,<i>pClimb</i>,<i>pHurt</i>,<i>pSwim</i>,<i>pWall</i>,<i>pDash</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Map the controller's states to the art's animation names.",
			"parameters":[{
				"name":"pIdle",
				"type":"",
				"refparam":"false",
				"description":"Animation for standing still."
			},{
				"name":"pRun",
				"type":"",
				"refparam":"false",
				"description":"Animation for running."
			},{
				"name":"pJump",
				"type":"",
				"refparam":"false",
				"description":"Animation for rising."
			},{
				"name":"pFall",
				"type":"",
				"refparam":"false",
				"description":"Optional animation for falling. Empty uses the jump animation."
			},{
				"name":"pLand",
				"type":"",
				"refparam":"false",
				"description":"Optional one-shot touch-down animation, held for its own length."
			},{
				"name":"pDuck",
				"type":"",
				"refparam":"false",
				"description":"Optional crouch animation. Empty uses idle."
			},{
				"name":"pClimb",
				"type":"",
				"refparam":"false",
				"description":"Optional ladder animation. Empty uses jump."
			},{
				"name":"pHurt",
				"type":"",
				"refparam":"false",
				"description":"Optional knockback animation. Empty uses jump."
			},{
				"name":"pSwim",
				"type":"",
				"refparam":"false",
				"description":"Optional swim animation. Empty uses the fall animation."
			},{
				"name":"pWall",
				"type":"",
				"refparam":"false",
				"description":"Optional wall-slide animation. Empty uses the fall animation."
			},{
				"name":"pDash",
				"type":"",
				"refparam":"false",
				"description":"Optional dash animation. Empty uses run."
			}],
			"examples":[{
				"script":"b2kPlayerAnims \"idle\", \"walk\", \"jump\", \"fall\", \"land\""
			}],
			"description":"The controller then plays these on the player's art and flips it to\nface the way it moves. If your game uses <b2kSpriteOnFinish> on the player's\nart, map a looping animation to hurt: a one-shot hurt pose fires the finish\nmessage mid-knockback.",
			"references":{
				"handler":["b2kPlayerState","b2kAnimDef","b2kPlayerSprite"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-313",
			"name":"b2ksetkinematic",
			"display name":"b2kSetKinematic",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSetKinematic <pControl>"
			],
			"display syntax":[
				"b2kSetKinematic <i>pControl</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Make a body kinematic (moved only by its velocity).",
			"parameters":[{
				"name":"pControl",
				"type":"",
				"refparam":"false",
				"description":"The control, by reference (the long id of the control is safest)."
			}],
			"examples":[{
				"script":"b2kSetKinematic tLift\nb2kSetVelocity tLift, 0, -60"
			}],
			"description":"The same as <b2kSetType> with \"kinematic\".",
			"references":{
				"handler":["b2kSetType","b2kSetVelocity"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-314",
			"name":"b2kexplodelegacy",
			"display name":"b2kExplodeLegacy",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kExplodeLegacy <pScreenX>,<pScreenY>,<pRadiusPx>,<pPowerPx>"
			],
			"display syntax":[
				"b2kExplodeLegacy <i>pScreenX</i>,<i>pScreenY</i>,<i>pRadiusPx</i>,<i>pPowerPx</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"The older velocity-based blast, for Kit bodies only.",
			"parameters":[{
				"name":"pScreenX",
				"type":"",
				"refparam":"false",
				"description":"The blast centre x, in pixels."
			},{
				"name":"pScreenY",
				"type":"",
				"refparam":"false",
				"description":"The blast centre y, in pixels."
			},{
				"name":"pRadiusPx",
				"type":"",
				"refparam":"false",
				"description":"The reach in pixels. Empty means 180."
			},{
				"name":"pPowerPx",
				"type":"",
				"refparam":"false",
				"description":"The speed added at the centre, falling to 0 at the edge. Empty means 900."
			}],
			"examples":[{
				"script":"b2kExplodeLegacy 300, 200"
			}],
			"description":"It adds velocity directly to every non-static Kit body in range,\nignoring size and mass. Kept for scripts that relied on that feel; new code\nshould use <b2kExplode>.",
			"references":{
				"handler":["b2kExplode"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-315",
			"name":"b2ksoundvolume",
			"display name":"b2kSoundVolume",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kSoundVolume <pPct>"
			],
			"display syntax":[
				"b2kSoundVolume <i>pPct</i>"
			],
			"associations":["box2dxt-kit"],
			"summary":"Set the engine's global playback volume.",
			"parameters":[{
				"name":"pPct",
				"type":"",
				"refparam":"false",
				"description":"Volume 0-100."
			}],
			"examples":[{
				"script":"b2kSoundVolume 70"
			}],
			"description":"It sets the playLoudness, which affects every stack's audio, so let the user choose it.",
			"references":{
				"handler":["b2kSoundMute"]
			},
			"tags":["physics","games"]
		},{
			"id":"box2dxt-kit-316",
			"name":"b2kdispatchcontacts",
			"display name":"b2kDispatchContacts",
			"library":"box2dxt-kit",
			"type":"command",
			"syntax":[
				"b2kDispatchContacts"
			],
			"display syntax":[
				"b2kDispatchContacts"
			],
			"associations":["box2dxt-kit"],
			"summary":"Send this frame's contact messages.",
			"examples":[{
				"script":"b2kDispatchContacts"
			}],
			"description":"Internal handler: sends b2kContact and b2kEndContact to the contact target, in step order. No target, no messages.",
			"references":{
				"handler":["b2kContactTarget","b2kDispatchSensors"]
			},
			"tags":["physics","games"]
		}