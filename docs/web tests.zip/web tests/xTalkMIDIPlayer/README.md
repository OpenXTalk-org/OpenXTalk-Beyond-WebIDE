# xTalk MIDI Widget

A single-file HTML5 widget (`dist/xtalk-midi-widget.html`) built from the CBB_MIDI_Player
engine: **FluidSynth (WASM) via `js-synthesizer`**. Everything (JS, WASM, optionally a default
SF2) is inlined, so it works from an iframe / browser widget / blob URL with no extra fetches.

## Build

```
npm install                 # pulls js-synthesizer (this is where the WASM lives; it is NOT in the repo zip)
npm run build               # -> dist/xtalk-midi-widget.html  (no soundfont; script must supply one)
npm run build:sf2           # same, with the repo's Microsoft_GS_Wavetable_Synth.sf2 baked in (~4.3 MB)
node build.mjs --sf2 my.sf2 # bake in any soundfont
```

## Passing binary data from xTalk

xTalk variables hold binary fine, but crossing into JavaScript is safest as **base64 text**:

```
put URL ("binfile:" & tPath) into tMidi        -- or any variable holding MIDI bytes
put base64Encode(tMidi) into tB64
```

Then hand `tB64` to the widget. If your bridge can pass an `ArrayBuffer`/typed array, use that
instead (`args.bytes`) and skip the encoding cost.

### Properties (`set` / `get`)

| name | type | notes |
|---|---|---|
| `midiData` | base64 string (set), base64 (get) | setting loads the MIDI; getting returns the last loaded file |
| `soundfontData` | base64 | same, for an .sf2/.sf3 |
| `volume` | 0..1 | |
| `tempo` | multiplier | 1 = normal, 0.5 = half speed |
| `loop` | bool | |
| `autoplay` | bool | start as soon as `midiData` is set |
| `position` | seconds | settable |
| `positionTicks` | ticks | settable |
| `duration`, `totalTicks`, `playing`, `ready`, `midiName`, `soundfontName` | read-only | |
| `ui` | bool | show/hide built-in controls (or `?ui=0` in the URL) |

Seconds are computed from the current tempo and the file's PPQ, so with tempo changes mid-song
they are approximate; ticks are exact.

### Commands (postMessage)

Host → widget: `{ target:'xtalk-midi', id, cmd, args }`

`loadMidi {base64|bytes, name}` · `loadSoundfont {base64|bytes, name}` · `loadMidiUrl {url}` ·
`loadSoundfontUrl {url}` · `play` · `pause` · `stop` · `seek {seconds}` · `seekTicks {ticks}` ·
`setVolume {value}` · `set {name,value}` · `get {name}` · `getState`

Widget → host: `{ source:'xtalk-midi', event:'result', id, ok, value|error }` for each command, plus
async events: `ready`, `midiLoaded {name,bytes,ticks,ppq,duration}`, `soundfontLoaded`, `playing`,
`paused`, `stopped`, `ended`, `looped`, `position {position,ticks,duration}` (≈10/s while playing),
`error {where,message}`.

### Direct JS API (same page, or `iframe.contentWindow`)

`window.XTalkMidi.loadMidi(b64)`, `.play()`, `.pause()`, `.stop()`, `.set('tempo', 1.5)`,
`.get('position')`, … and a hook: `XTalkMidi.onEvent = (name, data) => {...}`.

## xTalk side (sketch — adapt to however OpenXTalk's WASM engine exposes widgets / JS calls)

```
on playMidiFile pPath
   put URL ("binfile:" & pPath) into tMidi
   -- Option A: widget property wrapper
   set the midiData of widget "MidiPlayer" to base64Encode(tMidi)
   -- Option B: message to the iframe
   --   postMessage {target:"xtalk-midi", cmd:"loadMidi", args:{base64:<b64>}}
   set the autoplay of widget "MidiPlayer" to true
end playMidiFile

on midiEnded            -- map the widget's "ended" event to a script message
   -- next track...
end midiEnded
```

The `set the midiData of widget …` property needs a thin binding in the engine's widget layer that
calls `XTalkMidi.set('midiData', value)`. That binding depends on OpenXTalk's WASM bridge, which I
haven't seen, so it's the one piece to wire up on your side. Everything inside the widget is ready.

## Notes

* **Autoplay policy:** browsers keep the AudioContext suspended until a user gesture. The widget
  resumes on any click inside it and shows a "Click to enable audio" overlay if play is requested
  while suspended. When embedding in an iframe, add `allow="autoplay"`.
* **No SharedArrayBuffer** needed, so no COOP/COEP headers are required.
* Lock the message channel with `?origin=https://your-host`; by default only the embedding parent
  window is accepted as a command source.
* Licensing: the CBB player is Unlicense; `js-synthesizer` and FluidSynth are LGPL, so keep their
  notices when redistributing the built file.
* Not yet run against the real WASM build (it was not available offline in my environment): the
  script passes a syntax check and the build script was tested against a stub package, so please run
  `npm run build` and try `demo.MID` first.
