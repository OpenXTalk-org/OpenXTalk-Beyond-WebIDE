{
			"id":"com.livecode.widget.calendar-1",
			"name":"com.livecode.widget.calendar",
			"display name":"Calendar",
			"library":"com.livecode.widget.calendar",
			"type":"widget",
			"display syntax":[
				"Calendar"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"A calendar control. The calendar displays the dates of a month with the selected date highlighted. The user can move to the previous or next month and click on a date to select it. When a date is selected the <dateChanged> message is sent.",
			"description":"A calendar control. The calendar displays the dates of a month with the selected date highlighted. The user can move to the previous or next month and click on a date to select it. When a date is selected the <dateChanged> message is sent."
		},{
			"id":"com.livecode.widget.calendar-2",
			"name":"datechanged",
			"display name":"dateChanged",
			"library":"com.livecode.widget.calendar",
			"type":"message",
			"syntax":[
				"dateChanged <pDate>"
			],
			"display syntax":[
				"dateChanged <i>pDate</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"Sent when a date is selected.",
			"parameters":[{
				"name":"pDate",
				"type":"",
				"refparam":"false",
				"description":"The selected date in the form YYYY-MM-DD."
			}],
			"description":"The <dateChanged> message is sent when a date in the calendar is clicked. The <pDate> parameter gives the selected date in the form YYYY-MM-DD."
		},{
			"id":"com.livecode.widget.calendar-3",
			"name":"daynames",
			"display name":"dayNames",
			"library":"com.livecode.widget.calendar",
			"type":"property",
			"syntax":[
				"get the dayNames of <widget>",
				"set the dayNames of <widget> to <pDayNames>"
			],
			"display syntax":[
				"get the dayNames of <i>widget</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"Sets the day names to be displayed as headers in the Calendar.",
			"value":[{
				"name":"value",
				"type":"",
				"description":"A comma-delimited list of day names."
			}],
			"description":"Sets the day names to be displayed as headers in the Calendar."
		},{
			"id":"com.livecode.widget.calendar-4",
			"name":"monthnames",
			"display name":"monthNames",
			"library":"com.livecode.widget.calendar",
			"type":"property",
			"syntax":[
				"get the monthNames of <widget>",
				"set the monthNames of <widget> to <pMonthNames>"
			],
			"display syntax":[
				"get the monthNames of <i>widget</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"Sets the month names to be used when displaying the selected month in the Calendar header.",
			"value":[{
				"name":"value",
				"type":"",
				"description":"A comma-delimited list of month names."
			}],
			"description":"Sets the month names to be used when displaying the selected month in the Calendar header."
		},{
			"id":"com.livecode.widget.calendar-5",
			"name":"selecteddate",
			"display name":"selectedDate",
			"library":"com.livecode.widget.calendar",
			"type":"property",
			"syntax":[
				"get the selectedDate of <widget>",
				"set the selectedDate of <widget> to <pDate>"
			],
			"display syntax":[
				"get the selectedDate of <i>widget</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"Sets the selected date of the calendar. Shows the correct month and highlights the selected date.",
			"value":[{
				"name":"value",
				"type":"",
				"description":"A string in the form \"YYYY-MM-DD\""
			}],
			"description":"Sets the selected date of the calendar. Shows the correct month and highlights the selected date."
		},{
			"id":"com.livecode.widget.calendar-6",
			"name":"headercolor",
			"display name":"headerColor",
			"library":"com.livecode.widget.calendar",
			"type":"property",
			"syntax":[
				"get the headerBackround of <widget>",
				"set the headerBackround of <widget> to <pColor>"
			],
			"display syntax":[
				"get the headerBackround of <i>widget</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"The background color of the Calendar header.",
			"value":[{
				"name":"value",
				"type":"",
				"description":"A RGB color."
			}],
			"description":"The <headerBackround> is used to set the background color of the Calendar header bar."
		},{
			"id":"com.livecode.widget.calendar-7",
			"name":"hilitestyle",
			"display name":"hiliteStyle",
			"library":"com.livecode.widget.calendar",
			"type":"property",
			"syntax":[
				"get the hiliteStyle of <widget>",
				"set the hiliteStyle of <widget> to [ Text | Background ]"
			],
			"display syntax":[
				"get the hiliteStyle of <i>widget</i>"
			],
			"associations":["com.livecode.widget.calendar"],
			"summary":"The style with which selected dates are highlighted.",
			"value":[{
				"name":"value",
				"type":"",
				"description":"The hilite style\n- \"Text\": the text color of the selected date is changed.\n- \"Background\": the background color of the selected date is changed."
			}],
			"description":"The <hiliteStyle> is used to set the jighlight style of the selected date.\n"
		}